#!/bin/bash

#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

# This script might improve your bandwidth utilization.
# It tweaks buffer memory usage.
# It doesn't harm your NIC directly in any way.
# I got this from a friend who got it from a friend...
# It has been tested on four computers, all connected to
# 100mbit connections. The utilization reached close to 100%.
#
# The script will make a backup of your original settings,
# called speed_backup.sh. Run it to restore original values.
#
# Use it at your own risk.
#
# /Zio

#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#

# Create backup.
if [ ! -e ./speed_backup.sh ] ; then
echo -n "Creating backup (`pwd`/speed_backup.sh)...  "
echo "#!/bin/bash" > ./speed_backup.sh
echo "" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/ipv4/tcp_sack`\" > /proc/sys/net/ipv4/tcp_sack" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/ipv4/tcp_timestamps`\" > /proc/sys/net/ipv4/tcp_timestamps" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/ipv4/tcp_mem`\" > /proc/sys/net/ipv4/tcp_mem" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/ipv4/tcp_rmem`\" > /proc/sys/net/ipv4/tcp_rmem" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/ipv4/tcp_wmem`\" > /proc/sys/net/ipv4/tcp_wmem" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/core/optmem_max`\" > /proc/sys/net/core/optmem_max" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/core/rmem_default`\" > /proc/sys/net/core/rmem_default" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/core/rmem_max`\" > /proc/sys/net/core/rmem_max" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/core/wmem_default`\" > /proc/sys/net/core/wmem_default" >> ./speed_backup.sh
echo "echo \"`cat /proc/sys/net/core/wmem_max`\" > /proc/sys/net/core/wmem_max" >> ./speed_backup.sh
chmod 744 ./speed_backup.sh
echo -e "\tdone!"
else
echo "Backup found (`pwd`/speed_backup.sh). Skipping creation of one."
fi

# Boost buffer settings
echo -n "Boosting...  "
echo "0" > /proc/sys/net/ipv4/tcp_sack
echo "0" > /proc/sys/net/ipv4/tcp_timestamps
echo "3129344 3137536 3145728" > /proc/sys/net/ipv4/tcp_mem
echo "65536 1398080 2796160" > /proc/sys/net/ipv4/tcp_rmem
echo "65536 1398080 2796160" > /proc/sys/net/ipv4/tcp_wmem
echo "163840" > /proc/sys/net/core/optmem_max
echo "1048560" > /proc/sys/net/core/rmem_default
echo "2097136" > /proc/sys/net/core/rmem_max
echo "1048560" > /proc/sys/net/core/wmem_default
echo "2097136" > /proc/sys/net/core/wmem_max
echo -e "\tdone!"
