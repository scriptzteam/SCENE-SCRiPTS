/* 

++  Right Place Glftpd                          ++
** [iNFOS]                                      **
++                                              ++
++ [HiSTORY]                                    ++
++ - 04/01/2004 : First coding/testing.         ++
++ - 05/01/2004 : Version 0.2 completed/tested. ++

Util typ: Glftpd Move File.
Release Date: 2004-01-06
Disks: 01
Requirements: unix/gcc and glftpd

Title:
Right Place (rpgl)

Info:

I started to code the util due to problems on a standard ftp site.
People has to upload file in a dir, then an operator had to find the
files moved in right dirs (imagine a printing house).

So edit your 'dir_l' file located in /etc, with this syntax:

prefix:/site/place/to/move

es:

with this rule 'vcdx:/site/vcd/x/'
a file named vcdx-test55.avi (located in /site/incoming/) will be moved
to: /site/vcd/x .

If you use it as root (it's default, but you can set another user),
you can run it from bash or crontab, and it will place the PRED value
without problems.

The program, before move a file, checks that last change is lower than
one hour (from current time check), if not it will ignore the move.
I wrote this check so we are sure to move a complete file.

*/

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <time.h>

/* ^^^ Change the values as you want ^^^ */

#define PRED "/opt/glftpd"
#define BASE "/site/incoming"
#define FILED "/etc/dir_l"
/* Set here the user who runs the script from crontab */
#define	CRONUSR	"root"

/* User's UID and GID (where files are moved) */
#define	UIDC	103
#define	GIDC	100

/* -------------------------------- REAL CODE -------------------------------- */
#define VERSION "Right Place 0.2"
#define	MAXDIR	500
#define	MAXLEN	1024
#define MODE	0755

FILE	*cfg;
int	i,i2;
char	buf[255], buf2[255], wbuf[255], dest[255], realu[255];

void	getword(char *word, char *line, char stop);
void	clearme(char *some);
void	zcopy(char *inputName, char *outputName);

struct DIRZ {
	char	pre[255];
	char	path[255];
};

struct DIRZ grp[MAXDIR];
struct	stat	st;

DIR *dirptr;
struct dirent *entry;
struct stat filestats;
struct timeval new;
mode_t filemode;
long  dir_bytes;
char *name , tmpf[255], mdir[255], filepath[2048], dirpath[2048];

/* Here we start the real code */
main (argc, argv)
	int	argc;
	char	*argv[];
{
	int glsh=0;
	gettimeofday(& new, NULL);
	sprintf(realu, (char *) getenv("USER"));
	if(strcmp(realu,CRONUSR)==0) {
		glsh=1;
	} else {
		glsh=0;
	}
	/* printf("%d", new.tv_sec); */
	printf("%s starting up...\n", VERSION);
	if(glsh==1) { 
		sprintf(tmpf, "%s%s", PRED, FILED); 
	} else {
		sprintf(tmpf, "%s", FILED);
	}
	if ((cfg = fopen(tmpf, "r")) == NULL) {
		printf("Unable to read prefix dirs.\n");
		exit(1);
	} else {
		while (fgets(buf, MAXLEN, cfg) != NULL) {
			getword(wbuf,buf,':');
			clearme(buf);
			if(glsh==1) {
				sprintf(mdir, "%s%s", PRED, buf);
			} else {
				sprintf(mdir, buf);
			}
			dirptr = opendir(mdir);
			if ( dirptr != NULL ) {
				sprintf(grp[i].pre,wbuf);
				if(glsh==1) {
					sprintf(grp[i].path,"%s%s", PRED, buf);
				} else {
					sprintf(grp[i].path,buf);
				}
				i++;
			} else {
				printf("Unable to find %s, ignoring this rule.\n", mdir);
			}
		}
	}

	if(i==0) {
		printf("Sorry No rules collected.\n");
		exit(1);
	}

	if(glsh==1) {
		sprintf(tmpf, "%s%s", PRED, BASE);
	} else {
		sprintf(tmpf, BASE);
	}

	dirptr = opendir(tmpf);
	if ( dirptr == NULL ) {
		perror(BASE);
		exit(1);
	}

	printf("Checking Files to move.\n");
	entry = readdir(dirptr);
	for ( ; entry != NULL ; entry = readdir(dirptr) ) {
		name = entry->d_name;
		if ( strcmp(name,".")==0 || strcmp(name,"..")==0 ) {
			continue;
		}
		if(glsh==1) {
			sprintf(filepath,"%s%s/%s",PRED,BASE,name);
		} else {
                	sprintf(filepath,"%s/%s",BASE,name);
		}
                if ( lstat(filepath,&filestats) < 0 ) {
                        perror(filepath);
                        closedir(dirptr);
                        exit(1);
                }
 
		filemode = filestats.st_mode & S_IFMT;
		if ( filemode == S_IFDIR ) {
			printf("DIR %s skipping.\n", name);
		} else if ( filemode == S_IFREG ) {
			strcpy(buf2, name);
			getword(buf, name, '-');
			for(i2=0;i2<i;i2++) {
				if(strcmp(buf,grp[i2].pre)==0) {
					if(glsh==1) {
						sprintf(buf, "%s%s/%s", PRED, BASE, buf2);
					} else {
						sprintf(buf, "%s/%s", BASE, buf2);
					}
					sprintf(dest, "%s/%s", grp[i2].path, buf2);
					if((filestats.st_mtime+3600)<new.tv_sec) {
						printf("Moving: %s to: %s\n", buf, dest);
						/* printf("Moving: %s (%d) to: %s (%d)\n", buf, filestats.st_mtime, dest, new.tv_sec); */
						zcopy(buf, dest);
						chown(dest, UIDC, GIDC);
						unlink(buf);
					}
				}
			}
		} else {
			printf("Can't Process: %s\n", name);
		}
	}
	closedir(dirptr);
	
}

void clearme(char *some) {
	int	i3;
	for (i3=0;i3<strlen(some);i3++) if (some[i3] == '\n') some[i3] = 0;
	for (i3=0;i3<strlen(some);i3++) if (some[i3] == '\r') some[i3] = 0;
}

/* GetWord */
void getword(char *word, char *line, char stop) {
	int		x = 0,
			y;

	for (x = 0; ((line[x]) && (line[x] != stop)); x++)
	word[x] = line[x];

	word[x] = '\0';
	if (line[x])
		++x;
	y = 0;

	while ((line[y++] = line[x++]));
}

/* ZCOPY */
void zcopy(char *inputName, char *outputName) {
	int	input,output,n;
	char	b[512];

	input = open(inputName,O_RDONLY);
		if (input<0) {perror(inputName); exit(1);}
	output = open(outputName,O_WRONLY|O_CREAT,MODE);
		if (output<0) {perror(outputName); exit(1);}
	while ((n=read(input,b,sizeof b))>0)
		write(output,b,n);
	close(input); close(output);
}
