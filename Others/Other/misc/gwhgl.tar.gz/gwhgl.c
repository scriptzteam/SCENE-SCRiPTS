/*
  TiTLE.......: Graphic Works Hard 0.14
  TYPE........: Monitor AddOn
  DiSKS.......: 0/1
  PACK........: tar.gz
  DATE........: 11/11/03
  Requirements: unix/gcc and glftpd

Info:

What is it ? Some time ago a customer call me, he wants know
what a grapher modified in his ftp account.
From this the idea to write this little program.
Every user in his ftp can type: site gwhgl
He will get a daily report with created and changed files.
Also the report will be appened the the dupelog user file.

If you use it as root, yu can collect all the files uploaded
in one day.

The prog has also a dupe crc check. Take a look below:

ftp> site gwhgl dupe /site/birdy/tyty.txt
200- DUPE_CRC: 46227D52 Thu Nov 10 2003 20:17:33 NEW /site/birdy/tyty.txt
200- DUPE_CRC: 46227D52 Thu Nov 13 2003 16:10:32 NEW /site/birdy/tyty.txt
200 Command Successful.

  [HiSTORY]
  - 14/09/03: wrote routines to extract file/timestamps.
  - 17/09/03: some dirty code, but the script starts to work.
  - 18/09/03: dupes as now collected, routine gfile changed in gdata to get user name.
              (fixed /etc/glftpd.conf to enable group overwrite).
  - 21/09/03: Fixed the gtime routine. Many tests done.
  - 24/09/03: Added function to get time file modification.
  - 05/09/03: Pasted the crc_32 code (from: jehsom@jehsom.com)
              Started to write the dupefile stuff.
	      Doing many tests! Thx to Icy for his example log.
	      Added the Dupe_crc control function.
  - 29/10/03: Some fixes, other tests.
  - 12/11/03: Other fixes.
	      User Homedir from Glftpd Env.
*/

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>

//#define BASE	"/opt/glftpd/"
#define BASE "/"
#define	LOG	"ftp-data/logs"
#define	MAXLEN	1024
#define	MAXFILES	1000

time_t rawtime;
struct tm * timeinfo;
struct	stat st;

char	localt[255];
char	userd[255], dir[255], logx[255], buf[255], tmpcrc[50];
char	timex[255], datex[255], timef[255], datef[255], user[255], file[255], ffile[255];
char	realu[255], crcd[255], homed[255];
int	iz=0, i=0, fds=0, i3=0, func=0, t;
FILE	*cfg;
unsigned long	crc;

struct COL {
	char	name[255];
	char	time[255];
	int	access;
	char	act[50];
	char	crc[55];
};

struct	COL mods[MAXFILES];

void    gtime(char *times, char *hours, char *line);
void	gdata(char *filen, char *line2, int zs);
void	getword(char *word, char *line, char stop);
int	calc_crc32( const char *fname, unsigned long *crc );
void	collect(char *file);
void	dupestore();
void	dupecrc(char *filed, char *user);

/* CRC lookup table */
static unsigned long crcs[256]={ 0x00000000,0x77073096,0xEE0E612C,0x990951BA,
0x076DC419,0x706AF48F,0xE963A535,0x9E6495A3,0x0EDB8832,0x79DCB8A4,0xE0D5E91E,
0x97D2D988,0x09B64C2B,0x7EB17CBD,0xE7B82D07,0x90BF1D91,0x1DB71064,0x6AB020F2,
0xF3B97148,0x84BE41DE,0x1ADAD47D,0x6DDDE4EB,0xF4D4B551,0x83D385C7,0x136C9856,
0x646BA8C0,0xFD62F97A,0x8A65C9EC,0x14015C4F,0x63066CD9,0xFA0F3D63,0x8D080DF5,
0x3B6E20C8,0x4C69105E,0xD56041E4,0xA2677172,0x3C03E4D1,0x4B04D447,0xD20D85FD,
0xA50AB56B,0x35B5A8FA,0x42B2986C,0xDBBBC9D6,0xACBCF940,0x32D86CE3,0x45DF5C75,
0xDCD60DCF,0xABD13D59,0x26D930AC,0x51DE003A,0xC8D75180,0xBFD06116,0x21B4F4B5,
0x56B3C423,0xCFBA9599,0xB8BDA50F,0x2802B89E,0x5F058808,0xC60CD9B2,0xB10BE924,
0x2F6F7C87,0x58684C11,0xC1611DAB,0xB6662D3D,0x76DC4190,0x01DB7106,0x98D220BC,
0xEFD5102A,0x71B18589,0x06B6B51F,0x9FBFE4A5,0xE8B8D433,0x7807C9A2,0x0F00F934,
0x9609A88E,0xE10E9818,0x7F6A0DBB,0x086D3D2D,0x91646C97,0xE6635C01,0x6B6B51F4,
0x1C6C6162,0x856530D8,0xF262004E,0x6C0695ED,0x1B01A57B,0x8208F4C1,0xF50FC457,
0x65B0D9C6,0x12B7E950,0x8BBEB8EA,0xFCB9887C,0x62DD1DDF,0x15DA2D49,0x8CD37CF3,
0xFBD44C65,0x4DB26158,0x3AB551CE,0xA3BC0074,0xD4BB30E2,0x4ADFA541,0x3DD895D7,
0xA4D1C46D,0xD3D6F4FB,0x4369E96A,0x346ED9FC,0xAD678846,0xDA60B8D0,0x44042D73,
0x33031DE5,0xAA0A4C5F,0xDD0D7CC9,0x5005713C,0x270241AA,0xBE0B1010,0xC90C2086,
0x5768B525,0x206F85B3,0xB966D409,0xCE61E49F,0x5EDEF90E,0x29D9C998,0xB0D09822,
0xC7D7A8B4,0x59B33D17,0x2EB40D81,0xB7BD5C3B,0xC0BA6CAD,0xEDB88320,0x9ABFB3B6,
0x03B6E20C,0x74B1D29A,0xEAD54739,0x9DD277AF,0x04DB2615,0x73DC1683,0xE3630B12,
0x94643B84,0x0D6D6A3E,0x7A6A5AA8,0xE40ECF0B,0x9309FF9D,0x0A00AE27,0x7D079EB1,
0xF00F9344,0x8708A3D2,0x1E01F268,0x6906C2FE,0xF762575D,0x806567CB,0x196C3671,
0x6E6B06E7,0xFED41B76,0x89D32BE0,0x10DA7A5A,0x67DD4ACC,0xF9B9DF6F,0x8EBEEFF9,
0x17B7BE43,0x60B08ED5,0xD6D6A3E8,0xA1D1937E,0x38D8C2C4,0x4FDFF252,0xD1BB67F1,
0xA6BC5767,0x3FB506DD,0x48B2364B,0xD80D2BDA,0xAF0A1B4C,0x36034AF6,0x41047A60,
0xDF60EFC3,0xA867DF55,0x316E8EEF,0x4669BE79,0xCB61B38C,0xBC66831A,0x256FD2A0,
0x5268E236,0xCC0C7795,0xBB0B4703,0x220216B9,0x5505262F,0xC5BA3BBE,0xB2BD0B28,
0x2BB45A92,0x5CB36A04,0xC2D7FFA7,0xB5D0CF31,0x2CD99E8B,0x5BDEAE1D,0x9B64C2B0,
0xEC63F226,0x756AA39C,0x026D930A,0x9C0906A9,0xEB0E363F,0x72076785,0x05005713,
0x95BF4A82,0xE2B87A14,0x7BB12BAE,0x0CB61B38,0x92D28E9B,0xE5D5BE0D,0x7CDCEFB7,
0x0BDBDF21,0x86D3D2D4,0xF1D4E242,0x68DDB3F8,0x1FDA836E,0x81BE16CD,0xF6B9265B,
0x6FB077E1,0x18B74777,0x88085AE6,0xFF0F6A70,0x66063BCA,0x11010B5C,0x8F659EFF,
0xF862AE69,0x616BFFD3,0x166CCF45,0xA00AE278,0xD70DD2EE,0x4E048354,0x3903B3C2,
0xA7672661,0xD06016F7,0x4969474D,0x3E6E77DB,0xAED16A4A,0xD9D65ADC,0x40DF0B66,
0x37D83BF0,0xA9BCAE53,0xDEBB9EC5,0x47B2CF7F,0x30B5FFE9,0xBDBDF21C,0xCABAC28A,
0x53B39330,0x24B4A3A6,0xBAD03605,0xCDD70693,0x54DE5729,0x23D967BF,0xB3667A2E,
0xC4614AB8,0x5D681B02,0x2A6F2B94,0xB40BBE37,0xC30C8EA1,0x5A05DF1B,0x2D02EF8D};

/* Here we start the real code */
main (argc, argv)
	int	argc;
	char	*argv[];
{
	sprintf(homed, (char *) getenv("HOME"));
	sprintf(realu, (char *) getenv("USER"));
	sprintf(logx,"%s%s/xferlog",BASE,LOG);

	if (argc==0) {
		func=0;
        } else if (argc>1 && strcmp(argv[1],"dupe")==0) {
		if(argc<3) {
			printf("Please use this syntax:\n\tgwhgl dupe filename\n");
			exit(0);
		} else {
			dupecrc(argv[2], realu);
			exit(0);
		}
	} else if (argc>1 && strcmp(argv[1],"")!=0) {
		func=1;
	}

	time(&rawtime);
	timeinfo=localtime(&rawtime);
	sprintf(localt, (char *) asctime(timeinfo));
	for (i3=0;i3<strlen(localt);i3++) if (localt[i3] == '\n') localt[i3] = 0;
	/* printf("Local Time: %s\n", localt); */
	gtime(datex, timex, localt);
	/* printf("Data Corrente:%s - Time:%s\n", datex, timex); */
	if ((cfg=fopen(logx, "r"))!=NULL) {
		printf("Scanning %s at %s for %s\n",logx,localt, realu);
		while (fgets(buf, MAXLEN, cfg) != NULL) {
			gtime(datef, timef, buf);
			gdata(file, buf, 10); // Get file 
			gdata(user, buf, 15); // Get user 
			//printf("%s - File:%s - Date:%s - Time:%s\n",user,file,datef,timef);
			if (strcmp(datex,datef)==0) {
				if(func==0) {
					if(strcmp("root",realu)==0) {
						sprintf(buf,"%s%s", BASE, file);
						collect(buf);
					} else if (strcmp(user,realu)==0) {
						sprintf(buf,"%s", file);
						collect(buf);
					}
				} else if (func==1) {
					strcpy(ffile,file);
					for (i=0;i<3;i++) getword(buf,file,'/');
					/* printf("Ffile:%s - File:%s - Argv:%s - RealU:%s - User:%s - date:%s - RealDate:%s.\n", ffile,file,argv[1], realu, user, datef, datex); */
					if(strcmp(file,argv[1])==0 && strcmp(user,realu)==0 && strcmp(datex,datef)==0) {
						calc_crc32(ffile,&crc);
						printf("%s - %s\n", timef, ffile);
					}
				}
			}
		}
		fclose(cfg);
		if(func==0) {
			printf("[CRC---] [Date....................] [File...]\n");
			for(i=0;i<iz;i++) {
				printf("%s %s %d %s\n", mods[i].crc, mods[i].time, mods[i].access, mods[i].name);
			}
			dupestore();
		}
	} else {
		printf("I can't open xferlog file. Exiting.\n");
		exit(1);
	}
	exit(0);
}

void gtime(char *times, char *hours, char *line) {
	int	x=1, t=0, zs=6, h=0, x1=4, t1=0, y=0;
	for(t=0;x<zs;t++) {
		if(line[t]==' ') {
			x++;
			/* printf("x:%d - t:%d.\n",x,t); */
			if(line[t+1]==' ') {
				zs++; x1++;
				/* printf("Double Space, zs:%d - x:%d.\n",zs,x); */
			}
		}
		if(x==x1) {
			if(line[t]!=' ') {
				hours[h]=line[t];
				h++;
			}
			if(line[t+1]==' ') {
				/* printf("Doing Year. x:%d, zs:%d, t:%d\n",x,zs,t); */
				x1=0;
			}
		} else {
			times[t1]=line[t];
			t1++;
			if(t==strlen(line)) x++;
		}
	}
	hours[h]='\0';
	if(times[t1-1]==' ') { times[t1]='\0'; times[t1-1]='\0'; }
}

void gdata(char *filen, char *line2, int zs) {
	/* 10 for the host, 15 for the user. */
	int	x=1,t=0,y=0;
	for(t=0; x<zs; t++) {
		if(line2[t]==' ') {
			x++;
			if(line2[t+1]==' ') zs++;
		} else if ((line2[t]) && x==(zs-1)) {
			filen[y]=line2[t];
			y++;
		}

	}
	filen[y]='\0';
}

/* Collect Data */
void collect(char *filed) {
	char	buf2[255];
	/* printf("Gotcha: %s\n", filed); */
	fds=0;
	calc_crc32(filed,&crc);
	sprintf(buf2,"%08lX",crc);
	for(i=0;i<iz;i++) {
		/* printf("Searching: %s - %s\n", filed, mods[i].name); */
		if(strcmp(filed,mods[i].name)==0 && stat(filed, &st)!=-1) {
			/* printf("Searching: %s - %s\n",buf2,mods[i].crc); */
			if(strcmp(buf2,mods[i].crc)!=0) {
				printf("CHG: %s - %s - T: %d - User: %s\n", mods[i].name, timef, mods[i].access, user);
				sprintf(mods[i].crc,"%08lX", crc);
				mods[i].access++;
			}
			// we always keep date updated.
			sprintf(mods[i].time,"%s %s", datef, timef);
			strcpy(mods[i].act,"CHG");
			fds=1;
		}
	}
	if(fds==0) {
		if (stat(filed, &st)!=-1) {
			sprintf(mods[iz].name,filed);
			sprintf(mods[iz].crc,"%08lX", crc);
			strcpy(mods[iz].act,"NEW");
			sprintf(mods[iz].time,"%s %s", datef, timef);
			iz++;
		} else if (stat(filed, &st)==-1) {
			strcpy(mods[iz].name,filed);
			strcpy(mods[iz].crc,"00000000");
			strcpy(mods[iz].act,"DEL");
			sprintf(mods[iz].time,"%s %s", datef, timef);
			iz++;
		}
	}
}

/* GetWord */
void
getword(char *word, char *line, char stop)
{
	int		x = 0,
			y;

	for (x = 0; ((line[x]) && (line[x] != stop)); x++)
	word[x] = line[x];

	word[x] = '\0';
	if (line[x])
		++x;
	y = 0;

	while ((line[y++] = line[x++]));
}

/* Create your dupe file */
void dupestore() {
	char name[255];
	FILE	*out;
	if(strcmp(realu,"root")==0) {
		sprintf(name, "/root/dupelog");
	} else {
		sprintf(name, "%s/dupelog", homed);
	}
	if ((out=fopen(name, "a"))!=NULL) {
		for(i=0;i<iz;i++) {
			fprintf(out,"%s %s %s %s\n", mods[i].crc, mods[i].time, mods[i].act, mods[i].name);
		}
		fclose(out);
	} else {
		printf("I cant create or add the dupe data on:%s.\n", name);
		exit(1);
	}
}

/* Dupe Crc */
void dupecrc(char *filed, char *user) {
	int	r=0;
	calc_crc32(filed,&crc);
	sprintf(tmpcrc,"%08lX", crc);
	if (strcmp(tmpcrc,"00000000")==0) {
		printf("File not Found.\n");
		exit(1);
	}
	if(strcmp(realu,"root")==0) {
		sprintf(logx, "/root/dupelog");
	} else {
		sprintf(logx,"%s/site/%s/dupelog",BASE, user);
	}
	/* printf("Searching with %s name and crc: %s\n", filed, tmpcrc); */
	if ((cfg=fopen(logx, "r"))!=NULL) {
		while (fgets(buf, MAXLEN, cfg) != NULL) {
			getword(crcd,buf,' ');
			/* for (i=0;i<strlen(buf);i++) {
				if (buf[i]==' ') getword(filenamed,buf,' ');
			}
			sprintf(filenamed,buf); */
			if (strcmp(crcd,tmpcrc)==0) {
				printf("DUPE_CRC: %s %s", crcd, buf); r++;
			}
		}
		fclose(cfg);
		if(r==0) printf("No dupes.\n");
	} else {
		printf("I can't open your dupelog.\nCreate one first.\n");
		exit(1);
	}
}

/* Calculates the 32-bit checksum of fname, and stores the result
 * in crc. Returns 0 on success, nonzero on error.
 */
int calc_crc32( const char *fname, unsigned long *crc ) {
    FILE *in;           /* input file */
    unsigned char buf[BUFSIZ]; /* pointer to the input buffer */
    size_t i, j;        /* buffer positions*/
    int k;              /* generic integer */
    unsigned long tmpcrc=0xFFFFFFFF;

    /* open file */
    if((in = fopen(fname, "rb")) == NULL) return -1;

    /* loop through the file and calculate CRC */
    while( (i=fread(buf, 1, BUFSIZ, in)) != 0 ){
        for(j=0; j<i; j++){
            k=(tmpcrc ^ buf[j]) & 0x000000FFL;
            tmpcrc=((tmpcrc >> 8) & 0x00FFFFFFL) ^ crcs[k];
        }
    }
    fclose(in);
    *crc=~tmpcrc; /* postconditioning */
    return 0;
}
