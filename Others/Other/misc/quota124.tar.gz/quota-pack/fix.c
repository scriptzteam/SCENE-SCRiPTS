/*
	FixDir 0.1 (FRSoldier) 
	Simple program to fix the ownership in every /site/dir.
	Change your BASE and GRP as you prefer.
*/

#include <stdio.h>
/* #include <sys/stat.h> */
#include <dirent.h>

#define BASE "/opt/glftpd"
#define	MAXLEN	1024
#define	GRP	100

char    buf[MAXLEN];
char	wbuf[MAXLEN];
char	passwd[255];
char	path[255];
char	user[255];
char	uidz[255];
FILE	*pwd;
DIR 	*dirptr;

void	getword(char *word, char *line, char stop);

main (argc, argv)
	int     argc;
	char    *argv[];
{
	sprintf(passwd,"%s/etc/passwd", BASE);

	if ((pwd = fopen(passwd, "r")) == NULL) {
		printf("GlFtpd Passwd not found.\n");
		exit(1);
	}

	while (fgets(buf, MAXLEN, pwd) != NULL) {
		getword(wbuf,buf,':');
		sprintf(user,"%s", wbuf);
		getword(wbuf,buf,':');
		getword(wbuf,buf,':');
		sprintf(uidz,"%s", wbuf);
		printf("Doing on %s, with uid %s.\n",user,uidz);
		sprintf(path,"%s/site/%s", BASE, user);
		dirptr = opendir(path);
		if ( dirptr != NULL ) {
			chown(path, atoi(uidz), GRP);
		} else {
			printf("I can't locate %s homedir, skipping.\n", user);
		}
		closedir(dirptr);
	}
	fclose(pwd);
}

/* GetWord */
void
getword(char *word, char *line, char stop)
{
        int             x = 0,
                        y;

        for (x = 0; ((line[x]) && (line[x] != stop)); x++)
        word[x] = line[x];

        word[x] = '\0';
        if (line[x])
                ++x;
        y = 0;

        while ((line[y++] = line[x++]));
}

