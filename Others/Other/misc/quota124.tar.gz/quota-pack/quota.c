/*

  ** ----------------------------------------------- **
  **                  Quota 1.2.4                    **
  **            Last Update: 20/03/2004              **
  **                                                 **
  ** -[ Intro ]-                                     **
  ** Bug fixes:                                      **
  ** The user can now type from ftp the command to   **
  ** unlock his account and upload files. esample:   **
  ** site quota                                      **
  **                                                 **
  ** -[ Notes ]-                                     **
  ** The Quotadb file, should be placed in           **
  ** /glftpd/etc/ and make a symbolic lynk to        **
  ** /etc/ so you can use the bin in glftpd and      **
  ** from bash.                                      **
  **                                                 **
  ** From 1.2.4 Ver.                                 **
  ** Quota will change uid user file to enable the   **
  ** user to use 'site quota' and continue to upload **
  ** files.                                          **
  ** Root or glftpd operator will remove .quote file **
  ** in the next check.                              **
  ** The file /etc/quotadb have now to be compiled   **
  ** with KB values. Es:                             **
  ** gunma:1000 ( = 1 MegaByte).                     **
  ** Copy it in /glftpd/etc or /etc (if you run as   **
  ** root).                                          **
  **                                                 **
  ** -[ Extra ]-                                     **
  ** The program come with fix.c a little util that  **
  ** could help you to fix a bad command type in     **
  ** your system.                                    **
  **                                                 **
  ** ----------------------------------------------- **

*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <string.h>

#define EQ(s1,s2) (strcmp(s1,s2)==0)

#define BASE	"/opt/glftpd/" 
#define	QB	"/etc/quotadb"
#define PW	"/etc/passwd"
#define GLUSERS "ftp-data/users/"
#define GID	100

/* Other stuff  Please don't touch. */
#define VERSION "Gl Quota 1.2.4"
#define MAXLEN	1024
#define	MAXUSERS	500
#define	MODEZ	0755

/* Real Program */
struct stat     fbuf;
struct dirent *de;

struct DATI {
	char	names[255];
	int 	bytes;
	int 	rbytes;
};

struct DATI quota[MAXUSERS];

FILE	*cfg, *out;
DIR	*dp;
char	buf[MAXLEN];
char	buf2[MAXLEN];
char	wbuf[255];
char	userd[255];
char	filez[255];
char	qtn[255];
char	qt[255];
char	sys[255];
char	dbq[255], pwf[255];
char	prex[255];
int	i=0,sd=0,func=0, uid;

void	qus(int y);
int 	uidz (char *user);
void	getword(char *word, char *line, char stop);
void    zcopy(char *inputName, char *outputName);
long	dirsize(char *dirname);

/*
  Func=0 Admin.
  Func=1 User.
*/

main (argc, argv)
        int     argc;
        char    *argv[];
{
	int	i2, fg;
	sprintf(userd, getenv("USER"));
	if(strcmp("glftpd",userd)==0) {
		sprintf(dbq, QB);
		sprintf(prex, "/");
	} else if (strcmp("root",userd)==0) {
		sprintf(dbq, "%s%s", BASE, QB);
		sprintf(prex, BASE);
	} else {
		func=1;
		sprintf(prex, "/");
		sprintf(dbq, "%s%s", prex, QB);
	}

	if ((cfg = fopen(dbq, "r")) == NULL) {
		printf("%s not found.\n" ,dbq);
		exit(1);
	}

	if(func==0 && argc==1) {
		func=0; printf("Calculating Quota for all user in database.\n");
	} else if (func==0 && argc>1) {
		func=1;
	}

	while (fgets(buf, MAXLEN, cfg) != NULL) {
		getword(wbuf,buf,':');
		sprintf(quota[i].names,wbuf);
		quota[i].bytes=atol(buf);
		i++;
	}
	fclose(cfg);

	sprintf(pwf,"%s%s", prex, PW);
	if ((cfg = fopen(pwf, "r"))==NULL) {
		printf("%s not found.\n" ,pwf);
		exit(1);
	}
	fclose(cfg);

	if (func==1) {
		printf("Calculating Quota for user: %s\n", userd);
		for(i2=0;i2<i;i2++) {
			if(strcmp(quota[i2].names,userd)==0) {
				qus(i2);
				i2=i; fg=1;
			}
			if(fg==0) { printf("No user quota entry.\n"); }
		}
		exit(0);
	} else if (func==0) {
		for (i2=0;i2<i;i2++) {
			qus(i2);
		}
		exit(0);
	} 
}

void qus (int y) {
	DIR *dirpoint;
	if(quota[y].bytes==0) {
		printf("%s No quota setup, lucky.\n", quota[y].names);
	} else {
		sprintf(userd,"%ssite/%s", prex, quota[y].names);
		if(strcmp(quota[y].names,"\0")==0) {
			printf("Internal Error.\n");
			exit(1);
		}
		dirpoint = opendir(userd);
		if ( dirpoint == NULL ) {
			printf("No DIR to get %s Quota. Skipping it.\n", quota[y].names);

		} else {
			quota[y].rbytes = dirsize(userd)/1024;
			printf("[%ssite/%s] Quota: %d Kb - Current Space: %d Kb.\n", prex, quota[y].names, quota[y].bytes, quota[y].rbytes);
			sprintf(qtn,"%s%s%s", prex, GLUSERS, quota[y].names);
			sprintf(qt,"%s%s%s.quote", prex, GLUSERS, quota[y].names);
			if(quota[y].rbytes>quota[y].bytes) {
				if ((cfg = fopen(qt, "r")) != NULL) {
					printf("User still in overquota.\n");
					fclose(cfg);
					uid = uidz(quota[y].names);
					if(uid!=0) {
						chown(qt, uid, GID);
						chmod(qt, 0644);
						chown(qtn, uid, GID);
						chmod(qtn, 0644);
					}
				} else {
					if (func==0 && (cfg = fopen(qtn, "r")) != NULL) {
						printf("Warning, %s is exceding quota.\n", quota[y].names);
						if ((out = fopen(qt, "w"))==NULL) {
							printf("Cannot Write %s data file.\n", quota[y].names);
							exit(1);
						}
						while (fgets(buf, MAXLEN, cfg) != NULL) {
							if(sd==0) {
								buf2[strlen(buf2)-1]='\0';
								sprintf(buf2,buf);
								getword(wbuf,buf,' ');
								if (strcmp(wbuf,"LOGINS")==0) {
									fprintf(out,"LOGINS 2 0 -1 0\n");
									sd=1;
								} else {
									fprintf(out,buf2);
								}
							} else if (sd==1) {
								fprintf(out,buf);
							}	
						}
						fclose(out);
						fclose(cfg);
						zcopy(qt, qtn);
						uid = uidz(quota[y].names);
						if(uid!=0) {
							chown(qt, uid, GID);
							chown(qtn, uid, GID);
						} else {
							printf("Error! Unable to get user uid.\n");
							exit(1);
						} 
					} else if (func==1) {
						printf("You are OverQuota, in the next System Check your will not anymore able to upload files.\n");
					} else {
						printf("User file not found. Contact your Gadmin.\n");
						exit(1);
					}
				}
			} else if (quota[y].rbytes<quota[y].bytes) {
				if ((cfg = fopen(qt, "r"))!=NULL) {
					printf("User was in OverQuota Let me Correct.\n");
					if ((out=fopen(qtn,"w"))!=NULL) {
						while (fgets(buf, MAXLEN, cfg) != NULL) {
							if(sd==0) {
								sprintf(buf2,buf);
								getword(wbuf,buf,' ');
								if(strcmp(wbuf,"LOGINS")==0) {
									fprintf(out,"LOGINS 2 0 -1 1\n");
									sd=1;
								} else {
									fprintf(out,buf2);
								}
							} else if (sd==1) {
								fprintf(out,buf);
							}
						}
						fflush(out);
						fclose(out);
						fclose(cfg);
						if(func==0 && unlink(qt)==0) {
							printf("%s can now Upload.\n", quota[y].names);
						} else if (func==0 && unlink(qt)!=0) {
							printf("Quota Internal Error.\n");
						}
					} else {
						printf("Unable to open %s! Contact your admin!\n", qtn);
						exit(1);
					}
				} else {
					printf("%s Quota Regular.\n", quota[y].names);
					uid = uidz(quota[y].names);
					if(uid!=0) {
						chown(qt, uid, GID);
						chmod(qt, 0644);
						chown(qtn, uid, GID);
						chmod(qtn, 0644);
					}
				}
			}
		}
	}
}

int uidz (char *user) {
	int uf=0, uidx;
	cfg = fopen(pwf,"r");
	while (fgets(buf, MAXLEN, cfg) != NULL) {
		if(uf==0) {
			getword(wbuf,buf,':'); /* user */	
			if(strcmp(wbuf,user)==0) {
				getword(wbuf,buf,':'); /* pass */
				getword(wbuf,buf,':'); /* UID */
				uidx=atoi(wbuf);
				uf=1;
			}
		}
	}
	if(uf==1) { 
		return(uidx); 
	} else {
		return(0); 
	}
}

/* GetWord */
void
getword(char *word, char *line, char stop)
{
	int		x = 0,
			y;

	for (x = 0; ((line[x]) && (line[x] != stop)); x++)
	word[x] = line[x];

	word[x] = '\0';
	if (line[x])
		++x;
	y = 0;

	while ((line[y++] = line[x++]));
}

void zcopy(char *inputName, char *outputName) {
	int	input,output,n;
	char	b[512];

	input = open(inputName,O_RDONLY);
		if (input<0) {perror(inputName); exit(1);}
	output = open(outputName,O_WRONLY|O_CREAT,MODEZ);
		if (output<0) {perror(outputName); exit(1);}
	while ((n=read(input,b,sizeof b))>0)
		write(output,b,n);
	close(input); close(output);
}

long dirsize(char *dirname)
{
 DIR *dirptr;
 struct dirent *entry;
 struct stat filestats;
 mode_t filemode;
 long  dir_bytes;
 char *name , filepath[2048], dirpath[2048];

	dirptr = opendir(dirname);
	if ( dirptr == NULL ) {
		perror(dirname);
		exit(1);
	}
	entry = readdir(dirptr);
	dir_bytes = 0L;
	for ( ; entry != NULL ; entry = readdir(dirptr) ) {
		name = entry->d_name;
		if ( EQ(name,".") || EQ(name,"..") ) {
			continue;
		} /* IF */
		sprintf(filepath,"%s/%s",dirname,name);
		if ( lstat(filepath,&filestats) < 0 ) {
			perror(filepath);
			closedir(dirptr);
			exit(1);
		} /* IF */
		filemode = filestats.st_mode & S_IFMT;
		if ( filemode == S_IFDIR ) {
			sprintf(dirpath,"%s/%s", dirname,name);
			dir_bytes += dirsize(dirpath);
		} else {
			/* Only process regular files
			(i.e. ignore pipes, etc...) */
			if ( filemode == S_IFREG ) {
				dir_bytes += (long) filestats.st_size;
			} /* IF a regular file */
		} /* ELSE if not a directory */
	} /* FOR loop over directory entries */
	closedir(dirptr);

	return(dir_bytes);
} /* end of dirsize */ 

