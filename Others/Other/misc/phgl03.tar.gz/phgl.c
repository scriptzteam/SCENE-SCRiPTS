/* 

++  Private Hosting Glftpd                      ++
** [iNFOS]                                      **
** I warn you, this is an Internal releases.    **
** I wrote it just for test, and because I got  **
** a request some time ago.                     **
++                                              ++
++ [HiSTORY]                                    ++
++ - 30/08/03 Initial code.                     ++
++ - 04/09/03 Tests Tests and Tests, some fixes ++
++            with files descriptors.           ++
++ - 21/09/03 Found a setting problem when I    ++
++            change user's homedir. Rewroting  ++
++            some user's homedir. Rewroting    ++ 
++            stuff. (Updating to PhGL 0.3)     ++

Util typ: glftpd group management
Release Date: 2003-09-21
Disks: 01
Requirements: unix/gcc and glftpd

Title:
Private Hosting 0.3

News:
The 0.3 release fixes a big bug in setting users homedir, most of code have been
rewrited.
Before load my program with arg 'set' backup your glftpd /etc/passwd.

Info:

First: this is a Internal, test script, don't say nothing, if you wanna test
or do other things, do, but don't blame me (just report bugs).
So, what is it ? Well, this permits to set a Gadmin, and his max private users.
The tool will scan for every unset homedir user, create the homedir under
Gdamin dir, then it can checks if he is over user quota, and remove GADMIN
flag.
For me it's usefull, so I can only set in httpd.conf only the DocumentRoot
and VirtualHost ecc... other stuff is done by Gadmin or my script.

Installation:

1. In /etc/glftpd.conf add a 'J' at the end line of 'deluser' command, example:
   -deluser         1 2 7 J
2. Edit '/etc/grpdb' file, with this sintax:
   namegroup:max_users:admin_name:home_dir
   Note: 'home_dir' have to be: /site/user_name
3. Run the program as root, the args are:
   set     (scan every /glftpd/ftp-data/user/ file, looks if the user is not a Gadmin
           and creates a new dir and sets his homedir)
   show    (show you all groups collected from /etc/grpdb file)
   no_args (check if Gadmin is over-users and locks/restores him)
4. All done!


*/

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>

/* +++ Change the values as you want +++ */
#define BASE "/opt/glftpd"
#define	FTPD "/ftp-data/users/"
#define	PWD "/opt/glftpd/etc/passwd"
#define PWDT	"/opt/glftpd/etc/passwd.tmp"
#define FILEG "/etc/grpdb"

/* -------------------------------- REAL CODE -------------------------------- */
#define VERSION "PhGL 0.3"
#define	MAXGRPS	500
#define	MAXLEN	1024
#define MODE	0755

FILE	*cfg, *usc, *out, *ddt;
int	i,i2,i3,sd;
char	buf[255], buf2[255], bufc[255], wbuf[255], usf[255], uex[255], uext[255], uexx[255];

void	getword(char *word, char *line, char stop);
void	sethome(char *stream, char *newl);
void	zcopy(char *inputName, char *outputName);
void	getdata();
void	clearme(char *some);

struct DATI {
	char	path[255];
	char	admin[255];
	char	name[255];
	int	maxusers;
	int	realu;
};

struct DATI grp[MAXGRPS];
struct	stat	st;

/* Here we start the real code */
main (argc, argv)
	int	argc;
	char	*argv[];
{
	printf("%s starting up...\n", VERSION);
	getdata();
	if (stat(BASE, &st) == -1) { printf("Set correctly your BASE var.\n"); exit(1); }

	if (argc==0) {
		printf("Checking all the groups.\n");
	} else if (argc>1) {
		if(strcmp(argv[1],"set")==0) {
			printf("Set Homedir, Checking Users...\n");
			if ((cfg = fopen(PWD,"r")) == NULL) {
				printf("I can't find Glftpd Password file, sorry...\n");
				exit(1);
			}

			out=fopen(PWDT,"w");
			while (fgets(bufc, MAXLEN, cfg) != NULL) {
				sethome(bufc, buf);
				fprintf(out,buf);
			}
			printf("End Setting Users Homedirs.\n");
			fclose(cfg);
			fclose(out);
			zcopy(PWDT, PWD);
			exit(0);
		} else if(strcmp(argv[1],"show")==0) {
			for(i2=0;i2<i;i2++) {
				printf("%d) Group: %s, Admin: %s, Path: %s, Maxusers: %d.\n", i2, grp[i2].name, grp[i2].admin, grp[i2].path, grp[i2].maxusers);
			}
			printf("End Show Collected data.\n");
			exit(0);
		}
        }

	printf("Checking users and groups.\n");
	if ((cfg = fopen(PWD,"r")) == NULL) {
		printf("I can't find Glftpd Password file, sorry...\n");
		exit(1);
	}

	while (fgets(buf, MAXLEN, cfg) != NULL) {
		getword(wbuf,buf,':');
		sprintf(usf, "%s%s%s", BASE, FTPD, wbuf);
		if ((usc = fopen(usf,"r")) == NULL) {
			printf("Strange, %s misses is data file, skipping.\n", usf);
		} else {
			while (fgets(buf2, MAXLEN, usc) != NULL) {
				getword(wbuf,buf2,' ');
				if(strcmp(wbuf,"GROUP") == 0) {
					clearme(buf2);
					for(i2=0;i2<i;i2++) {
						if(strcmp(grp[i2].name,buf2)==0) {
							grp[i2].realu++;
						}
					}
				}
			}
			fclose(usc);
		}
	}
	fclose(cfg);

	for(i2=0;i2<i;i2++) {
		sprintf(uex, "%s%s/%s", BASE, FTPD, grp[i2].admin);
		sprintf(uexx, "%s.ex", uex);
		sprintf(uext, "%s.tmp", uex);
		if(grp[i2].realu>grp[i2].maxusers && (cfg = fopen(uexx, "r")) == NULL) {
			printf("!WARN! Group %s | Real users: %d - Max Users: %d. I have to change the GroupAdmin flag.\n", grp[i2].name, grp[i2].realu, grp[i2].maxusers);
			/* print user.ex file and remove flags nrb. 2 */
			if ((ddt = fopen(uex, "r"))==NULL) {
				printf("!WARN!, Admin %s misses his data file. Fix it!\n", grp[i2].admin);
				exit(1);
			}
			out = fopen(uext, "w");
			while (fgets(buf, MAXLEN, ddt) != NULL) {
				if(sd==0) {
					sprintf(buf2,buf);
					getword(wbuf,buf,' ');
					if(strcmp(wbuf,"FLAGS")==0) {
						for (i3=0;i3<strlen(buf2);i3++) if (buf2[i3] == '2') buf2[i3] = 'J';
						fprintf(out,buf2);
						sd=1;
					} else {
						fprintf(out,buf2);
					}
				} else if (sd==1) {
					fprintf(out,buf);
				}
			}
			fflush(out);
			fclose(out);
			fclose(ddt);
			sd=0;
			/* admin file to admin.ex */
			zcopy(uex, uexx);
			rename(uext, uex);
		} else if (grp[i2].realu>grp[i2].maxusers && (cfg = fopen(uexx, "r")) != NULL) {
			printf("Gadmin %s already exceding max users...\n", grp[i2].admin);
		} else if (grp[i2].realu<grp[i2].maxusers && (cfg = fopen(uexx, "r")) != NULL) {
			printf("Gadmin %s was OverUsers, now fixing...\n", grp[i2].admin);
			rename(uexx, uex);
		} else if (grp[i2].realu<grp[i2].maxusers && (cfg = fopen(uexx, "r")) == NULL) {
			printf("Gadmin %s is ok.\n", grp[i2].admin);
		}
	}
	printf("End.\n");
}

/* Create the homedir set the uid and gid */
void sethome(char *stream, char *newl) {
	char	athd[255];
	char	user[255], pwdx[255], uidx[255], gidx[255], datex[255], hodx[255], shlx[255];
	int	iz, ib=-1;
	getword(user,stream,':');
	getword(pwdx,stream,':');  /* Password */
	getword(uidx,stream,':');  /* Uid      */
	getword(gidx,stream,':');  /* GiD      */
	getword(datex,stream,':'); /* Date     */
	getword(hodx,stream,':');  /* HOMEDiR  */
	getword(shlx,stream,':');  /* SHELL    */

	sprintf(athd,"%s%s%s", BASE, FTPD, user);
	if ((usc = fopen(athd,"r")) == NULL) {
		printf("Strange, I can't locate %s, fix it!\n", athd);
		exit(1);
	} else {
		while (fgets(buf2, MAXLEN, usc) != NULL) {
			getword(wbuf,buf2,' ');
			if(strcmp(wbuf,"GROUP")==0) {
				clearme(buf2);
				for(iz=0;iz<i;iz++) {
					/* printf("Comparing %s with %s\n",buf2,grp[iz].name); */
					if(strcmp(buf2,grp[iz].name)==0) {
						printf("Ok, user %s is in a private group.\n", user);
						ib=iz; iz=i;
					}
				}
			} else if (strcmp(wbuf,"FLAGS")==0) {
				for (i3=0;i3<strlen(buf2);i3++) {
					if (buf2[i3] == '2') {
						printf("%s is a Gadmin skipping.\n", user);
						ib=-1;
						fseek(usc, 0L, SEEK_END);
					}
				}
			}
		}
		fclose(usc);

		if(ib>-1) {
			sprintf(athd,"%s/%s", grp[ib].path, user);
			if(strcmp(hodx,athd)==0) {
				printf("--> %s Homedir already setted.\n", user);
			} else {
				printf("Setting passwd file for %s\n", user);
				sprintf(athd,"%s%s/%s", BASE,grp[ib].path, user);
				printf("%s dir:%s\n", user, athd);
				if (stat(athd, &st) == -1) {
					printf("Making the new dir...\n");
					mkdir(athd, MODE);
				}
				chown(athd, atoi(uidx), atoi(gidx));
				sprintf(hodx,"%s/%s", grp[ib].path, user);
			}
		}
		sprintf(newl,"%s:%s:%s:%s:%s:%s:%s", user, pwdx, uidx, gidx, datex, hodx, shlx);
	}
}

void getdata() {
	int	i4;
	if ((cfg = fopen(FILEG, "r")) == NULL) {
		printf("File Group not Found, sorry I can't work...\n");
		exit(1);
	}

	while (fgets(buf, MAXLEN, cfg) != NULL) {
		getword(wbuf,buf,':');
		sprintf(grp[i].name,wbuf); /* NAME */
		getword(wbuf,buf,':');
		grp[i].maxusers=atoi(wbuf); /* MAXUSER */
		getword(wbuf,buf,':');
		sprintf(grp[i].admin,wbuf); /* ADMiN */
		clearme(buf);
		if (buf[0] != '/') {
			printf("Please correct %s homedir (es: /site/stuff ).\n", grp[i].admin);
			exit(1);
		}
		sprintf(grp[i].path,buf); /* HOMEDiR PATH */
		i++;
	}
	fclose(cfg);
}

void clearme(char *some) {
	int	i3;
	for (i3=0;i3<strlen(some);i3++) if (some[i3] == '\n') some[i3] = 0;
	for (i3=0;i3<strlen(some);i3++) if (some[i3] == '\r') some[i3] = 0;
}

/* GetWord */
void getword(char *word, char *line, char stop) {
	int		x = 0,
			y;

	for (x = 0; ((line[x]) && (line[x] != stop)); x++)
	word[x] = line[x];

	word[x] = '\0';
	if (line[x])
		++x;
	y = 0;

	while ((line[y++] = line[x++]));
}

/* ZCOPY */
void zcopy(char *inputName, char *outputName) {
	int	input,output,n;
	char	b[512];

	input = open(inputName,O_RDONLY);
		if (input<0) {perror(inputName); exit(1);}
	output = open(outputName,O_WRONLY|O_CREAT,MODE);
		if (output<0) {perror(outputName); exit(1);}
	while ((n=read(input,b,sizeof b))>0)
		write(output,b,n);
	close(input); close(output);
}
