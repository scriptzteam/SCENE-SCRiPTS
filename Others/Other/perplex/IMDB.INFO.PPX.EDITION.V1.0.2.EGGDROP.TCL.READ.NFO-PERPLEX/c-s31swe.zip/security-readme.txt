More information about Secret!'s industrial strength security

We don't believe in security by obscurity. An encryption program that
does not name the algorithm used cannot be trusted.

Encryption Algorithm

Secret! uses the well-known standard IDEA encryption algorithm
(International Data Encryption Algorithm) to encrypt your data. IDEA
is a symmetric 128 bit block cipher which is extensively covered in
the literature (e.g. in Bruce Schneier's excellent book Applied
cryptography) and believed to be unbreakable. No known exploits exist.

LinkeSOFT uses IDEA under license from Swiss ASCOM AG (now
MediaCrypt). The encryption implementation in C has been published by
the patent owner. The current version of Secret! uses an encryption
engine that is identical to the one used in Secret! 2.0, the source
code of which has been send to hundreds of interested users. This
makes the chance of implementation flaws very small.

128 Bit Key Length

Your password may consist of up to 24 characters choosen from the 44
keys of the on-screen keyboard or, if you use Graffiti to enter the
password, up to 93 Graffiti strokes. This lets you exploit the whole
128 bit IDEA key space.

If you choose your password right, brute-force attacks (trying every
character combination) are impossible: There are 2**128 = 3 * 10**38
key possibilities. Even if you were using all the computers in the
Internet (approximately 40 million) and each one were to try one
password per nanosecond (1 billionth of a second), you'd still need 8
* 10**21 seconds or 270 trillion years to find the one and only
correct password to decrypt the data stored in Secret!

Even if you only use an 8 character password choosen from the
on-screen keyboard, there are still more than 14 trillion
possibilities.

Some other security programs brag about using longer key lengths of up
to 1024 bit. For any practical purposes, a key length longer as 128
Bit adds no extra security: Your password length determines your
effective key length. To use a true 1024 bit key, you'd need to enter
a password of (1024/7=) 146 characters which is not very practical on
a handheld. If you use only a 10 character password, your effective
key length is approximately (10*7=) 70 bit and it makes no differences
whether you use a 128 bit encryption algorithm or one with a longer
internal key length.

However, longer keys degrade program performance and increase memory
usage.

Security At Focus

Secret! has a unique close-when-off feature that ensures that all text
is encrypted

- after a predefined time of inactivity,
- when the handheld powers off or you power it off manually,
-  and whenever you switch to the Launcher or another program.

The text is encrypted before the device automatically turns itself
off.

Much care has been taken to ensure no copies of your data are
unprotected in memory at any time. Dynamic memory used at run time is
overwritten with zeros and the entered password is erased as soon as
it is no longer needed. The database that is backed up during HotSync
contains only the encrypted version of the data.

Category Names

Note that for technical reasons, the Secret! category labels are not
encrypted. They are needed in plain text during HotSync to display
information in the case of changed/mismatched records. You should
therefore not store any valuable information in the name of the
category.

