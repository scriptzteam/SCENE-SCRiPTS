#!/bin/sh
#
#
# ids( generate checksum of any files )
# write logfile with changes/removes/new files in different directories
# (c)ode Monday
#
# v1 done at -> Sun Oct 26 13:05:46 GMT 2003
# - in $Include, u can add dir (ex. /etc) or filesnames (ex. /etc/sysconfig/network/ifcfg-eth0)
# - in $Include, when u add dirs with % (ex. /etc/%) then will checked all files recursive in that directory 
# -- wildcard is '%' ( hehe im working as DBA ) 
# v1.1 done at -> Mon Oct 27 07:47:21 MET 2003
# - at function Exclude() to disable any files (ex. .log or somethink)  
#
#
# 

# example config:
Include="/etc/%"
Exclude="log swp cks"
LogDir="/root/log/cksum"
SumLogDir="/root/log"
Date=`date '+%x-%T' | sed 's/\//-/g'`
Today=`date '+%x' |sed 's/\//-/g'`
SumLogFile="$SumLogDir/`basename $0`-$Today.log"
LogFileName=`basename $0`

ExClude()
{
 # in $1 filename
 for ExFile in $Exclude; do
  if [ -z "`echo $1 | grep "$ExFile"`" ];then 
   OverFlow=1 
  else
   OverFlow=0
   break
  fi
 done
 echo $OverFlow
}


GetCheckSum()
{
 for dir in $Include;do
  if [ -z "`echo $dir | grep "%"`" ]; then
   FileName=""
   for file in `ls -la $dir | awk '{print $9}'`;do
    FileName="$dir/$file" 
    if [ -f "$FileName" ]; then
     if [ "`ExClude "$FileName"`" -eq "1" ]; then 
      cksum $FileName >> $LogDir/$LogFileName-$Date
     fi
    fi 
   done
  else
   FileName=""
   dirfix="`echo $dir | sed 's/%//g'`"
   for FileName in `find $dirfix -type f`; do
    if [ "`ExClude "$FileName"`" -eq "1" ]; then 
     cksum $FileName >> $LogDir/$LogFileName-$Date
    fi
  done
  fi
 done
 chmod -R 700 $LogDir
}

BuildOutput()
{
 #in $1 new
 #in $2 remove
 #in $3 changes

 FileCount=`cat $LogDir/$LogFileName-$Date | wc -l`
 if [ "$1" != "" ] || [ "$2" != "" ] || [ "$3" != "" ]; then
  printf "| DATA GENERATED ON: $Date - %10s files checked\n" "$FileCount" >> $SumLogFile
  printf "|--------------------------------------------------------- -- -  -\n" >> $SumLogFile
  for new in $1; do
   printf "| %40s - NEW\n" $new >> $SumLogFile
  done
  for remove in $2; do
   printf "| %40s - REMOVED\n" $remove >> $SumLogFile
  done
  for change in $3; do
   printf "| %40s - CHANGED\n" $change >> $SumLogFile
  done
  printf "|--------------------------------------------------------- -- -  -\n" >> $SumLogFile
 else 
  printf "| NO NEW DATA ON: $Date    - %10s files checked\n" "$FileCount" >> $SumLogFile
 fi
}

MergeLastandThisRun()
{
 # in $1 thisrun
 # in $2 lastrun
 OverFlow=0
 for tdata in $1; do
  for ldata in $2; do
   if [ "$tdata" = "$ldata" ]; then
    OverFlow=1 
    break
   else 
    OverFlow=0
   fi
  done
  if [ "$OverFlow" -eq "0" ]; then
   NEW="$NEW $tdata"
  else 
   CHANGE="$CHANGE $tdata"
  fi 
 done
 OverFlow=0
 for ldata in $2; do 
  for tdata in $1; do 
   if [ "$ldata" = "$tdata" ]; then 
    OverFlow=1
    break
   else
    OverFlow=0
   fi
  done
 if [ "$OverFlow" -eq "0" ]; then 
  REMOVE="$REMOVE $ldata"
 fi
 done
 BuildOutput "$NEW" "$REMOVE" "$CHANGE"
}

DiffLastRunWithThisRun()
{
 if [ "`ls -rtl $LogDir/$LogFileName* | wc -l | sed 's/ //g'`" -ge "2" ];then 
  LastRun=`ls -rtl $LogDir/$LogFileName* |tail -2 |head -1 | awk '{print $9}'`
  ThisRun="$LogDir/$LogFileName-$Date"
  ChangesInThisRun=`diff $LastRun $ThisRun | grep ">" | awk '{print $4}'`
  ChangesInLastRun=`diff $LastRun $ThisRun | grep "<" | awk '{print $4}'`
  MergeLastandThisRun "$ChangesInThisRun" "$ChangesInLastRun" 
 else
  printf "|--[ IDS (c)ode by Monday ]------------------------------- -- -  -\n" >> $SumLogFile
  printf "| DATA GENERATED ON: $Date\n" >> $SumLogFile
  printf "|---- -- -  -\n" >> $SumLogFile
  printf "| FIRST RUN ! \n" >> $SumLogFile
  printf "|--------------------------------------------------------- -- -  -\n" >> $SumLogFile
 fi 
}

main()
{
 GetCheckSum
 DiffLastRunWithThisRun
}

main
