#!/bin/bash
#
# set packdir to your preferred rls pack directory
# and dsstandard to the mainly used disksize
#
# copy all files to a directory, named the same way as the release
# /path/to/release-GROUP
#
# then type: site ppack prefix <disksize>
#
# as the prefix is the <prefix>C.zip
#
# disksize is a number between 1 and 4
# if you leave it out, disksize will be dsstandard
#
# much fun, any problems? mailto:null
#

packdir="/private/perplex/"
dsstandard=1

disksize[1]=" 1.44MB:1040000"
disksize[2]=" 3.00MB:3000000"
disksize[3]=" 5.00MB:5000000"
disksize[4]="15.00MB:15000000"
dsnum=4

########### no changes under the bridge #########
########### unless you know what you do #########

banner()
{
 echo "   ,...................,"
 echo " ::: ppack ::: zoo   ::::mc!ppx"
 echo "   ::::::::::::::::::::"
 echo ""
}

usage()
{
 echo " Usage: site ppack prefix <disksize>"
 echo ""
 echo " prefix is diskprefix: urprefx1.zip"
 echo ""
 echo " standard disksize is: `echo ${disksize[$dsstandard]}|awk -F: '{ print $1 }'`"
 echo " possible disksizes:"
 i=0
 while [ $i -lt $dsnum ] ; do
  i=$[i + 1]
  dshuman=`echo ${disksize[$i]}|awk -F: '{ print $1 }'`
  echo " <$i> $dshuman"
 done
}

main()
{
 path=`pwd`
 date=`date +%m-%Y`
 rel=`echo $path | awk -F/ '{ print $NF }'`
 abc="_abcdefghijklmnopqrstuvwxyz"
 packpre=`echo $path | awk -F/ '{ print substr($0,1,length($0) - length($NF)) }'`
 if [ $packpre != $packdir ] ; then
  echo " $packpre is not a valid packdir!"
  echo " valid dir is: $packdir"
  exit
 fi
 nfo=`ls $path/*.nfo | tail -n1 | awk -F/ '{ print $NF }'`
 diz=`ls $path/*.diz | tail -n1 | awk -F/ '{ print $NF }'`

 echo ""
 echo " $USER tries to pack release $rel"
 echo " date     : $date"
 echo " nfo File : $nfo"
 echo " diz File : $diz"

 topack=`ls -x --ignore=*.[dDnN][iIfF][zZoO]`
 echo ""
 echo " temp raring to $path/packed..."
 mkdir packed

 rar a -v${dsize}b  -vn -inul packed/$prefix $topack
 total=`ls packed | wc -w | tr -d ' '`
 echo " ok .. rared $total disks"
 echo ""

 sed "s/#total/$total/g;s/#disksize/$dhuman/g;s/#date/$date/g" $nfo > packed/$nfo

 echo " zipping $rel .."
 mkdir $path/$rel


 templist=`ls -x $path/packed/*.[rR][aA][rR]`
 filelist="$templist `ls -x --sort=size $path/packed/*.[rR][0-9][0-9]`"

 disk=0
 for file in $filelist
 do
  disk=$[++disk]
  if [ $total -lt 27 ] ; then
   fdisk=${abc:$disk:1}
  else
   if [ $total -lt 100 ] ; then
    if [ $disk -lt 10 ] ; then
     fdisk="0$disk"
    else
     fdisk="$disk"
    fi
   else
    if [ $disk -lt 10 ] ; then
     fdisk="00$disk"
    elsif [ $disk -lt 100 ]
     fdisk="0$disk"
    else
     fdisk="$disk"
    fi
   fi
  fi
  file=`echo $file | awk -F/ '{ print $NF }'`
  echo " packing $file, file $disk of $total..."
  sed "s/#relname/$rel/g;s/#disk/$disk/g;s/#total/$total/g" $diz > packed/$diz
  zip -jq $path/$rel/$prefix$fdisk.zip packed/$file packed/$nfo packed/$diz
 done
 mv packed/$diz $path/$rel/$diz
 mv packed/$nfo $path/$rel/$nfo
 rm -rf packed
 echo ""
 echo "`ls -l $path/$rel`"
 echo ""
 echo "Release $rel packed. may the force be with u.."

}

banner

if [ -z $1 ] ; then
 usage
 exit
fi
prefix=$1
if [ -n "$2" ] ; then
 if [ $2 -le 0 ] ; then
  usage
  exit
 fi
 if [ $2 -gt $dsnum ] ; then
  usage
  exit
 fi
 ds=$2
else
 ds=$dsstandard
fi
dhuman=`echo ${disksize[$ds]}|awk -F: '{ print $1 }'`
dsize=`echo ${disksize[$ds]}|awk -F: '{ print $2 }'`

echo " diskprefix : $prefix"
echo " disksize   : $dhuman"

main

