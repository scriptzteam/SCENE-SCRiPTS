
/*
 *       getbot regex-tester
 *     
 *       If you are not that familiar with regular expressions,
 *       you might use this little tool  to check whether  your
 *       regular expressions  which you might need to configure
 *       work like expected.       See regex-tester-examples.sh
 *
 *       
 *       Compile with: gcc -Wall regex-tester.c -o regex-tester -lpcre
 *       PCRE-library must be installed
 */


#include <stdio.h>
#include <string.h>
#include <pcre.h>

#define OVECCOUNT 30    /* should be a multiple of 3 */


int main(int argc, char **argv)
{
    pcre *re;
    const char *error;
    char *pattern;
    char *subject;
    unsigned char *name_table;
    int erroffset;
    int namecount;
    int name_entry_size;
    int ovector[OVECCOUNT];
    int subject_length;
    int rc, i;



    /* After the options, we require exactly two arguments, which are the pattern,
    and the subject string. */
    if (argc != 3) {
          printf("Two arguments required: a regex and a subject string\n");
          return 1;
    }

    pattern = argv[1];
    subject = argv[2];
    subject_length = (int)strlen(subject);



    re = pcre_compile(
             pattern,              /* the pattern */
             PCRE_CASELESS,        /* case insensitive */
             &error,               /* for error message */
             &erroffset,           /* for error offset */
             NULL);                /* use default character tables */


    if (re == NULL) { /* Compilation failed: print the error message and exit */
        printf("PCRE compilation failed at offset %d: %s\n", erroffset, error);
        return 1;
    }


    rc = pcre_exec(
             re,                   /* the compiled pattern */
             NULL,                 /* no extra data - we didn't study the pattern */
             subject,              /* the subject string */
             subject_length,       /* the length of the subject */
             0,                    /* start at offset 0 in the subject */
             0,                    /* default options */
             ovector,              /* output vector for substring information */
             OVECCOUNT);           /* number of elements in the output vector */



    if (rc < 0) {                  /* Matching failed: handle error cases */
        switch(rc) {
            case PCRE_ERROR_NOMATCH: printf("No match\n");
              break;
            default: printf("Matching error %d\n", rc);
              break;
        }
      free(re);
      return 1;
    }
    /* Match succeded */
    printf("\nMatch succeeded at offset %d\n", ovector[0]);



    /*************************************************************************
    * We have found the first match within the subject string. If the output *
    * vector wasn't big enough, set its size to the maximum. Then output any *
    * substrings that were captured.                                         *
    *************************************************************************/
    if (rc == 0) { /* The output vector wasn't big enough */
        rc = OVECCOUNT/3;
        printf("ovector only has room for %d captured substrings\n", rc - 1);
    }


    /* Show substrings stored in the output vector by number. Obviously, in a real
    application you might want to do things other than print them. */
    for (i = 0; i < rc; i++) {
        char *substring_start = subject + ovector[2*i];
        int substring_length = ovector[2*i+1] - ovector[2*i];
        printf("%2d: %.*s\n", i, substring_length, substring_start);
    }


    return 0;
}



