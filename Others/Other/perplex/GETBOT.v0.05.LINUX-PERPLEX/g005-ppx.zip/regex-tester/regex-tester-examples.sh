#!/bin/bash

# examples for regex-tester, see ReadMe.txt
#                            ==============
 
clear
echo $'\n'
echo '----------------------------------------------------------------'
echo regex: '^200- *(/.*releaseame.*)'
echo site-search response: '200- /path/to/ReleaseName.v0.01.linux (whatever info)'
./regex-tester  '^200- *(/.*releasename.*)'  '200- /path/to/ReleaseName.v0.01.linux (whatever info)'
echo $'\n'correct, match \#1 holds /path/to/ReleaseName.v0.01.linux \(whatever info\)
echo '----------------------------------------------------------------'


echo $'\n'
echo '----------------------------------------------------------------'
echo regex: '^200- */.*releasename.*'
echo site-search response: '200- /path/to/releasename.win32.xxx (whatever info)'
./regex-tester  '^200- */.*releasename.*'  '200- /path/to/releasename.win32.xxx (whatever info)'
echo $'\n'not correct, there is no match \#1  \(brackets are missing in regex\)
echo '----------------------------------------------------------------'


echo $'\n'
echo '----------------------------------------------------------------'
echo regex: '^200- *\[.*\]+ *(/.*releaseNAME[^ ]*)'
echo site-search response:  '200-   [whatever info]   /path/to/Releasename (whatever info)'
./regex-tester  '^200- *\[.*\]+ *(/.*releaseNAME[^ ]*)'  '200-   [whatever info]   /path/to/Releasename (whatever info)'
echo $'\n'correct, match \#1 holds /path/to/Releasename
echo 'btw: nice but not necessary: the " (whatever info)" is already truncated'
echo '----------------------------------------------------------------'


echo $'\n'
echo '----------------------------------------------------------------'
echo regex: '^200- *(\[.*\])+ *(/.*releasename[^ ]*)'
echo site-search response: '200-   [whatever info]   /path/to/releasename (whatever info)'
./regex-tester '^200- *(\[.*\])+ *(/.*releasename[^ ]*)'   '200-   [whatever info]   /path/to/releasename (whatever info)'
echo $'\n'not correct, match \#1 does not contain /path/to/releasename \(too many brackets in regex\)
echo '----------------------------------------------------------------'
echo $'\n'


