

                                               .: getbot - PERPLEX :.


[INFO]
- This t00l - the 'getbot' - allows you to transfer (fxp) releases controlled by irc,  even without knowing the credentials for
  the server.
- Getbot is able to search for the release on all configured sites,  by making use of the SEARCH SITE command
- It's a standalone IRC drone (no Eggdrop needed!)
- Supports DH1080 & BLOWCRYPT & FISH & MCPS
- Supports TLS/SSL connections (default)
- Supports SSL based IRCD servers (Linknet)
- Supports site search (output to irc channel)
- Supports multiple site bouncers
- Supports multiple irc channels
- Uses encryted site/user databases
- Commands work in irc-channels and as private messages to drone 
  (query mode -for security reasons- needs DH1080 KeyEx: /keyx getbot)
- We *DONT* give support how to set it up correctly.
- Runs on *Linux* or Cygwin
- Bugs, comments, hints, questions?


[LIMITS]
- Max. number of sites in sites-db:            25
- Max. number of user in user-db:              25
- Max. number of files to fxp per release:    100 (more files won't be transferred)
- Max. number of irc-channels in config-file:  10
- Max. number of irc-server in config-file:    25
- Max strlen for vhost and bnc-host/ip:       128
- Max. strlen for path:                       512  
- Current version is not multi-threaded and processes all jobs sequentially.


[VERSION]
- Current version is v0.05


[SETUP]
- Edit all conf/*.conf files and run 'getbot' ;-)
- In case the user-db is empty or not existent, getbot will automatically add the admin-user gbAdm1n (for temporary use).
  Add a new admin-user then and delete the gbAdm1n.
- Bot will randomly connect one of the configured irc-servers and join all configured irc-channels.


[COMMANDS]
  &help ................................................................. shows all available commands
  &version .............................................................. shows the bot-version
  &die .................................................................. shuts down the bot

  &get <sourcesite> </srcpath/releasename> <targetsite> </targetpath> ... transfers the release from source to target
  &get <releasename> <targetsite> </targetpath> ......................... transfers the release and lets the bot search for it
  &search  <sitename> <releasename> ..................................... searchs for the release, if <sitename> == ALL, 
                                                                          getbot searchs on all added sites

  &showsites ............................................................ lists all added sites
  &checksite <sitename> ................................................. checks bnc/bnc2/bnc3-connect of the site
  &infosite <sitename> .................................................. gives info about the site
* &enablesite <sitename> ................................................ enables the site for release-searching
* &disablesite <sitename> ............................................... disables the site for release-searching
* &addsite <sitename>  <[ BNC | IP ]:port> <username> <passwd> .......... adds a new site
* &delsite <sitename>  -deletes a site
* &changesite <sitename> <-switch> <value> .............................. lets you edit more site-options
              switches:   -name    <sitename> ........................... sets the name for the site
                          -bnc1    <host:port> .......................... sets the bnc1:port for the site
                          -bnc2    <host:port> .......................... sets/adds bnc2:port for the site
                          -bnc3    <host:port> .......................... sets/adds bnc3:port for the site
                          -user    <username> ........................... sets the username for the site       
                          -pass    <passwd> ............................. sets the passwd for the site
                          -mode    <[ 0 | 1 | 2]> ....................... sets mode, 0=unsecure | 1=TLS | 2=SSL
                          -data    <[ 0 | 1 ]> .......................... sets tls/ssl data mode, 0=disabled | 1=enabled 
                          -pasv    <[ 0 | 1 ]> .......................... sets passive mode, 0=disabled | 1=enabled
                          -searchFoundRegex <regular expression> ........ sets the regex to match the "site search" response
                                                                          default is   ^200- *(/.*<REL>[^ ]*)
                                                                          at runtime the "<REL>" will be replaced with the
                                                                          current release name
                                                                          the regex must contain one ()-pair, the matching
                                                                          substring in () must start with / and hold the
                                                                          current release name (see directory regex-tester)

  &showuser ............................................................. lists all added user
* &adduser <nick> ....................................................... adds a user 
* &deluser <nick> ....................................................... deletes a user
  
  *) denotes admin-commands

[QUERY - MODE]
  You also may send private messages to the getbot. Before doing so -for security reasons-  it's necessary to do a key-exchange
  (run a  /keyx getbot  command).

[ADMIN - COMMANDS]
  As mentioned above, commands work in the irc-channels and as well as private-messages.   In both cases all admin-commands may
  only be launched by an authed user. When an admin-command is launched in query mode, the command needs a passwd as additional
  first argument.                                                   Examples:  &addsite <passwd> <sitename>,  or  &die <passwd>
  Since the getbot decides (in channel-mode) whether a user is an admin or not by checking the nick (in query-mode as mentioned
  by checking the password as additional first argument) the channel-op should ensure that arbitrary users may not change their
  nick to an admins nick.


[SOURCE]
- It's pure C/C++ Code
- It's pre-compiled
- Don't ask us for sources :-)


[GREETS]
- tc & acht3 / PERPLEX - #ppx (efnet)
