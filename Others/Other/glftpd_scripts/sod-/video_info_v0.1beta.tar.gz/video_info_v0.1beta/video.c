#include "video_info.h"

int get_mpeg_video_info(char program_type, struct video_info *video, FILE *fp) {
  long int file_size;
  unsigned int temp2, horizontal_size_value, vertical_size_value,
               bit_rate_value, bit_rate_extension;
  unsigned char temp1, aspect_ratio_information, frame_rate_code, 
                extension_start_code_identifier, profile_and_level_indication,
                progressive_sequence, chroma_format, horizontal_size_extension,
                vertical_size_extension, drop_frame_flag;

  rewind(fp);
  /* MPEG-1 or MPEG-2 video? */
  while(!feof(fp))
    if(get_start_code(fp, 0x000001, 50000000) == 0xB3)
      break;
  if(feof(fp))
    return(-1);
  video->video_mpeg_type = 1;
  if(get_start_code(fp, 0x000001, 140) == 0xB5)
    video->video_mpeg_type = 2;

  /* Get the length of the video stream. since some "mpeg-cutters" doesnt seem
   * to update all the time stamps in the file this code snippet subtracts the
   * first timestamps from the last.
   */
  fseek(fp, 0L, SEEK_END);
  file_size = ftell(fp);
  rewind(fp);
  while(!feof(fp)) {
    if(get_start_code(fp, 0x000001, 50000000) == 0xB8) { /*group_start_code*/
      data = getc(fp);
      /* This is an ugly fix for (to me) weird time stamps. */
      if(!(data & 0x80) && (((data & 0x7C) >> 2) < 4)) {
        drop_frame_flag = (data & 0x80);
        video->video_duration = ((data & 0x7C) >> 2) * 3600;
        temp1 = (data & 0x03) << 4;
        data = getc(fp);
        video->video_duration += ((temp1 | (data >> 4)) * 60);
        temp1 = (data & 0x07) << 3;
        data = getc(fp);
        video->video_duration += (temp1 | (data >> 5));
        break;
      }
    }
  }
  if(file_size > 1000000)
    fseek(fp, -1000000L, SEEK_END);
  else
    rewind(fp);
  while(!feof(fp)) {
    if(get_start_code(fp, 0x000001, 50000000) == 0xB8) { /*group_start_code*/
      data = getc(fp);
      /* This is an ugly fix for (to me) weird time stamps. */
      if(!(data & 0x80) && (((data & 0x7C) >> 2) < 4)) {
        drop_frame_flag = (data & 0x80);
        temp2 = ((data & 0x7C) >> 2) * 3600;
        temp1 = (data & 0x03) << 4;
        data = getc(fp);
        temp2 += ((temp1 | (data >> 4)) * 60);
        temp1 = (data & 0x07) << 3;
        data = getc(fp);
        temp2 += (temp1 | (data >> 5));
      }
    }
  }
  video->video_duration = temp2 - video->video_duration;

  rewind(fp);
  while(!feof(fp))
    if(get_start_code(fp, 0x000001, 50000000) == 0xB3) /*sequence_header_code*/
      break;
  if(feof(fp))
    return(-1);
  if(program_type == 1) {
    data = getc(fp);
    horizontal_size_value = data << 4;
    data = getc(fp);
    horizontal_size_value = horizontal_size_value | (data >> 4);
    vertical_size_value = (data & 0x0F) << 8;
    data = getc(fp);
    vertical_size_value = vertical_size_value | data;
    data = getc(fp);
    aspect_ratio_information = data >> 4;
    frame_rate_code = data & 0x0F;
    video->video_bit_rate = (getc(fp) << 10) | (getc(fp) << 2) |
                           (getc(fp) & 0xC0);
    if(video->video_bit_rate == 0x3FFFF) /* intended for vbr operation. */
      video->video_bit_rate = 0;
    else
      video->video_bit_rate = video->video_bit_rate * 400;
    video->video_horizontal_size = horizontal_size_value;
    video->video_vertical_size = vertical_size_value;
    chroma_format = 0x01;
    profile_and_level_indication = 0x00;
  }
  else if(program_type == 2) {
    data = getc(fp);
    horizontal_size_value = data << 4;
    data = getc(fp);
    horizontal_size_value = horizontal_size_value | (data >> 4);
    vertical_size_value = (data & 0x0F) << 8;
    data = getc(fp);
    vertical_size_value = vertical_size_value | data;
    data = getc(fp);
    aspect_ratio_information = data >> 4;
    frame_rate_code = data & 0x0F;
    bit_rate_value = (getc(fp) << 10) | (getc(fp) << 2) | (getc(fp) & 0xC0);
    /* not much more useful information to read here so lets go on... */
    if(get_start_code(fp, 0x000001, 50000000) != 0xB5) /*extension_start_code*/
      return(-1);
    data = getc(fp);
    extension_start_code_identifier = data >> 4;
    profile_and_level_indication = data << 4;
    data = getc(fp);
    profile_and_level_indication = profile_and_level_indication | (data >> 4);
    progressive_sequence = (data & 0x08) >> 3;
    chroma_format = (data & 0x06) >> 1;
    horizontal_size_extension = (data & 0x01) << 1;
    data = getc(fp);
    horizontal_size_extension = horizontal_size_extension |
                                ((data & 0x80) >> 7);
    vertical_size_extension = (data & 0x60) >> 5;
    video->video_horizontal_size = horizontal_size_value |
                                  (horizontal_size_extension << 12);
    video->video_vertical_size = vertical_size_value |
                                (vertical_size_extension << 12);
    bit_rate_extension = (data & 0x1F) << 7;
    data = getc(fp);
    bit_rate_extension = bit_rate_extension | ((data & 0xFE) >> 1);
    video->video_bit_rate = (bit_rate_value | (bit_rate_extension << 18)) * 400;
  /*  getc(fp);
   *  data = getc(fp);
   *  frame_rate_extension_n = (data & 0x60) >> 5;
   *  frame_rate_extension_d = data & 0x1F;
   */
  }
  switch((profile_and_level_indication & 0x70) >> 4) {
    case 0x01: sprintf(video->video_profile, "high"); break;
    case 0x02: sprintf(video->video_profile, "spatially_scalable"); break;
    case 0x03: sprintf(video->video_profile, "snr_scalable"); break;
    case 0x04: sprintf(video->video_profile, "main"); break;
    case 0x05: sprintf(video->video_profile, "simple"); break;
    default:   sprintf(video->video_profile, "n/a"); break;
  }
  switch(profile_and_level_indication & 0x0F) {
    case 0x04: sprintf(video->video_level, "high"); break;
    case 0x06: sprintf(video->video_level, "high_1440"); break;
    case 0x08: sprintf(video->video_level, "main"); break;
    case 0x0A: sprintf(video->video_level, "low"); break;
    default:   sprintf(video->video_level, "n/a"); break;
  }

  switch(aspect_ratio_information) {
    case 0x01: sprintf(video->video_aspect_ratio, "%.2f",
               (float)video->video_vertical_size /
               video->video_horizontal_size); break;
    case 0x02: if(video->video_mpeg_type == 1) {
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.6735"));
                 break;
               }
               else if(video->video_mpeg_type == 2) {
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.75"));
                 break;
               }
    case 0x03: if(video->video_mpeg_type == 1){
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.7031"));
                 break;
               }
               else if(video->video_mpeg_type == 2) {
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.5625"));
                 break;
               }
    case 0x04: if(video->video_mpeg_type == 1) {
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.7615"));
                 break;
               }
               else if(video->video_mpeg_type == 2) {
                 sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.4524"));
                 break;
               }
    case 0x05: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.8055"));
      break;
    case 0x06: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.8437"));
      break;
    case 0x07: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.8935"));
      break;
    case 0x08: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.9375"));
      break;
    case 0x09: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("0.9815"));
      break;
    case 0x0A: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("1.0255"));
      break;
    case 0x0B: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("1.0695"));
      break;
    case 0x0C: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("1.1250"));
      break;
    case 0x0D: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("1.1575"));
      break;
    case 0x0E: sprintf(video->video_aspect_ratio, "%.2f", 1/atof("1.2015"));
      break;
    default:   sprintf(video->video_aspect_ratio, "n/a");
      break;
  }

  switch(frame_rate_code) {
    case 0x01: sprintf(video->video_frame_rate, "23.976"); break;
    case 0x02: sprintf(video->video_frame_rate, "24"); break;
    case 0x03: sprintf(video->video_frame_rate, "25"); break;
    case 0x04: sprintf(video->video_frame_rate, "29.97"); break;
    case 0x05: sprintf(video->video_frame_rate, "30"); break;
    case 0x06: sprintf(video->video_frame_rate, "50"); break;
    case 0x07: sprintf(video->video_frame_rate, "59.94"); break;
    case 0x08: sprintf(video->video_frame_rate, "60"); break;
    default:   sprintf(video->video_frame_rate, "n/a"); break;
  }

  switch(chroma_format) {
    case 0x01: sprintf(video->video_chroma_format, "4:2:0"); break;
    case 0x02: sprintf(video->video_chroma_format, "4:2:2"); break;
    case 0x03: sprintf(video->video_chroma_format, "4:4:4"); break;
    default:   sprintf(video->video_chroma_format, "n/a"); break;
  }

  return(0);
}




int get_xvid_video_info(char program_type, struct video_info *video, FILE *fp) {
  int time_increment, time_resolution, temp;

  rewind(fp);
  if(program_type == 100) {
    while(!feof(fp))
      if((get_start_code(fp, 0x000001, 50000000) == 0x00)
         && (get_start_code(fp, 0x000001, 4) & 0xF0) == 0x20)
        break;
    if(feof(fp))
      return(-1);
    video->video_mpeg_type = 4;

    SKIP_BYTE;
    temp = getc(fp);
    data = getc(fp);
    switch((temp >> 2) & 0x0F) {
      case 0x01: sprintf(video->video_aspect_ratio, "1"); break;
      default:   sprintf(video->video_aspect_ratio, "n/a"); break;
    }
    if((temp >> 1) & 0x01) { /* vol_control_parameters = 1 */
      switch(((temp & 0x01) << 1) | (data >> 7)) {
        case 0x01: sprintf(video->video_chroma_format, "4:2:0"); break;
        default:   sprintf(video->video_chroma_format, "n/a"); break;
      }
      time_resolution = (data & 0x03) << 14;
      data = getc(fp);
      time_resolution |= data << 6;
      data = getc(fp);
      time_resolution |= (data & 0xFC) >> 2;
      /* This is a fix for a (to me) weird bit stream. */
      /* It might need to look ahead and make shure tha ttime_increment == 1. */
      if(time_resolution == 25) {
        data = getc(fp);
        video->video_horizontal_size = (data & 0x03) << 11;
        data = getc(fp);
        video->video_horizontal_size = video->video_horizontal_size | (data << 3);
        data = getc(fp);
        video->video_horizontal_size = video->video_horizontal_size | ((data & 0xE0) << 3);
        video->video_vertical_size = (data & 0x0F) << 9;
        data = getc(fp);
        video->video_vertical_size = video->video_vertical_size | (data << 1);
        data = getc(fp);
        video->video_vertical_size = video->video_vertical_size | (data >> 7);
      }
      else {
        time_increment = (getc(fp) << 8) | getc(fp);
        sprintf(video->video_frame_rate, "%.3f", (float)time_resolution / time_increment);
        data = getc(fp);
        video->video_horizontal_size = (data & 0x7F) << 6;
        data = getc(fp);
        video->video_horizontal_size = (video->video_horizontal_size | (data & 0xFC) >> 2);
        video->video_vertical_size = (data & 0x01) << 12;
        data = getc(fp);
        video->video_vertical_size = (video->video_vertical_size | data << 4);
        data = getc(fp);
        video->video_vertical_size = (video->video_vertical_size | data >> 4);
      }
    }
    else { /* vol_control_parameters = 0 */
      SKIP_BYTE;
      data = getc(fp);
      video->video_horizontal_size = (data & 0x07) << 10;
      data = getc(fp);
      video->video_horizontal_size = (video->video_horizontal_size | (data << 2));
      data = getc(fp);
      video->video_horizontal_size = (video->video_horizontal_size | (data >> 6));
      video->video_vertical_size = (data & 0x1F) << 8;
      data = getc(fp);
      video->video_vertical_size = video->video_vertical_size  | data;
      sprintf(video->video_chroma_format, "n/a");
      sprintf(video->video_frame_rate, "n/a");
    }
    sprintf(video->video_profile, "n/a");
    sprintf(video->video_level, "n/a");
    video->video_bit_rate = 0;
    video->video_duration = 0;
  }
  else if(program_type > 100)
    return(-1); /* No support for these video streams (yet). */

  return(0);
}
