#include "video_info.h"

int main(int argc, char *argv[]) {
  unsigned long int file_size;
  struct audio_info audio;
  struct video_info video;
  struct program_info program;
  static char temp1[8], temp2[8], temp3[8], outdata[100];
  FILE *fp;

  if((fp = fopen(argv[1], "r")) == NULL)
    exit(EXIT_FAILURE);

  fseek(fp, 0L, SEEK_END);
  file_size = ftell(fp);

  if(get_program_info(&program, fp) != 0) /* MPEG-1, MPEG-2 or AVI? */
    exit(EXIT_FAILURE);

  if(program.program_type == 1 || program.program_type == 2) { /* MPEG-1/2. */
    if(get_mpeg_video_info(program.program_type, &video, fp) != 0)
      exit(EXIT_FAILURE);
  }
  else if(program.program_type == 100) { /* XviD. */
    if(get_xvid_video_info(program.program_type, &video, fp) != 0)
      exit(EXIT_FAILURE);
  }
  else
    exit(EXIT_FAILURE);

  if(video.video_duration > 0)
    program.program_avg_bit_rate = file_size / video.video_duration * 8;
  else
    program.program_avg_bit_rate = 0;

  if(get_audio_info(program.program_type, &audio, fp) != 0)
    exit(EXIT_FAILURE);

  switch(program.program_type) {
    case 1:   sprintf(temp1, "\"MPEG-1\""); break;
    case 2:   sprintf(temp1, "\"MPEG-2\""); break;
    default:  sprintf(temp1, "\"AVI\""); break;
  }

  switch(audio.audio_id) {
    case 1:   sprintf(temp2, "\"MPEG-1\""); break;
    case 0:   sprintf(temp2, "\"MPEG-2\""); break;
    case 100: sprintf(temp2, "\"AC-3\""); break;
  }

  if(program.program_avg_bit_rate == 0)
    sprintf(temp3, "n/a");
  else
    sprintf(temp3, "%d", program.program_avg_bit_rate);

  sprintf(outdata, " %.8s \"%s\" \"%d\" \"%.6s\" \"%d\" \"%d\" \"%.4s\" %.8s \"%d\" \"%d\" \"%.14s\"",
    temp1, temp3, video.video_mpeg_type,
    video.video_frame_rate, video.video_horizontal_size,
    video.video_vertical_size, video.video_aspect_ratio, temp2,
    audio.audio_bitrate, audio.audio_sampling_frequency, audio.audio_mode);
  if(writelog(outdata, argv[1]) == 0)
    exit(EXIT_SUCCESS);
  else
    exit(EXIT_FAILURE);
}




/* get_start_code() Searches for a start code. Valid start codes consists of
 *                  4 bytes in which the first 3 bytes are known. For example
 *                  the MPEG start codes that always begin with 0x000001. The
 *                  4:th byte determines what kind of start code it is. The
 *                  start code has to be byte aligned.
 * param_1: A pointer to the file in which the byte is to be found.
 * param_2: The 24 bit long pattern to search for.
 * param_3: Maximum number of bytes to search (has to be at least 4), not
 *          including heading zeroes in the file.
 * returns: The byte following the 2nd parameter or '0' if EOF.
 */
unsigned char get_start_code(FILE *fp, int search_pattern, unsigned int search_limit) {
  #define BUFFER_LENGTH 1000
  long int fp_start_pos;
  int bytes_read, i = 0, j;
  unsigned char buffer[BUFFER_LENGTH];

  fp_start_pos = ftell(fp);
  bytes_read = fread(buffer, 1, BUFFER_LENGTH, fp);

  /* Skip heading zeroes (in multiples of 4) at the start of the file. */
  if(ftell(fp) == bytes_read) {
    while(!buffer[i] && !buffer[i+1] && !buffer[i+2] && !buffer[i+3]) {
      i += 4;
      if(i > (bytes_read - 4))
        return(0);
    }
  }

  if(search_limit < bytes_read)
    bytes_read = search_limit;

  /* This loop, if nescessary, reads more data from fp to the buffer. */
  for(j = 0; j <= (search_limit / BUFFER_LENGTH); j++) {
    /* This loop goes through the read buffer. */
    for(i = 0; i < (bytes_read - 3); i++) {
      if(buffer[i] == ((search_pattern >> 16) & 0xFF)) {
        if(buffer[i+1] == ((search_pattern >> 8) & 0xFF)) {
          if(buffer[i+2] == (search_pattern & 0xFF)) {
            fseek(fp, fp_start_pos + j * BUFFER_LENGTH + i + 4, SEEK_SET);
            return(buffer[i+3]);
          }
        }
      }
    }
    if(feof(fp))
      return(0);
/*    fseek(fp, -3, SEEK_CUR); */
    bytes_read = fread(buffer, 1, BUFFER_LENGTH, fp);
  }
  fseek(fp, fp_start_pos, SEEK_SET);
  return(0); /* Error. */
}




int get_program_info(struct program_info *program, FILE *fp) {
  unsigned int fourcc;

  rewind(fp);
  /* Find the pack_start_code (0x000001BA). */
  if(get_start_code(fp, 0x000001, 4) == 0xBA) {  /* MPEG-1/2 program stream? */
    data = getc(fp);
    if(((unsigned char)data & 0xF0) == 0x20)
      program->program_type = 1;
    else if((data & 0xC0) == 0x40)
      program->program_type = 2;
    else
      return(-1);
    ungetc(data, fp);

    /* find system_header_start_code (0x000001BB). */
    while(!feof(fp)) {
      data = get_start_code(fp, 0x000001, 10000000);
      if(data == 0xBB)
        break;
    }

    SKIP_BYTES(5);
    if(getc(fp) & 0x02)
      sprintf(program->program_bit_rate_type, "cbr");
    else
      sprintf(program->program_bit_rate_type, "vbr");
  }
  else { /* avi or vob stream? */
    rewind(fp);
    if(get_start_code(fp, 0x524946, 4) != 0x46) {
      rewind(fp);

      while(!feof(fp)) {
        if(get_start_code(fp, 0x000001, 50000) == 0xBA)
          break;
      }
      data = getc(fp);
      if((data & 0xF0) == 0x20)
        program->program_type = 1;
      else if((data & 0xC0) == 0x40)
        program->program_type = 2;
      else
        return(-1);
      ungetc(data, fp);
      /* find system_header_start_code (0x000001BB). */
      while(!feof(fp)) {
        if(get_start_code(fp, 0x000001, 10000000) == 0xBB)
          break;
      }
      SKIP_BYTES(5);
      if(getc(fp) & 0x02)
        sprintf(program->program_bit_rate_type, "cbr");
      else
        sprintf(program->program_bit_rate_type, "vbr");
      return(0);
    }

    if(get_start_code(fp, 0x766964, 112) != 0x73) /* "vids". */
      return(-1);
    fourcc = (getc(fp) << 24) | (getc(fp) << 16) | (getc(fp) << 8) | getc(fp);

    switch(fourcc) {
      case 0x78766964: program->program_type = 100; break;
      case 0x33697678: program->program_type = 101; break;
      case 0x64697678: program->program_type = 102; break;
      case 0x64697633: program->program_type = 103; break;
      case 0x64697634: program->program_type = 104; break;
      case 0x64697635: program->program_type = 105; break;
      default:         program->program_type = 0;   break;
    }
    sprintf(program->program_bit_rate_type, "n/a");
  }

  return(0);
}




int writelog(char *outdata, char *file_name) {
  FILE *log_file;
  time_t cur_time;
  char path[256];
  int i, j = 0, l = 0;

  if((log_file = fopen(LOG_FILE, "a+")) == NULL)
    return(-1);

  for(i = 0; file_name[i] != '\0'; i++) /* Strip the filename. */
    if(file_name[i] == '/')
      j = i;
  for(i = 0; i < j; i++) /* Strip the sample-dir. */
    if(file_name[i] == '/')
      l = i;

  strncpy(path, file_name, l);
  path[l] = '\0';

  cur_time = time(NULL);
  fprintf(log_file, "%.24s VIDEO_INFO: \"%s\"%s\n", ctime(&cur_time), path, outdata);
  fclose(log_file);

  return(0);
}
