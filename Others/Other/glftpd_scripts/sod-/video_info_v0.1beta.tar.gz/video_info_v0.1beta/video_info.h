#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define LOG_FILE "/ftp-data/logs/glftpd.log"

#define SKIP_BYTE getc(fp)
#define SKIP_BYTES(n) for(k = 0; k < n; k++) getc(fp)

int k; /* Used for the SKIP_BYTES() macro */
unsigned char data;

struct audio_info {
  char audio_id;                /* 1 = MPEG-1, 2 = MPEG-2, 100 = AC-3. */
  char audio_layer;             /* Only for MPEG audio. */
  char audio_protection_bit;    /* Only for MPEG audio. */
  int audio_bitrate;            /* In kb/s. */
  int audio_sampling_frequency; /* In Hz. */
  char audio_mode[14];          /* Number of channels (sort of). */
  char audio_mode_extension;    /* Only for MPEG audio joint_stereo mode. */
  char audio_copyright;         /* Only for MPEG audio. */
  char audio_original;          /* Only for MPEG audio. */
  char audio_emphasis;          /* Only for MPEG audio. */
};

struct video_info {
  char video_profile[18];       /* Only for MPEG-1/2. */
  char video_level[9];          /* Only for MPEG-1/2. */
  char video_aspect_ratio[4];   /* Only for MPEG-1/2 and MPEG-4 with ar of 1. */
  unsigned int video_bit_rate;  /* Only for MPEG-1/2. This only indicates the
                                   max rate of operation of the vbv. In b/s. */
  int video_vertical_size;      /* In pixels. */
  int video_horizontal_size;    /* In pixels. */
  char video_mpeg_type;         /* 1 = MPEG-1, 2 = MPEG-2, 4 = MPEG-4. */
  char video_frame_rate[6];     /* In Hz. */
  char video_chroma_format[6];  /* */
  unsigned int video_duration;  /* Only for MPEG-1/2. In seconds. */
};

struct program_info {
  char program_type;            /* 1 = MPEG-1, 2 = MPEG-2, 100-105 = AVI */
  char program_bit_rate_type[3];/* CBR/VBR. */
  unsigned int program_avg_bit_rate; /* Only for MPEG-1/2. In b/s. */
};

int writelog(char *, char *);
unsigned char get_start_code(FILE *fp, int, unsigned int);
int get_audio_info(char, struct audio_info *, FILE *);
int get_ac3_info(struct audio_info *, FILE *);
int get_mpeg_video_info(char, struct video_info *, FILE *);
int get_xvid_video_info(char, struct video_info *, FILE *);
int get_program_info(struct program_info *, FILE *);
