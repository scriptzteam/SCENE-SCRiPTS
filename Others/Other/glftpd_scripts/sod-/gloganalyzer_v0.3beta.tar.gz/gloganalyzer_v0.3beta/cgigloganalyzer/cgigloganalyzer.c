/* Compilation: gcc -Wall -lm -lgd -lpng -lz -ljpeg -lcrypt cgic.c \
                gloganalyzer.c cgigloganalyzer.c -o cgigloganalyzer
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "cgic.h"

#define PASSWORD_FILE "/glftpd/etc/passwd"
#define _DEBUG

int get_username(char *);
int get_password(char *);
int get_ul_dl(char *);
int get_user_group(char *);
int get_users(char *);
int get_start_year(char *);
int get_start_month(char *);
int get_start_day(char *);
int get_start_hour(char *);
int get_stop_year(char *);
int get_stop_month(char *);
int get_stop_day(char *);
int get_stop_hour(char *);
void send_error(char);
int mmain();
char *crypt();

int temp;

int cgiMain() {
  char buffer[256], username[32], password[32], uldl[3], users[1024],
       usr[256], pwd[256], no_match=1, start_year[5], start_month[3],
       start_day[3], start_hour[3], stop_year[5], stop_month[3],
       stop_day[3], stop_hour[3], u01[16], u02[16], u03[16], u04[16],
       u05[16], u06[16], u07[16], u08[16], u09[16], u10[16], u11[16],
       u12[16],u13[16], u14[16], usergroup[2];
  int argv[62], error, no_of_users;
  FILE *fp;

  /* Retrieve user input. */
  if(get_username(username) != 0)
    send_error(1);
  if(get_password(password) != 0)
    send_error(2);
  if(get_ul_dl(uldl) != 0)
    send_error(3);
  if(get_user_group(usergroup) != 0)
    send_error(9);
  if(get_users(users) != 0)
    send_error(4);
  if(get_start_year(start_year) != 0)
    send_error(5);
  if(get_start_month(start_month) != 0)
    send_error(5);
  if(get_start_day(start_day) != 0)
    send_error(5);
  if(get_start_hour(start_hour) != 0)
    send_error(5);
  if(get_stop_year(stop_year) != 0)
    send_error(6);
  if(get_stop_month(stop_month) != 0)
    send_error(6);
  if(get_stop_day(stop_day) != 0)
    send_error(6);
  if(get_stop_hour(stop_hour) != 0)
    send_error(6);

  /* Verify the user and his password. */
  if((fp = fopen(PASSWORD_FILE, "r")) == NULL)
    send_error(7);
  while(fgets (buffer, 255, fp) != NULL) {
    sscanf(buffer, "%[^:]:%[^:]", usr, pwd);
    if(strcmp(usr, username) == 0 && strcmp(crypt(password, pwd), pwd) == 0) {
      no_match=0;
      break;
    }
  }
  fclose(fp);
  if(no_match)
    send_error(8);

  /* Prepare the data that is to be sent to mmain. */
  argv[0]=(int)"gloganalyzer";
  argv[1]=(int)&start_year;
  argv[2]=(int)&start_month;
  argv[3]=(int)&start_day;
  argv[4]=(int)&start_hour;
  argv[5]=(int)&stop_year;
  argv[6]=(int)&stop_month;
  argv[7]=(int)&stop_day;
  argv[8]=(int)&stop_hour;
  argv[9]=(int)&uldl;
  argv[10]=(int)&usergroup;

  no_of_users = sscanf(users, "%s %s %s %s %s %s %s %s %s %s %s %s %s %s", \
  u01,u02,u03,u04,u05,u06,u07,u08,u09,u10,u11,u12,u13,u14);
  argv[11]=(int)&u01;
  argv[12]=(int)&u02;
  argv[13]=(int)&u03;
  argv[14]=(int)&u04;
  argv[15]=(int)&u05;
  argv[16]=(int)&u06;
  argv[17]=(int)&u07;
  argv[18]=(int)&u08;
  argv[19]=(int)&u09;
  argv[20]=(int)&u10;
  argv[21]=(int)&u11;
  argv[22]=(int)&u12;
  argv[23]=(int)&u13;
  argv[24]=(int)&u14;

  #ifndef DEBUG
    if((error = mmain(no_of_users+11, &argv)) != 0)
      send_error(error);
  #endif

  #ifdef DEBUG
    cgiHeaderContentType("text/html");
    fprintf(cgiOut, "\n\n<HTML><HEAD><TITLE>...</TITLE></HEAD><BODY>\n");
    fprintf(cgiOut, "%s %s %s %s %s %s %s %s %s %s -u %s<BR>\n", \
    "gloganalyzer", start_year, start_month, start_day, start_hour, \
    stop_year, stop_month, stop_day, stop_hour, uldl, users);
    fprintf(cgiOut, "\n</BODY></HTML>\n");
    exit(0);
  #endif

  return 0;
}

void send_error(char error) {
  cgiHeaderContentType("text/html");
  fprintf(cgiOut, "\n\n<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">\n \
                   <HTML><HEAD><META http-equiv=\"Content-Type\" content=\"\
                   text/html; charset=ISO-8859-1\"><TITLE>cgigloganalyzer \
                   v0.3beta by SoD-</TITLE></HEAD><BODY>\n");
  if(error < 0 && error > -10) {
    if(error == -1)
      fprintf(cgiOut, "Couldn't open glftpd's xferlog, aborting.");
    else if(error == -2 || error == -3)
      fprintf(cgiOut, "Erroneus arguments received, aborting.");
    else if(error == -4)
      fprintf(cgiOut, "The SAMPLES value in the program isn't properly set, \
                       aborting.");
    else if(error == -5)
      fprintf(cgiOut, "Your choice in start date and/or stop date isn't valid, \
                       aborting.<BR> Increase time span and/or change \
                       users/groups.");
    else if(error == -6)
      fprintf(cgiOut, "Program failed to allocate memory, aborting.");
    else if(error == -7)
      fprintf(cgiOut, "None of the users/groups for whom you requested stats \
                       have up/downloaded enough.<BR>Change time span and/or \
                       user.");
    else if(error == -8)
      fprintf(cgiOut, "There seems to be an error in the xferlog...");
    else if(error == -9)
      fprintf(cgiOut, "Only 1 instance of the same user/group is allowed in \
                       the \"Select users/groups\" field.");
  }
  if(error == 1)
    fprintf(cgiOut, "Invalid username was entered, aborting.");
  if(error == 2)
    fprintf(cgiOut, "Invalid password was entered, aborting.");
  if(error == 3)
    fprintf(cgiOut, "Your choice of UL/DL was somehow erroneous, aborting.");
  if(error == 4)
    fprintf(cgiOut, "Invalid userlist was entered, aborting.");
  if(error == 5)
    fprintf(cgiOut, "Invalid start date was entered, aborting.");
  if(error == 6)
    fprintf(cgiOut, "Invalid end date was entered, aborting.");
  if(error == 7)
    fprintf(cgiOut, "Couldn't open the passwd file, aborting.");
  if(error == 8)
    fprintf(cgiOut, "Entered username and/or password isn't valid, aborting.");
  if(error == 9)
    fprintf(cgiOut, "Your choice of USR/GRP was somehow erroneous, aborting.");
  fprintf(cgiOut, "\n</BODY></HTML>\n");
  exit(-1);
}

int get_username(char *username) {
  switch (cgiFormStringNoNewlines("username", username, 32)) {
    case cgiFormSuccess:   break;
    default:               return(-1);
  }
  return(0);
}

int get_password(char *password) {
  switch (cgiFormStringNoNewlines("password", password, 32)) {
    case cgiFormSuccess:   break;
    default:               return(-1);
  }
  return(0);
}

int get_ul_dl(char *uldl) {
  switch (cgiFormIntegerBounded("ul_dl", &temp, 1, 2, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
/*
  sprintf(uldl, "%d", temp);
  return(0);
*/
  if(temp == 1)
    sprintf(uldl, "-ul");
  else
    sprintf(uldl, "-dl");
  return(0);
}

int get_user_group(char *usergroup) {
  switch (cgiFormIntegerBounded("user_group", &temp, 1, 2, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  if(temp == 1)
    sprintf(usergroup, "-u");
  else
    sprintf(usergroup, "-g");
  return(0);
}

int get_users(char *users) {
  switch (cgiFormStringNoNewlines("users", users, 1024)) {
    case cgiFormSuccess:   break;
    default:               return(-1);
  }
  return(0);
}

int get_start_year(char *start_year) {
  switch (cgiFormIntegerBounded("start_year", &temp, 1970, 2037, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(start_year, "%d", temp);
  return(0);
}

int get_start_month(char *start_month) {
  switch (cgiFormIntegerBounded("start_month", &temp, 0, 11, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(start_month, "%d", temp);
  return(0);
}

int get_start_day(char *start_day) {
  switch (cgiFormIntegerBounded("start_day", &temp, 1, 31, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(start_day, "%d", temp);
  return(0);
}

int get_start_hour(char *start_hour) {
  switch (cgiFormIntegerBounded("start_hour", &temp, 0, 23, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(start_hour, "%d", temp);
  return(0);
}

int get_stop_year(char *stop_year) {
  switch (cgiFormIntegerBounded("stop_year", &temp, 1970, 2037, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(stop_year, "%d", temp);
  return(0);
}

int get_stop_month(char *stop_month) {
  switch (cgiFormIntegerBounded("stop_month", &temp, 0, 11, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(stop_month, "%d", temp);
  return(0);
}

int get_stop_day(char *stop_day) {
  switch (cgiFormIntegerBounded("stop_day", &temp, 1, 31, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(stop_day, "%d", temp);
  return(0);
}

int get_stop_hour(char *stop_hour) {
  switch (cgiFormIntegerBounded("stop_hour", &temp, 0, 23, 0)) {
    case cgiFormSuccess:     break;
    default:                 return(-1);
  }
  sprintf(stop_hour, "%d", temp);
  return(0);
}
