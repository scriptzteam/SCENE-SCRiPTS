/*******************************************************************************
* Changes from the "real" gloganalyzer.c:                                      *
*: - cgic.h is included                                                        *
*  - main() is now called mmain()                                              *
*  - the image is written to cgiOut instead of to fp                           *
*  - cgiHeaderContentType("image/png"); is put at the bottom of the file       *
*  - fp is removed from write_stats()                                          *
*  - #define PICTURE_FILE have been removed                                    *
*  - all printf(...) have been removed                                         *
*  - all DEBUG have been removed                                               *
*  - all exit() have been replaced by return()                                 *
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "gd.h"
#include "gdfontl.h"
#include "gdfontg.h"
#include "cgic.h"

#define LOG_FILE     "/glftpd/ftp-data/logs/xferlog"
#define PICTURE_X    1024 /* horisontal picture size                          */
#define PICTURE_Y    768  /* vertical picture size                            */
#define X_CLEARANCE  60   /* horisontal space to save for axes in the image   */
#define Y_CLEARANCE  40   /* vertical space to save for axes in the image     */
#define SAMPLES      128  /* changes the stats appearance (SAMPLES<=PICTURE_X)*/
#define Y_ORIGIN     (PICTURE_Y-Y_CLEARANCE)

/* all_months[] is an external variable so it doesnt have to be reinitialized */
/* or passed as argument for every call of the function month_string_to_int().*/
char all_months[37] = "JanFebMarAprMayJunJulAugSepOctNovDec";

int month_string_to_int(char *);
int time_convert(struct tm *, char *);
int write_stats(unsigned long *, int, struct tm *, struct tm *, long, char **, \
                unsigned long);

int mmain(int argc, char *argv[]) {
  char buffer[512], month_str[4], username[16], groupname[16], ul_or_dl,
       use_last_entry = 0, use_first_entry = 0;
  int i, j, k, no_of_users, month = 0, day = 0, hour = 0, min = 0, sec = 0, 
      year = 0, offset;
  long time_span, logfile_size, qwerty;
  unsigned long filesize, *stat_array, total_up_dn = 0;
  struct tm t_start, t_start_copy, t_stop, t_stop_copy, t_temp, t_temp_copy,
            t_first_entry, t_temp_3;
  FILE *fp;

  /* Don't allow the same user to be sent to the program more then once */
  for(i = 1; i <= argc - 11; i++)
    for(j = 1; j < i; j++)
      if(strcmp(argv[i + 10], argv[j + 10]) == 0)
        return(-9);

  if((fp = fopen(LOG_FILE, "r")) == NULL)
    return(-1);

  /* Quick and dirty test to see if parameters passed to program are valid. */
  if((argc < 12) || ((strcmp(argv[10], "-u") != 0) && (strcmp(argv[10], "-g") != 0)))
    return(-2);
  if(argc > 25)
    return(-3);

  /* Needed so the program doesn't crash. */
  if(SAMPLES > PICTURE_X)
    return(-4);

  /* Initialize t_start according to the parameter passed to the program or */
  /* if that's not valid, to the first entry in the logfile.                */
  fgets(buffer, 511, fp);
  sscanf(buffer, "%*s%s%2d%2d%*1s%2d%*1s%2d%4d%*s[^/n]", month_str, &day, \
         &hour, &min, &sec, &year);
  t_temp.tm_year = year - 1900;
  t_temp.tm_mon = month_string_to_int(month_str);
  t_temp.tm_mday = day;
  t_temp.tm_hour = hour;
  t_temp.tm_min = min;
  t_temp.tm_sec = sec;
  t_temp.tm_isdst = 0;
  t_start.tm_year = atoi(argv[1]) - 1900;
  t_start.tm_mon = atoi(argv[2]) - 1;
  t_start.tm_mday = atoi(argv[3]);
  t_start.tm_hour = atoi(argv[4]);
  t_start.tm_min = 0;
  t_start.tm_sec = 0;
  t_start.tm_isdst = 0;
  t_start_copy = t_start;
  t_temp_copy=t_first_entry = t_temp;
  if(difftime(mktime(&t_temp_copy), mktime(&t_start_copy)) > 0) {
    t_start.tm_year = t_temp.tm_year;
    t_start.tm_mon = t_temp.tm_mon;
    t_start.tm_mday = t_temp.tm_mday;
    t_start.tm_hour = t_temp.tm_hour;
    t_start.tm_min = t_temp.tm_min;
    use_first_entry = 1;
  }

  /* Initialize t_stop according to the parameter passed to the program or if */
  /* that's not valid, to the last entry in the logfile.                      */
  fseek(fp, -511L, SEEK_END);
  while(fgets(buffer, 511, fp) != NULL)
    sscanf(buffer, "%*s%s%2d%2d%*1s%2d%*1s%2d%4d%*[^/n]", month_str, &day, \
           &hour, &min, &sec, &year);
  t_temp.tm_year = year - 1900;
  t_temp.tm_mon = month_string_to_int(month_str);
  t_temp.tm_mday = day;
  t_temp.tm_hour = hour;
  t_temp.tm_min = min;
  t_temp.tm_sec = sec;
  t_temp.tm_isdst = 0;
  t_stop.tm_year = atoi(argv[5]) - 1900;
  t_stop.tm_mon = atoi(argv[6]) - 1;
  t_stop.tm_mday = atoi(argv[7]);
  t_stop.tm_hour = atoi(argv[8]);
  t_stop.tm_min = 0;
  t_stop.tm_sec = 0;
  t_stop.tm_isdst = 0;
  t_stop_copy = t_stop;
  t_temp_copy=t_temp_3 = t_temp;
  if(difftime(mktime(&t_stop_copy), mktime(&t_temp_copy)) > 0) {
    t_stop.tm_year = t_temp.tm_year;
    t_stop.tm_mon = t_temp.tm_mon;
    t_stop.tm_mday = t_temp.tm_mday;
    t_stop.tm_hour = t_temp.tm_hour;
    t_stop.tm_min = t_temp.tm_min;
    use_last_entry = 1;
  }

  /* Calculate needed number of 15mins samples required to display the stats  */
  /* and exit program if t_start >= t_stop.                                   */
  t_start_copy = t_start;
  t_stop_copy = t_stop;
  time_span = (int)ceil(difftime(mktime(&t_stop_copy), mktime(&t_start_copy)) \
              / 900) + 1;
  if(time_span <= 1)
    return(-5);

  /***** Increase execution time by searching for the start date. *****/
  /* This code ain't pretty but does the job fairly good... */
  if(!use_first_entry) {
    logfile_size = ftell(fp);
    t_temp = t_first_entry;
    t_start_copy = t_start;

    /* Move the filepointer near the start date. */
    fseek(fp, logfile_size * difftime(mktime(&t_start_copy), mktime(&t_temp)) \
          / difftime(mktime(&t_temp_3), mktime(&t_first_entry)), SEEK_SET);
    if(ftell(fp) > 10000) {
      /* Read a line in the log and check the date. */
      t_temp = t_start;
      fgets(buffer, 511, fp);
      fgets(buffer, 511, fp); /* Do it twice or seg fault. */
      sscanf(buffer, "%*s%s%2d%2d%*1s%2d%*1s%2d%4d%*s[^/n]", month_str, &day, \
             &hour, &min, &sec, &year);
      t_start_copy.tm_year = year - 1900;
      t_start_copy.tm_mon = month_string_to_int(month_str);
      t_start_copy.tm_mday = day;
      t_start_copy.tm_hour = hour;
      t_start_copy.tm_min = min;
      t_start_copy.tm_sec = sec;
      t_start_copy.tm_isdst = 0;

      /* See if the date in the log is beyond the start date */
      qwerty = (long)difftime(mktime(&t_temp), mktime(&t_start_copy));
      /* Find the start date by moving the fp backwards */
      while(qwerty < 0) {
        fseek(fp, -10000, SEEK_CUR);
        fgets(buffer, 511, fp);
        fgets(buffer, 511, fp); /* Do it twice or seg fault. */
        sscanf(buffer, "%*s%s%2d%2d%*1s%2d%*1s%2d%4d%*s[^/n]", month_str, &day, \
               &hour, &min, &sec, &year);
        t_start_copy.tm_year = year - 1900;
        t_start_copy.tm_mon = month_string_to_int(month_str);
        t_start_copy.tm_mday = day;
        t_start_copy.tm_hour = hour;
        t_start_copy.tm_min = min;
        t_start_copy.tm_sec = sec;
        t_start_copy.tm_isdst = 0;
        t_temp = t_start;
        qwerty = (long)difftime(mktime(&t_temp), mktime(&t_start_copy));
        if(ftell(fp) < 50000) {
          rewind(fp);
          break;
        }
      }
    }
    else
      rewind(fp);
  }
  else
    rewind(fp);

  no_of_users = argc - 11;

  /* Allocate an array in which all stats will be stored. */
  if((stat_array = calloc(no_of_users * time_span, sizeof(unsigned long))) == \
     NULL)
    return(-6);

  /* Start reading the file. Stop at EOF. */
  while(fgets(buffer, 511, fp) != NULL) {
    sscanf(buffer, \
           "%*s%s%2d%2d%*1s%2d%*1s%2d%4d%*s%*s%ld%*s%*s%*s %c%*s%s%s%*[^/n]", \
           month_str, &day, &hour, &min, &sec, &year, &filesize, &ul_or_dl, \
           username, groupname);
    month = month_string_to_int(month_str);

    if((year > t_start.tm_year + 1900) || ((year == t_start.tm_year + 1900) && \
       (month > t_start.tm_mon)) || ((year == t_start.tm_year + 1900) && \
       (month == t_start.tm_mon) && (day > t_start.tm_mday)) || \
       ((year == t_start.tm_year + 1900) && (month == t_start.tm_mon) && \
       (day == t_start.tm_mday) && (hour >= t_start.tm_hour))) {
      if((strcmp(argv[9], "-ul") == 0) && (strncmp(&ul_or_dl, "i", 1) == 0))
        total_up_dn += filesize / 1024;
      else if((strcmp(argv[9], "-dl") == 0) && (strncmp(&ul_or_dl, "o", 1) == \
              0))
        total_up_dn += filesize / 1024;
    }

    /* Stop reading the log and call write_stats() if end time has passed. */
    if((year > t_stop.tm_year + 1900) || ((year == t_stop.tm_year + 1900) && \
       (month > t_stop.tm_mon)) || ((year == t_stop.tm_year + 1900) && \
       (month == t_stop.tm_mon) && (day > t_stop.tm_mday)) || \
       ((year == t_stop.tm_year + 1900) && (month == t_stop.tm_mon) && \
       (day == t_stop.tm_mday) && (hour >= t_stop.tm_hour))) {
      if(use_last_entry)
        use_last_entry = 2;
      else {
        if(write_stats(stat_array, no_of_users, &t_start, &t_stop, time_span, \
           argv, total_up_dn) != 0)
          return(-7);
        break;
      }
    }

    /* Loop through every user/group. */
    for(i = 0; i < argc - 11; i++) {
      /* Check if user/group in log matches one given as a parameter. */
      if(((strcmp(argv[10], "-u") == 0) && \
        (strcmp(argv[i + 11], username) == 0)) || \
        ((strcmp(argv[10], "-g") == 0)  && \
        (strcmp(argv[i + 11], groupname) == 0))) {
        /* Continue if date in log >= start_time, else read next line in log. */
        if((year > t_start.tm_year + 1900) || ((year == t_start.tm_year + 1900)\
           && (month > t_start.tm_mon)) || ((year == t_start.tm_year + 1900) &&\
           (month == t_start.tm_mon) && (day > t_start.tm_mday)) || \
           ((year == t_start.tm_year + 1900) && (month == t_start.tm_mon) && \
           (day == t_start.tm_mday) && (hour >= t_start.tm_hour))) {
          /* Only process uploads. */
          if((strcmp(argv[9], "-ul") == 0) && (strncmp(&ul_or_dl, "i", 1) == 0 \
             )) {
            t_start_copy = t_start;
            if(strcmp(argv[10], "-u") == 0)
              for(k = 0; (strcmp(argv[11 + k], username) != 0); k++) {
              }
            else
              for(k = 0; (strcmp(argv[11 + k], groupname) != 0); k++) {
              }
            offset = k * time_span + time_convert(&t_start_copy, buffer);
            /* Exit if we are about to write to uninitialized memory. */
            if(offset > no_of_users * time_span)
              return(-8);
            if(offset != -1)
              stat_array[offset] += filesize;
          }
          /* Only process downloads. */
          else if((strcmp(argv[9], "-dl") == 0) && (strncmp(&ul_or_dl, "o", 1) \
                  == 0)) {
            t_start_copy = t_start;
            if(strcmp(argv[10], "-u") == 0)
              for(k = 0; (strcmp(argv[11 + k], username) != 0); k++) {
              }
            else
              for(k = 0; (strcmp(argv[11 + k], groupname) != 0); k++) {
              }
            offset = k * time_span + time_convert(&t_start_copy, buffer);
            /* Exit if we are about to write to uninitialized memory. */
            if(offset > no_of_users * time_span)
              return(-8);
            if(offset != -1)
              stat_array[offset] += filesize;
          }
        }
      }
    }
    if(use_last_entry == 2) {
      if(write_stats(stat_array, no_of_users, &t_start, &t_stop, time_span, \
         argv, total_up_dn) != 0)
        return(-7);
      break;
    }
  }
  free(stat_array);
  fclose(fp);
  return(0);
}


/******************************************************************************* 
* month_string_to_int() converts the month name from a string to its           *
* corresponding number.                                                        *
*                                                                              *
* param 1: A string containing the month name in 3-char format (Jan, Feb...).  *
* returns: The number of the month (Jan=0, Feb=1, Mar=2...).                   *
*******************************************************************************/
int month_string_to_int(char *month_string) {
  char *p = all_months, month;

  for(month=0; ; p += 3, month++)
    if(memcmp(month_string, p, 3) == 0)
      break;
  return(month);
}


/*******************************************************************************
* time_convert() calculates the time offset (in 15min intervals) between the   *
* last read line from the log and the first.                                   *
*                                                                              *
* param 1: A pointer to a struct holding the date of the first data.           *
* param 2: A pointer to a string containing the last read line of the log.     *
* returns: The time offset between the current and the first line of the log.  *
*******************************************************************************/
int time_convert(struct tm *t_start_copy, char *buffer) {
  char month_str[5];
  int year, day, hour, min;
  struct tm t_buffer;

  sscanf(buffer, "%*s%s%2d%2d%*1s%2d%*1s%*s%4d%*s%*s%*s%*s%*s%*s%*s%*s[^/n]",
         month_str, &day, &hour, &min, &year);
  t_buffer.tm_year = year - 1900;
  t_buffer.tm_mon = month_string_to_int(month_str);
  t_buffer.tm_mday = day;
  t_buffer.tm_hour = hour;
  t_buffer.tm_min = min;
  t_buffer.tm_sec = 0;
  t_buffer.tm_isdst = 0;
  /* BUGALERT - the expression below sometimes caues a bug with tzfile. */
  return((int)(difftime(mktime(&t_buffer), mktime(t_start_copy)) / 900));
}


/*******************************************************************************
* write_stats() converts the data stored in the array to an image.             *
*                                                                              *
* param 1: A pointer to a string containing all the filesize data.             *
* param 2: The number of users whos data is in the filesize data.              *
* param 3: A pointer to a struct holding the date of the first filesize data.  *
* param 4: The time span of the filesize data.                                 *
* param 5: A pointer to the parameters that was passed to the program.         *
* returns: -                                                                   *
*******************************************************************************/
int write_stats(unsigned long *stat_array, int no_of_users, struct tm *t_start, 
                struct tm *t_stop, long time_span, char **argv, \
                unsigned long total_up_dn) {
  gdImagePtr im;
  unsigned char text[55], vertical_string[6], resolution_string[50], padding=0,
                padding_str[26], temppp[30], color_array[] = {0xFF,0x00,0x00,
                0xFF,0x00,0xFF,0x00,0x00,0xFF,0x00,0xFF,0xFF,0x00,0xFF,0x00,
                0xFF,0xFF,0x00,0xFF,0x99,0x00,0x66,0x00,0x00,0x66,0x00,0x66,
                0x00,0x00,0x66,0x00,0x66,0x66,0x00,0x66,0x00,0x66,0x66,0x00,
                0x00,0x00,0x00};
  char *vertical_unit, *buffer, month_str[4];
  int year, day, i, j, k, counter=0, resolution=0, interval, offset, SAMPLES_, 
      background, text_color, line_color, x_prev, y_prev, pixels_byte_ratio,
      scale_factor=1;
  unsigned long average=0, maximum_average=0, total_stat;
  float pixels_per_hour, increment, temp;
  struct tm t_temp;

  /* Create the picture and set the background and the text color. */
  im = gdImageCreate(PICTURE_X, PICTURE_Y);
  background = gdImageColorAllocate(im, 204, 204, 153);
  text_color = gdImageColorAllocate(im, 0, 0, 0);

  pixels_per_hour = (PICTURE_X - X_CLEARANCE) * 4 / (float)time_span;

  /***** Draw vertical grid for small time spans (<48h) *****/
  if(time_span <= 192) {
    scale_factor = 4;
    if(time_span <= 96)
      scale_factor = 2;
    if(time_span <= 24)
      scale_factor = 1;

    /* Draw a vertical line and write its corresponding date. */
    interval = pixels_per_hour * scale_factor;
    t_temp.tm_hour = t_start->tm_hour;
    for(i = interval, j = 0; i - interval < (PICTURE_X - X_CLEARANCE); \
        i += interval, j++) {
      gdImageLine(im, i - interval + X_CLEARANCE, Y_ORIGIN, \
                  i - interval + X_CLEARANCE, 0, text_color);
      t_temp.tm_hour += scale_factor;
      if(t_temp.tm_hour > 24 + scale_factor)
        t_temp.tm_hour = t_temp.tm_hour - 24;
      sprintf(text, "%d", t_temp.tm_hour - scale_factor);
      gdImageString(im, gdFontLarge, i - interval + X_CLEARANCE - \
                    (strlen(text) * gdFontLarge->w / 2), Y_ORIGIN + 3, text, \
                    text_color);
    }
  }

  /***** Draw vertical grid for "normal" time spans (2-49days) *****/
  else if(time_span <= 5376) {
    /* Find the resolution that gives about 7 vertical lines/dates. */
    for(scale_factor = 1; 6 < time_span / (96 * scale_factor); scale_factor++) {
    }

    /* Draw a vertical line and write its corresponding date. */
    interval = pixels_per_hour * 24 * scale_factor;
    for(i = interval, j = 0; i - interval < (PICTURE_X - X_CLEARANCE); \
        i += interval, j++) {
      gdImageLine(im, i - interval + X_CLEARANCE, Y_ORIGIN, i - interval + \
                  X_CLEARANCE, 0, text_color);
      t_temp.tm_year = t_start->tm_year;
      t_temp.tm_mon = t_start->tm_mon;
      t_temp.tm_mday = t_start->tm_mday;
      t_temp.tm_hour = t_start->tm_hour;
      t_temp.tm_min = t_start->tm_min;
      t_temp.tm_mday += scale_factor * j;
      mktime(&t_temp);
      buffer = asctime(&t_temp);
      sscanf(buffer, "%*s%s%d%*d:%*d:%*d%d", month_str, &day, &year);
      sprintf(text, "%d-%d-%d", year, month_string_to_int(month_str) + 1, day);
      gdImageString(im, gdFontLarge, i - interval + X_CLEARANCE - \
                    (strlen(text) * gdFontLarge->w / 2), Y_ORIGIN + 3, text, \
                    text_color);
    }
    /* The lines below fixes a problem with displaying the start date. */
    sprintf(text, " %d-%d-%d ", t_start->tm_year + 1900, t_start->tm_mon + 1, \
            t_start->tm_mday);
    gdImageFilledRectangle(im, X_CLEARANCE - (strlen(text) * \
                           gdFontLarge->w / 2), Y_ORIGIN + 3, X_CLEARANCE + \
                           (strlen(text) * gdFontLarge->w / 2), Y_ORIGIN + 3 + \
                           gdFontLarge->h, background);
    gdImageString(im, gdFontLarge, X_CLEARANCE - (strlen(text) * \
                  gdFontLarge->w / 2), Y_ORIGIN + 3, text, text_color);
  }

  /***** Draw vertical grid for high time spans (>8 weeks) *****/
  else if(time_span > 5376) {
    /* Find the resolution that gives about 7 vertical lines. */
    for(scale_factor = 1; 6 < time_span/(96 * scale_factor * 7); \
        scale_factor++) {
    }

    /* Calculate the offset between the start_time and 00.00 monday morning. */
    t_temp.tm_year = t_start->tm_year;
    t_temp.tm_mon = t_start->tm_mon;
    t_temp.tm_mday = t_start->tm_mday;
    t_temp.tm_hour = t_start->tm_hour;
    t_temp.tm_min = t_start->tm_min;
    mktime(&t_temp);
    offset = (t_temp.tm_wday - 1) * 24 + t_start->tm_hour;
    /* wday is calculated from sunday, not monday so step back almost a week. */
    if(offset < 0)
      offset = offset + 168;

    /* Draw a vertical line and write its corresponding date. */
    interval = pixels_per_hour * 24 * 7 * scale_factor;
    for(i = interval, j = 0; i - interval < (PICTURE_X - X_CLEARANCE); \
        i += interval, j++) {
      gdImageLine(im, i - interval + X_CLEARANCE, Y_ORIGIN, i - interval + \
                  X_CLEARANCE, 0, text_color);
      t_temp.tm_year = t_start->tm_year;
      t_temp.tm_mon = t_start->tm_mon;
      t_temp.tm_mday = t_start->tm_mday;
      t_temp.tm_hour = t_start->tm_hour;
      t_temp.tm_min = t_start->tm_min;
      t_temp.tm_mday += scale_factor * j * 7;
      mktime(&t_temp);
      buffer = asctime(&t_temp);
      sscanf(buffer, "%*s%s%d%*d:%*d:%*d%d", month_str, &day, &year);
      sprintf(text, "%d-%d-%d", year, month_string_to_int(month_str) + 1, day);
      gdImageString(im, gdFontLarge, i - interval + X_CLEARANCE - \
                    (strlen(text) * gdFontLarge->w / 2), Y_ORIGIN + 3, text, \
                    text_color);
    }
  }

  /* Adjust a little if there are less stats than SAMPLES. */
  SAMPLES_ = SAMPLES;
  if(SAMPLES_ > no_of_users * time_span)
    SAMPLES_ = no_of_users * time_span;

  /* resolution is the number of consecutive stats to average together. */
  if(time_span/SAMPLES_ < 1) {
    resolution = 1;
    SAMPLES_ = time_span;
  }
  else {
    /* Try to find the best integer values for SAMPLES_ and resolution (the   */
    /* values that makes SAMPLES_*resolution be as near as possible to        */
    /* time_span without deviating to much from "#define SAMPLES").           */
    for(temp = 0.1; temp < 0.9 && temp >= 0 && SAMPLES_ != 0; SAMPLES_--)
      temp=ceil((float)time_span / SAMPLES_) - (float)time_span / SAMPLES_;

    /* Avoid a divide-by-zero error */
    if(SAMPLES_ == 0)
      SAMPLES_ = SAMPLES;
    if(temp == 0)
      temp = 1;

    SAMPLES_ = (int)(SAMPLES_ * temp);
    resolution = time_span / SAMPLES_;

    while(SAMPLES_ * resolution < time_span * 0.99) {
      if(SAMPLES_ < resolution || SAMPLES_ >= PICTURE_X)
        resolution++;
      else
        SAMPLES_++;
    }

    while(SAMPLES_ * resolution > time_span) {
      if(SAMPLES_ > resolution || SAMPLES_ < 2)
        resolution--;
      else
        SAMPLES_--;
    }

    if(SAMPLES_ == 0 || resolution == 0) {
      SAMPLES_ = no_of_users * time_span;
      resolution = 1;
    }
  }

  if(resolution < 5)
    sprintf(resolution_string, "Statistics are averaged in about %d minutes "
            "intervals", resolution * 15);
  else
    sprintf(resolution_string, "Statistics are averaged in about %d hours "
            "intervals", resolution / 4);
  gdImageString(im, gdFontLarge, X_CLEARANCE, PICTURE_Y - 20, \
                resolution_string, text_color);

  /* increment is the number of pixels per sample to be shown in the image. */
  increment = (float)(PICTURE_X - X_CLEARANCE) / SAMPLES_;

  /* Find the maximum average in kB. */
  for(counter = 0; counter < no_of_users; counter++) {
    for(i = 0; i < SAMPLES_; i++) {
      for(j = 0, average = 0; j < resolution; j++) {
        average += stat_array[counter * time_span + i * resolution + j] / 1024;
        if(average > maximum_average)
          maximum_average = average;
      }
      /* Make shure the last stats for every user is accounted for. */
      if(i == SAMPLES_ - 1) {
        for(k = counter * time_span + i * resolution + j; k <= time_span; k++)
          average += stat_array[k] / 1024;
      }
      if(average > maximum_average)
        maximum_average = average;
    }
  }

  if(maximum_average / 100 == 0)
    return(-1);

  /* Calculate and draw the horisontal grid (.1MB, 1MB, 10MB, 100MB). */
  if(maximum_average < 1024) {           /* 100kB resolution. */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 10);
    vertical_unit = "   0kB 100kB 200kB 300kB 400kB 500kB 600kB 700kB 800kB "
                    "900kB";
  }
  else if(maximum_average < 10240) {     /* 1MB resolution.   */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 1);
    vertical_unit = "   0MB   1MB   2MB   3MB   4MB   5MB   6MB   7MB   8MB "
                    "  9MB";
  }
  else if(maximum_average < 102400) {    /* 10MB resolution.  */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 0.1);
    vertical_unit = "   0MB  10MB  20MB  30MB  40MB  50MB  60MB  70MB  80MB "
                    " 90MB";
  }
  else if(maximum_average < 1024000) {   /* 100MB resolution. */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 0.01);
    vertical_unit = "   0MB 100MB 200MB 300MB 400MB 500MB 600MB 700MB 800MB "
                    "900MB";
  }
  else if(maximum_average < 10240000) {  /* 1GB resolution.    */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 0.001);
    vertical_unit = "   0MB   1GB   2GB   3GB   4GB   5GB   6GB   7GB   8GB "
                    "  9GB";
  }
  else                                {  /* 10GB resolution.   */
    pixels_byte_ratio = 1024 * Y_ORIGIN / (maximum_average * 0.0001);
    vertical_unit = "   0MB  10GB  20GB  30GB  40GB  50GB  60GB  70GB  80GB "
                    " 90GB";
  }

  for(i = 0, j = 0; i < PICTURE_Y; i += pixels_byte_ratio, j++) {
    gdImageLine(im, X_CLEARANCE - 5, PICTURE_Y - i - Y_CLEARANCE, \
                PICTURE_X - 5, PICTURE_Y - i - Y_CLEARANCE, text_color);
    if(j == 0)
      sscanf(vertical_unit, "%6c", vertical_string);
    else if(j == 1)
      sscanf(vertical_unit, "%*s%6c", vertical_string);
    else if(j == 2)
      sscanf(vertical_unit, "%*s%*s%6c", vertical_string);
    else if(j == 3)
      sscanf(vertical_unit, "%*s%*s%*s%6c", vertical_string);
    else if(j == 4)
      sscanf(vertical_unit, "%*s%*s%*s%*s%6c", vertical_string);
    else if(j == 5)
      sscanf(vertical_unit, "%*s%*s%*s%*s%*s%6c", vertical_string);
    else if(j == 6)
      sscanf(vertical_unit, "%*s%*s%*s%*s%*s%*s%6c", vertical_string);
    else if(j == 7)
      sscanf(vertical_unit, "%*s%*s%*s%*s%*s%*s%*s%6c", vertical_string);
    else if(j == 8)
      sscanf(vertical_unit, "%*s%*s%*s%*s%*s%*s%*s%*s%6c", vertical_string);
    else if(j == 9)
      sscanf(vertical_unit, "%*s%*s%*s%*s%*s%*s%*s%*s%*s%6c", vertical_string);
    vertical_string[6] = '\0';
    gdImageString(im, gdFontLarge, 0, PICTURE_Y - i - Y_CLEARANCE - 8, \
                  vertical_string, text_color);
  }

  /* Find the length of the longest username. */
  padding = strlen(argv[11]);
  for(i = 0; i < no_of_users; i++) {
    if(i && strlen(argv[i + 11]) > padding)
      padding = strlen(argv[i + 11]);
  }

  /* Loop through each user, one at a time. */
  for(counter = 0; counter < (no_of_users * 3); counter += 3) {
    /* Get the color to be used when displaying the current user. */
    line_color = gdImageColorAllocate(im, color_array[counter], \
                                      color_array[counter + 1], \
                                      color_array[counter + 2]);

    /* Get the up/dn stat string for the current user. */
    strcpy(temppp, argv[11 + counter / 3]);
    for(i = 0; i < padding - strlen(argv[11 + counter / 3]); i++)
      temppp[i + strlen(argv[11 + counter / 3])]=' ' ;
    temppp[padding] = '\0';
    for(i = 0, total_stat = 0; i < time_span; i++)
      total_stat += stat_array[i + counter / 3 * time_span] / 1024;
    if(total_stat < 10000)
      sprintf(padding_str, " %ld kB (%.1f%%)", total_stat, (float)total_stat / \
              total_up_dn * 100);
    else if(total_stat < 10000000)
      sprintf(padding_str, " %ld MB (%.1f%%)", total_stat / 1024, \
              (float)total_stat / total_up_dn * 100);
    else
      sprintf(padding_str, " %ld GB (%.1f%%)", total_stat / 1048576, \
              (float)total_stat / total_up_dn * 100);
    sprintf(text, "%s %s", temppp, padding_str);

    /* Write the users stat. */
    gdImageLine(im, X_CLEARANCE, 43 + counter * 5, 10 + X_CLEARANCE, \
                43 + counter * 5, line_color);
    gdImageString(im, gdFontLarge, 18 + X_CLEARANCE, 35 + counter * 5, text, \
                  text_color);

    /* Loop through the current user and draw his stats. */
    for(average = 0, i = 0, x_prev = 0, y_prev = 0; i < SAMPLES_; i++) {
      x_prev = increment * i;
      y_prev = (int)((float)average / (float)maximum_average * Y_ORIGIN);

      /* Calculate the average stat within the resolution. */
      for(average = 0, j = 0; j < resolution; j++) {
        average += stat_array[i * resolution + j + counter / 3 * time_span] / \
                   1024;

        /* Make shure the last stats for every user is shown */
        if(i == SAMPLES_ - 1 && j == resolution - 1) {
          for(k = resolution * SAMPLES_; k <= time_span; k++)
            average += stat_array[k + time_span * counter / 3] / 1024;
        }
      }

      /* Draw a line between the previous stat and the current. */
      gdImageLine(im, x_prev + X_CLEARANCE, Y_ORIGIN - y_prev, x_prev + \
                  X_CLEARANCE + increment, Y_ORIGIN - (int)((float)average / \
                  (float)maximum_average * (Y_ORIGIN)), line_color);
    }
  }

  /* Write the total ul/dl. */
  if(strcmp(argv[9], "-ul") == 0) {
    if(total_up_dn < 10000)
      sprintf(text, "Total upload: %ld kB", total_up_dn);
    else if(total_up_dn < 10000000)
      sprintf(text, "Total upload: %ld MB", total_up_dn / 1024);
    else
      sprintf(text, "Total upload: %ld GB", total_up_dn / 1048576);
  }
  else if(strcmp(argv[9], "-dl") == 0) {
    if(total_up_dn < 10000)
      sprintf(text, "Total download: %ld kB", total_up_dn);
    else if(total_up_dn < 10000000)
      sprintf(text, "Total download: %ld MB", total_up_dn / 1024);
    else
      sprintf(text, "Total download: %ld GB", total_up_dn / 1048576);
  }
  gdImageString(im, gdFontLarge, 10 + X_CLEARANCE, 20, text, text_color);

  /* Write the headline. */
  if(strcmp(argv[10], "-u") == 0 && strcmp(argv[9], "-ul") == 0)
    sprintf(text, "User upload statistics from %d-%d-%d to %d-%d-%d", \
            t_start->tm_year + 1900, t_start->tm_mon + 1, t_start->tm_mday, \
            t_stop->tm_year + 1900, t_stop->tm_mon + 1, t_stop->tm_mday);
  else if(strcmp(argv[10], "-u") == 0 && strcmp(argv[9], "-dl") == 0)
    sprintf(text, "User download statistics from %d-%d-%d to %d-%d-%d", \
            t_start->tm_year + 1900, t_start->tm_mon + 1, t_start->tm_mday, \
            t_stop->tm_year + 1900, t_stop->tm_mon + 1, t_stop->tm_mday);
  else if(strcmp(argv[10], "-g") == 0 && strcmp(argv[9], "-ul") == 0)
    sprintf(text, "Group upload statistics from %d-%d-%d to %d-%d-%d", \
            t_start->tm_year + 1900, t_start->tm_mon + 1, t_start->tm_mday, \
            t_stop->tm_year + 1900, t_stop->tm_mon + 1, t_stop->tm_mday);
  else if(strcmp(argv[10], "-g") == 0 && strcmp(argv[9], "-dl") == 0)
    sprintf(text, "Group download statistics from %d-%d-%d to %d-%d-%d", \
            t_start->tm_year + 1900, t_start->tm_mon + 1, t_start->tm_mday, \
            t_stop->tm_year + 1900, t_stop->tm_mon + 1, t_stop->tm_mday);
  gdImageFilledRectangle(im, PICTURE_X / 2 - (strlen(text) * \
                         gdFontGiant->w / 2) - 3, 5, PICTURE_X / 2 + \
                         (strlen(text) * gdFontGiant->w / 2) + 3, 5 + \
                         gdFontGiant->h, background);
  gdImageString(im, gdFontGiant, PICTURE_X / 2 - (strlen(text) * \
                gdFontGiant->w / 2), 5, text, text_color);

  gdImageLine(im, X_CLEARANCE, Y_ORIGIN, PICTURE_X, Y_ORIGIN, text_color);
  cgiHeaderContentType("image/png");
  gdImagePng(im, cgiOut);
  gdImageDestroy(im);
  return(0);
}
