/*
** oneLiner v0.0.3 (c) pSi
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#define	MAX_MSGS	10
#define	MSG_WIDTH	78
#define	MSG_DELIMITER	'|'

#define	MSGS_FILE	"/var/xftpd/msgs/oneliner.msgs"
#define	HEADER_FILE	"/var/xftpd/msgs/oneliner.top"
#define	FOOTER_FILE	"/var/xftpd/msgs/oneliner.bot"
#define	ONELINER_OUT	"/.oneliner"


void AddOneliner(char *user, char *msg)
{
	char *lines[MAX_MSGS + 1];
	int n, msg_count = 0;
	FILE *file, *file2;

	for(n = 0; n < (MAX_MSGS + 1); n++)
		lines[n] = malloc(256);

	if(file = fopen(MSGS_FILE, "r")) {
		/* there are previous msgs, read them */
		do {
			fgets(lines[msg_count], 256, file);
			if(!feof(file))
				*(lines[msg_count] + strlen(lines[msg_count]) - 1) = '\0';
			msg_count++;
		} while(!feof(file) && (msg_count < MAX_MSGS));

		if(feof(file))
			msg_count--;

		fclose(file);
	}

	/* enter the msg in the next line */
	sprintf(lines[msg_count], "%c<%s> %s", MSG_DELIMITER, user, msg);
	if(strlen(lines[msg_count]) > (MSG_WIDTH - 2)) {
		*(lines[msg_count] + MSG_WIDTH - 2) = MSG_DELIMITER;
		*(lines[msg_count] + MSG_WIDTH - 1) = '\0';
	}
	else {
		for(n = strlen(lines[msg_count]); n < (MSG_WIDTH - 2); n++)
			*(lines[msg_count] + n) = ' ';
		*(lines[msg_count] + n) = MSG_DELIMITER;
		*(lines[msg_count] + n + 1) = '\0';
	} 

	/* check if we have to skip the first msg */
	if(msg_count == MAX_MSGS) {
		for(n = 1; n < (MAX_MSGS + 1); n++)
			strcpy(lines[n-1], lines[n]);
		msg_count--;
	}	

	/* store them */
	file = fopen(MSGS_FILE, "w");
	for(n = 0; n <= msg_count; n++)
		fprintf(file, "%s\n", lines[n]);
	fclose(file);
	chmod(MSGS_FILE, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);

	/* write outfile */
	file = fopen(ONELINER_OUT, "w");
	file2 = fopen(HEADER_FILE, "r");
	
	do {
		fgets(lines[MAX_MSGS], 256, file2);
		if(!feof(file2))
			fprintf(file, "%s", lines[MAX_MSGS]);
	} while(!feof(file2));
	fclose(file2);

	for(n = 0; n <= msg_count; n++)
		fprintf(file, "%s\n", lines[n]);

	file2 = fopen(FOOTER_FILE, "r");
	do {
		fgets(lines[MAX_MSGS], 256, file2);
		if(!feof(file2))
			fprintf(file, "%s", lines[MAX_MSGS]);
	} while(!feof(file2));
	fclose(file2);
	fclose(file);
	chmod(ONELINER_OUT, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);

	for(n = 0; n < (MAX_MSGS + 1); n++)
		free(lines[n]);
}

void main(int argc, char **argv)
{
	char *msg, *user = getenv("XFTP_USERNAME");
	int n, len = 0;

	for(n = 1; n < argc; n++)
		len += strlen(argv[n]) + 1;
	
	msg = malloc(len);
	*msg = '\0';
	for(n = 1; n < argc; n++) {
		strcat(msg, argv[n]);
		strcat(msg, " ");
	}

	AddOneliner(user, msg);
	printf("You entered the following oneliner:\n%s\n", msg);

	free(msg);
}

