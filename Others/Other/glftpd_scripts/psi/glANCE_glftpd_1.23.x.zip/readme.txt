This is a service release to make glANCE somewhat compatible with new glftpd versions,
it only consists of a new DLL.

It was designed for v1.23 but might (and will most likely) work with some older, and the
upcoming version of glftpd.

Simply put glftpd_1.23.x.dll into GLANCE-DIR\DAEMONS, then select the new daemon type
for your already existing sites (Site-Manager, Daemon-Type).

If you still have problems (GPF's, incomplete/wrong user detail detection, ...) then it's
most likely because the site you are trying to admin uses a heavily modified output of
the SITE USER command. glANCE can only find the details about a user by issuing this
command and parsing the output for certain keywords.

One might ask why I didn't use SITE SHOW instead, which gives you a nice machine-readable
output of the users details. The only reason is: You need to be siteop by default in order
to use this command (as it really dumps all of the userfile).
Now you might think thats no problem, I can ask the siteops of my sites where I am groupop
so they change the permission for this command to allow groupops as well...
Think about it - hardly any siteop will do that :P

So unless people flood me with emails to fu**ing put this feature into glANCE, I won't do it
because of all the other users which wouldn't be able to use glANCE in a useful manner anymore.

pSi

