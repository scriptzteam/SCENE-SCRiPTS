#!/bin/sh
# ----------------------------
# --- modify to your shell ---
# ----------------------------

APPBIN=diketraffic
APPPID=.diketraffic.pid
APPPATH=/root/data/code/dike

# ---------------------
# --- end of config ---
# ---------------------

cd $APPPATH
if test -r $APPPATH/$APPPID; then
     PIDNUM=$(cat $APPPATH/$APPPID)
     if $(kill -CHLD $PIDNUM >/dev/null 2>&1)
     then
        exit 0
     fi
     echo ""
     echo "erasing stale dupeserv PID file"
     rm -f $APPPATH/$APPPID
fi

echo ""
echo "application not running, restarting..."
echo ""

if test -x $APPBIN ;then
   $APPPATH/$APPBIN
   exit 0
fi

echo "error restarting application"

