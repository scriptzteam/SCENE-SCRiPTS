/*
** weekTop v0.0.1 (c) pSi
*/

#include <stdio.h>
#include <time.h>

#define	XFERLOG		"/var/log/xftpd/xferlog"
#define	WEEKTOP_OUT	"/FTP/incoming/.message"
#define	WEEKTOP_HEAD	"/FTP/var/xftpd/msgs/week.top"
#define	WEEKTOP_FOOT	"/FTP/var/xftpd/msgs/week.bot"
#define	UNFO_PATH	"/FTP/var/xftpd/unfo/"
#define	LINE_DELIMITER	'|'
#define	LINE_LENGTH	75
#define	USERS_LISTED	10

struct user {
	char name[32];
	unsigned long uploads;
	struct user *next;
};

FILE *file, *file2;
char space[] = "                                                          ";
struct user *head = NULL;

int UseLine(char *mode, char *day)
{
	if(*mode == 'i')
		return(1);
		
	/* for future use */
	return(0);
}

struct user *FindUser(char *user)
{
	struct user *temp = head, *temp1;
	int found = 0;

	if(!temp) {
		/* create the head */
		head = temp = (struct user *)malloc(sizeof(struct user));
		strcpy(&(temp->name[0]), user);
		temp->uploads = 0;
		temp->next = NULL;
	}
	else {
		/* first try to find the name */
		while(temp && !found) {
			if(!strcmp(&(temp->name[0]), user))
				found = 1;
			else {
				temp1 = temp;
				temp = temp->next;
			}
		}

		if(!found) {
			/* we have to create a new entry */
			temp = (struct user *)malloc(sizeof(struct user));
			temp1->next = temp;
			strcpy(&(temp->name[0]), user);
			temp->uploads = 0;
			temp->next = NULL;
		}
	}

	return(temp);
}

void WriteLine(char *user, unsigned long uploads, char *unfo)
{
	int n;
	float temp_up;
	char temp[80], line[80];

	/* format user-name */
	if(strlen(user) > 15)
		*(user + 15) = '\0';
	else
	{
		strcpy(&temp[0], &space[0]);
		strncpy(&temp[0], user, strlen(user));
		temp[15] = '\0';
		strcpy(user, &temp[0]);
	}
	strcpy(&line[0], user);

	/* format the upload size */

	temp_up = (float)uploads / 1024.0;
	
	if(temp_up >= 1024.0) {
		sprintf(&temp[0], "%4.3f", (float)uploads / (1024.0 * 1024.0));
		strcpy(&temp[8], "      .000 GB   ");
	}
	else {
		sprintf(&temp[0], "%4.3f", (float)uploads / 1024.0);
		strcpy(&temp[8], "      .000 MB   ");
	}
	
	strncpy(&temp[18 - strlen(&temp[0])], &temp[0], strlen(&temp[0]));
	strcat(&line[0], &temp[10]);

	/* format tagline */
	if(strlen(unfo) > (LINE_LENGTH - 33))
		*(unfo + LINE_LENGTH - 33) = '\0';
	else {
		strcpy(&temp[0], &space[0]);
		strncpy(&temp[LINE_LENGTH - 33 - strlen(unfo)], unfo, strlen(unfo));
		temp[LINE_LENGTH - 33] = '\0';
		strcpy(unfo, &temp[0]);
	}
	strcat(&line[0], unfo);

	fprintf(file, "%c %s %c\n", LINE_DELIMITER, &line[0], LINE_DELIMITER);
}

void ProcessXferLog(void)
{
	struct user *temp, *temp1, *temp2;
	char line[256], day[10], user[32], dummy[256], mode[5];
	int user_listed = 0, n, dummy_int;
	unsigned long size, max;

	/* read xferlog and build user-db */
	do {
		fgets(&line[0], 256, file);
		if(!feof(file)) {
			/* parse line */
			sscanf(&line[0], "%s %s %d %s %d %s %s %ld %s %s %s %s %s %s %s %s %s", &day[0], &dummy[0], &dummy_int, &dummy[0], &dummy_int, &dummy[0], &dummy[0], &size, &dummy[0], &dummy[0], &dummy[0], &mode[0], &dummy[0], &user[0], &dummy[0], &dummy[0], &dummy[0]);
			if(UseLine(&mode[0], &day[0])) {
				/* this line has a correct date, use it */
				temp = FindUser(&user[0]);
				temp->uploads += size / 1024;
			}
		}
	} while(!feof(file));
	fclose(file);

	file = fopen(WEEKTOP_OUT, "w");
	file2 = fopen(WEEKTOP_HEAD, "r");
	do {
		fgets(&line[0], 256, file2);
		if(!feof(file2))
			fprintf(file, "%s", &line[0]);
	} while(!feof(file2));
	fclose(file2);

	temp = head;
	while(temp) {
		max = temp->uploads;
		temp2 = temp;
		temp1 = head;
		while(temp1) {
			if(temp1->uploads > max) {
				max = temp1->uploads;
				temp2 = temp1;
			}
			temp1 = temp1->next;
		}

		strcpy(&dummy[0], UNFO_PATH);
		strcat(&dummy[0], &(temp2->name[0]));
		if(file2 = fopen(&dummy[0], "r")) {
			fgets(&dummy[0], 256, file2);
			fclose(file2);
		}
		else
			strcpy(&dummy[0], "I am too lame to set my UNFO");

		WriteLine(&(temp2->name[0]), temp2->uploads, &dummy[0]);
		temp2->uploads = 0;
		temp = temp->next;

		user_listed++;
		if(user_listed == USERS_LISTED)
			temp = NULL;
	}

	file2 = fopen(WEEKTOP_FOOT, "r");
	do {
		fgets(&line[0], 256, file2);
		if(!feof(file2))
			fprintf(file, "%s", &line[0]);
	} while(!feof(file2));
	fclose(file2);
	fclose(file);

	/* free user mem */
	temp = head;
	while(temp) {
		temp1 = temp;
		temp = temp->next;
		free(temp1);
	}
}

void main(void)
{
	if(file = fopen(XFERLOG, "r")) {
		ProcessXferLog();
		fclose(file);
	}
}

