#include <stdlib.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <string.h>

#define	VERSION	"v0.9"

pthread_mutex_t	count_lock, print_lock, copy_lock;
pthread_attr_t	thread_attr;
pthread_t	thread_t;

extern int errno;

int port, time_out;
int cnt, thread_count = 0;
FILE	*log;

void print_status(char *msg)
{
	pthread_mutex_lock(&print_lock);
	printf("%s\n", msg);
	fprintf(log, "%s\n", msg);
	pthread_mutex_unlock(&print_lock);
}

int TryConnect(char *ip, int port)
{
	char			data[64], temp[100];
	int			len, sock_fd, okay, dont_print = 0;
	struct	in_addr		ip_address;
	struct	sockaddr_in	peer_addr;
	struct	timeval		timeout;
	fd_set			set;
	
	if(!inet_aton(ip, &ip_address)) {
		perror("Error converting dottet-IP.");
		return(0);
	}

	if((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Unable to create socket.");
		return(0);
	}

	peer_addr.sin_family	= AF_INET;
	peer_addr.sin_port	= htons(port);	// no probing
	peer_addr.sin_addr	= ip_address;
	bzero(&(peer_addr.sin_zero), 8);

	fcntl(sock_fd, F_SETFL, O_NONBLOCK);

	connect(sock_fd, (struct sockaddr *)&peer_addr, sizeof(struct sockaddr));

	FD_ZERO(&set);
	FD_SET(sock_fd, &set);
	timeout.tv_sec = time_out;
	okay = select(FD_SETSIZE, NULL, &set, NULL, &timeout);

	if(okay != 0) {
		// read the welcome data
		strcpy(data, "[CONNECT without MSG]");
		usleep(1500000);	// 1.5 sec time
		len = recv(sock_fd, &data[0], 64, 0);

		if(len >= 0) {
			if(len >= 64)
				data[63] = '\0';
			else
				data[len] = '\0';
		}
		else if(errno == ECONNREFUSED)
			okay = 0;	// refused
		else if(errno != EAGAIN)
			okay = 0;	// bogus
		else
			dont_print = 1;
			
		// now probe for SOCKS host
		if(okay != 0) {
			strcpy(temp, "012");
			temp[0] = 5;
			temp[1] = 1;
			temp[2] = 0;
			
			send(sock_fd, &temp[0], 3, 0);
			temp[0] = 0;
			temp[1] = 10;
			
			usleep(3000000);	// 3.0 sec time
			len = recv(sock_fd, &temp[0], 64, 0);
			
			if((temp[0] == 5) && (temp[1] == 0)) {
				strcpy(data, "* SOCKS5, no restriction");
				dont_print = 0;
			}
			else if((temp[0] == 5) && (temp[1] != 0)) {
				strcpy(data, "- SOCKS5, restricted");
				dont_print = 0;
			}
		}
	}
	else
		data[0] = '\0';

	close(sock_fd);

	if(okay != 0) {
		sprintf(temp, "* %s: %s", ip, data);
		if(dont_print)
			printf("%s\n", temp);
		else
			print_status(temp);
	}
//	else {
//		printf("- %s: refused\n", ip);
//	}
	
	return(okay != 0);	// we could/couldn't connect on the specified port (no probing)
}

void break_handler(int sig)
{
	fclose(log);
	printf("\nAborted. Check the logfile for details.\n\n");
	exit(0);
}

void decrement_count(void)
{
	pthread_mutex_lock(&count_lock);
	thread_count--;
	pthread_mutex_unlock(&count_lock);
}

int get_count(void)
{
	int	cnt;
	
	pthread_mutex_lock(&count_lock);
	cnt = thread_count;
	pthread_mutex_unlock(&count_lock);
	return(cnt);
}

void increment_count(void)
{
	pthread_mutex_lock(&count_lock);
	thread_count++;
	pthread_mutex_unlock(&count_lock);
}

void thread_main(void *th_arg)
{
	char	*ip_str = (char *)th_arg;
	char	ip_string[32];
	
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

	strcpy(ip_string, ip_str);
	pthread_mutex_unlock(&copy_lock);
	
	// do your duty...
	TryConnect(ip_string, port);
	decrement_count();	
}

int main(int argc, char **argv)
{
	int	max_threads, a, b, c, d, a1, b1, c1, d1, a2, b2, c2, d2;
	char	ip_str[32], temp[64];

	printf("mtscan %s - multithread TCP scanner (c) pSi\n", VERSION);

	if(argc != 6) {
		printf("usage: %s <from> <to> <port> <timeout> <threads>\nexample: %s 193.171.0.1 193.171.255.254 21 3 50\n\n", argv[0], argv[0]);
		printf("use of more than 200 threads ain't recommended :)\n");
		exit(0);
	}

	signal(SIGINT, break_handler);
	pthread_mutex_init(&count_lock, NULL);
	pthread_mutex_init(&print_lock, NULL);
	pthread_mutex_init(&copy_lock, NULL);

	pthread_attr_init(&thread_attr);
	pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
	
	max_threads = atoi(argv[5]);
	port = atoi(argv[3]);
	time_out = atoi(argv[4]);
		
	// set range of scan
	sscanf(argv[1], "%d.%d.%d.%d", &a1, &b1, &c1, &d1);
	sscanf(argv[2], "%d.%d.%d.%d", &a2, &b2, &c2, &d2);
	
	sprintf(temp, "log-%s-%s.log", argv[1], argv[2]);
	log = fopen(temp, "w");

	printf("scanning from %d.%d.%d.%d to %d.%d.%d.%d on port %d...\n", a1, b1, c1, d1, a2, b2, c2, d2, port);
	fprintf(log, "scanning from %d.%d.%d.%d to %d.%d.%d.%d on port %d...\n", a1, b1, c1, d1, a2, b2, c2, d2, port);

	a = a1;
	b = b1;
	c = c1;
	d = d1;
	
	do {
		sprintf(ip_str, "%d.%d.%d.%d", a, b, c, d);

		//printf("%d = %s\n", get_count(), ip_str);
		while(get_count() >= max_threads) {
			usleep(50000);
		}
					
		increment_count();
		pthread_mutex_lock(&copy_lock);
		pthread_create(&thread_t, &thread_attr, (void *)thread_main, (void *)ip_str);
		pthread_mutex_lock(&copy_lock);
		pthread_mutex_unlock(&copy_lock);
		
		d += 1;
		if(d >= 255) {
			d = 2;
			c += 1;
			if(c >= 255) {
				c = 2;
				b += 1;
				if(b >= 255) {
					b = 2;
					a += 1;
				}
			}
		}
	} while((d != d2) || (c != c2) || (b != b2) || (a != a2));
	
	do {
		usleep(50000);
		cnt = get_count();
	} while(cnt > 0);
	
	printf("\nReady. Check '%s' for details.\n\n", temp);
	fclose(log);
}
