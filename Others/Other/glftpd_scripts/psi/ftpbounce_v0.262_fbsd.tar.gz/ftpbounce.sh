#!/bin/sh
# ----------------------------
# --- modify to your shell ---
# ----------------------------

APPBIN=ftpbounce
APPPID=ftpbounce.pid
APPPATH=/home/psi/source/ftpbounce

# ---------------------
# --- end of config ---
# ---------------------

cd $APPPATH
if test -r $APPPATH/$APPPID; then
     SERVPID=$(cat $APPPATH/$APPPID)
     if $(kill -CHLD $SERVPID >/dev/null 2>&1)
     then
        exit 0
     fi
     echo ""
     echo "erasing stale application PID file"
     rm -f $APPPATH/$APPPID
fi

echo ""
echo "application not running, restarting..."
echo ""

if test -x $APPBIN ;then
   $APPPATH/$APPBIN
   exit 0
fi

echo "error restarting application"

