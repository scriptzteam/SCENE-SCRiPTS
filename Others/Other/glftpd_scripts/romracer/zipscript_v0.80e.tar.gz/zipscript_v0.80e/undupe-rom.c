/**
	Removes entries from dupelog

	Copyright (C) 2000 ROMRacer <romracer@isonews.com>
**/
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>

struct dupefile {
  char filename[256];
  time_t timeup;
  char uploader[25];
};

int main (int argc, char *argv[]) {
  // Variables
  FILE *fp;
  char dupename[1024], datapath[1024] = "/ftp-data", 
       dupefile[1024];
  int ch;
  
  struct dupefile buffer;
  
  // User better supply a few options  
  if ( (argc < 3) || (argc > 5) || (argc == 4) ) {
    printf("USAGE: %s [switch]\n", argv[0]);
    printf("Switches:\n");
    printf("\t  -f [filename]\n");
    printf("\t  -d [datapath]\n");
    exit(1);
  }

  // Command line parsing
  while ((ch = getopt(argc, argv, "f:d:")) != -1)
    switch (ch) {
    case 'f':
      strncpy(dupename, optarg, 1024);
      break;
    case 'd':
      strncpy(datapath, optarg, 1024);
      break;
    case '?':
    default:
      if ( (argc < 3) || (argc > 5) || (argc == 4) ) {
        printf("USAGE: %s [switch]\n", argv[0]);
        printf("Switches:\n");
        printf("\t  -f [filename]\n");
        printf("\t  -d [datapath]\n");
        exit(1);
      }
    }
  argc -= optind;
  argv += optind;
  
  snprintf(dupefile, sizeof(dupefile), "%s/logs/dupefile", datapath);

  // Opening the data files
  if((fp = fopen(dupefile, "r+b")) == NULL) {
    return 1;
  }

  // While the file is still open
  while (!feof(fp)) {
    if (fread(&buffer, sizeof(struct dupefile), 1, fp) < 1)
      break;
    if (!strcasecmp(dupename, buffer.filename)) {
      fseek(fp, -(sizeof(struct dupefile)), SEEK_CUR);
      buffer.timeup = (time_t)0;
      fwrite(&buffer, sizeof(struct dupefile), 1, fp);
      fflush(fp);
    }
  }

  fclose(fp);
  return 0;
}
