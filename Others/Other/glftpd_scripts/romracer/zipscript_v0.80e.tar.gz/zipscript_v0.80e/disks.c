/* Disks finder (file_id.diz analyzer) by Usurper
   22 July 1999, version 1.2 (now supports PFT releases)
   I started with evilution's code for up.c but I totally
   changed and enhanced it so I doubt you'll find much resemblence
   Nevertheless he deserves some credit :}

   Just run this program in a release dir (best use it with my disks.csh script */ 

/* Output: -1 if .message not found, 0 if disk number not found, or number of disks otherwise.
   Please report problems to theusurper@geocities.com */

#include <string.h>
#include <stdio.h>

FILE *fp;

char is_a_num(char thechar) {

  if (thechar == 'o' || thechar == 'O' || thechar == 'x' || thechar == 'X')
    return '0';
  if (isdigit(thechar))
    return thechar;
  else
    return 'n';
}

void finalize(char *numb) {
  int num = 0;

  numb[2] = '\0';
  num = atoi(numb);
  if (!num) return;
  printf("%d\n", num);
  fclose(fp);
  exit(num);
}

void try_new_format(char *buff) {   /* the new ## x 2.88 format (LND) */
  char number[3];

  if (*(buff-1) != ' ' || *(buff+1) != ' ')
    return;
  if ((number[1] = is_a_num(*(buff-2))) == 'n')
    return;
  if ((number[0] = is_a_num(*(buff-3))) == 'n')
    number[0] = '0';
  finalize(number);
}

void try_pft_format(char *buff) {    /* [1] or [99] used by PFT */
  char number[3];

  if (*(buff-2) != '[' && *(buff-3) != '[') 
    return;
  if ((number[0] = is_a_num(*(buff-2))) != 'n') { /* if there are 2 digits */
    if ((number[1] = is_a_num(*(buff-1))) == 'n') /* get second digit or return */
      return;
  } else {       /* if there is only one digit */
    if ((number[0] = is_a_num(*(buff-1))) == 'n') /* if it's not a digit */
      return;
    number[1] = '\0';
  }
  finalize(number);
}

void try_fallen_format(char *buff) {    /* Fallen has another new invention */
  char number[3];

  if (*(buff-2) != '(' || *(buff+3) != ')' || (number[1] = is_a_num(*(buff-3))) == 'n'
     || (number[0] = is_a_num(*(buff-4))) == 'n') 
    return;
  finalize(number);
}

void try_old_format(char *linestart, char *buff) {  /* the old xx/## format */
  char number[3];

    if (*(buff-3) != ' ' && *(buff-2) != ' ' &&    /* so we don't match Win95/98 */
        *(buff-3) != '[' && *(buff-2) != '[' &&    /* most releases */
        *(buff-3) != '<' && *(buff-2) != '<' &&
        *(buff-3) != '(' && *(buff-2) != '(' &&    /* GLOW and such */
        *(buff-3) != '|' && *(buff-2) != '|' &&    /* FCN */
        *(buff-3) != ':' &&    /* core releases */
        buff-3 >= linestart )   /* in case disk number starts at beginning of line */
      return;
    if ((number[0] = is_a_num(*(++buff))) == 'n')
      return;
    if ((number[1] = is_a_num(*(++buff))) == 'n')
      number[1] = '\0';
    if (isalpha(*++buff) || isdigit(*buff) || *buff == '/')
      return;  /* if this is not the end (as in dates) */
    finalize(number);
}


int main ( void ) {
  char *buff;
  char line[200];
  
  if((fp = fopen(".message", "r")) == NULL) {
    printf("-1\n");
    return -1;
  }
  
  while(!feof(fp)) {
     buff = fgets(line, sizeof(line), fp);
     if (buff == NULL) {
       printf("0\n");
       fclose(fp);
       return 0;
     }
     while(*buff != '\0') {
       if ( *buff == '/' || *buff == '\\')   /* second case is for TRPS releases */
         try_old_format(line,buff);
       else if ( *buff == 'x' || *buff == '*')   /* new format, ## x 2.88 */
         try_new_format(buff);
       else if ( *buff == '.' )   /* as in 01(1.44) */
	 try_fallen_format(buff);
       else if ( *buff == ']' )   /* as in [10] */
         try_pft_format(buff);
       buff++;
     } /* nested while */
  } /* main while */
  fclose(fp);
  printf("0\n");
  return 0;
}

