/*

  ON - THE - FLY  SFV CHECKING for glFtpD, v0.04, 07 July 2000

  Must be called with the following parameters:

  /bin/flysfv filename.rxx localcrc file1.sfv file2.sfv ...

  Usually done within /bin/zipscript using

  cd $2
  /bin/flysfv $1 $3 *.[sS][fF][vV]

  Returns errorlevel 0 if file was OK, 1 if file was bad or not listed or
  no SFV file was found.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>


int main (int argc, char *argv[]) {

  char          filename[150];
  char          localcrc[20];
  int           cnt, argn;
  char          sfvname[150];
  FILE          *sfvfile;
  DIR           *dirp = NULL;
  char          sfvline[250];
  struct dirent *dirinfo;

  if (argc < 4) {
    printf("Usage: %s <filename.rxx> <localcrc> <sfv-file1> [sfv-file2...]\n", argv[0]);
    exit(1);
  }

  strncpy(filename, argv[1], 150);
  for (cnt = 0; cnt < strlen(filename); cnt++)
    filename[cnt] = tolower(filename[cnt]);

  strncpy (localcrc, argv[2], 20);
  for (cnt = 0; cnt < strlen(localcrc); cnt++)
    localcrc[cnt] = tolower(localcrc[cnt]);

  dirp = opendir(".");
  if (dirp == NULL) {
    exit(1);
  }

  argn = 3;
  while (argn < argc) {
    strncpy (sfvname, argv[argn], 150);
    if (sfvname[0] != '*') {
      while ((dirinfo = readdir(dirp)) != NULL) {
        if (!strcasecmp(dirinfo->d_name, sfvname)) {
          strncpy(sfvname, dirinfo->d_name, 150);
          break;
        }
      }
      rewinddir(dirp);

      sfvfile = fopen (sfvname, "rt");
      if (sfvfile == NULL) {
        exit(1);
      }

      while (fgets (sfvline, 250, sfvfile) != NULL) {
        for (cnt = 0; cnt < strlen(sfvline); cnt++)
          sfvline[cnt] = tolower(sfvline[cnt]);
        if (sfvline[0] != ';') {
          if (strstr(sfvline, filename) != NULL) {
            if (strstr(sfvline, localcrc) != NULL) {
              // found
              exit(0);
            } else {
              // no match
              exit(1);
            }
          }
        }
      }

      fclose (sfvfile);
    }
    argn++;
  }

  // never was found
  exit(1);
}
