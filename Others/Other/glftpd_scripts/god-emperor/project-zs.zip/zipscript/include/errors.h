#define		EMPTY_SFV	"SFV-file: BAD!"
#define		EMPTY_FILE	"zero-byte file: Not allowed!"
#define		UNKNOWN_FILE	"%s-file: Not allowed!"				/* %s = file extension	*/
#define		BAD_ZIP		"ZiP integrity - BAD!"
#define 	BANNED_GENRE	"%s is banned here!"				/* %s = genre		*/
#define		BANNED_YEAR	"Releases from %s are not allowed here!"	/* %s = year		*/
#define		BANNED_BITRATE	"%s kbit encodec is not allowed here!"		/* %s = bitrate		*/
#define		SFV_FIRST	"CRC-Check: SFV first!"
#define		ZERO_CRC	"CRC-Check: ERROR!"
#define		BAD_CRC		"CRC-Check: BAD!"
#define		NOT_IN_SFV	"CRC-Check: Not in sfv!"
