#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include "../include/objects.h"

char * genre_s[] = {
	"Blues",		"Classic Rock",		"Country",		"Dance",
	"Disco",		"Funk",			"Grunge",		"Hip-Hop",
	"Jazz",			"Metal",		"New Age",		"Oldies",
	"Other",		"Pop",			"R&B",			"Rap",
	"Reggae",		"Rock",			"Techno",		"Industrial",
	"Alternative",		"Ska",			"Death Metal",		"Pranks",
	"Soundtrack",		"Euro-Techno",		"Ambient",		"Trip-Hop",
	"Vocal",		"Jazz+Funk",		"Fusion",		"Trance",
	"Classical",		"Instrumental",		"Acid",			"House",
	"Game",			"Sound Clip",		"Gospel",		"Noise",
	"Alternative Rock",	"Bass",			"Soul",			"Punk",
	"Space",		"Meditative",		"Instrumental Pop",	"Instrumental Rock",
	"Ethnic",		"Gothic",		"Darkwave",		"Techno Industrial",
	"Electronic",		"Pop Folk",		"Eurodance",		"Dream",
	"Southern Rock",	"Comedy",		"Cult",			"Gangsta",
	"Top40",		"Christian Rap",	"Pop Funk",		"Jungle",
	"Native US",		"Cabaret",		"New Wave",		"Psychadelic",
	"Rave",			"Showtunes",		"Trailer",		"Lo-Fi",
	"Tribal",		"Acid Punk",		"Acid Jazz",		"Polka",
	"Retro",		"Musical",		"Rock & Roll",		"Hard Rock",
	"Folk",			"Folk Rock",		"National Folk",	"Swing",
	"Fast Fusion",		"Bebob",		"Latin",		"Revival",
	"Celtic",		"Bluegrass",		"Avantgarde",		"Gothic Rock",
	"Progressive Rock",	"Psychedelic Rock",	"Symphonic Rock",	"Slow Rock",
	"Big Band",		"Chorus",		"Easy Listening",	"Acoustic",
	"Humour",		"Speech",		"Chanson",		"Opera",
	"Chamber Music",	"Sonata",		"Symphony",		"Booty Bass",
	"Primus",		"Porn Groove",		"Satire",		"Slow Jam",
	"Club",			"Tango",		"Samba",		"Folklore",
	"Ballad",		"Power Ballad",		"Rhytmic Soul",		"Freestyle",
	"Duet",			"Punk Rock",		"Drum Solo",		"Acapella",
	"Euro House",		"Dance Hall",		"Goa",			"Drum & Bass",
	"Club House",		"Hardcore",		"Terror",		"Indie",
	"BritPop",		"Negerpunk",		"Polsk Punk",		"Beat",
	"Christian Gangsta Rap",  "Heavy Metal",	"Black Metal",		"Crossover",
	"Contemporary Christian", "Christian Rock",	"Merengue",		"Salsa",
	"Trash Metal",		"Anime",		"Jpop",			"Synthpop",
	"Unknown"
};

char * fps_s[]		= { "Unknown", "23.976", "24", "25", "29.97", "30", "50", "59.94", "60" };
char * layer_s[]	= { "Unknown", "Layer III", "Layer II", "Layer I" };
char * codec_s[]	= { "Mpeg 2.5", "Unknown", "Mpeg 2", "Mpeg 1" };
char * chanmode_s[]	= { "Stereo", "Joint Stereo", "Dual Channel", "Single Channel", "Unknown" };


/*
 * Updated     : 01.22.2002
 * Author      : Dark0n3
 *
 * Description : Reads height, width and fps from mpeg file.
 *
 */
void mpeg_video(char *f, struct video *video) {
 int		fd;
 unsigned char	header[] = { 0, 0, 1, 179 };
 unsigned char	buf[8];
 short		width = 0;
 short		height = 0;
 unsigned char	aspect_ratio;
 unsigned char	fps = 0;
 short		t = 0;

 fd = open(f, O_RDONLY);

 while ( read(fd, buf, 1) == 1 ) {
	if ( *buf == *(header + t)) {
		t++;
		if ( t == sizeof(header) ) {
			read(fd, buf, 8);
			memcpy(&t, buf, 2);

			t = *(buf + 1) >> 4;
			width = (*buf << 4) + t;
			height = ((*(buf + 1) - (t << 4)) << 4) + *(buf + 2);

			aspect_ratio = *(buf + 3) >> 4;
			fps = *(buf + 3) - (aspect_ratio << 4);
			break;
			}
		} else if ( *buf == 0 ) {
		t = (t == 2 ? 2 : 1);
		} else {
		t = 0;
		}
	}

 video->height = height;
 video->width = width;
 video->fps = fps_s[fps > 8 ? 0 : fps];

 close(fd);
}





/*
 * Updated     : 01.22.2002
 * Author      : Dark0n3
 *
 * Description : Reads height, width and fps from avi file.
 *
 */
char	fps_t[10];
void avi_video(char *f, struct video *video) {
 int		fd;
 unsigned char	buf[56];
 int		fps;

 fd = open(f, O_RDONLY);
 if ( lseek(fd, 32, 0) != -1 &&
	read(fd, buf, 56) == 56 ) {
	memcpy(&fps, buf, 4);
	if ( fps > 0 ) {
		memcpy(&video->width, buf + 32, 4);
		memcpy(&video->height, buf + 36, 4);
		sprintf(fps_t, "%i", 1000000 / fps);
		video->fps = fps_t;
		} else {
		video->height = 0;
		video->width = 0;
		video->fps = fps_s[0];
		}
	}
 close(fd);
};





/* 
 * Updated     : 01.22.2002
 * Author      : Dark0n3
 *
 * Description : Reads MPEG header from file and stores info to 'audio'.
 *
 */
void get_mpeg_audio_info(char *f, struct audio *audio) {
 int		fd;
 int		t_genre;
 int		n;
 int		tag_ok = 0;
 unsigned char	header[4];
 unsigned char	version;
 unsigned char	layer;
 unsigned char	protected = 1;
 unsigned char	t_bitrate;
 unsigned char	t_samplingrate;
 unsigned char	channelmode;
 short		bitrate;
 short		br_v1_l3[]  = { 0, 32, 40, 48,  56,  64,  80,  96, 112, 128, 160, 192, 224, 256, 320, 0 };
 short		br_v1_l2[]  = { 0, 32, 48, 56,  64,  80,  96, 112, 128, 160, 192, 224, 256, 320, 384, 0 };
 short		br_v1_l1[]  = { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 0 };
 short		br_v2_l1[]  = { 0, 32, 48, 56,  64,  80,  96, 112, 128, 144, 160, 176, 192, 224, 256, 0 };
 short		br_v2_l23[] = { 0,  8, 16, 24,  32,  40,  48,  56,  64,  80,  96, 112, 128, 144, 160, 0 };
 unsigned	samplingrate = 0;
 unsigned	sr_v1[] = { 44100, 48000, 32000, 0 };
 unsigned	sr_v2[] = { 22050, 24000, 16000, 0 };
 unsigned	sr_v25[] = { 11025, 12000, 8000, 0 };


 fd = open(f, O_RDONLY);

 n = 2;
 while ( read(fd, header + 2 - n, n) == n ) {
	if ( *header == 255 ) {
		n = 2;
		if (*(header + 1) >= 224) {
			n = 0;
			break;
			} else {
			n = 2;
			}
		} else {
		if (*(header + 1) == 255 ) {
			*header = *(header + 1);
			n = 1;
			} else {
			n = 2;
			}
		}
	};

 if ( n == 0 ) { /* mp3 header */
	*(header + 1) -= 224;

	read(fd, header + 2, 2);

	version = *(header + 1) >> 3;
	layer = (*(header + 1) - (version << 3)) >> 1;
	if ( ! *(header + 1) & 1 ) protected = 0;
	t_bitrate = *(header + 2) >> 4;
	t_samplingrate = *(header + 2) - (t_bitrate << 4) >> 2;
	switch ( version ) {
		case 3:
			samplingrate = sr_v1[t_samplingrate];
			switch ( layer ) {
				case 1:
					bitrate = br_v1_l3[t_bitrate];
					break;
				case 2:
					bitrate = br_v1_l2[t_bitrate];
					break;
				case 3:
					bitrate = br_v1_l1[t_bitrate];
					break;
				}
			break;
		case 0:
			samplingrate = sr_v25[t_samplingrate];
		case 2:
			if ( ! samplingrate ) {
				samplingrate = sr_v2[t_samplingrate];
				}
			switch ( layer ) {
				case 3:
					bitrate = br_v2_l1[t_bitrate];
					break;
				case 1:
				case 2:
					bitrate = br_v2_l23[t_bitrate];
					break;
				}
			break;
		}
	channelmode = *(header + 3) >> 6;

	sprintf(audio->samplingrate, "%i", samplingrate);
	sprintf(audio->bitrate, "%i", bitrate);
	audio->codec = codec_s[version];
	audio->layer = layer_s[layer];
	audio->channelmode = chanmode_s[channelmode];

	/* ID3 TAG */

	lseek(fd, -128, SEEK_END);
	read(fd, header, 3);
	if ( memcmp(header, "TAG", 3) == 0 ) { /* id3 tag */
		tag_ok = 1;
		read(fd, audio->id3_title, 30);
		read(fd, audio->id3_artist, 30);
		read(fd, audio->id3_album, 30);

		lseek(fd, -35, SEEK_END);
		read(fd, audio->id3_year, 4);
		if ( tolower(audio->id3_year[1]) == 'k' ) {
			memcpy(header, audio->id3_year, 3);
			sprintf(audio->id3_year, "%c00%c", *header, *(header + 2));
			}

		lseek(fd, -1, SEEK_END);
		read(fd, header, 1);
		t_genre = (int)*header;
		if ( t_genre < 0 ) t_genre += 256;
		if ( t_genre > 148 ) t_genre = 148;

		audio->id3_genre = genre_s[t_genre];
		audio->id3_year[4] =
		audio->id3_artist[30] =
		audio->id3_title[30] =
		audio->id3_album[30] = 0;
 		}
	} else { /* header is broken, shouldnt crc fail? */
	strcpy(audio->samplingrate, "0");
	strcpy(audio->bitrate, "0");
	audio->codec = codec_s[1];
	audio->layer = layer_s[0];
	audio->channelmode = chanmode_s[4];
	}

 if ( tag_ok == 0 ) {
	strcpy(audio->id3_year, "0000");
	strcpy(audio->id3_title, "Unknown");
	strcpy(audio->id3_artist, "Unknown");
	strcpy(audio->id3_album, "Unknown");
	audio->id3_genre = genre_s[148];
	}

 close(fd);
}
