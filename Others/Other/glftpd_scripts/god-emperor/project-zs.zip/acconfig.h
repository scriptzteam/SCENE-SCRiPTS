/* Define mysql support */
#undef HAVE_MYSQL

/* Define mysql support */
#undef HAVE_CURSES

