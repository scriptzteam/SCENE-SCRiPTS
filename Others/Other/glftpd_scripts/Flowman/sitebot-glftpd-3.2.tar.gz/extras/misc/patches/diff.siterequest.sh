*** extras/siterequest.sh	Sun Nov 16 22:49:47 2003
--- /glftpd/sitebot/extras/siterequest.sh	Thu Dec  4 11:11:46 2003
***************
*** 5,11 ****
  ## Leave this marked out and it will read the config from the
  ## same directory as tur-request.sh is located. Otherwise you may
! ## specify where it is.
! #config=/glftpd/bin/siterequest.conf
! 
  
  #-[ Script Start ]----------------------------------------------#
--- 5,13 ----
  ## Leave this marked out and it will read the config from the
  ## same directory as tur-request.sh is located. Otherwise you may
! ## specify where it is. Please note that you cannot use absolute
! ## paths here - we need to read the config from both outside and
! ## inside glfptd's chroot.
! #config=./siterequest.conf
! #config=../etc/siterequest.conf
  
  #-[ Script Start ]----------------------------------------------#
***************
*** 19,27 ****
    config="`dirname $0`/siterequest.conf"
  fi
! if [ ! -r $config ]; then
!   echo "Error. Cant not read $config"
    exit 0
  else
!   . $config
  fi
  
--- 21,29 ----
    config="`dirname $0`/siterequest.conf"
  fi
! if [ ! -r `dirname $0`/$config ]; then
!   echo "Error. Cannot read `dirname $0`/$config"
    exit 0
  else
!   . `dirname $0`/$config
  fi
  
