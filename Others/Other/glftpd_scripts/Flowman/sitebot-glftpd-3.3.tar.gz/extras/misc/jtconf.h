//#define DEBUG
/**************************************************************************************
*                                                                                     *
*   JeTrial-C Config file v0.21                                                       *
*                                                                                     *
***************************************************************************************
*                                                                                     *
*   To make your life easier as of 0.19b i've added config changelog for variables    *
*   which have been added or changes, so you can edit your old config and add/change  *
*   a single line instead of re-edit the config file.                                 *
*   However, you should always read the comments, even if you have read them before   *
*   look for changes, and check the default settings...                               *
*   (legend: + added, - removed/changed)                                              *
*                                                                                     *
*   -- JTCONF CHANGELOG --                                                            *
*   v0.21                                                                             *
*   + typo: corret your BOT_TRAIL_* to BOT_TRIAL_ (AI instead of IA)                  *
*   + GLDIR              - new variable, holds the location of glftpd.                *
*   - These variables are now glftpd chrooted-dir (GLDIR) relative, means that you    *
*     need to remove "/glftpd" prefix from the following variables:                   *
*     GLUSERDIR, PASSWDFILE, GROUPFILE, GLFTPDLOG, DELUSER_LOG, BYEFILES_PATH,        *
*     MSG_PATH, EXEMPT_GROUPS_FILE, EXEMPT_GROUPS_DIRS, GROUP_TRIAL_FILE              *
*   This change was made for easier customization and in order to allow running of    *
*   jtc from within glftpd command - and to allow smooth work of untrial              *
*                                                                                     *
*   v0.20                                                                             *
*   + typo: correct your *_CHECK to MONTHUP instead of MONTUP (missing H)             *
*   + EXEMPT_GROUPS_FILE - optional, dynamic list of exempt groups (in a file)        *
*   + EXEMPT_GROUPS_DIRS - optional, dirs which contain subdirs of groups (PREdirs)   *
*   + GROUP_TRIAL_FILE   - optional, if configured requires                           *
*   + BOT_GT_PASSED      - this                                                       *
*   + BOT_GT_FAILED      - and this.                                                  *
*   + theperiod (%s)     - used only for BOT_GT_*                                     *
*   + BOT_EXEMPT_GROUP   - is printed when using -g/-gs option on exempted group(s).  *
*   + BOT_GROUP_NOTFOUND - is printed when using -g grp and grp does not exist        *
*                          or couldnt be found.                                       *
*                                                                                     *
*   v0.19b                                                                            *
*   + BOT_DELETED	 - add it to your old config file when upgrading.             *
*                                                                                     *
**************************************************************************************/

/* GLDIR       - path to your glftpd dir

   The following variables are relative to GLDIR:

   GLUSERDIR   - path to users dir with trailing slash /
   PASSWDFILE  - the passwd file (read only)
   GROUPFILE   - the groups file
   GLFTPDLOG   - path to glftpd.log for daily/weekly/monthly deleted users (see README)
   DELUSER_LOG - (optional, but recommended) if defined, when a user is deleted, 
		 it'll be logged to that file with the following info
		 date, username, group(s), uploaded, minquota (mb required), class
*/

#define GLDIR       "/glftpd"
#define GLUSERDIR   "/ftp-data/users/"
#define PASSWDFILE  "/etc/passwd"
#define GROUPFILE   "/etc/group"
#define GLFTPDLOG   "/ftp-data/logs/glftpd.log"
#define DELUSER_LOG "/ftp-data/logs/jdeluser.log"

/* Bye Files -
     Bye files are files which are displayed when a deleted user logs in 
     and usually shows the reason because of which the user has been deleted.
   ENABLE_BYE_FILE - comment it if you dont want bye files to be written
   BYEFILES_PATH - path to byefiles dir (in ftp-data)
   BYE_MSG - the msg to be written to the file (must not exceed MSG_LEN chars)
   MSG_LEN - maximum char length of BYE_MSG (256 is a good value,
             unless you'r gonna write a book there... keep in mind that
             you need some room for the uploaded and required variables in the text)
*/

#define ENABLE_BYE_FILE
#define BYEFILES_PATH "/ftp-data/byefiles/"
#define BYE_MSG "You have been deleted becuase you have only uploaded %ldMb of out %ldMb required.",uploaded,required
#define MSG_LEN 256

/* Warning Msg - 
     If enabled, a warning msg will be sent to user which is monthly checked
	 ENABLE_WARNING_MSG - comment it with // if you dont want warning message
	 MSG_PATH - the path to the messages dir
	 MSG_DAYS - number of days before the end of the month when message will be sent (1-28)
	 WARNING_MSG - the body of the message
*/

#define ENABLE_WARNING_MSG
#define MSG_PATH "/ftp-data/msgs/"
#define MSG_DAYS 10
#define WARNING_MSG "---------- Warning! -----------\n\
You have not reached minimum quota, you have till the end of the month to comply or be deleted!\n\
This is your first and final warning!"

/* Genereal information about *_GROUPS:

	(+) groups are case INsensitive, (TrIaL==TRIAL==trial) this becuase
		glftpd is case insensitive to group so we want to be compatible dont we?
	(+) (new in 0.18) - GROUPS can have airstrike (*) wildcard in the in the begining or
	the end of the groupname, for example: 
	*Groupa - will allow asdGroupa eretqGroupa etc... (anything ends with Groupa)
	Trial* - will allow trial0708 trialA1BO etc.. (anything begins with Trial)
	*shit* - will allow bullSHiTkk11 (andthing which includes shit)
*/

/* Exempt users  - users who are exempted from upload quota (siteops, freinds)

	EXEMPT_GROUPS - the (static) list groups of exempt users, separated by space
	EXEMPT_FLAGS  - flags of exempt users, NOT separated at all (nor by space)
	EXEMPT_GROUPS_FILE - (optional) path to a file of exempted groups (1 group per line)
	EXEMPT_GROUPS_DIRS - (optional) path to dir(s) which contains subdirectories with
	                     names of groups to be added to exempt list (good for affils).
*/

#define EXEMPT_GROUPS	"siteops glftpd"
#define EXEMPT_FLAGS	"14T"

/* OPTIONAL: EXEMPT_FILE, EXEMPT_DIRS */
#define EXEMPT_GROUPS_FILE	"/ftp-data/jtc/exempt.db"
#define EXEMPT_GROUPS_DIRS	"/site/GROUPS /site/PRE"

/* Trial users  - users from specific groups, are on trial

   TRIAL_GROUPS - Groups of trial users, separated by space
   TRIAL_CHECK  - Type of check, can be DAYUP (daily) WKUP (weekly) MONTHUP (monthly)
   TRIAL_MINMB  - Minimum amount of megabytes to upload per TRIAL_CHECK period
   to disable trial check set TRIAL_GROUPS to "" and TRIAL_MINMB to 0

*/

#define TRIAL_GROUPS	"TriAL"
#define TRIAL_CHECK	"WKUP"
#define TRIAL_MINMB	2000

/* Normal users - users who are not exempt nor trial

   NORMAL_CHECK - Type of check, can be DAYUP (daily) WKUP (weekly) MONTHUP (monthly)
   NORMAL_MINMB - Minimum amount of megabytes to upload per NORMAL_CHECK period
   to disable normal check set NORMAL_MINMB to 0
*/

#define NORMAL_CHECK	"MONTHUP"
#define NORMAL_MINMB	2000

/* Group trial - this new special feature allows you to put a whole group into the trial test!
                 this feature uses a dynamic file, with lists of groups, minimum MB, and checktype,
                 so that you can dynamically add new groups and delete old ones.
                 jetrial-c will add up all users stats who are in a group trial to the total group.
                 if you want to disable this feature (and not even compile it), comment the next var
                 out, if the file you enter here does not exist, it will not use this function but 
                 will compile it in.

   GROUP_TRIAL_FILE - path to the filename which contains trial groups database, file synatax:
                      <groupname> <minmb> <checktype>
                      where checktype is WKUP/MONTHUP/DAYUP, for example: iND 2000 MONTHUP
*/

#define GROUP_TRIAL_FILE "/ftp-data/jtc/groups.db"


/* WEEK_DELDAY - defines the day of which WKUP failed users will be deleted
		 if you use the -e option on glftpd (on inetd/xinetd) set it to 0
		 otherwise, set to 6 (by default)		 
   DAY_DELHOUR - defines the hour of which DAYUP failed users will be deleted
		 23 means, that if you run this prog between 23:00 to 00:00
		 users who are tested and failed per day will be deleted (23 is the best option)
		 22, for example would check between 22:00 to 23:00.
*/
		 
#define WEEK_DELDAY	6
#define DAY_DELHOUR	23


/*****************************************************************************
* .... The string setcion ....                                               *
******************************************************************************
* A small note about the following variables, all of them effect the output  *
* of the program, mostly for the bot which outputs this info, so if you are  *
* too tired to configure these settings, the default provide a fine output   *
* for your channel, of course, you can change it to fit your own style.      *
* note that the "allowed variables" are not cookies, they are variables      *
* some are integers, some are long integers, some are strings, if you have   *
* some background in C, you would have probably guess that the style is      *
* like printf() function (and it sibilings), as a matter of fact, jtc passed *
* these variables directly to printf(VARIABLE).                              *
*****************************************************************************/

/* Bot echo definitions:
	Allowed variables:
	  user (%s) - username
	  group (%s) - users's main group
	  needs (%ld) - the amount of megabytes user needs to complete his quota
	  uploaded (%ld) - the amount of megabytes user has uploaded over min qutoa
	  minqutoa (%ld) - the minimum user quota which user needs to pass in mb
	  daysleft (%d) - number of days left for the user to finish upload period.
	  theperiod (%s) - can be Month, Week, Day
	Usage:
	  "string %?",vara,varb...
	  ex.: "string %s %s %ld %ld %ld...",user,group,needs,uploaded,quota
	
	Note: not all variables are available for all definition, the definitions
	      that do take all variables are BOT_TRIAL_* and BOT_NORMAL_*
*/


/* BOT_NOTFOUND, BOT_DELTED can take: user */
#define BOT_NOTFOUND "notfound^%s",user
#define BOT_DELETED "deleted^%s",user
/* BOT_EXEMPT can take: user, group */
#define BOT_EXEMPT "exempt^%s %s",user,group

/* BOT_EXEMPT_GROUP, BOT_GROUP_NOTFOUND can take: group */
#define BOT_EXEMPT_GROUP "exempt_group^%s",group
#define BOT_GROUP_NOTFOUND "group_notfound^%s",group

/* BOT_GT_* (Optional) can take: theperiod, group, needs ,uploaded ,minquota, daysleft */
#define BOT_GT_PASSED "gt_passed^%s %ld %ld %s",group,uploaded,minquota,theperiod
#define BOT_GT_FAILED "gt_failed^%s %ld %d %ld",group,needs,daysleft,minquota,theperiod

/* BOT_TRIAL_* and BOT_NORMAL_* can take all execpt thepeiord (user, group, needs, uploaded, minquota, daysleft) */
#define BOT_TRIAL_PASSED "trial_passed^%s %s %ld %ld",user,group,uploaded,minquota
#define BOT_TRIAL_PERIOD "trial_period^%s %s %ld %d %ld",user,group,needs,daysleft,minquota
#define BOT_TRIAL_FAILED "trial_failed^%s %s %ld %ld",user,group,needs,minquota

#define BOT_NORMAL_PASSED "passed^%s %s %ld %ld",user,group,uploaded,minquota
#define BOT_NORMAL_PERIOD "period^%s %s %ld %d %ld",user,group,needs,daysleft,minquota
#define BOT_NORMAL_FAILED "failed^%s %s %ld %ld",user,group,needs,minquota


/* Bot untrial definition:
	Allowed variables:
	  g_user (%s) - username
	  g_group (%s) - desired groupname
	Usage:
	  "string %?",vara,varb...
	  ex.: "string %s %s %ld %ld %ld...",g_user,g_group
*/

#define UNTRIAL_EXEMPT "[UNTRiAL] Nice try... choose a non-exempt group will ya ?\n"
#define UNTRIAL_NOTONSITE "[UNTRiAL] The user \002%s\002 is not on site!\n",g_user
#define UNTRIAL_NONTRIAL "[UNTRiAL] Sorry, \002%s\002 is not a trial user.\n",g_user
#define UNTRIAL_NOTPASSED "[UNTRiAL] Sorry, \002%s\002 has not passed the trial, only PASSED users may untrial and get a group!\n",g_user
#define UNTRIAL_SUCCESS "[UNTRiAL] Done, user \002%s\002 has successfuly untrialed into \002%s\002 !\n",g_user,g_group

