#!/bin/bash

# SiteBot installer - 2003 - psxc

VERSION=3.3

############################################################################
# some variables.                                                          #

# Fold output at this number of chars
foldline=77

# These files will be changed in the sitebot dir
tclfiles="sitebot-glftpd.cfg.new extras/siterules.sh extras/sitesearch.sh extras/siterequest.sh extras/siterequest.conf extras/misc/jtconf.h"

# name of the config-file for sitebot
sitebotcfg=sitebot-glftpd.cfg

# name of the api-file for sitebot
sitebotapi=sitebot-glftpd.api

# name of the main tcl file
sitebottcl=sitebot-glftpd.tcl

# location of P-ZS' sources.
zscsource=extras/misc/project-zs-022302.tar.gz

# location of JTC's sources.
jtcsource=extras/misc/jtc-0.21b.tgz

# location of video_info sources.
vidsource=extras/misc/video_info_v0.2beta.tar.gz
vidmake=extras/misc/video_info_Makefile

# This is a tempfile.
tmpfile=/tmp/sitebot-tempfile

#                                                                          #
############################################################################

choose_editor ()
{
# Choose an editor for the user.
 while [ -z "$EDITOROK" ]; do
  if [ ! -z "$EDITOR" ]; then
   EDITOR=`basename $EDITOR`
  else
   if [ ! -z "`which nano`" ]; then
    EDITOR="nano -w"
   elif [ ! -z "`which pico`" ]; then
    EDITOR="pico"
   elif [ ! -z "`which vi`" ]; then
    EDITOR="vi"
   else
    EDITOR=""
   fi
  fi
  clear
  echo ""
  if [ -z "`which $EDITOR`" ]; then
   echo "Could not find your specified editor, or the EDITOR variable is blank."
   echo ""
  fi
  echo -n "During the install-process you need to make some config changes. You should choose a good editor to work in, like pico, vi or aee. Please name your favourite editor. [$EDITOR]> " | fold -s -w $foldline
  read line
  if [ ! -z "$line" ]; then
   EDITOR="$line"
  fi
  if [ ! -z "`which $EDITOR`" ] && [ -x `which $EDITOR` ]; then
   EDITOROK="OK"
  fi
 done

# To read files, 'less' is prefered over 'more'. If none of
# those can be found, use the editor.
 if [ ! -z "`which less`" ]; then
  MYPAGER=`which less`
 elif [ ! -z "`which more`" ]; then
  MYPAGER=`which more`
 else
  MYPAGER=$EDITOR
 fi
}

check_dir ()
{
# Check to see if we're in the correct dir, and that some of the files
# needed exists.
 if [ ! -e sitebot-glftpd.cfg.new ] || [ ! -d extras ]; then
  cd `dirname $0`
 fi
 if [ ! -e sitebot-glftpd.cfg.new ] || [ ! -d extras ]; then
  echo "Please start this script from within the installdir."
  exit 1
 fi
}

find_glpaths ()
{
# Try to find glftpd.conf and the rootpath for glftpd.
 if [ -z "$GLBOTOK" ]; then
  ITYPE="`ps ax | grep inetd`"
  ITYPE=`echo "$ITYPE" | grep -v "ps" | grep -v "grep" | tr ' ' '\n' | grep -e "inetd"`
  ITYPE=`basename $ITYPE`
  if [ "$ITYPE" = "inetd" ]; then
   if [ -e /etc/inetd.conf ]; then
    GLFTPD_CONF="`cat /etc/inetd.conf | grep -e "^glftpd" | grep -e "-r" | sed "s|-r |-r_|" | tr ' ' '\n' | grep -e "-r" | head -n 1 | sed "s|-r_||"`"
   fi
  elif [ "$ITYPE" = "xinetd" ]; then
   if [ -e /etc/xinetd.d/glftpd ]; then
    GLFTPD_CONF="`cat /etc/xinetd.d/glftpd | grep -e "bin/glftpd" | grep -e "-r" | sed "s|-r |-r_|" | tr ' ' '\n' | grep -e "-r" | head -n 1 | sed "s|-r_||"`"
   fi
  fi
  if [ -z "$GLFTPD_CONF" ] || [ ! -e $GLFTPD_CONF ]; then
   GLFTPD_CONF="/etc/glftpd.conf"
  fi
  if [ -e $GLFTP_CONF ]; then
   GLROOT="`cat $GLFTPD_CONF | grep ^rootpath | awk '{print $2}'`"
  fi
  if [ -z "$GLROOT" ] || [ ! -d $GLROOT ]; then
   GLROOT="/glftpd"
  fi
  
  # In case we grabbed the wrong info, let the user verify.
  GLOK=""
  while [ -z "$GLOK" ]; do
   echo ""
   echo -n "Please enter the installdir of glftpd [$GLROOT]> "
   read line
   if [ ! -z $line ]; then
    GLROOT="$line"
   fi
   echo -n "Please enter full path to glftpd.conf [$GLFTPD_CONF]> "
   read line
   if [ ! -z $line ]; then
    GLFTPD_CONF="$line"
   fi
   if [ -d $GLROOT ]; then
    if [ -e $GLFTPD_CONF ]; then
     GLOK="YES"
    fi
   fi
   done
  while [ -z "$GLBOTOK" ]; do
   echo ""
   echo -n "Please enter the full path to the eggdrop dir here: [$GLROOT/sitebot]> " | fold -s -w $foldline
   read line
   if [ -z "$line" ]; then
    GLBOT=$GLROOT/sitebot
   else
    GLBOT=$line
   fi
   if [ ! -d $GLBOT ]; then
    echo "Unable to find a dir named $GLBOT"
   else
    EGGDROP_CONF=eggdrop.conf
    while [ -z "$EGGCONFOK" ]; do
     echo -n "Please enter the path/name of your eggdrop.conf: [$EGGDROP_CONF]> " | fold -s -w $foldline
     read line
     if [ ! -z "$line" ]; then
      EGGDROP_CONF=$line
     fi
     if [ -e $GLBOT/$EGGDROP_CONF ]; then
      EGGCONFOK="OK"
     else
      echo "Unable to find a file named $EGGDROP_CONF in $GLBOT"
     fi
    done
    echo ""
    echo -n "The sitebot tcl files needs to be placed somewhere. Usually, I place them in a dir called \"sitebot\", within the eggdrop's script dir ($GLBOT/scripts/sitebot). Please enter the relative path (ie, without \"$GLBOT\" in front) you wish to install the files, or hit enter for the default. [/scripts/sitebot]> " | fold -s -w $foldline
    read line
    if [ -z "$line" ]; then
     GLBOTPATH=$GLBOT/scripts/sitebot
    else
     GLBOTPATH=$GLBOT$line
    fi
    if [ ! -d $GLBOTPATH ]; then
     echo -n "$GLBOTPATH does not exists. Should I create it? [y]> " | fold -s -w $foldline
     read line
     if [ -z "$line" ] || [ "$line" = "y" ]; then
      mkdir -p $GLBOTPATH
      GLBOTOK="OK"
     fi
    else
     GLBOTOK="OK"
    fi
   fi
  done
 fi
 
 # Get working.
 # First, grab some needed variables from glftpd's config
 GLDATA=`cat $GLFTPD_CONF | grep -e "^datapath" | head -n 1 | awk '{print $2}'`
 GLSITE=`cat $GLFTPD_CONF | grep -e "^min_homedir" | head -n 1 | awk '{print $2}'`
 zscsourcedir=$GLROOT/src
 jtcsourcedir=$GLROOT/src
  echo -n "" >/$tmpfile || { 
   echo "I could not make a temporary file \"$tmpfile\". Cannot continue until this is fixed." | fold -s -w $foldline
   exit 1
 }
 test -w $GLROOT || {
   echo "Unable to write in $GLROOT. Cannot continue until this is fixed." | fold -s -w $foldline
   exit 1
 }
 test -w $GLROOT/bin || {
   echo "Unable to write in $GLROOT/bin. Cannot continue until this is fixed." | fold -s -w $foldline
   exit 1
 }
 test -w $GLBOTPATH || {
   echo "Unable to write in $GLBOTPATH. Cannot continue until this is fixed." | fold -s -w $foldline
   exit 1
 }
}

edit_tcl ()
{
# Time to edit those tcl files.
 if [ -e $GLBOTPATH/$sitebotcfg ]; then
  echo -n "Do you wish to [e]dit $sitebotcfg and $sitebotapi, or [s]kip for now? [e]> " | fold -s -w $foldline
  read line
  if [ ! "$line" = "s" ]; then
   $EDITOR $GLBOTPATH/$sitebotcfg
   $EDITOR $GLBOTPATH/$sitebotapi
  fi
 else
  echo -e "Please install the sitebot before trying to edit the files.\nHit <enter> to continue."
  read line
 fi
}

fix_eggdrop_conf ()
{
 if [ -e $GLBOT/$EGGDROP_CONF ]; then
  clear
  echo ""
  echo -n "I will now modify your $EGGDROP_CONF - is that okay? [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   if [ -z "`cat $GLBOT/$EGGDROP_CONF | grep -e "sourcemissing"`" ]; then
    cat $GLBOT/$EGGDROP_CONF | grep -v "^\ *source\ " >$tmpfile
    echo "#Include your eggdrop sources here" >$tmpfile.2
    echo "set source {" >>$tmpfile.2
    cat $GLBOT/$EGGDROP_CONF | grep -e "^\ *source\ " | tr -s ' ' | sed "s|source|	|g" >>$tmpfile.2
    if [ -z "`cat $tmpfile.2 | grep -e "$sitebottcl"`" ]; then
     scriptpath="`echo $GLBOTPATH | sed "s|$GLBOT/||"`"
     echo "	$scriptpath/$sitebottcl" >>$tmpfile.2
    fi
    echo "}" >>$tmpfile.2
    cat $tmpfile.2 >>$tmpfile
    cat extras/tclerrorcontrol.tcl >>$tmpfile
    cat $GLBOT/$EGGDROP_CONF >`basename $EGGDROP_CONF`.backup
    cat $tmpfile >$GLBOT/$EGGDROP_CONF
    echo "Modification done. The bot should now be sort-of crash free ;)" | fold -s -w $foldline
   else
    echo "Your $EGGDROP_CONF is already modified - skipping." | fold -s -w $foldline
   fi
  fi
  echo ""
  echo "Hit <enter> to continue."
  read line
 fi
}

install_tcl ()
{
# Let's do the tcl stuff.
 clear
 echo ""
 insttcl=""
 if [ -e $GLBOTPATH/$sitebotcfg ]; then
  echo -n "It seems that you have already installed the sitebot. Do you wish to overwrite your current files? [n]> " | fold -s -w $foldline
  read line
  if [ "$line" = "y" ]; then
   insttcl="OK"
  fi
 else
  insttcl="OK"
 fi
 if [ ! -z "$insttcl" ]; then
  echo "... copying files to $GLBOTPATH" | fold -s -w $foldline
   cp -fRp ./ $GLBOTPATH/
   modify_scripts
  echo ""
  echo "You should now edit $sitebotcfg and $sitebotapi - at least verify that most of it looks okay." | fold -s -w $foldline
  chmod -R 700 $GLBOTPATH
  chown -R `ls -1ld $GLBOT | awk '{print $3":"$4}'` $GLBOTPATH
 fi
}

make_zsc ()
{
 if [ -e $zscsourcedir/project-zs/zipscript/conf/zsconfig.h ]; then
  echo ""
  echo -n "Do you wish to make and install Project-ZS? This will compile the c-sources and copy the bins to $GLROOT/bin. [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   homedir=`pwd`
   cd $zscsourcedir/project-zs && ./configure && make && make install && echo "" && echo "done."
   cd $homedir
  fi
 fi
 echo ""
 echo "Please hit <enter> to continue."
 read line
}

edit_zsc ()
{
# Time to edit zsconfig.h.
 if [ -e $zscsourcedir/project-zs/zipscript/conf/zsconfig.h ]; then
  echo -n "Do you wish to [e]dit Project-ZS' config-file (zsconfig.h), or [s]kip for now? [e]> " | fold -s -w $foldline
  read line
  if [ ! "$line" = "s" ]; then
   $EDITOR $zscsourcedir/project-zs/zipscript/conf/zsconfig.h
  fi
 else
  echo -e "Please install Project-ZS before trying to edit the config.\nHit <enter> to continue" | fold -s -w $foldline
  read line
 fi
}

install_zsc ()
{
# project-zs
 clear
 echo ""
 instdzs=""
 if [ -e $zscsourcedir/project-zs/zipscript/conf/zsconfig.h ]; then
  echo -n "It seems that you already have unpacked the sources for Project-ZS. Do you wish to overwrite your current files? [n]> " | fold -s -w $foldline
  read line
  if [ "$line" = "y" ]; then
   instdzs="OK"
  fi
 else
  instdzs="OK"
 fi
 if [ ! -z "$instdzs" ]; then
  echo -e -n "Would you like to set up Project-ZS? [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   while [ -z "$ZSCOK" ]; do
    echo ""
    echo -n "Where should I unpack the sources for Project-ZS? [$zscsourcedir]> " | fold -s -w $foldline
    read line
    if [ ! -z "$line" ]; then
     zscsourcedir=$line
    fi
    if [ ! -d $zscsourcedir ]; then
     echo -n "$zscsourcedir does not exist. Should I create it? [y]> " | fold -s -w $foldline
     read line
     if [ -z "$line" ] || [ "$line" = "y" ]; then
      mkdir -p $zscsourcedir
      ZSCOK="OK"
     fi
    else
     ZSCOK="OK"
    fi
   done
   instdzs=""
   if [ -e $zscsourcedir/project-zs/zipscript/conf/zsconfig.h ]; then
    echo -n "It seems that you already have unpacked the sources for Project-ZS. Do you wish to overwrite your current files? [n]> " | fold -s -w $foldline
    read line
    if [ "$line" = "y" ]; then
     instdzs="OK"
    fi
   else
    instdzs="OK"
   fi
   if [ ! -z "$instdzs" ]; then
    echo "...extracting the sources and making a few changes.." | fold -s -w $foldline
    tar xfz $zscsource -C $zscsourcedir || {
     echo "Unable to extract P-ZS sources."
     exit 1
    }
    glmodify extras/misc/zsconfig.h.patched >$zscsourcedir/project-zs/zipscript/conf/zsconfig.h 
    cat extras/misc/zipscript-c.c.patched >$zscsourcedir/project-zs/zipscript/src/zipscript-c.c
    rm $zscsourcedir/project-zs/zipscript/src/Makefile 2>/dev/null
    glmodify $zscsourcedir/project-zs/zipscript/src/Makefile.in >$tmpfile && cat $tmpfile >$zscsourcedir/project-zs/zipscript/src/Makefile.in
    echo ""
    echo "Project-ZS is extracted, patched with the video_info patch and psxc's nfo_script patch. Both are currently DISABLED in zsconfig.h. Before you enable them, please make sure you know what they do and what is required for them to work." | fold -s -w $foldline
   fi
  fi
 fi
}

make_jtc ()
{
 if [ -e $jtcsourcedir/jtc-0.21b/config/jtconf.h ]; then
  echo ""
  echo -n "Do you wish to make and install JeTrial-C? This will compile the c-sources and copy the bin to $GLROOT/bin. [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   homedir=`pwd`
   cd $jtcsourcedir/jtc-0.21b && make && make install && echo "" && echo "done."
   cd $homedir
  fi
 fi
 echo ""
 echo "Please hit <enter> to continue."
 read line
}

edit_jtc ()
{
# Time to edit jtconf.h.
 if [ -e $jtcsourcedir/jtc-0.21b/config/jtconf.h ]; then
  echo -n "Do you wish to [e]dit JeTrial-C's config-file (jtconf.tcl), or [s]kip for now? [e]> " | fold -s -w $foldline
  read line
  if [ ! "$line" = "s" ]; then
   $EDITOR $jtcsourcedir/jtc-0.21b/config/jtconf.h
  fi
 else
  echo -e "Please install JeTrial-C before trying to edit the config.\nHit <enter> to continue" | fold -s -w $foldline
  read line
 fi
}

install_jtc ()
{
# JeTrial-C
 clear
 echo ""
 instjtc=""
 if [ -e $jtcsourcedir/jtc-0.21b/config/jtconf.h ]; then
  echo -n "It seems that you already have unpacked the sources for JeTrial-C. Do you wish to overwrite your current files? [n]> " | fold -s -w $foldline
  read line
  if [ "$line" = "y" ]; then
   instjtc="OK"
  fi
 else
  instjtc="OK"
 fi
 if [ ! -z "$instjtc" ]; then
  echo -e -n "Would you like to set up JeTrial-C? [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   while [ -z "$JTCOK" ]; do
    echo ""
    echo -n "Where is/should I unpack the sources for JeTrial-C? [$jtcsourcedir]> " | fold -s -w $foldline
    read line
    if [ ! -z "$line" ]; then
     jtcsourcedir=$line
    fi
    if [ ! -d $jtcsourcedir ]; then
     echo -n "$jtcsourcedir does not exist. Should I create it? [y]> " | fold -s -w $foldline
     read line
     if [ -z "$line" ] || [ "$line" = "y" ]; then
      mkdir -p $jtcsourcedir
      JTCOK="OK"
     fi
    else
     JTCOK="OK"
    fi
   done
   instjtc=""
   if [ -e $jtcsourcedir/jtc-0.21b/config/jtconf.h ]; then
    echo -n "It seems that you already have unpacked the sources for JeTrial-C. Do you wish to overwrite your current files? [n]> " | fold -s -w $foldline
    read line
    if [ "$line" = "y" ]; then
     instjtc="OK"
    fi
   else
    instjtc="OK"
   fi
   if [ ! -z "$instjtc" ]; then
    echo "...extracting the sources and making a few changes.." | fold -s -w $foldline
    tar xfz $jtcsource -C $jtcsourcedir || {
     echo "Unable to extract JeTrial-C sources."
     exit 1
    }
    glmodify extras/misc/jtconf.h >$jtcsourcedir/jtc-0.21b/config/jtconf.h 
    glmodify $jtcsourcedir/jtc-0.21b/scripts/grptrial.sh >$GLROOT/bin/grptrial.sh && chmod 755 $GLROOT/bin/grptrial.sh
    cat $jtcsourcedir/jtc-0.21b/scripts/untrial.sh >$GLROOT/bin/untrial.sh && chmod 755 $GLROOT/bin/untrial.sh
    glmodify $jtcsourcedir/jtc-0.21b/Makefile >$tmpfile && cat $tmpfile >$jtcsourcedir/jtc-0.21b/Makefile
    mkdir -p $GLROOT/$GLDATA/jtc && chmod 666 $GLROOT/$GLDATA/jtc
    echo ""
    echo "JeTrial-C is extracted, and the two site-scripts (grptrial.sh and untrial.sh) are modified and copied to $GLROOT/bin. They still need to be set up as commands in your glftpd.conf." | fold -s -w $foldline
   fi
  fi
 fi
}

make_vid ()
{
 if [ -e $vidsource ]; then
  clear
  echo ""
  echo -n "Do you wish to make and install video_info? This will compile the c-sources and copy the bin to $GLROOT/bin. [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   homedir=`pwd`
   cd `dirname $tmpfile` && tar xfz $homedir/$vidsource && \
    cp $homedir/$vidmake video_info_v0.2beta/Makefile && \
    cd video_info_v0.2beta && make && cp video_info $GLROOT/bin && \
    chmod 4755 $GLROOT/bin/video_info && cd .. && \
    rm -fR video_info_v0.2beta && echo "" && echo "done."
   cd $homedir
  fi
 fi
 echo ""
 echo "Please hit <enter> to continue."
 read line
}

make_src ()
{
 if [ -e extras/source/sitebotwho.c ]; then
  clear
  echo ""
  echo -n "Do you wish to make and install file_date, passchk and sitebotwho? This will compile the c-sources and copy the bins to $GLROOT/bin. [y]> " | fold -s -w $foldline
  read line
  if [ -z "$line" ] || [ "$line" = "y" ]; then
   glbin=$GLROOT/bin
   if [ -e extras/source/sitebotwho.c ]; then
    glmodify extras/source/sitebotwho.c >$tmpfile.c && \
     gcc -o ${glbin}/sitebotwho $tmpfile.c && chmod 4755 ${glbin}/sitebotwho && \
     rm -f $tmpfile.c && echo "sitebotwho done."
   fi
   if [ -e extras/source/passchk.c ]; then
    gcc -lcrypt -O2 -o $glbin/passchk extras/source/passchk.c && \
     chmod 4755 ${glbin}/passchk && echo "passchk done."
   fi
   if [ -e extras/source/file_date.c ]; then
    gcc -o $glbin/file_date extras/source/file_date.c && \
     chmod 4755 ${glbin}/file_date && echo "file_date done."
   fi
  fi
 fi
 echo ""
 echo "Please hit <enter> to continue."
 read line
}

glmodify ()
{
 if [ -r $1 ]; then
  cat $1 | tr -d '
' | sed "s|/etc/glftpd.conf|$GLFTPD_CONF|g" | \
   sed "s|/glftpd/|$GLROOT/|g" | sed "s|/glftpd$|$GLROOT|g" | \
   sed "s|/glftpd |$GLROOT |g" | sed "s|/glftpd\"|$GLROOT\"|g" | \
   sed "s|/ftp-data/|$GLDATA/|g" | sed "s|/ftp-data$|$GLDATA|g" | \
   sed "s|/ftp-data |$GLDATA |g" | sed "s|/ftp-data\"|$GLDATA\"|g" | \
   sed "s|/site/|$GLSITE/|g" | sed "s|/site$|$GLSITE|g" | \
   sed "s|/site |$GLSITE |g" | sed "s|/site \"|$GLSITE\"|g"
 else
  return 1
 fi
}

copy_scripts ()
{
 scrlist="sitesearch.sh|y siterequest.conf|y siterequest.sh|y siterules.sh|y siteinvite.sh|y"
 for scrnamed in $scrlist; do
  scrname=`echo $scrnamed | cut -d '|' -f 1`
  scrdo=`echo $scrnamed | cut -d '|' -f 2`
  if [ -e extras/$scrname ]; then
   clear
   echo ""
   echo -n "Do you wish to install the script/file $scrname? [y]> " | fold -s -w $foldline
   read line
   if [ -z "$line" ] || [ "$line" = "y" ]; then
    glbin=$GLROOT/bin
    glmodify extras/$scrname >$tmpfile && \
     cat $tmpfile >${glbin}/$scrname && chmod 4755 ${glbin}/$scrname
    if [ "$scrdo" = "y" ]; then
     echo ""
     echo -n "Do you wish to edit/check the config in $scrname? [y]> " | fold -s -w $foldline
     read line
     if [ -z "$line" ] || [ "$line" = "y" ]; then
      $EDITOR $glbin/$scrname
     fi
    fi
   fi
  fi
  echo ""
  echo "Please hit <enter> to continue."
  read line
 done
}

modify_scripts ()
{
 for scrname in $tclfiles; do
  if [ -e $scrname ]; then
   glmodify $scrname >$tmpfile && cat $tmpfile >$GLBOTPATH/$scrname
  fi
 done
 if [ -e $GLBOTPATH/$sitebotcfg.new ]; then
  cp $GLBOTPATH/$sitebotcfg.new $GLBOTPATH/$sitebotcfg
 fi
 if [ -e $GLBOTPATH/$sitebotapi.new ]; then
  cp $GLBOTPATH/$sitebotapi.new $GLBOTPATH/$sitebotapi
 fi
# for scrname in `ls -1f addons/ | grep -e ".tcl$"`; do
#  if [ -e addons/$scrname ]; then
#   glmodify addons/$scrname >$tmpfile && cat $tmpfile >$GLBOTPATH/addons/$scrname
#  fi
# done
}

export_vars ()
{
 echo "#!/bin/bash" >./installer.vars
 echo "EDITOROK=\"$EDITOROK\"" >>./installer.vars
 echo "EDITOR=\"$EDITOR\"" >>./installer.vars
 echo "MYPAGER=\"$MYPAGER\"" >>.installer.vars
 echo "GLBOTOK=\"$GLBOTOK\"" >>./installer.vars
 echo "GLROOT=\"$GLROOT\"" >>./installer.vars
 echo "GLSITE=\"$GLSITE\"" >>./installer.vars
 echo "GLDATA=\"$GLDATA\"" >>./installer.vars
 echo "GLFTPD_CONF=\"$GLFTPD_CONF\"" >>./installer.vars
 echo "EGGDROP_CONF=\"$EGGDROP_CONF\"" >>./installer.vars
 echo "GLBOT=\"$GLBOT\"" >>./installer.vars
 echo "GLBOTPATH=\"$GLBOTPATH\"" >>./installer.vars
 echo "zscsourcedir=\"$zscsourcedir\"" >>./installer.vars
 echo "jtcsourcedir=\"$jtcsourcedir\"" >>./installer.vars
}

start_menu ()
{
# Start menu.
 MYSELECT=""
 while [ -z "$MYSELECT" ]; do
  clear
  echo ""
  echo "Welcome to the Sitebot v$VERSION installer."
  echo ""
  echo "Selections:"
  echo "1. Read the installation readme."
  echo "2. Read the sitebot readme."
  echo "3. Read the sitebot faq."
  echo ""
  echo "4. Install the sitebot/edit the tcl config-files."
  echo "5. Install Project-ZS/edit the config-file."
  echo "6. Install JeTrial-C/edit the config-file."
  echo "7. Install various scripts/bins."
  echo ""
  echo ""
  echo "9. Do a complete install."
  echo ""
  echo "g. Edit glftpd.conf."
  echo "e. Edit eggdrop.conf."
  if [ -e ./installer.vars ]; then
   echo "r. Reset/zero the installer variables."
  fi
  echo ""
  echo "x. Exit."
  echo ""
  echo -n "Your choice: [1]> "
  read line
  if [ "$line" = "x" ]; then
   MYSELECT="OK"
  elif [ "$line" = "1" ] || [ -z "$line" ]; then
   choose_editor
   $MYPAGER installer.README
   echo ""
   echo "Please hit <enter> to continue."
   read line
   export_vars
  elif [ "$line" = "2" ]; then
   choose_editor
   $MYPAGER sitebot-glftpd.readme
   echo ""
   echo "Please hit <enter> to continue."
   read line
   export_vars
  elif [ "$line" = "3" ]; then
   choose_editor
   $MYPAGER sitebot-glftpd.faq
   echo ""
   echo "Please hit <enter> to continue."
   read line
   export_vars
  elif [ "$line" = "4" ]; then
   choose_editor; find_glpaths; install_tcl; edit_tcl; fix_eggdrop_conf; export_vars
  elif [ "$line" = "5" ]; then
   choose_editor; find_glpaths; install_zsc; edit_zsc; make_zsc; export_vars
  elif [ "$line" = "6" ]; then
   choose_editor; find_glpaths; install_jtc; edit_jtc; make_jtc; export_vars
  elif [ "$line" = "7" ]; then
   choose_editor; find_glpaths; copy_scripts; make_vid; make_src; export_vars;
#  elif [ "$line" = "8" ]; then
  elif [ "$line" = "9" ]; then
   choose_editor; find_glpaths; install_tcl; edit_tcl; fix_eggdrop_conf
   install_zsc; edit_zsc; make_zsc; install_jtc; edit_jtc; make_jtc;
   copy_scripts; make_vid; make_src; export_vars
  elif [ "$line" = "g" ]; then
   choose_editor; find_glpaths
   $EDITOR $GLFTPD_CONF
   echo ""
   echo "Please hit <enter> to continue."
   read line
   export_vars
  elif [ "$line" = "e" ]; then
   choose_editor; find_glpaths
   $EDITOR $GLBOT/$EGGDROP_CONF
   echo ""
   echo "Please hit <enter> to continue."
   read line
   export_vars
  elif [ "$line" = "r" ]; then
   EDITOROK=""; EDITOR=""; MYPAGER=""; GLBOTOK=""; GLROOT=""; GLSITE=""
   GLDATA=""; GLFTPD_CONF=""; EGGDROP_CONF=""; GLBOT=""; GLBOTPATH=""
   zscsourcedir=""; jtcsourcedir=""
   export_vars
  fi
 done
}

check_dir
if [ -e ./installer.vars ]; then
 . ./installer.vars
fi
start_menu

