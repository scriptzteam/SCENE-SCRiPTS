#!/usr/bin/perl
##
### [ Cleaner 0.1 ]
###
### Little script that cleans out your old files
### and folders.
###
### // pnG
##
## Settings:
# What folders do I clean? Give me full path please
@folders = ('/glftpd/site/MP3', '/glftpd/site/ISO/GAMES');

# How many days old is the dir allowed to be in the different sections?
# The first setting is for the first folder in @folders. If you dont
# understand this, dont use this script.
@time = ('10', '10');

# Quota. How big is the dir allowed to be before Im beginning to 
# delete from it? (in mBytes)
# Set this to '0' if you whant to disable quota for this directory.
@quota = ('5000', '10000');

# If I find a dir thats old, what do you whant me to do whith it?
# 
# 1 = flag it
# 2 = leave a log 
# 3 = delete it
# 4 = Ask, then delete
#
## Be carefull with setting 3, I wouldnt recommend you to use it.
$action = "2";

##########################################################################
# (script is  always login. if you set $action = ""			)
# (nothing will happen to your dirs. This can be usefull if you only	)
# (whant a fast check of your dirs.					)
#
##########################[ Thats all, now watch the magic ]##
$cnt = 0;
foreach $folder (@folders) {
	print "::: Reading from $folder\n";
	print "::: In this dir folders can be $time[$cnt] days old\n";
	
	# Trying quota
	my $output = `du -s $folder`;
	($bytes, $path) = split(/ /, $output);
	$bytes = $bytes / 1024^2;
	print "::: This dir is $bytes mB big, quota is $quota[$cnt] mB\n";
    if ($bytes > $quota[$cnt] or $quota[$cnt] == 0) {
	opendir(DIR, "$folder") or die "Cant open $folder!\n";
        my @files = readdir(DIR);
        for my $file (@files) {
             if ($file ne "." and $file ne "..") {
		($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
                 $atime,$mtime,$ctime,$blksize,$blocks) = stat("$folder/$file");
		$mod = scalar localtime($mtime);
		# Need to find out how old the things are
		$now = time;
		$lostsecs = $now - $mtime;
		$lostdays = $lostsecs / 86400;
		$lostdays =~ s/\.(\d*)//;
		if ($lostdays >= $time[$cnt] and $mode) {
			print "OLD :: $file :: Is $lostdays days old";
			if ($action == 1) {
				$delfile = $file;
				$delfile =~ s/^/[OLD]/;
				$system = "mv $folder/$file $folder/$delfile";
				system($system);
				print ", tagged it";
			} elsif ($action == 2) {
				$log = $now.".log";
				print ", logged it to $log";
				open LOG, ">> $log" or die "Cant open $log (logfile) for output!\n";
				print LOG "[OLD] - [$folder/$file] - [$lostdays old]\n";
				close LOG;
			} elsif ($action == 3) {
				print "Deleteing...";
				system("rm -rf $folder/$file");
			} elsif ($action == 4) {
				print "\nDo you want me to delete that for you? (y/N)\n";
				$uresp = <STDIN>;
				if ($uresp =~ /^y(.*)/) {
					print "Ok, deleting...";
				} else {
					print "Ok, leaving behind...";
				}
			}
					 
			print "\n";
		};
	     };
        };
	$cnt++;
	} else {print ":: Quota is not reached, ignoring this dir\n\n"};
};
print "\n------------------------------------\n";
print "Im all done, this is your new space:\n\n";
system('df -h');
print "\n------------------------------------\n";
print "cleaner - by pnG @ efnet\n\n";
