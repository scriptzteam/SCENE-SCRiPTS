#!/usr/bin/perl
##
### [ Cleaner 1.5 ]
###
### Little script that cleans out your old files
### and folders. If you use the -auto flag to the script
### the script will not ask you questions, only delete and leave a
### logfile.
###
### // pnG
##
## Settings:
# What folders do I clean? Give me full path please
@folders = ('/glftpd/site/xxx', '/glftpd/site/vcd', '/glftpd/site/svcd', '/glftpd/site/0day');

#### TYPE OF FILTER
##
## IMPORTANT:
## If you want to delete by quota, set the time for that section to 0
## in the @time var. Like in my example below, /glftpd/site/xxx /vcd
## /svcd time is set to 0, and quota is set to 20gB, 20gB and 30gB.
## And for 0day, time is set to 30 days, and quota to 0.
##
## YOU CANT USE BOTH QUOTA AND TIME!

# Time. How many days old is the dir allowed to be in the different sections?
# The first setting is for the first folder in @folders, the second is for
# the second and so on. Set this to 0 to disable it.
@time = ('0', '0', '0', '30');

# Quota. How big is the dir allowed to be before Im beginning to 
# delete from it? (in mBytes)
# Set this to '0' if you want to disable quota for this directory.
@quota = ('20000', '20000', '30000', '0');

#### ACTION ON OLDIR
##
## This is if you use time as a filter method
##
# If I find a dir thats old, what do you whant me to do whith it?
# 
# 1 = flag it
# 2 = leave a log 
# 3 = delete it
# 4 = Ask, then delete
#
## Be carefull with setting 3, I wouldnt recommend you to use it.
$action = "4";

### Name of logfile?
$log = "cleaner.log";

##########################################################################
# script will  always log. if you set $action = "" nothing will happen 	##
# to your dirs. This can be usefull if you only	want a fast check of 	##
# your dirs.								##
#									##
##########################[ Thats all, now watch the magic ]##############
$cnt = 0;
foreach $folder (@folders) {
	## Resetting vars
	@FilesArr = ('');	
        $count = 0;
	## Printing some info to user
	print "::: Reading from $folder\n";
	if ($time[$cnt] != 0) {
		print "::: In this dir folders can be $time[$cnt] days old\n";
	} else {
		print "::: Finding out how many folders I need to delete to match quota\n";
	}

	## Trying quota
	my $output = `du -s $folder`;
	($bytes, $path) = split(/ /, $output);
	$bytes = $bytes / 1024^2;
	$removemb = $bytes - $quota[$cnt];
	if ($removemb > 0 and $quota[$cnt] != 0) {
		print "::: This dir is $bytes mB big, quota is $quota[$cnt] mB. I must remove $removemb mBs\n";
	};

    if ($bytes > $quota[$cnt] or $quota[$cnt] == 0) {
	opendir(DIR, "$folder") or die "Cant open $folder!\n";
        my @files = readdir(DIR);
        for my $file (@files) {
             if ($file ne "." and $file ne "..") {
		($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
                 $atime,$mtime,$ctime,$blksize,$blocks) = stat("$folder/$file");
		$mod = scalar localtime($mtime);
		# Need to find out how old the things are
		$now = time;
		$lostsecs = $now - $mtime;
		$lostdays = $lostsecs / 86400;
		$lostdays =~ s/\.(\d*)//;
		
		$file =~ s/\(/\\(/g;
		$file =~ s/\)/\\)/g;

	        my $output = `du -s $folder/$file`;
        	($bytes, $path) = split(/ /, $output);
	        $bytes = $bytes / 1024^2;

		if ($mode) {
			## This is where I add the folders to a array
			$FilesArr[$count] = "$lostdays!!!$bytes!!!$file";
			$count++;
			#print "$count :: FOUND: $lostdays days :: $bytes mB :: $file\n";
		}

		## Here Im removing depending on dates
		if ($lostdays >= $time[$cnt] and $mode and $quota[$cnt] == 0) {
			print "[OLD]==($file)===($lostdays days)";
			if ($action == 1) {
				$delfile = $file;
				$delfile =~ s/^/[OLD]/;
				$system = "mv $folder/$file $folder/$delfile";
				system($system);
				print ", tagged it";
			} elsif ($action == 2) {
				$log = "cleaner.log";
				print ", logged it to $log";
				open LOG, ">> $log" or die "Cant open $log (logfile) for output!\n";
				print LOG "[OLD] - [$folder/$file] - [$lostdays old]\n";
				close LOG;
			} elsif ($action == 3) {
				print "[DELETED] ====> ($file)\n";
				if ($file) {system("rm -rf $folder/$file"); $logg .= "[REMOVED] - ($folder/$file)\n";};
			} elsif ($action == 4) {
				print "\n[REMOVE?]=($file)==(y/N)\n";
				if ($ARGV[0] ne "-auto") {$uresp = <STDIN>};
				if ($uresp =~ /^y(.*)/ or $ARGV[0] eq "-auto") {
					print "[DELETED] ====> ($file)\n";
					system("rm -rf $folder/$file"); 
					$logg .= "[REMOVED] - ($folder/$file)\n";
				} else {
					print "[SKIPPING] ====> ($file)\n";
				}
			}
			print "\n";
		};
	     };
        };
	
	### Here im removing dirs depending on quota
	if ($time[$cnt] == 0 and $quota[$cnt] != 0) {
		@dires = reverse sort { $a <=> $b } @FilesArr;
		#while ($removemb > 0) {
			foreach $thing (@dires) {
				@filesthing = split(/!!!/, $thing);
				if ($removemb < 0) {last};
				print "[REMOVE?] ($filesthing[2]) which is $filesthing[0] days old. It will free $filesthing[1] mBs (y/N)?";
	                        if ($ARGV[0] ne "-auto") {$uresp = <STDIN>};
        	                if ($uresp =~ /^y(.*)/ or $ARGV[0] eq "-auto") {
                	        	print "[DELETED] ====> ($filesthing[2])\n";
					if ($filesthing[2]) {system("rm -rf $folder/$filesthing[2]"); $logg .= "[REMOVED] - ($folder/$filesthing[2])\n"}; 
					$removemb = $removemb - $filesthing[1];
					if ($removemb > 0) {
						print "[INFO] Now I only need to free $removemb mBs\n\n";
					} else {
						print "\n[QUOTA MET] Cleaning done for dir $folder!\n\n";
					};
                        	} else {
                              	        print "[SKIPPING] ====> ($filesthing[2])\n";
					print "[INFO] Now I only need to free $removemb mBs\n\n";
	                        }
			}
		#}
	}
	
	} else {print ":: Quota is not reached, ignoring this dir\n\n"};
$cnt++;
};



print "\n------------------------------------\n";
print "Im all done, this is your new space:\n\n";
system('df -h');
print "\n------------------------------------\n";
print "cleaner - by pnG @ efnet\n\n";

open LOG, ">> $log" or die "Cant open $log (logfile) for output!\n";
print LOG "$logg";
close LOG;

