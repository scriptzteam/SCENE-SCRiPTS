This script (checknfo) will test an uploaded .nfo file to see wheather it
contains useful info about a program release.

It doesn't clean the .zip archive yet.  I'll work on that and maybe in
a future script I will address that issue.  It is kinda nice to be able to
view the .nfo directly from the upload dir with out having the open the
.zip and extract the correct .nfo file.

To install this script follow these steps:

1. Put the following files in your glftpd bin directory:
   (Wherever that may be)  The script calls on them.

   # these file paths are from the sytem root
   /bin/expr
   /bin/grep
   /bin/cp
   /bin/rm
   checknfo  (this should be included in the .zip package)

   if these files are already in place then great!
   If not you better put 'em there or this script will puke

2. Copy this next section and put it in your zipscript.  I have included my
   full zipscript for reference.

    *.zip|*.ZIP)
        echo -e "Checking file integrity..."

        if /bin/unzip -tqq $1 ; then
            echo -e "PASSED.  Extracting FILE_ID.DIZ and .nfo files..."
            /bin/unzip -Cpoqq $1 file_id.diz > .message 

            # extract all the .nfo files.
            # We'll delete what we don't want in a minute
            /bin/unzip -Coqq $1 *.NFO

            # Add site nfo here
            /bin/zip -j -q $1 /rigid.nfo

            # delete any known crap .nfo files
            echo -e "Removing any .nfo files that do not contain release info..."

	    for nfo in *.[Nn][Ff][Oo] ; do
	        checknfo $nfo
	    done

            # Add zip comment here
            /bin/zip -z -q $1 < /TPoGW.nfo
    	  
            # Add .nfo to the dir
            /bin/cp -f /TPoGW.nfo $PWD

            # Tell daemon file is good.
            exit 0
        else
            echo -e "FAILED!  $1 is not a valid .zip archive!"
            /bin/mv $1 $1.bad
            /bin/chmod 000 $1.bad
            # Tell daemon file is bad.
            exit 1
        fi
    	;;


    *.[nN][fF][oO])
        # let's see if this .nfo is relevent to the release.
	echo `checknfo $1`;

        # put your site ad here if you want
	/bin/cp -f /TPoGW.nfo $PWD

        # the checknfo script already kept or deleted the file so just
        # make it easy and tell the daemon it's OK either way
        # so the curry might get a free 1k...  Who gives a shit
	exit 0;
	;;

3. Make sure that your glftpd.conf has a line that looks something like this:

   post_check      /bin/zipscript
