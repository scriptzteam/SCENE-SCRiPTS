This script (postsfv) will do a post-sfv check.  That is, it will check all
files that were marked .bad when they may have actually been good.  This is
useful when a curry doesn't upload the .sfv file first and then all
files are renamed to .bad.

Instead of not checking the CRC at all I allow the system to mark anything
bad that cannot be definitely verified.  As soon as the .sfv is available
this script will loop through all the .bad files and re-instate the good
files and leave any .bad files marked .bad

To install this script follow these steps:

1. Put the following files in your glftpd bin directory:
   (Wherever that may be)  The script calls on them.

   # these file paths are from the sytem root
   /bin/awk
   /bin/mv
   /bin/cp
   sfv_check  (this should have come w/ glftpd)

   if these files are already in place then great!
   If not you better put 'em there or this script will puke


2. This script is actually embedded into your zipscript.  It was easier to
   implement this way and it's not very big.  To make the script work just 
   copy this next section and put it in your zipscript.  I have included my
   full zipscript for reference.


    *.[Ss][Ff][Vv])
        # this runs every time a .sfv file is uploaded to check if there
        # might be untested disks
        echo
        echo "Running Lepricon\'s post .sfv CRC scanner..."
        echo

	for rar in *.[rR0123456789][aA0123456789][rR0123456789].bad ; do
	    newrar=`echo $rar | /bin/awk -F.bad '{print$1}'`
	    if [ ! -f $newrar ] ; then
		mv $rar $newrar
		if /bin/sfv_check $newrar ; then
		    echo -e "$rar CRC32 Passed.  File renamed to $newrar"
    		else
		    /bin/mv $newrar $rar
		    echo -e "$rar Failed CRC32!"
		fi
	    fi
	done
	exit 0
	;;


    *.[rR][aA][rR]|*.[rR0123456789][0123456789][0123456789])
        # CRC32 relies upon the *.sfv file to be uploaded first
        # but now there is post-sfv so not to worry...
	echo -e "Checking CRC32..."
        if /bin/sfv_check $1 ; then
            echo -e "CRC32 Passed."
            /bin/cp -f /TPoGW.nfo $PWD
            exit 0
	else
            echo -e "CRC32 FAILED!"
            echo -e "$1 is either corrupt or you did not upload the *.sfv file first."
            echo -e "You may upload the .sfv file at any time to check this file's CRC."
            /bin/mv $1 $1.bad
            exit 1
	fi
	;;


3. Make sure that your glftpd.conf has a line that looks something like this:

   post_check      /bin/zipscript

