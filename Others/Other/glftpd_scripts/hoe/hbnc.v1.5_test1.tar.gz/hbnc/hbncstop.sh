#!/bin/bash
# will kill running hbnc

hbncpath="."
pidfile="hbnc.pid"

if [ ! -d $hbncpath ]; then
 echo "Directory $hbncpath does not exist..."
 exit 1
fi

if [ -f $hbncpath/$pidfile ]; then
 PID=`cat $hbncpath/$pidfile`
 echo "killing PID $PID..."
 kill -9 $PID >/dev/null 2>&1
 rm $hbncpath/$pidfile   
else 
 echo "Pidfile hbncpath/$pidfile not found..."
fi

exit 0
