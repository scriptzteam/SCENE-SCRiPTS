//TODO: spoof prot, interface to bind


//some code parts are hacked from ftpd-tls (dsa cert handling)

#define VERSION "v1.5_test1"
//#define RESOLVE_HOSTS_BNC

#include <stdarg.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <pwd.h>
#include <unistd.h>
#include <netdb.h>
#include <string.h>
#include <sys/param.h>
#include <fcntl.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include "tls_dh.h"

#define debug 1
     //debuglevel 0=nothing (just fatal to stderr)
    //           1=errors to stdout
    //           2+=internal debug (ftp commands and ssl states)
    //           5+=read buffer stats to stdout

#define PIDFILE "hbnc.pid"
#define MAXLINELEN 4096
#define BUFLEN 1024*4           //you can try to play with it
#define DEFAULTCIPHERLIST       "ALL"
#define DEFRSACERTFILE          "hbnc-rsa.pem"
#define DEFRSAKEYFILE           "hbnc-rsa-key.pem"
#define DEFDSACERTFILE          "hbnc-dsa.pem"
#define DEFDSAKEYFILE           "hbnc-dsa-key.pem"
#define DEFDHPARAMFILE          "hbnc-dhparam.pem"
#define CLIENT 1
#define SERVER 0

//if you dont have /dev/urandom on your system make a rand file and set it
//here !!! (however fbsd and linux both have urandom)
char *ssl_rand_file = NULL;
char ssl_cipher_list[255] = DEFAULTCIPHERLIST;
char *tls_rsa_key_file = DEFRSAKEYFILE;
char *tls_dsa_key_file = DEFDSAKEYFILE;
char *tls_rsa_cert_file = DEFRSACERTFILE;
char *tls_dsa_cert_file = DEFDSACERTFILE;
char *tls_dhparam_file = DEFDHPARAMFILE;
SSL_CTX *ssl_ctx = NULL;
int ftps;


char rhost[2048];
int lport, idnt;
char pidfile[1024];             //, lbind[256], rbind[256];

int readconfig(char *filename)
{
    FILE *in_file;              //, *dircheck;
    char line[2048], label[2048], value[2048], *start;

    lport = -1;
    strcpy(pidfile, "hbnc.pid");
    strcpy(rhost, "");
    idnt = 0;
    ftps = 0;
//    strcpy(lbind, "");
//    strcpy(rbind, "");

    if (!(in_file = fopen(filename, "r")))
        return (0);

    do {
        fgets(line, 2047, in_file);
        if (!feof(in_file)) {
            if (line[0] != '#') {
                strcpy(label, line);

                start = strrchr(label, '\n');
                if (start)
                    *start = '\0';

                start = strrchr(label, '\r');
                if (start)
                    *start = '\0';

                start = strchr(label, '=');
                if (start)
                    *start = '\0';
                else
                    start = label;

                strcpy(value, start + 1);
                if (*label != '\0') {
                    if (!strcasecmp(label, "LPORT")) {
                        lport = atoi(value);
                    } else if (!strcasecmp(label, "IDNT")) {
                        idnt = atoi(value);
                    } else if (!strcasecmp(label, "FTPS")) {
                        ftps = atoi(value);
                    } else if (!strcasecmp(label, "RHOST")) {
                        strncpy(rhost, value, 2047);
                        rhost[2047] = '\0';
//                    } else if (!strcasecmp(label, "LBIND")) {
//                        strncpy(lbind, value, 255);
//                        lbind[255] = '\0';
//                    } else if (!strcasecmp(label, "RBIND")) {
//                        strncpy(rbind, value, 255);
//                        lbind[255] = '\0';
                    } else if (!strcasecmp(label, "PIDFILE")) {
                        strncpy(pidfile, value, 1023);
                        pidfile[1023] = '\0';
                    } else {
                        printf("unknown label '%s' in configfile.\n",
                               label);
                        fclose(in_file);
                        return (0);
                    }
                }
            }
        }
    }
    while (!feof(in_file));

    fclose(in_file);

    return (1);
}



extern char *rfc931(struct sockaddr_in *rmt_sin,
                    struct sockaddr_in *our_sin);

char *file_fullpath(char *fn)
{
    static char fp[256];
    FILE *file;
    char *dir;

    /* check if it is a full path already */
    if ((strchr(fn, '/'))) {
        if ((file = fopen(fn, "r"))) {
            fclose(file);
            return fn;
        } else
            return NULL;
    }
    /* check if it is in current dir */
    if ((file = fopen(fn, "r"))) {
        fclose(file);
        return fn;
    }
    if (!(dir = getenv(X509_get_default_cert_dir_env())))       /* $SSL_CERT_DIR */
        dir = (char *) X509_get_default_cert_dir();
    snprintf(fp, sizeof(fp), "%s/%s", dir, fn);
    if ((file = fopen(fp, "r"))) {
        fclose(file);
        return fp;
    }
    dir = (char *) X509_get_default_private_dir();
    snprintf(fp, sizeof(fp), "%s/%s", dir, fn);
    if ((file = fopen(fp, "r"))) {
        fclose(file);
        return fp;
    }
    return NULL;
}

/* check_file() expands 'file' to an existing full path or NULL if not found */
void check_file(char **file)
{
    char *p;

    if (*file) {
        p = file_fullpath(*file);
        if (p == *file)         /* same pointer returned from file_fullpath() */
            return;
//      free(*file);
        if (p) {
            *file = malloc(strlen(p) + 1);
            strcpy(*file, p);
        } else
            *file = NULL;
    }
}

int seed_PRNG(void)
{
    char stackdata[1024];
    static char rand_file[300];
    FILE *fh;

    if (RAND_status())
        return 0;               /* PRNG already good seeded */

    /* if the device '/dev/urandom' is present, OpenSSL uses it by default.
     * check if it's present, else we have to make random data ourselfs.
     */
    if ((fh = fopen("/dev/urandom", "r"))) {
        fclose(fh);
        return 0;
    }
    if (RAND_file_name(rand_file, sizeof(rand_file)))
        ssl_rand_file = rand_file;
    else
        return 1;
    if (!RAND_load_file(rand_file, 1024)) {
        /* no .rnd file found, create new seed */
        unsigned int c;
        c = time(NULL);
        RAND_seed(&c, sizeof(c));
        c = getpid();
        RAND_seed(&c, sizeof(c));
        RAND_seed(stackdata, sizeof(stackdata));
    }
    if (!RAND_status())
        return 2;               /* PRNG still badly seeded */
    return 0;
}

RSA *tmp_rsa_cb(SSL * ssl, int is_export, int keylength)
{
    static RSA *rsa_tmp = NULL;

    if (!rsa_tmp)
        rsa_tmp = RSA_generate_key(keylength, RSA_F4, NULL, NULL);
    return rsa_tmp;
}

DH *tmp_dh_cb(SSL * ssl, int is_export, int keylength)
{
    static DH *dh = NULL;
    FILE *fp;

    if (!dh) {
        /* first try any 'tls_dhparam_file', else use built-in dh params */
        if (tls_dhparam_file && (fp = fopen(tls_dhparam_file, "r"))) {
            dh = PEM_read_DHparams(fp, NULL, NULL, NULL);
            fclose(fp);
            if (dh)
                return dh;
        }
        switch (keylength) {
        case 512:
            return dh = get_dh512();
        case 768:
            return dh = get_dh768();
        case 1024:
            return dh = get_dh1024();
        case 1536:
            return dh = get_dh1536();
        case 2048:
            return dh = get_dh2048();
        default:
            return dh = get_dh1024();
        }
    } else
        return dh;
}


int sslinit(void)
{
    int err;
    SSL_load_error_strings();
    OpenSSL_add_ssl_algorithms();
    ssl_ctx = SSL_CTX_new(SSLv23_method());
    if (!ssl_ctx) {
        printf("SSL_CTX_new() %s\r\n",
               (char *) ERR_error_string(ERR_get_error(), NULL));
        return 1;
    }
    SSL_CTX_set_options(ssl_ctx, SSL_OP_NO_SSLv2);
    SSL_CTX_set_default_verify_paths(ssl_ctx);

    /* let's find out which files are available */
    check_file(&tls_rsa_cert_file);
    check_file(&tls_rsa_key_file);
    check_file(&tls_dsa_cert_file);
    check_file(&tls_dsa_key_file);
    check_file(&tls_dhparam_file);
    if (!tls_rsa_cert_file && !tls_dsa_cert_file) {
        printf("No certificate files found!\n");
        return 2;
    }
    if (!tls_rsa_key_file)
        tls_rsa_key_file = tls_rsa_cert_file;
    if (!tls_dsa_key_file)
        tls_dsa_key_file = tls_dsa_cert_file;

    if (tls_rsa_cert_file) {
        err =
            SSL_CTX_use_certificate_file(ssl_ctx, tls_rsa_cert_file,
                                         X509_FILETYPE_PEM);
        if (err <= 0) {
            if (debug)
                printf("SSL_CTX_use_certificate_file(%s) %s\n",
                       tls_rsa_cert_file,
                       (char *) ERR_error_string(ERR_get_error(), NULL));
            return 3;
        }
        SSL_CTX_set_tmp_rsa_callback(ssl_ctx, tmp_rsa_cb);
    }
    if (tls_rsa_key_file) {
        err =
            SSL_CTX_use_PrivateKey_file(ssl_ctx, tls_rsa_key_file,
                                        X509_FILETYPE_PEM);
        if (err <= 0) {
            if (debug)
                printf("SSL_CTX_use_PrivateKey_file(%s) %s\n",
                       tls_rsa_key_file,
                       (char *) ERR_error_string(ERR_get_error(), NULL));
            return 4;
        }
    }
    if (tls_dsa_cert_file) {
        err =
            SSL_CTX_use_certificate_file(ssl_ctx, tls_dsa_cert_file,
                                         X509_FILETYPE_PEM);
        if (err <= 0) {
            if (debug)
                printf("SSL_CTX_use_certificate_file(%s) %s\n",
                       tls_dsa_cert_file,
                       (char *) ERR_error_string(ERR_get_error(), NULL));
            return 5;
        }
    }
    if (tls_dsa_key_file) {
        err =
            SSL_CTX_use_PrivateKey_file(ssl_ctx, tls_dsa_key_file,
                                        X509_FILETYPE_PEM);
        if (err <= 0) {
            if (debug)
                printf("SSL_CTX_use_PrivateKey_file(%s) %s\n",
                       tls_dsa_key_file,
                       (char *) ERR_error_string(ERR_get_error(), NULL));
            return 6;
        }
    }
    SSL_CTX_set_tmp_dh_callback(ssl_ctx, tmp_dh_cb);

    SSL_CTX_set_session_cache_mode(ssl_ctx, SSL_SESS_CACHE_CLIENT);
    SSL_CTX_set_session_id_context(ssl_ctx, (const unsigned char *) "1",
                                   1);
    if (seed_PRNG())
        fprintf(stderr, "Wasn't able to properly seed the PRNG!\r\n");
    return 0;
}


void sslcleanup(void)
{
    if (ssl_ctx) {
        SSL_CTX_free(ssl_ctx);
        ssl_ctx = NULL;
    }
    if (ssl_rand_file)
        RAND_write_file(ssl_rand_file);
}

int getline(char *buf, int bufread, char *actline, int *linepos,
            int *bufpos)
{
    while (bufread != (*bufpos)) {
        if (buf[*bufpos] == '\n') {
            (*bufpos)++;
            actline[(*linepos)++] = '\r';
            actline[(*linepos)++] = '\n';
            actline[*linepos] = '\0';
            return 0;
        }
        // we ignore \r but we add it to every line
        // rfc says there should be \r\n anyway, some servers dont do this...
        // also some buggy clients forget about it (hint - windows clients)
        if (buf[*bufpos] != '\r') {
            if ((*linepos) == (MAXLINELEN - 3)) {
                // too long line -> the rest of it goes to next line */
                actline[MAXLINELEN - 3] = '\0';
                if (debug) {
                    printf("Attempt to line buffer overflow !\n");
                    printf("%s\n", actline);
                }
                return 1;
            }
            actline[(*linepos)++] = buf[*bufpos];
        }
        (*bufpos)++;
    }
    /* not finished with the line yet */
    return -1;
}


struct bnccon {
    int sock, ssl, ssldata;
    SSL *sslcon;
    void *sockid;
     ssize_t(*hread) (struct bnccon * bnc, void *buf, size_t count);
     ssize_t(*hwrite) (struct bnccon * bnc, void *buf, size_t count);
    int (*shouldretry) (struct bnccon * bnc);
};

int should_retry_normal(struct bnccon *bnc)
{
    return 0;
}

int should_retry_SSL(struct bnccon *bnc)
{
    return SSL_pending(bnc->sslcon);
}

ssize_t hread_normal(struct bnccon * bnc, void *buf, size_t count)
{
    return read(bnc->sock, buf, count);
}

ssize_t hread_SSL(struct bnccon * bnc, void *buf, size_t count)
{
    return SSL_read(bnc->sslcon, buf, count);
}

ssize_t hwrite_normal(struct bnccon * bnc, void *buf, size_t count)
{
    return write(bnc->sock, buf, count);
}

ssize_t hwrite_SSL(struct bnccon * bnc, void *buf, size_t count)
{
    return SSL_write(bnc->sslcon, buf, count);
}

int acceptnb(int s, struct sockaddr_in *cs, int maxsec)
{
    int flags, n;
    fd_set ac_s;
    int len;
    struct timeval tval;

    flags = fcntl(s, F_GETFL, 0);
    if (flags == -1)
        return (-1);
    n = fcntl(s, F_SETFL, flags | O_NONBLOCK);
    if (flags == -1)
        return (-1);

    FD_ZERO(&ac_s);
    FD_SET(s, &ac_s);
    tval.tv_sec = maxsec;
    tval.tv_usec = 0;

    n = select(s + 1, &ac_s, NULL, NULL, maxsec ? &tval : NULL);
    if (n == 0)
        return (0);

    if (FD_ISSET(s, &ac_s)) {
        len = sizeof(struct sockaddr_in);
        n = accept(s, (struct sockaddr *) cs, &len);
        if (n == -1) {
            switch (errno) {
            case EWOULDBLOCK:
            case ECONNABORTED:
/* fbsd doesnt have EPROTO heh */
#ifndef FIX_BSD
            case EPROTO:
#endif
            case EINTR:
                if (fcntl(s, F_SETFL, flags) == -1)
                    return (-1);
                return (0);
            default:
                return (-1);
            }
        }
        if (fcntl(s, F_SETFL, flags) == -1)
            return (-1);
        return (n);
    }
    if (fcntl(s, F_SETFL, flags) == -1)
        return (-1);
    return (0);
}


void bounce(int servsock, struct sockaddr_in *target, int datamode,
            SSL * csslcon)
{
    int tdiff = 100, maxwait = 100, maxfd, nbyt, err;
    struct bnccon cli, trg;
    char buf[BUFLEN];
    fd_set fdsr, fdse;
    struct timeval tstart, tcur;
    struct sockaddr_in clientaddr;

    (void) gettimeofday(&tstart, NULL);
    cli.sock = 0;
    while ((tdiff > 0) && (cli.sock == 0)) {
        cli.sock = acceptnb(servsock, &clientaddr, tdiff);
        if (cli.sock == -1) {
            if (debug)
                printf("accept() failed\n");
            return;
        }
        (void) gettimeofday(&tcur, NULL);
        tdiff = maxwait - (tcur.tv_sec - tstart.tv_sec);
    }

    /* on timeout terminate */
    if (tdiff <= 0 && cli.sock == 0) {
        if (debug)
            printf("timeout on waiting for DATA accept\n");
        // close(cli.sock);
        return;
    }

    if (debug > 4)
        printf("DATA accept\n");

    if ((trg.sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        if (debug)
            printf("socket() failed\n");
        close(cli.sock);
        return;
    }

    if (debug > 4)
        printf("DATA accept-connecting\n");

    if (connect
        (trg.sock, (struct sockaddr *) target,
         sizeof(struct sockaddr_in)) < 0) {
        if (debug)
            printf("connect() failed\n");
        close(cli.sock);
        close(trg.sock);
        return;
    }

    if (datamode == 2) {
        if (debug > 4)
            printf("DATA accept-going to ssl datamode 2\n");

        /* ok lets try to go ssl */
        cli.sslcon = SSL_new(ssl_ctx);
        if (!cli.sslcon) {
            if (debug)
                printf("SSL_new() on DATA failed\n");
            close(cli.sock);
            return;
        }
        if (debug > 1)
            printf("data socket connected\n");


        SSL_copy_session_id(cli.sslcon, csslcon);
        SSL_set_fd(cli.sslcon, cli.sock);

        err = SSL_accept(cli.sslcon);

        if (err != 1) {
            if (debug)
                printf("SSL_accept() on DATA failed\n");
            close(cli.sock);
            return;
        }
        cli.hread = hread_SSL;
        cli.hwrite = hwrite_SSL;
        cli.shouldretry = should_retry_SSL;
        if (debug > 1)
            printf("SSL_accept() on DATA accepted\n");
    } else {
        cli.hread = hread_normal;
        cli.hwrite = hwrite_normal;
        cli.shouldretry = should_retry_normal;
    }


    if (datamode == 1) {
        if (debug > 4)
            printf("DATA accept-connect ssl data\n");
        /* ok lets try to go ssl */
        trg.sslcon = SSL_new(ssl_ctx);
        if (!trg.sslcon) {
            if (debug)
                printf("SSL_new() on DATA failed\n");
            close(cli.sock);
            close(trg.sock);
            return;
        }

        SSL_copy_session_id(trg.sslcon, csslcon);
        SSL_set_fd(trg.sslcon, trg.sock);

        err = SSL_accept(trg.sslcon);

        if (err != 1) {
            if (debug)
                printf("SSL_accept() on DATA failed\n");
            close(cli.sock);
            close(trg.sock);
            return;
        }
        trg.hread = hread_SSL;
        trg.hwrite = hwrite_SSL;
        trg.shouldretry = should_retry_SSL;
        if (debug > 1)
            printf("SSL_accept() on DATA accepted\n");
    } else {
        trg.hread = hread_normal;
        trg.hwrite = hwrite_normal;
        trg.shouldretry = should_retry_normal;
    }

    /* this could be done one way but we dont know the way so we do both */
    while (1) {
        FD_ZERO(&fdsr);
        FD_ZERO(&fdse);
        FD_SET(cli.sock, &fdsr);
        FD_SET(cli.sock, &fdse);
        FD_SET(trg.sock, &fdsr);
        FD_SET(trg.sock, &fdse);
        maxfd = ((trg.sock > cli.sock) ? trg.sock : cli.sock) + 1;
        if (select(maxfd, &fdsr, NULL, &fdse, NULL) == -1) {
            if (debug)
                printf("select() failed\n");
            goto bncstop;
        }
        if (FD_ISSET(cli.sock, &fdsr) || FD_ISSET(cli.sock, &fdse)) {
            do {
                if ((nbyt = cli.hread(&cli, buf, BUFLEN)) <= 0)
                     {
                    goto bncstop;
                    }
                if ((trg.hwrite(&trg, buf, nbyt)) <= 0)
                     {
                    goto bncstop;
                    }
            } while (cli.shouldretry(&cli));
        } else if (FD_ISSET(trg.sock, &fdsr) || FD_ISSET(trg.sock, &fdse)) {
            do {
                if ((nbyt = trg.hread(&trg, buf, BUFLEN)) <= 0)
                     {
                    goto bncstop;
                    }
                if ((cli.hwrite(&cli, buf, nbyt)) <= 0)
                     {
                    goto bncstop;
                    }
            } while (cli.shouldretry(&trg));
        }
    }
  bncstop:
    if (debug > 1)
        printf("data bounce stop\n");
    close(cli.sock);
    close(trg.sock);
    return;
}

int processline(struct bnccon *cbnc, struct bnccon *obnc, char *line,
                int linelen, int inorout)
{
    char *answer;
    int err;
    int n, ip[4], ph, pl, rport, lport;
    int socksize = sizeof(struct sockaddr_in);
    int socksize2 = sizeof(struct sockaddr_in);
    struct sockaddr_in sockname;
    struct sockaddr_in sockname2;
    unsigned char reuse_addr = 1;
    unsigned char linger_opt = 0;
    int servsock, datamode;
    struct sockaddr_in server;
    struct sockaddr_in newsession;
    char tmpbuf[100];

    if (inorout == CLIENT) {
        if (debug > 2)
            printf("--> %s", line);
        if ((!strcmp(line, "AUTH TLS\r\n"))
            || (!strcmp(line, "AUTH TLS-C\r\n"))) {
            // client requested SSL mode
            // we dont pass this to server, but we handle the mode
            // and we give client answer for this command
            if (cbnc->ssl == 1) {
                answer = "534 Already in TLS mode\r\n";
                if ((cbnc->hwrite(cbnc, answer, strlen(answer))) <= 0)
                    return -1;
                return 0;
            }
            answer = "234 AUTH TLS successfull by hBNC\r\n";
            if (debug > 2)
                printf("<-- %s", answer);
            if ((cbnc->hwrite(cbnc, answer, strlen(answer))) <= 0)
                return -1;
            /* ok lets try to go ssl */
            cbnc->sslcon = SSL_new(ssl_ctx);
            if (!cbnc->sslcon) {
                if (debug)
                    printf("SSL_new() failed\n");
                answer =
                    "421 Failed TLS negotiation on control channel, disconnected by hBNC\r\n";
                cbnc->hwrite(cbnc, answer, strlen(answer));
                return -1;
            }

            SSL_set_cipher_list(cbnc->sslcon, ssl_cipher_list);
            SSL_set_fd(cbnc->sslcon, cbnc->sock);

            err = SSL_accept(cbnc->sslcon);

            if (err == 1) {
                if (debug > 1)
                    printf("SSL_accept ok\n");
                cbnc->ssl = 1;
                //TLS mode
                cbnc->ssldata = 0;
                cbnc->hread = hread_SSL;
                cbnc->hwrite = hwrite_SSL;
                cbnc->shouldretry = should_retry_SSL;
                return 0;
            }
            if (debug)
                printf("SSL_connect failed\n");
            answer =
                "421 Failed TLS negotiation on control channel, disconnected by hBNC\r\n";
            cbnc->hwrite(cbnc, answer, strlen(answer));
            return -1;
        } else if ((!strcmp(line, "AUTH SSL\r\n"))
                   || (!strcmp(line, "AUTH TLS-S\r\n"))) {
            if (cbnc->ssl == 1) {
                answer = "534 Already in TLS mode\r\n";
                if ((cbnc->hwrite(cbnc, answer, strlen(answer))) <= 0)
                    return -1;
                return 0;
            }
            answer = "234 AUTH SSL successfull by hBNC\r\n";
            if (debug > 2)
                printf("<-- %s", answer);
            if ((cbnc->hwrite(cbnc, answer, strlen(answer))) <= 0)
                return -1;
            /* ok lets try to go ssl */
            cbnc->sslcon = SSL_new(ssl_ctx);
            if (!cbnc->sslcon) {
                if (debug)
                    printf("SSL_new() failed\n");
                answer =
                    "421 Failed TLS negotiation on control channel, disconnected by hBNC\r\n";
                cbnc->hwrite(cbnc, answer, strlen(answer));
                return -1;
            }

            SSL_set_cipher_list(cbnc->sslcon, ssl_cipher_list);
            SSL_set_fd(cbnc->sslcon, cbnc->sock);

            err = SSL_accept(cbnc->sslcon);

            if (err == 1) {
                if (debug > 1)
                    printf("SSL_accept ok\n");
                cbnc->ssl = 1;
                cbnc->hread = hread_SSL;
                cbnc->hwrite = hwrite_SSL;
                cbnc->shouldretry = should_retry_SSL;
                //SSL mode (private)
                cbnc->ssldata = 1;
                return 0;
            }
            if (debug)
                printf("SSL_Accept failed\n");
            answer =
                "421 Failed TLS negotiation on control channel, disconnected by hBNC\r\n";
            cbnc->hwrite(cbnc, answer, strlen(answer));
            return -1;
        }

        if (!strncmp(line, "PBSZ", 4)) {
            //do not pass to server
            answer = "200 PBSZ 0 successful\r\n";
            if (debug > 2)
                printf("<--(by bnc) %s", answer);

            if (cbnc->hwrite(cbnc, answer, strlen(answer)) <= 0)
                return -1;
            return 0;
        }

        if (!strcmp(line, "PROT C\r\n")) {
            //do not pass to server but set the bnc.cssldata
            answer = "200 Protection set to Clear\r\n";
            if (debug > 2)
                printf("<--(by bnc) %s", answer);
            if (cbnc->hwrite(cbnc, answer, strlen(answer)) <= 0)
                return -1;
            cbnc->ssldata = 0;
            return 0;
        }

        if (!strcmp(line, "PROT P\r\n")) {
            //do not pass to server but set the bnc.cssldata
            answer = "200 Protection set to Private\r\n";
            if (debug > 2)
                printf("<--(by bnc) %s", answer);
            if (cbnc->hwrite(cbnc, answer, strlen(answer)) <= 0)
                return -1;
            cbnc->ssldata = 1;
            return 0;
        }

        if (!strncmp(line, "IDNT", 4)) {
            if (line[linelen - 2] == '\r') {
                linelen--;
                line[linelen - 1] = '\n';
                line[linelen] = '\n';
            }
        }

        if (strncmp(line, "PORT", 4)) {
            if ((obnc->hwrite(obnc, line, linelen)) <= 0)
                return -1;
            return 0;
        }
        //now we have PORT command from client...
        n = sscanf(line, "PORT %d,%d,%d,%d,%d,%d", &ip[0], &ip[1], &ip[2],
                   &ip[3], &ph, &pl);
        if (n != 6) {
            if (debug)
                printf
                    ("client supplied PORT command in invalid format: %s\n",
                     line);
            answer =
                "421 PORT command in bad format, disconnected by hBNC\r\n";
            cbnc->hwrite(cbnc, answer, strlen(answer));
            //close connection
            return -1;
        }
    } else {
        if (debug > 2)
            printf("<-- %s", line);
        /* is this a passive mode return ? */
        if (strncmp(line, "227", 3)) {
            if ((cbnc->hwrite(cbnc, line, linelen)) <= 0)
                return -1;
            return 0;
        }
        n = sscanf(line, "227 %*[^(](%d,%d,%d,%d,%d,%d)", &ip[0], &ip[1],
                   &ip[2], &ip[3], &ph, &pl);
        if (n != 6) {
            if (debug)
                printf
                    ("PASV reply from server was in invalid format: %s\n",
                     line);
            answer =
                "421 PASV reply in bad format, disconnected by hBNC\r\n";
            cbnc->hwrite(cbnc, answer, strlen(answer));
            //close connection
            return -1;
        }
    }
    /* get the client interface so we can listen */
    if (getsockname(cbnc->sock, (struct sockaddr *) &sockname, &socksize)
        != 0) {
        if (debug)
            printf("getsockname() failed\n");
        answer = "421 getsockname() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        return -1;
    }
    /* get server interface for use with port commands
       and when the server is on an other interface  */
// added by bloody_a
    if (getsockname(obnc->sock, (struct sockaddr *) &sockname2, &socksize2)
        != 0) {
        if (debug)
            printf("getsockname() server failed\n");
        answer = "421 getsockname() failed on server interface\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        return -1;
    }
    rport = (ph << 8) + pl;
    //set up a socket

    if ((servsock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        if (debug)
            printf("socket() failed\n");
        answer = "421 socket() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        //close connection
        return -1;
    }

    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = 0;        //we get a free port
    if (inorout == CLIENT)
        server.sin_addr = sockname2.sin_addr;
    else
        server.sin_addr = sockname.sin_addr;

    //allows reuse on local addr ???
    setsockopt(servsock, SOL_SOCKET, SO_REUSEADDR, &reuse_addr,
               sizeof(reuse_addr));
    //make sure all data get out when we close()
    //this is rather important (hint-buggy clients :P)
    setsockopt(servsock, SOL_SOCKET, SO_LINGER, &linger_opt,
               sizeof(SO_LINGER));

    if (bind(servsock, (struct sockaddr *) &server, sizeof(server)) < 0) {
        if (debug)
            printf("bind() failed\n");
        answer = "421 bind() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        //close connection
        return -1;
    }
    if (listen(servsock, 1) < 0) {
        if (debug)
            printf("listen() failed\n");
        answer = "421 listen() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        //close connection
        return -1;
    }
    /* get the real info */
    if (getsockname(servsock, (struct sockaddr *) &server, &socksize) < 0) {
        if (debug)
            printf("getsockname() failed\n");
        answer = "421 getsockname() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        //close connection
        return -1;
    }

    lport = ntohs(server.sin_port);
    if (inorout == CLIENT) {
        /* send the new port and ipaddress to the server */
        n = snprintf(tmpbuf, 100, "PORT %d,%d,%d,%d,%d,%d\r\n",
                     server.sin_addr.s_addr & 0xff,
                     (server.sin_addr.s_addr >> 8) & 0xff,
                     (server.sin_addr.s_addr >> 16) & 0xff,
                     server.sin_addr.s_addr >> 24, (lport >> 8) & 0xff,
                     lport & 0xff);
        if (debug > 2)
            printf("-->(changed) %s", tmpbuf);
        obnc->hwrite(obnc, tmpbuf, n);
    } else {
        /* send the new port and ipaddress to the client */
        n = snprintf(tmpbuf, 100,
                     "227 Entering Passive Mode (%d,%d,%d,%d,%d,%d)\r\n",
                     server.sin_addr.s_addr & 0xff,
                     (server.sin_addr.s_addr >> 8) & 0xff,
                     (server.sin_addr.s_addr >> 16) & 0xff,
                     server.sin_addr.s_addr >> 24, (lport >> 8) & 0xff,
                     lport & 0xff);
        if (debug > 2)
            printf("<--(changed) %s", tmpbuf);
        if ((cbnc->hwrite(cbnc, tmpbuf, n)) <= 0)
            return -1;
    }
    if (inorout == CLIENT) {
        //was PORT command
        if (cbnc->ssldata)
            datamode = 1;
        else
            datamode = 0;
        //datamode 1 means ssl needed for connecting conn
    } else {
        //PASV reply
        if (cbnc->ssldata)
            datamode = 2;
        else
            datamode = 0;
        //datamode 2 means ssl needed for accepting conn
    }

    newsession.sin_port = htons(rport);
    newsession.sin_family = AF_INET;
    newsession.sin_addr.s_addr =
        ip[0] | (ip[1] << 8) | (ip[2] << 16) | (ip[3] << 24);
    switch (fork()) {
    case -1:                   /* Error */
        if (debug)
            printf("fork() failed\n");
        answer = "421 fork() failed\r\n";
        cbnc->hwrite(cbnc, answer, strlen(answer));
        //close connection
        return -1;
    case 0:
        {
            bounce(servsock, &newsession, datamode, cbnc->sslcon);
            close(servsock);
            exit(0);
        }
    default:
        {
            close(servsock);
        }
    }
    return 0;
}

#ifndef FIX_BSD
char **Argv = NULL;             /* pointer to argument vector */
char *LastArgv = NULL;          /* end of argv */

/* fbsd has it built in */
void setproctitle(char *fmt, ...)
{
    register char *p;
    register char *bp;
    register char ch;
    register int i;
    char buf[BUFSIZ];
    va_list argp;

    /*
     * Build "buf" out of variable args
     */
    va_start(argp, fmt);
    vsnprintf(buf, sizeof(buf), fmt, argp);
    va_end(argp);

    /*
     * Make "ps" print our process name
     */
    p = Argv[0];

    i = strlen(buf);
    if (i > LastArgv - p - 2) {
        i = LastArgv - p - 2;
        buf[i] = '\0';
    }

    bp = buf;
    while ((ch = *bp++))
        if (ch != '\n' && ch != '\r')
            *p++ = ch;
    *p++ = '\0';
    while (p < LastArgv)
        *p++ = ' ';
}
#endif

int main(int argc, char **argv, char **envp) 
{
    int lsock;
    struct bnccon cbnc, obnc;
    FILE *cfile, *pidfile;
    char buf[BUFLEN];
    struct sockaddr_in laddr, caddr, oaddr;
    fd_set fdsr, fdse;
    struct hostent *h;
    int maxfd;
    int nbyt;
    int err;
    int inbufpos, inlinepos;
    char actlinein[MAXLINELEN];
    int outbufpos, outlinepos;
    char actlineout[MAXLINELEN];
    unsigned long a;
    unsigned short oport;
    char *curport;
    char *identname;
    char *cwd = NULL;
    struct passwd *passw;

#ifndef FIX_BSD
    Argv = argv;
    while (*envp)
        envp++;
    LastArgv = envp[-1] + strlen(envp[-1]);
#endif

    setbuf(stdout, NULL);
    cbnc.hread = hread_normal;
    cbnc.hwrite = hwrite_normal;
    cbnc.shouldretry = should_retry_normal;
    obnc.hread = hread_normal;
    obnc.hwrite = hwrite_normal;
    obnc.shouldretry = should_retry_normal;
    cbnc.ssl = 0;
    cbnc.ssldata = 0;
    obnc.ssl = 0;
    obnc.ssldata = 0;
    if (sslinit()) {
        fprintf(stderr, "SSL init failed\n");
        return -1;
    }
    ftps = 0;

    if (argc != 2) {
        fprintf(stderr, "hbnc %s\n", VERSION);
        fprintf(stderr, "Usage: %s config_file\n", argv[0]);
        return -1;
    }

    if (readconfig(argv[1]) == 0) {
        fprintf(stderr, "Error reading config file\n");
        return -1;
    }

    if ((curport = strrchr(rhost, ':')) != NULL) {
        *curport = '\0';
        curport++;
    } else {
        fprintf(stderr, "error getting port in RHOST");
	return -1;
    }

    a = inet_addr(rhost);
    if (!(h = gethostbyname(rhost))
         && !(h = gethostbyaddr((char *) &a, 4, AF_INET))) {
        perror(rhost);
        return 25;
    }
    oport = atol(curport);
    laddr.sin_port = htons((unsigned short) (lport));
    if ((lsock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
        perror("socket");
        return 20;
    }
    laddr.sin_family = AF_INET;
    laddr.sin_addr.s_addr = htonl(0);
    if (bind(lsock, (struct sockaddr *) &laddr, sizeof(laddr))) {
        perror("bind");
        return 20;
    }
    if (listen(lsock, 1)) {
        perror("listen");
        return 20;
    }
    if ((nbyt = fork()) == -1) {
        perror("fork");
        return 20;
    }
    if (nbyt > 0)
         {
        //detach parent process
        return 0;
        }
    //edit this to fake the processes to whatever you want
    setproctitle("%s", argv[0]);
    setsid();
    
    //create pid file
    //we should check for failure here but i am lazy :)
    //one day i will fix it :)
    unlink(PIDFILE);

    pidfile = fopen(PIDFILE, "w");
    if (pidfile == NULL) {
        fprintf(stderr, "cannot create pidfile %s: %s\n", PIDFILE,
                strerror(errno));
        return -1;
    }
    fprintf(pidfile, "%d", (int) getpid());
    fclose(pidfile);

    if (getuid() == 0) {
        passw = getpwnam("nobody");
        if (passw == NULL) {
            fprintf(stderr, "unable to find uid for nobody\n");
            return 666;
        }
        cwd = getcwd(NULL, MAXPATHLEN);
        if (!cwd) {
            fprintf(stderr, "getcwd() failed\n");
            return 30;
        }
        if (debug > 1)
            printf("chrooting to %s\n", cwd);
        if (chroot(cwd)) {
            fprintf(stderr, "Unable to chroot to %s\n", cwd);
            return 30;
        }
        if (debug > 1)
            printf("changing uid to %d\n", passw->pw_uid);
        if (setuid(passw->pw_uid)) {
            fprintf(stderr, "Unable to setuid to %d\n", passw->pw_uid);
            return 30;
        }
    }
    while (1) {
        cbnc.sock = acceptnb(lsock, &caddr, 2);
        if (cbnc.sock == -1) {
            if (debug)
                printf("accept() failed\n");
            
                //return 20;
                continue;
        }
        if (cbnc.sock == 0) {
            //we handle the finished child processes...
            while (waitpid(-1, NULL, WNOHANG) > 0);
            continue;
        }
        cfile = fdopen(cbnc.sock, "r+");
        if ((nbyt = fork()) == -1) {
            fprintf(cfile, "421 fork: %s\r\n", strerror(errno));
            shutdown(cbnc.sock, 2);
            fclose(cfile);
            continue;
        }
        if (nbyt == 0)
            break;
        fclose(cfile);
        while (waitpid(-1, NULL, WNOHANG) > 0);
    }
    if ((obnc.sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
        fprintf(cfile, "421 socket: %s\r\n", strerror(errno));
        goto quit1;
    }
    oaddr.sin_family = h->h_addrtype;
    oaddr.sin_port = htons(oport);
    memcpy(&oaddr.sin_addr, h->h_addr, h->h_length);
    if (connect(obnc.sock, (struct sockaddr *) &oaddr, sizeof(oaddr))) {
        fprintf(cfile, "421 connect: %s\r\n", strerror(errno));
        goto quit1;
    }
    
        /* get remote user's name */
        identname = rfc931(&caddr, &laddr);

#ifdef RESOLVE_HOSTS_BNC
    {
        struct hostent *hp;
        char remotehost[MAXHOSTNAMELEN];
        /* get remote host name */
        hp = gethostbyaddr((char *) &caddr.sin_addr,
                           sizeof(struct in_addr), AF_INET);
        if (hp)
            (void) strncpy(remotehost, hp->h_name, sizeof(remotehost));
        else
            (void) strncpy(remotehost, inet_ntoa(caddr.sin_addr),
                           sizeof(remotehost));

        printf("connection from %s@%s (%s)\n", identname,
               remotehost, inet_ntoa(caddr.sin_addr));
        if (idnt) {
            snprintf(buf, BUFLEN, "IDNT %s@%s:%s\n", identname,
                     inet_ntoa(caddr.sin_addr), remotehost);
            if ((write(obnc.sock, buf, strlen(buf))) <= 0)
                goto quit2;
        }
    }

#else
    printf("connection from %s@%s\n", identname,
           inet_ntoa(caddr.sin_addr));
    if (idnt) {
        /* like dike */
        snprintf(buf, BUFLEN, "IDNT %s@%s:%s\n", identname,
                 inet_ntoa(caddr.sin_addr), inet_ntoa(caddr.sin_addr));
        if ((write(obnc.sock, buf, strlen(buf))) <= 0)
            goto quit2;
    }
#endif
    if (ftps) {
        //ftps mode, lets do SSL_accept()
        cbnc.sslcon = SSL_new(ssl_ctx);
        if (!cbnc.sslcon) {
            if (debug)
                printf("SSL_new() failed\n");
            goto quit2;
        }

        SSL_set_cipher_list(cbnc.sslcon, ssl_cipher_list);
        SSL_set_fd(cbnc.sslcon, cbnc.sock);

        err = SSL_accept(cbnc.sslcon);

        if (err != 1) {
            if (debug)
                printf("SSL_Accept failed\n");
            goto quit2;
        }

        if (debug > 1)
            printf("SSL_accept ok\n");
        cbnc.ssl = 1;
        cbnc.hread = hread_SSL;
        cbnc.hwrite = hwrite_SSL;
        cbnc.shouldretry = should_retry_SSL;
        //SSL mode (private) (default in ftps)
        cbnc.ssldata = 1;
    }

    inlinepos = 0;
    outlinepos = 0;
    while (1) {
        while (waitpid(-1, NULL, WNOHANG) > 0);
        FD_ZERO(&fdsr);
        FD_ZERO(&fdse);
        FD_SET(cbnc.sock, &fdsr);
        FD_SET(cbnc.sock, &fdse);
        FD_SET(obnc.sock, &fdsr);
        FD_SET(obnc.sock, &fdse);
        maxfd = ((cbnc.sock > obnc.sock) ? cbnc.sock : obnc.sock) + 1;
        if (select(maxfd, &fdsr, NULL, &fdse, NULL) == -1) {
            fprintf(cfile, "421 select: %s\r\n", strerror(errno));
            goto quit2;
        }
        if (FD_ISSET(cbnc.sock, &fdsr)
             || FD_ISSET(cbnc.sock, &fdse)) {
            do {
                if ((nbyt = cbnc.hread(&cbnc, buf, BUFLEN)) <= 0)
                    goto quit2;
                if (debug > 5)
                    printf("outread %d bytes\n", nbyt);
                outbufpos = 0;
                while (getline
                       (buf, nbyt, actlineout, &outlinepos,
                        &outbufpos) != -1) {
                    if (processline
                        (&cbnc, &obnc, actlineout, outlinepos,
                         CLIENT) == -1)
                        goto quit2;
                    outlinepos = 0;
                }
            } while (cbnc.shouldretry(&cbnc));
        } else if (FD_ISSET(obnc.sock, &fdsr)
                   || FD_ISSET(obnc.sock, &fdse)) {
            do {
                if ((nbyt = obnc.hread(&obnc, buf, BUFLEN)) <= 0)
                    goto quit2;
                if (debug > 5)
                    printf("inread %d bytes\n", nbyt);
                inbufpos = 0;
                while (getline
                       (buf, nbyt, actlinein, &inlinepos,
                        &inbufpos) != -1) {
                    if (processline
                        (&cbnc, &obnc, actlinein, inlinepos, SERVER) == -1)
                        goto quit2;
                    inlinepos = 0;
                }
            } while (obnc.shouldretry(&obnc));
        }
    }
  quit2:
    if (obnc.ssl)
        SSL_shutdown(obnc.sslcon);
    shutdown(obnc.sock, 2);
    close(obnc.sock);
  quit1:fflush(cfile);
    if (cbnc.ssl)
        SSL_shutdown(cbnc.sslcon);
    shutdown(cbnc.sock, 2);
    
// quit0:
        fclose(cfile);
    sslcleanup();
    return 0;
}


