#!/bin/bash
# checker for crontab
# crontab line example :
#    0,10,20,30,40,50 * * * *   /home/mydir/hbnccheck.sh >/dev/null 2>&1
# removing the >/dev/null 2>&1 will cause sending you mail with info

hbncpath="."
hbncbinaryname="hbnc"
pidfile="hbnc.pid"
# logfile... or use /dev/null for no log
logfile="hbnc.log"
#config file
conffile="hbnc.conf"

if [ ! -d $hbncpath ]; then
 echo "Directory $hbncpath does not exist..."
 exit 1
fi

if [ ! -f $hbncpath/$hbncbinaryname ]; then
 echo "File $hbncpath/$hbncbinaryname does not exist..."
 exit 1
fi

if [ -f $hbncpath/$pidfile ]; then
 PID=`cat $hbncpath/$pidfile`
 if `kill -CHLD $PID >/dev/null 2>&1`; then
  #seems to be running ok
  exit 0
 fi
 echo "Pidfile was found but hbnc wasnt running, restarting..."
 rm $hbncpath/$pidfile   
else 
 echo "Pidfile was not found, starting hbnc..."
fi

echo "Starting hbnc..."

OLDPWD=$PWD
cd $hbncpath
./$hbncbinaryname $conffile >>$logfile
cd $OLDPWD

exit 0
