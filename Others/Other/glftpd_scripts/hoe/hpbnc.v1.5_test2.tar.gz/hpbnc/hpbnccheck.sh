#!/bin/sh
# checker for crontab
# crontab line example :
# 0,20,40 * * * *   /home/mydirs/hpbnccheck.sh >/dev/null 2>&1
# removing the ">/dev/null 2>&1" will cause sending you mail with info

hpbncpath="."
hpbncbinaryname="hpbnc"
pidfile="hpbnc.pid"
# logfile... or use /dev/null for no log
logfile="hpbnc.log"
config="hpbnc.conf"

if [ ! -d $hpbncpath ]; then
 echo "Directory $hpbncpath does not exist..."
 exit 1
fi

if [ ! -f $hpbncpath/$hpbncbinaryname ]; then
 echo "File $hpbncpath/$hpbncbinaryname does not exist..."
 exit 1
fi

if [ -f $hpbncpath/$pidfile ]; then
 PID=`cat $hpbncpath/$pidfile`
 if `kill -CHLD $PID >/dev/null 2>&1`; then
  #seems to be running ok
  exit 0
 fi
 echo "Pidfile was found but hbnc wasnt running, restarting..."
 rm $hpbncpath/$pidfile   
else 
 echo "Pidfile was not found, starting hbnc..."
fi

echo "Starting hbnc..."

OLDPWD=$PWD
cd $hpbncpath
./$hpbncbinaryname $config >>$logfile
cd $OLDPWD

exit 0
