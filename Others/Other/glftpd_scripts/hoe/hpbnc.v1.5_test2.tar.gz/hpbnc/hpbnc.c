#define VERSION "v1.5_test2"
//#define RESOLVE_HOSTS_BNC


#include <sys/types.h>
#include <stdarg.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <pwd.h>
#include <unistd.h>
#include <netdb.h>
#include <string.h>
#include <sys/param.h>
#include <sys/time.h>

#define BUFLEN 4096

char rhosts[2048];
int lport, idnt;
char pidfile[1024], lbind[256], rbind[256];

int readconfig(char *filename)
{
    FILE *in_file;              //, *dircheck;
    char line[2048], label[2048], value[2048], *start;

    lport = -1;
    strcpy(pidfile, "hpbnc.pid");
    strcpy(rhosts, "");
    idnt = 0;
    strcpy(lbind, "");
    strcpy(rbind, "");

    if (!(in_file = fopen(filename, "r")))
        return (0);

    do {
        fgets(line, 2047, in_file);
        if (!feof(in_file)) {
            if (line[0] != '#') {
                strcpy(label, line);

                start = strrchr(label, '\n');
                if (start)
                    *start = '\0';

                start = strrchr(label, '\r');
                if (start)
                    *start = '\0';

                start = strchr(label, '=');
                if (start)
                    *start = '\0';
                else
                    start = label;

                strcpy(value, start + 1);
                if (*label != '\0') {
                    if (!strcasecmp(label, "LPORT")) {
                        lport = atoi(value);
                    } else if (!strcasecmp(label, "IDNT")) {
                        idnt = atoi(value);
                    } else if (!strcasecmp(label, "RHOSTS")) {
                        strncpy(rhosts, value, 2047);
                        rhosts[2047] = '\0';
                    } else if (!strcasecmp(label, "LBIND")) {
                        strncpy(lbind, value, 255);
                        lbind[255] = '\0';
                    } else if (!strcasecmp(label, "RBIND")) {
                        strncpy(rbind, value, 255);
                        lbind[255] = '\0';
                    } else if (!strcasecmp(label, "PIDFILE")) {
                        strncpy(pidfile, value, 1023);
                        pidfile[1023] = '\0';
                    } else {
                        printf("unknown label '%s' in configfile.\n",
                               label);
                        fclose(in_file);
                        return (0);
                    }
                }
            }
        }
    }
    while (!feof(in_file));

    fclose(in_file);

    return (1);
}

extern char *rfc931(struct sockaddr_in *rmt_sin,
                    struct sockaddr_in *our_sin);

int acceptnb(int s, struct sockaddr_in *cs, int maxsec)
{
    int flags, n;
    fd_set ac_s;
    int len;
    struct timeval tval;

    flags = fcntl(s, F_GETFL, 0);
    if (flags == -1)
        return (-1);
    n = fcntl(s, F_SETFL, flags | O_NONBLOCK);
    if (flags == -1)
        return (-1);

    FD_ZERO(&ac_s);
    FD_SET(s, &ac_s);
    tval.tv_sec = maxsec;
    tval.tv_usec = 0;

    n = select(s + 1, &ac_s, NULL, NULL, maxsec ? &tval : NULL);
    if (n == 0)
        return (0);

    if (FD_ISSET(s, &ac_s)) {
        len = sizeof(struct sockaddr_in);
        n = accept(s, (struct sockaddr *) cs, &len);
        if (n == -1) {
            switch (errno) {
            case EWOULDBLOCK:
            case ECONNABORTED:
#ifndef FIX_BSD
            case EPROTO:
#endif
            case EINTR:
                if (fcntl(s, F_SETFL, flags) == -1)
                    return (-1);
                return (0);
            default:
                return (-1);
            }
        }
        if (fcntl(s, F_SETFL, flags) == -1)
            return (-1);
        return (n);
    }
    if (fcntl(s, F_SETFL, flags) == -1)
        return (-1);
    return (0);
}

#ifndef FIX_BSD
char **Argv = NULL;             /* pointer to argument vector */
char *LastArgv = NULL;          /* end of argv */

void setproctitle(char *fmt, ...)
{
    register char *p;
    register char *bp;
    register char ch;
    register int i;
    char buf[BUFSIZ];
    va_list argp;

    /*
     * Build "buf" out of variable args
     */
    va_start(argp, fmt);
    vsnprintf(buf, sizeof(buf), fmt, argp);
    va_end(argp);

    /*
     * Make "ps" print our process name
     */
    p = Argv[0];

    i = strlen(buf);
    if (i > LastArgv - p - 2) {
        i = LastArgv - p - 2;
        buf[i] = '\0';
    }

    bp = buf;
    while ((ch = *bp++))
        if (ch != '\n' && ch != '\r')
            *p++ = ch;
    *p++ = '\0';
    while (p < LastArgv)
        *p++ = ' ';
}
#endif
int main(int argc, char **argv, char **envp) 
{
    int lsock, csock, osock;
    FILE * cfile, *pid_file;
    char buf[BUFLEN];
    struct sockaddr_in laddr, caddr, oaddr;
    struct hostent *h;
    struct sockaddr_in sourcedef;
//  int caddrlen = sizeof(caddr);
    fd_set fdsr, fdse;
    
//  struct servent *s;
    int nbyt, maxfd;
    unsigned long a;
    char *curport;
    char *identname;
    struct passwd *passw;
    char tempstr[2048], *tempptr1, *tempptr;
    char *cwd = NULL;

#ifndef FIX_BSD
    Argv = argv;
    while (*envp)
        envp++;
    LastArgv = envp[-1] + strlen(envp[-1]);
#endif
    setbuf(stdout, NULL);
    if (argc != 2) {
        fprintf(stderr, "hpbnc %s\n", VERSION);
        fprintf(stderr, "Usage: %s config_file\n", argv[0]);
        return -1;
    }
    if (readconfig(argv[1]) == 0) {
        fprintf(stderr, "Error reading config file\n");
        return -1;
    }

    laddr.sin_port = htons((unsigned short) (lport));
    if ((lsock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
        perror("socket");
        return 20;
    }
    laddr.sin_family = htons(AF_INET);
    if (strcmp(lbind, "") != 0) {
        a = inet_addr(lbind);
        if (!(h = gethostbyname(lbind))
             && !(h = gethostbyaddr((char *) &a, 4, AF_INET))) {
            perror(lbind);
            goto quit1;
        }
        memcpy(&laddr.sin_addr, h->h_addr, h->h_length);        
    } else
        laddr.sin_addr.s_addr = htonl(0);
       //bind to all ifaces
        if (bind(lsock, (struct sockaddr *) &laddr, sizeof(laddr))) {
        perror("bind");
        return 20;
    }
    if (listen(lsock, 1)) {
        perror("listen");
        return 20;
    }
    if ((nbyt = fork()) == -1) {
        perror("fork");
        return 20;
    }
    if (nbyt > 0)
         {
        return 0;
        }
    //edit this to fake the processes to whatever you want
    setproctitle("%s", argv[0]);
    setsid();
    
    //create pid file
    pid_file = fopen(pidfile, "w");
    if (pid_file == NULL) {
        fprintf(stderr, "cannot create pidfile %s: %s\n", pidfile,
                strerror(errno));
        return -1;
    }
    fprintf(pid_file, "%d", (int) getpid());
    fclose(pid_file);

    if (getuid() == 0) {
//   fprintf(stderr,"Running as root... trying to chroot and change uid...");
        passw = getpwnam("nobody");
        if (passw == NULL) {
            fprintf(stderr, "unable to find uid for nobody\n");
            return 666;
        }
        cwd = getcwd(NULL, MAXPATHLEN);
        if (!cwd) {
            fprintf(stderr, "getcwd() failed\n");
            return 30;
        }
//had problems with resolving after chroot (/etc/hosts)
/*   printf("chrooting to %s\n",cwd);
   if (chroot(cwd)) {
    fprintf(stderr,"Unable to chroot to %s\n",cwd);
    return 30;
   }
*/ printf("changing uid to %d\n", passw->pw_uid);
        if (setuid(passw->pw_uid)) {
            fprintf(stderr, "Unable to setuid to %d\n", passw->pw_uid);
            return 30;
        }
    }

    tempptr1 = tempstr;
    strcpy(tempptr1, rhosts);

    tempptr = strsep(&tempptr1, " ");
    if (tempptr == NULL) {
        fprintf(stderr, "RHOSTS empty ?\n");
        return 40;
    }

    tempptr1 = tempstr;
    strcpy(tempptr1, rhosts);
    tempptr = strsep(&tempptr1, " ");

    while (1) {
        csock = acceptnb(lsock, &caddr, 2);
        if (csock == -1) {
            continue;
        }
        if (csock == 0) {
            //we handle the finished child processes...
            while (waitpid(-1, NULL, WNOHANG) > 0);
            continue;
        }
        cfile = fdopen(csock, "r+");
        if ((nbyt = fork()) == -1) {
            fprintf(cfile, "500 fork: %s\n", strerror(errno));
            fprintf(stdout, "fork: %s\n", strerror(errno));
            shutdown(csock, 2);
            fclose(cfile);
            continue;
        }
        if (nbyt == 0)
            break;

        fclose(cfile);
        
            //get cur host and port
        tempptr = strsep(&tempptr1, " ");
        if (tempptr == NULL) {
            tempptr1 = tempstr;
            strcpy(tempptr1, rhosts);
            tempptr = strsep(&tempptr1, " ");
        }


        while (waitpid(-1, NULL, WNOHANG) > 0);
    }
    
// gotsock:
        if ((osock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
        fprintf(cfile, "500 socket: %s\n", strerror(errno));
        fprintf(stdout, "socket: %s\n", strerror(errno));
        goto quit1;
    }
    memset(&sourcedef, '\0', sizeof(struct sockaddr_in));

    if (strcmp(rbind, "") != 0) {
        a = inet_addr(rbind);
        if (!(h = gethostbyname(rbind))
             && !(h = gethostbyaddr((char *) &a, 4, AF_INET))) {
            //XXX
	    perror(rbind);
            goto quit1;
        }
        memcpy(&sourcedef.sin_addr, h->h_addr, h->h_length);
    } else
        sourcedef.sin_addr.s_addr = htonl(0);
                               //bind to all ifaces
        sourcedef.sin_family = AF_INET;
    sourcedef.sin_port = 0;


    if (bind(osock, (struct sockaddr *) &sourcedef,
             sizeof(struct sockaddr_in)) < 0) {
        fprintf(cfile, "500 bind: %s\n", strerror(errno));
        fprintf(stdout, "bind: %s\n", strerror(errno));
        goto quit1;
    }

    if ((curport = strrchr(tempptr, ':')) != NULL) {
        *curport = '\0';
        curport++;
    } else {
        fprintf(stdout, "error getting port in RHOSTS");
        fprintf(cfile, "500 error getting port in RHOSTS");
        goto quit1;
    }

//yes we resolve here, slow but better for dynip hosts
    a = inet_addr(tempptr);
    if (!(h = gethostbyname(tempptr))
         && !(h = gethostbyaddr((char *) &a, 4, AF_INET))) {
        //XXX
	perror(tempptr);
        goto quit1;
    }
    oaddr.sin_family = h->h_addrtype;
    oaddr.sin_port = htons(atol(curport));
    memcpy(&oaddr.sin_addr, h->h_addr, h->h_length);
    if (connect(osock, (struct sockaddr *) &oaddr, sizeof(oaddr))) {
        fprintf(cfile, "500 connect: %s\n", strerror(errno));
        fprintf(stdout, "connect: %s\n", strerror(errno));
        goto quit1;
    }
    
        /* get remote user's name */
        identname = rfc931(&caddr, &laddr);
#ifdef RESOLVE_HOSTS_BNC
    {
        struct hostent *hp;
        char remotehost[MAXHOSTNAMELEN];
        /* get remote host name */
        hp = gethostbyaddr((char *) &caddr.sin_addr,
                           sizeof(struct in_addr), AF_INET);
        if (hp)
            (void) strncpy(remotehost, hp->h_name, sizeof(remotehost));
        else
            (void) strncpy(remotehost, inet_ntoa(caddr.sin_addr),
                           sizeof(remotehost));

        printf("connection from %s@%s (%s)\n", identname, remotehost,
               inet_ntoa(caddr.sin_addr));
        if (idnt) {
            snprintf(buf, BUFLEN, "IDNT %s@%s:%s\n", identname,
                     inet_ntoa(caddr.sin_addr), remotehost);
            if ((write(osock, buf, strlen(buf))) <= 0)
                goto quit2;
        }
    }
#else
    printf("connection from %s@%s\n", identname,
           inet_ntoa(caddr.sin_addr));
    if (idnt) {
        /* like dike */
        snprintf(buf, BUFLEN, "IDNT %s@%s:%s\n", identname,
                 inet_ntoa(caddr.sin_addr), inet_ntoa(caddr.sin_addr));
        if ((write(osock, buf, strlen(buf))) <= 0)
            goto quit2;
    }
#endif
    while (1) {
        
//sleep(20);
            FD_ZERO(&fdsr);
        FD_ZERO(&fdse);
        FD_SET(csock, &fdsr);
        FD_SET(csock, &fdse);
        FD_SET(osock, &fdsr);
        FD_SET(osock, &fdse);
        maxfd = ((csock > osock) ? csock : osock) + 1;
        if (select(maxfd, &fdsr, NULL, &fdse, NULL) == -1) {
            fprintf(cfile, "500 select: %s\n", strerror(errno));
            fprintf(stdout, "select: %s\n", strerror(errno));
            goto quit2;
        }
        if (FD_ISSET(csock, &fdsr) || FD_ISSET(csock, &fdse)) {
            if ((nbyt = read(csock, buf, BUFLEN)) <= 0)
                goto quit2;
            if ((write(osock, buf, nbyt)) <= 0)
                goto quit2;
        } else if (FD_ISSET(osock, &fdsr) || FD_ISSET(osock, &fdse)) {
            if ((nbyt = read(osock, buf, BUFLEN)) <= 0)
                goto quit2;
            if ((write(csock, buf, nbyt)) <= 0)
                goto quit2;
        }
    }
  quit2:shutdown(osock, 2);
    close(osock);
  quit1:fflush(cfile);
    shutdown(csock, 2);
    
// quit0:
    fclose(cfile);
    return 0;
}


