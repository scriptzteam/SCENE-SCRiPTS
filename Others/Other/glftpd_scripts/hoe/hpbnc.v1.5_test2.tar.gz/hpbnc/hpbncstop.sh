#!/bin/sh
# will kill running hbnc

hpbncpath="."
pidfile="hpbnc.pid"

if [ ! -d $hpbncpath ]; then
 echo "Directory $hpbncpath does not exist..."
 exit 1
fi

if [ -f $hpbncpath/$pidfile ]; then
 PID=`cat $hpbncpath/$pidfile`
 echo "killing PID $PID..."
 kill -9 $PID >/dev/null 2>&1
 rm $hpbncpath/$pidfile   
else 
 echo "Pidfile $hpbncpath/$pidfile not found..."
fi

exit 0
