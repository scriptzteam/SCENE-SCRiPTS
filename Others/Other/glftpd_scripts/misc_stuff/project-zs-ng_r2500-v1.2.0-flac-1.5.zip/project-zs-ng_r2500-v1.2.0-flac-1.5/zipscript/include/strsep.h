#ifndef STRSEP_H
#define STRSEP_H
char    *strsep(char **, const char *);
#endif
