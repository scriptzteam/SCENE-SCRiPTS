#ifndef _CRC_H_
#define _CRC_H_

unsigned int calc_crc32(char *);

#endif
