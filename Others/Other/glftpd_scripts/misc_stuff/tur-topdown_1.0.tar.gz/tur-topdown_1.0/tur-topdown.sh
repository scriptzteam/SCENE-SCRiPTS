#!/bin/bash
VER=1.0

#--------------------------------------------------------#
#                                                        #
# Tur-TopDown. A script which produces a list of         #
# the most downloaded release per section.               #
#                                                        #
# REQUIRES: xferlog-import.sh & tur-relsizeupdate.sh     #
#           installed and working.                       #
#                                                        #
#--[ Setup ]---------------------------------------------#
#                                                        #
# Copy tur-topdown.sh to /glftpd/bin. Chmod to 700.      #
#                                                        #
# Change the settings.                                   #
#                                                        #
# Run it once manually. Check the output file for the    #
# final result.                                          #
#                                                        #
# Crontab it as often as you like. Once a day should be  #
# good enough.                                           #
# 0 0 * * * /glftpd/bin/topdown_sql.sh >/dev/null 2>&1   #
#                                                        #
# If you want to present this data in your welcome.msg   #
# then add this to it:                                   #
# %!/ftp-data/misc/topdown                               #
#                                                        #
#--[ Configuration ]-------------------------------------#

## These should be self explaining. 
## I'm just gonna assume you have the same MySQL server
## for both xferlog-import.sh and tur-relsizeupdate.sh
SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"

## Database and table for xferlog-import.sh
TRANSFER_SQLDB="transfers"
TRANSFER_SQLTB="transfers"

## Database and table for tur-relsizeupdate.sh
RELSIZE_SQLDB="relsize"
RELSIZE_SQLTB="relsize"

## Number of releases to show per section.
NumberToShow=5

## Temporary path somewhere
tmp=/glftpd/tmp

## Sections you want to include in the list. Should be set
## as they are in the transfers table (xferlog-import.sh).
## The order set is the order in which they will appear.
SECTIONS="DVDR ISO-UTILS XBOX XXX"

## Output file produced.
output=/glftpd/ftp-data/misc/topdown

## If, for some reason, you get weird results from some releases,
## you can add the full releasename here and it will be skipped
## in the future. Shouldnt be needed if the two required scripts
## are setup as they should.
## Seperate releases with a space or newline. As long as its
## included in ""
fuckeduprels=""

## This script works by grabbing the most downloaded releases.
## It then compares that list to the size of the release and gets
## a download ratio. Most downloaded does not have to mean most
## popular since the size differs, so it grabs a large number to
## compare. This is the list of how many release will be tested.
## The larger the number, the more accurate and more slower it 
## will become. 300 is a good round number. On slow boxes, you
## might want to lower it a bit. Play around.
matches="300"

## If this is set, only traffic of releases from this date and forward
## will be counted for. If not, its the "most downloaded ever" list
## thats used. From the example here, it uses date to produce the
## current year and adds 01-01 to make 2005-01-01 and forward.
## Make sure you set an accurate date here.
## Set to "" to disable.
only_since=`date +%Y`"-01-01"

## This is the header of the output file.
## I've added a # line to use as an example if only_since is "".

proc_header() {
  echo "+-----------------------------------------------------------+" > $output
# echo "+                Top downloaded releases ever !             +" >> $output
  echo "+                Top downloaded since $only_since !          +" >> $output
  echo "+-----------------------------------------------------------+" >> $output
  echo "+ (# Of DL's) (size) (Total DL) (Release)                    " >> $output
}

## This is the footer of the file.

proc_footer() {
  showdate="$( date +%c )"
  echo "+-----------------------------------------------------------+" >> $output
  echo "+  Last Updated: $showdate           +" >> $output
  echo "+----------------------------------------[ Turranius 2003 ]-+" >> $output
}


#--[ Script Start ]----------------------------------------#

if [ "$only_since" ]; then
  echo "Only looking for stuff from $only_since and forward."
  only_since_sql="and datum >= '${only_since}'"
fi

TRANSFER_SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $TRANSFER_SQLDB -N -s -e"
RELSIZE_SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $RELSIZE_SQLDB -N -s -e"

if [ -e $tmp/final.tmp ]; then
  rm -f $tmp/final.tmp
fi

if [ "$fuckeduprels" = "" ]; then
  fuckeduprels="Jkfe893r7"
else
  fuckeduprels="$( echo $fuckeduprels | tr -s ' ' '|' )"
fi


for section in $SECTIONS; do
  unset TOPDL

  TOPDL="`$TRANSFER_SQL "select sum(size/1024/1024) as storlek, name from $TRANSFER_SQLTB where section = '$section' and direction = 'o' $only_since_sql group by name order by storlek desc limit $matches" | awk '{print $1"^"$2}' | egrep -vi "$fuckeduprels"`"

  for each in `echo $TOPDL`; do
    unset diff; unset rel; unset relrel; unset amount; unset amountrel; unset TOPDL; unset size
    amount="$( echo $each | awk -F"^" '{print $1}' )"
    rel="$( echo $each | awk -F"^" '{print $2}' )"
   
    ## Check actual size from folder from relsize DB.
    sizetest=`$RELSIZE_SQL "select size, name from $RELSIZE_SQLTB where name = '$rel' limit 1" | awk '{print $1"^"$2}'`
    if [ "$sizetest" ]; then
      ## Found it in DB
      size="$( echo $sizetest | awk -F"^" '{print $1}' )"
      readrel="$( echo $sizetest | awk -F"^" '{print $2}' )"
      rm -f $tmp/outputrelsize.tmp
      echo "size from DB: $size $rel"
    fi
     
    if [ -z "$size" ]; then
      echo "No size found for $rel. Skipping"
      echo ""
    else
      echo "Out: $amount $rel"
      echo "In : $size $readrel"
      if [ "$size" != "0" ]; then
        diff="$( echo $amount / $size | bc -l | cut -b1-4 )"
      else
        diff="0"
      fi
      difftest="$( echo $diff | awk -F"." '{print $1}' )"
      if [ -z "$difftest" ]; then
        diff="0"
      elif [ "$difftest" -gt "100" ]; then
        diff="0.00"
      fi
      if [ "$rel" != "$readrel" ]; then
        echo "Found wrong rel? $rel <?> $readrel"
      fi
      size="$( echo $size | awk -F"." '{print $1}' )"
      amount="$( echo $amount | awk -F"." '{print $1}' )"
      echo "Downloaded $diff times ( $amount/ $size )"
      unset difftest
      echo ""
      echo "$diff^$rel^$size^$amount" >> $tmp/final.tmp
    fi
  done

  if [ -z "$saidit" ]; then
    proc_header
    saidit="yepp"
  fi

  echo "+ Section: $section                                          " >> $output

  for each in `cat $tmp/final.tmp | sort -n -r | head -n $NumberToShow`; do
    dl="$( echo $each | awk -F"^" '{print $1}' )"
    if [ "$dl" != "0" ]; then
      sz="$( echo $each | awk -F"^" '{print $3}' )"
      sz="${sz}MB"
      while [ -z "`echo "$sz" | grep "......."`" ]; do
        sz=" $sz"
      done

      td="$( echo $each | awk -F"^" '{print $4}' )"
      td="${td}MB"
      while [ -z "`echo "$td" | grep "........."`" ]; do
        td=" $td"
      done

      rl="$( echo $each | awk -F"^" '{print $2}' )"
      echo "  $dl $sz $td   $rl" >> $output
      rm -f $tmp/final.tmp
    fi
  done
  rm -f $tmp/final.tmp
done

proc_footer

exit 0
