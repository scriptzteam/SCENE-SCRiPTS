#!/bin/bash

## Reads file that tur-topdown.sh makes and presents it in chan.
## Kinda needs the default footer if you want to display the 
## last updated part.
##
## Copy to /glftpd/bin. Chmod 755
## Load the tcl in your bot. Change the trigger and/or path to
## topdown-announce.sh if needed.
##
## Run topdown-announce.sh from shell to test it.

## Sections as defined in tur-topdown.sh
SECTIONS="DVDR ISO-UTILS XBOX XXX"

## Topdown file (output in tur-topdown.sh)
topdown=/glftpd/ftp-data/misc/topdown

## Lines to show. Should match NumberToShow in tur-topdown.sh
lines="5"


#--[ Script Start ]--------------------------#

COMMAND="$1"

if [ ! -r "$topdown" ]; then
  echo "Error. Cant read topdown file."
  exit 0
fi

COMMAND="$( echo "$COMMAND" | tr '[:lower:]' '[:upper:]' )"

if [ -z "$COMMAND" ]; then
  echo "Specify a section too. Section are $SECTIONS"
  exit 0
fi

if [ -z "$( echo "$SECTIONS" | grep -w "$COMMAND" )" ]; then
  echo "Invalid section. Sections are $SECTIONS"
  exit 0
fi

echo "Top Downloaded Releases in $COMMAND"
echo "Times |Size    |Leeched  |Name"

grep -A${lines} "Section: $COMMAND" $topdown | grep -v "Section:" | cut -c3-

grep "Last Updated" $topdown | tr -d '+' | cut -c3-