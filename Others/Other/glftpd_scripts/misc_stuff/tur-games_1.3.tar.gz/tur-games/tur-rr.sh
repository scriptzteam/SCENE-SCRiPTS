#!/bin/sh
VER=1.2

USERPATH=/ftp-data/users
BACKUPPATH=/ftp-data/users/backup
TEMPPATH=/tmp
LOCKFILE=/tmp/rr.lock
GLLOGFILE=/ftp-data/logs/games.log
LOGFILE=/ftp-data/logs/rr.log
LOGFILETMP=/ftp-data/logs/rrtmp.log
USERFILETMP=/tmp/$USER.RRTMP
BINFOLDER=/bin
LOCKDELETEPASS=deletelock
MINBET=400
MAXROUNDS=8

MSG1="looks real cool, putting the gun to his head and..."
MSG2="quickly grabs the gun and..."
MSG3="grabs the gun from the table and..."
MSG4="breaks a sweat as he takes the gun and..."
MSG5="pees his pants when the gun goes"
MSG6="presses the gun to his head and..."
MSG7="feels the pressure of the barrel and..."
MSG8="does not even blink and..."
MSG9="gets the shakes and..."
MSG10="sees his life flash before his eyes when the gun goes"



#--[ Script Start ]--#

proc_output() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $GLLOGFILE
}

BOLD=""
ULINE=""

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

DEAD="0"

## If the user does not type anything after 'site rr', this is displayed.
if [ -z $1 ]; then
  echo "-----------------[ Roussian Roulette $VER ]---------------------"
  echo "Usage: site rr attack <user> <MB>  - Challenge user to a fight "
  echo "Usage: site rr accept <user>       - Accept the fight          "
  echo "Usage: site rr deny                - Cancel any challenges     "    
  echo "Usage: site rr highscores          - To see the highscores     "
  echo "Usage: site myscore                - Your score in all games   "
  echo "---------------------------------------------------------------"
  echo "Hint: use 'site rr accept' to see if anyone has challenged you."
  echo "This is Russian Roulette with a twist. You have one gun and one"
  echo "bullet. You take turns putting the gun to your own head and    "
  echo "pulling the trigger. The first one to dies looses!             "
  echo "The first round, there is a 10% chance that the gun goes off.  "
  echo "For round two, 20% etc etc.                                    "
  echo "----------------------------------------[ Turranius 2002 ]-----"
  exit 0
fi

## Create or update filedate on logfile.
touch $LOGFILE

if [ "$1" = "$LOCKDELETEPASS" ]; then
  if [ -e "$LOCKFILE" ]; then
    echo "Clearing lockfile."
    rm -f $LOCKFILE
    exit 0
  else
    echo "Lockfile not found."
    exit 0
  fi
fi

## User selected to see highscores.
if [ "$1" = "highscores" ]; then
  echo "----------[ Highscore for Roussian Roulette ] ----------"
  echo "Player:  Win-Ratio:  Dollah ratio:                      "
  cat $LOGFILE | sort -k 2,2 -n -r
  echo "-----[ Roussian Roulette was created by Turranius ]-----"
  exit 0
fi

## Check that another game isnt running.
if [ -e $LOCKFILE ]; then
  echo "Another game is in progress. Try again once they are dead."
  exit 0
fi

if [ "$1" = "attack" ]; then
  USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
  USERCREDSMB="$(expr $USERCREDSKB \/ 1024)"
 
  if [ "$2" = "" ]; then
    echo "You must specify who you wish to attack."
    exit 0
  else
    if [ "$2" = "$USER" ]; then
      echo "You challenge yourself and win and loose at the same time."
      echo "Good work!"
      proc_output "${BOLD}-(RR)- $USER${BOLD} shoots himself in the head."
      exit 0
    fi
 
    if [ -e $USERPATH/$2 ]; then
      ok=yes
    else
      echo "User $2 was not found"
      exit 0
    fi

    if [ -e $TEMPPATH/rr_$2 ]; then
      echo "That user has already been challenged. Get in line."
      exit 0
    fi

    ## Check that the user does not have leech
    RATIO=$(grep RATIO $USERPATH/$USER | awk -F" " '{print $2}')
    if [ $RATIO = "0" ]; then
      echo "Sorry, you are immortal and therefor cant play! (leech=noplay)"
      exit 0
    fi

    ## Check that the opponent does not have leech
    RATIO=$(grep RATIO $USERPATH/$2 | awk -F" " '{print $2}')
    if [ $RATIO = "0" ]; then
      echo "Sorry, your opponent has leech. Cant fight someone that powerful!"
      exit 0
    fi

    if [ -f $USERPATH/$2 ]; then
      if [ "$3" = "" ]; then
        echo "You must also choose how many dollars you wish to challenge him for."
        USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
        USERCREDSMB="$(expr $USERCREDSKB \/ 1024)"
        OPCREDSKB="$(cat $USERPATH/$2 | grep CREDITS | awk -F" " '{print $2}')"
        OPCREDSMB="$(expr $OPCREDSKB \/ 1024)"
        echo "You have $USERCREDSMB dollars"
        echo "Your opponent has $OPCREDSMB dollars"
        exit 0
      else
        if [ "`echo "$3" | grep "......"`" ]; then
          echo "Too many chars in bet."
          exit 0
        fi

        if [ "$3" -lt "$MINBET" ]; then
          echo "Sorry, minimum amount to fight for is $MINBET dollars."
          exit 0
        fi

        VALIDATE="$(expr $3 \* 2)"
        if [ "$VALIDATE" = "" ]; then
          echo "Seems to be a problem with your bet. Did you use dots?"
          exit 0
        fi

        # echo "checking if both have creds, then go"
        USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
        USERCREDSMB="$(expr $USERCREDSKB \/ 1024)"
        OPCREDSKB="$(cat $USERPATH/$2 | grep CREDITS | awk -F" " '{print $2}')"
        OPCREDSMB="$(expr $OPCREDSKB \/ 1024)"
        if [ $3 -gt $USERCREDSMB ]; then
          echo "Heh, you can't afford that fight, shithead."
          exit 0
        fi
        if [ $3 -gt $OPCREDSMB ]; then
          echo "Pick on someone your own size! That poor jerkoff can't afford it."
          exit 0
        fi
        echo "$USER pulls out the gun and tells $2 '$3 dollars says this bullet goes in you head!'"
        #MESSAGE="$($BINFOLDER/randomit 1 5)"

        LOW=1
        HIGH=5
        proc_random
        MESSAGE="$number"


        if [ "$MESSAGE" = "1" ]; then
          proc_output "${BOLD}-(RR)- $USER${BOLD} shows a gun, one bullet and ${BOLD}$3${BOLD} Dollars to ${BOLD}$2${BOLD}."
        fi
        if [ "$MESSAGE" = "2" ]; then
          proc_output "${BOLD}-(RR)- $USER${BOLD} has ${BOLD}$3${BOLD} Dollars and one fine looking gun. ${BOLD}$2${BOLD} is toast!"
        fi
        if [ "$MESSAGE" = "3" ]; then
          proc_output "${BOLD}-(RR)- $USER${BOLD} tells ${BOLD}$2${BOLD}: 'Yo papa!', then slaps him with ${BOLD}$3${BOLD} Dollars."
        fi
        if [ "$MESSAGE" = "4" ]; then
          proc_output "${BOLD}-(RR)- $USER${BOLD} suggests a match of russian roulette with ${BOLD}$2${BOLD} for ${BOLD}$3${BOLD} Dollars."
        fi
        if [ "$MESSAGE" = "5" ]; then
          proc_output "${BOLD}-(RR)- $USER${BOLD} calls ${BOLD}$2${BOLD} a big fat wuss and slaps him with ${BOLD}$3${BOLD} Dollars."
        fi

        echo "$USER $3" > $TEMPPATH/rr_$2
        exit 0
      fi
    fi
  fi
fi


if [ "$1" = "deny" ]; then
  if [ -e $TEMPPATH/rr_$USER ]; then
    ATTACKER="$(cat $TEMPPATH/rr_$USER | awk -F" " '{print $1}')"
    echo "You chicken out on $ATTACKER's attack."
    proc_output "${BOLD}-(RR)- $USER${BOLD} chickens out and flees from $ATTACKER"
    rm -f $TEMPPATH/rr_$USER
    exit 0
  else
    echo "You do not have any challenges on you."
    exit 0
  fi
fi


if [ "$1" = "accept" ]; then
  if [ ! -e $TEMPPATH/rr_$USER ]; then
    echo "Nobody has challenged you yet. Make some enemies!"
    exit 0
  fi

  ATTACKER="$(cat $TEMPPATH/rr_$USER | awk -F" " '{print $1}')"
  FIGHTMB="$(cat $TEMPPATH/rr_$USER | awk -F" " '{print $2}')"
  
  if [ "$2" = "" ]; then
    echo "$ATTACKER has challenged you to russian roulette for $FIGHTMB Dollahs."
    echo "Type 'site rr accept $ATTACKER' to accept."
    echo "Type 'site rr deny $ATTACKER' to deny."
    exit 0
  fi
  
  if [ "$2" != "$ATTACKER" ]; then
    echo "$2 has not challenged you. $ATTACKER has."
    exit 0
  fi

  CUR_CREDS="`grep "^CREDITS " $USERPATH/$USER | cut -d ' ' -f2`"
  CUR_CREDS_MB="`echo "$CUR_CREDS / 1024" | bc -l | cut -d '.' -f1`"
  if [ "$CUR_CREDS_MB" -lt "$FIGHTMB" ]; then
    echo "You dont have the cash to accept that fight."
    rm -f $TEMPPATH/rr_$USER
    exit 0
  fi
  CUR_CREDS="`grep "^CREDITS " $USERPATH/$ATTACKER | cut -d ' ' -f2`"
  CUR_CREDS_MB="`echo "$CUR_CREDS / 1024" | bc -l | cut -d '.' -f1`"
  if [ "$CUR_CREDS_MB" -lt "$FIGHTMB" ]; then
    echo "$ATTACKER cant no longer afford this fight."
    rm -f $TEMPPATH/rr_$USER
    exit 0
  fi

  ## Here we go!
  touch $LOCKFILE
  echo "$ATTACKER vs $USER for $FIGHTMB Dollahs"
  proc_output "${BOLD}-(RR)-${BOLD} Russian Roulette: ${BOLD}$ATTACKER${BOLD} vs ${BOLD}$USER${BOLD} for ${BOLD}$FIGHTMB${BOLD} Dollars."

  ## Coin toss.
  #COINTOSS="$($BINFOLDER/randomit 1 100)"

  LOW=1
  HIGH=100
  proc_random
  COINTOSS="$number"

  if [ "$COINTOSS" -lt "51" ]; then
    echo "$ATTACKER wins cointoss. $USER goes first."
    proc_output "${BOLD}-(RR)- $ATTACKER${BOLD} wins cointoss. ${BOLD}$USER${BOLD} will go first."
    FIRST="$USER"
    SECOND="$ATTACKER"
  else
    echo "$USER wins cointoss. $ATTACKER goes first."
    proc_output "${BOLD}-(RR)- $USER${BOLD} wins cointoss. ${BOLD}$ATTACKER${BOLD} will go first."
    FIRST="$ATTACKER"
    SECOND="$USER"
  fi

    while [ "$DEAD" != "1" ]; do
echo "maxrounds is $MAXROUNDS"
      #BULLET="$($BINFOLDER/randomit 1 $MAXROUNDS)"

      LOW=1
      HIGH="$MAXROUNDS"
      proc_random
      BULLET="$number"
echo "bullet is $BULLET"

    
      if [ "$BULLET" != "1" ]; then
        #RANDOMNUM="$($BINFOLDER/randomit 1 10)"

        LOW=1
        HIGH=10
        proc_random
        RANDOMNUM="$number"

        case $RANDOMNUM in
          1) MESSAGE="$FIRST $MSG1 CLICK";;
          2) MESSAGE="$FIRST $MSG2 CLICK";;
          3) MESSAGE="$FIRST $MSG3 CLICK";;
          4) MESSAGE="$FIRST $MSG4 CLICK";;
          5) MESSAGE="$FIRST $MSG5 CLICK";;
          6) MESSAGE="$FIRST $MSG6 CLICK";;
          7) MESSAGE="$FIRST $MSG7 CLICK";;
          8) MESSAGE="$FIRST $MSG8 CLICK";;
          9) MESSAGE="$FIRST $MSG9 CLICK";;
          10) MESSAGE="$FIRST $MSG10 CLICK";;
          *) MESSAGE="$FIRST smiles and... CLICK";;
        esac
        echo $MESSAGE
        proc_output "${BOLD}-(RR)-${BOLD} $MESSAGE."
      else
        #RANDOMNUM="$($BINFOLDER/randomit 1 10)"

        LOW=1
        HIGH=10
        proc_random
        RANDOMNUM="$number"

        case $RANDOMNUM in
          1) MESSAGE="$FIRST $MSG1 BAM!";;
          2) MESSAGE="$FIRST $MSG2 BOOM!";;
          3) MESSAGE="$FIRST $MSG3 BANG!";;
          4) MESSAGE="$FIRST $MSG4 BAM!";;
          5) MESSAGE="$FIRST $MSG5 BANG!";;
          6) MESSAGE="$FIRST $MSG6 BANG!";;
          7) MESSAGE="$FIRST $MSG7 BOOOOM!";;
          8) MESSAGE="$FIRST $MSG8 KABAM!";;
          9) MESSAGE="$FIRST $MSG9 CLICK.. BOOOM!";;
          10) MESSAGE="$FIRST $MSG10 BAM!";;
          *) MESSAGE="$FIRST smiles and... BAM!";;
        esac
        echo $MESSAGE
        proc_output "${BOLD}-(RR)-${BOLD} $MESSAGE."
        DEAD="1"
        FIRSTDEAD="1"
      fi

      sleep 2
      #BULLET="$($BINFOLDER/randomit 1 $MAXROUNDS)"

      LOW=1
      HIGH="$MAXROUNDS"
      proc_random
      BULLET="$number"
    
      if [ "$DEAD" != "1" ]; then
        if [ "$BULLET" != "1" ]; then
          #RANDOMNUM="$($BINFOLDER/randomit 1 10)"

          LOW=1
          HIGH=10
          proc_random
          RANDOMNUM="$number"

          case $RANDOMNUM in
            1) MESSAGE="$SECOND $MSG1 CLICK";;
            2) MESSAGE="$SECOND $MSG2 CLICK";;
            3) MESSAGE="$SECOND $MSG3 CLICK";;
            4) MESSAGE="$SECOND $MSG4 CLICK";;
            5) MESSAGE="$SECOND $MSG5 CLICK";;
            6) MESSAGE="$SECOND $MSG6 CLICK";;
            7) MESSAGE="$SECOND $MSG7 CLICK";;
            8) MESSAGE="$SECOND $MSG8 CLICK";;
            9) MESSAGE="$SECOND $MSG9 CLICK";;
            10) MESSAGE="$SECOND $MSG10 CLICK";;
            *) MESSAGE="$SECOND smiles and... CLICK";;
          esac
          echo $MESSAGE
          proc_output "${BOLD}-(RR)-${BOLD} $MESSAGE."
        else
          #RANDOMNUM="$($BINFOLDER/randomit 1 10)"

          LOW=1
          HIGH=10
          proc_random
          RANDOMNUM="$number"

          case $RANDOMNUM in
            1) MESSAGE="$SECOND $MSG1 BAM!";;
            2) MESSAGE="$SECOND $MSG2 BOOM!";;
            3) MESSAGE="$SECOND $MSG3 BANG!";;
            4) MESSAGE="$SECOND $MSG4 BAM!";;
            5) MESSAGE="$SECOND $MSG5 BANG!";;
            6) MESSAGE="$SECOND $MSG6 BANG!";;
            7) MESSAGE="$SECOND $MSG7 BOOOOM!";;
            8) MESSAGE="$SECOND $MSG8 KABAM!";;
            9) MESSAGE="$SECOND $MSG9 CLICK.. BOOOM!";;
            10) MESSAGE="$SECOND $MSG10 BAM!";;
            *) MESSAGE="$SECOND smiles and... BAM!";;
          esac
          echo $MESSAGE
          proc_output "${BOLD}-(RR)-${BOLD} $MESSAGE."
          DEAD="1"
          SECONDDEAD="1"
        fi
      fi
      
      if [ "$DEAD" != "1" ]; then
        MAXROUNDS="$(expr "$MAXROUNDS" \- "1" )"
        sleep 2
      fi
    done
  

  if [ "$FIRSTDEAD" = "1" ]; then
    WINNER=$SECOND
    LOOSER=$FIRST
  else
    WINNER=$FIRST
    LOOSER=$SECOND
  fi
  echo "$LOOSER lost $FIGHTMB Dollahs to $WINNER."
  proc_output "${BOLD}-(RR)- $WINNER${BOLD} won $FIGHTMB Dollahs from ${BOLD}$LOOSER${BOLD}."
  ## Back up userfiles just in case.
  if [ "$BACKUPPATH" ]; then
    cp -f $USERPATH/$LOOSER $BACKUPPATH/$LOOSER.rr
    cp -f $USERPATH/$WINNER $BACKUPPATH/$WINNER.rr
  fi

  ## Remove creds from looser
  CREDSKB="$(cat $USERPATH/$LOOSER | grep CREDITS | awk -F" " '{print $2}')"
  FIGHTKB="$(expr $FIGHTMB \* 1024 )"
  NEWCREDSKB="$(expr $CREDSKB \- $FIGHTKB)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $NEWCREDSKB /1" $USERPATH/$LOOSER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$LOOSER
  rm -f $USERFILETMP

  ## COPS RAID.
  #COPS="$($BINFOLDER/randomit 0 100)"

  LOW=0
  HIGH=100
  proc_random
  COPS="$number"

  if [ "$COPS" -gt "90" ]; then
    proc_output "${BOLD}-(RR)- COPS${BOLD} raid and confiscates the winning from ${BOLD}$WINNER${BOLD}."
    WINLOG="$(grep $WINNER $LOGFILE | awk -F" " '{print $2}')"
    WINLOGCRED="$(grep $WINNER $LOGFILE | awk -F" " '{print $3}')"
    WINLOGCREDNEW="$WINLOGCRED"
    if [ "$WINLOG" = "" ]; then
      echo "$WINNER 1 0" >> $LOGFILE
      WINLOGNEW="1"
    else
      WINLOGNEW="$(expr $WINLOG + 1)"
      sed -e "s/^$WINNER.*/$WINNER $WINLOGNEW $WINLOGCREDNEW/" $LOGFILE > $LOGFILETMP
      cp -f $LOGFILETMP $LOGFILE
      rm -f $LOGFILETMP
    fi

  ## NO COPS.
  else
    ## Add creds to winner.
    CREDSKB="$(cat $USERPATH/$WINNER | grep CREDITS | awk -F" " '{print $2}')"
    FIGHTKB="$(expr $FIGHTMB \* 1024 )"
    NEWCREDSKB="$(expr $CREDSKB \+ $FIGHTKB)"
    sed -e "s/^CREDITS [0-9]* /CREDITS $NEWCREDSKB /1" $USERPATH/$WINNER > $USERFILETMP
    cp -f $USERFILETMP $USERPATH/$WINNER
    rm -f $USERFILETMP
 
    ## Winners Logfile.
    WINLOG="$(grep $WINNER $LOGFILE | awk -F" " '{print $2}')"
    WINLOGCRED="$(grep $WINNER $LOGFILE | awk -F" " '{print $3}')"
    if [ "$WINLOG" = "" ]; then
      echo "$WINNER 1 $FIGHTMB" >> $LOGFILE
      WINLOGNEW="1"
      WINLOGCREDNEW="$FIGHTMB"
    else
      WINLOGNEW="$(expr $WINLOG + 1)"
      WINLOGCREDNEW="$(expr $WINLOGCRED \+ $FIGHTMB )"
      sed -e "s/^$WINNER.*/$WINNER $WINLOGNEW $WINLOGCREDNEW/" $LOGFILE > $LOGFILETMP
      cp -f $LOGFILETMP $LOGFILE
      rm -f $LOGFILETMP
    fi
  fi
  
  ## Looser Logfile.
  LOSLOG="$(grep $LOOSER $LOGFILE | awk -F" " '{print $2}')"
  LOSLOGCRED="$(grep $LOOSER $LOGFILE | awk -F" " '{print $3}')"
  if [ "$LOSLOG" = "" ]; then
    echo "$LOOSER -1 -$FIGHTMB " >> $LOGFILE
    LOSLOGNEW="-1"
    LOSLOGCREDNEW="-$FIGHTMB"
  else
    LOSLOGNEW="$(expr $LOSLOG - 1)"
    LOSLOGCREDNEW="$(expr $LOSLOGCRED \- $FIGHTMB )"
    sed -e "s/^$LOOSER.*/$LOOSER $LOSLOGNEW $LOSLOGCREDNEW/" $LOGFILE > $LOGFILETMP
    cp -f $LOGFILETMP $LOGFILE
    rm -f $LOGFILETMP
  fi
 
  echo "$WINNER has a win ratio of $WINLOGNEW and $WINLOGCREDNEW Dollahs. $LOOSER's win ratio is $LOSLOGNEW with $LOSLOGCREDNEW Dollahs."
  proc_output "${BOLD}-(RR)- $WINNER${BOLD} has a win ratio of $WINLOGNEW and $WINLOGCREDNEW dollah's. ${BOLD}$LOOSER${BOLD}'s win ratio is $LOSLOGNEW with $LOSLOGCREDNEW dollah's."

rm -f $TEMPPATH/rr_$USER
rm -f $LOCKFILE
exit 0
fi

echo "That's not a valid command."
echo "Use 'site rr' for help."
exit 0