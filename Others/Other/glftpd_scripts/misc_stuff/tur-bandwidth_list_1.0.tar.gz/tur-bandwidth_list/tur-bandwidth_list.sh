#!/bin/bash
VER=1.0
#--[ Intro ]--------------------------------------------#
#                                                       #
# Tur-Bandwidth_List. A script that will display the    #
# traffic based on total, month, week, day or all of    #
# them.                                                 #
# It does this by logging on to the site and executing  #
# 'site traffic'. This is the fastest way to get the    #
# info rather then calculating this ourselfs from the   #
# userfiles.                                            #
# It also makes the output less configurable, but in    #
# return, this script does not have to be run from the  #
# same box as the ftp.                                  #
#                                                       #
#-[ Install ]-------------------------------------------#
#                                                       #
# Copy tur-bandwidth_list.sh to /glftpd/bin and make it #
# executable (chmod 755).                               #
#                                                       #
# Copy tur-bandwidth_list.tcl to your bots config dir   #
# and load it in the bots config file.                  #
#                                                       #
#--[ Settings ]-----------------------------------------#
#                                                       #
# ftp  =   Full path to the ftp binary.                 #
#                                                       #
# user   = The username that will log on to the site    #
#          and do the stuff. Make sure he has access to #
#          site traffic.                                #
#          This user SHOULD have flag 4 (excluded).     #
#          This user should NOT have flag 5 (color).    #
#                                                       #
# pass   = The above users password.                    #
#                                                       #
# host   = Hostname to log into. Just the hostname.     #
#          Always better to use 127.0.0.1 instead of    #
#          localhost.                                   #
#                                                       #
# port   = Port of above hostname.                      #
#                                                       #
# teston = If this is set to TRUE, you may run          #
# ./tur-bandwidth_list.sh test                          #
# from shell to see if ftp works. Once verified, set    #
# it to FALSE so users cant run this from irc.          #
#                                                       #
# grepfor = This is what it greps for in the output to  #
#           get the default traffic fields. Should not  #
#           need to be modified, but you never know.    #
#                                                       #
# dontgrepfor = If you get the info you want but also   #
#               some other crap, you can use this one   #
#               to exclude (egrep -v) a whole line.     #
#               If you get egrep errors on execution,   #
#               remember to escape ( \ ) any non alpha  #
#               chars (  for example: - becomes: \-   ) #
#                                                       #
#               Both this and "grepfor" are case        #
#               sensitive.                              #
#                                                       #
#--[ Info ]---------------------------------------------#
#                                                       #
# Run the .sh from shell first to make sure it works.   #
# No arguments will give you the help list.             #
#                                                       #
#--[ Changelog ]----------------------------------------#
#                                                       #
# 1.0   : Initial release.                              #
#                                                       #
#--[ Contact ]------------------------------------------#
#                                                       #
# http://www.grandis.nu/glftpd                          #
#                                                       #
#--[ Settings ]-----------------------------------------#

ftp=/usr/bin/ftp
user=glftpd
pass=ostnisse
host=127.0.0.1
port=21

teston=TRUE

grepfor="200- .-=----| Totals | Statistics |200- \`-=------ "
dontgrepfor=""

#--[ Script Start ]-------------------------------------#


if [ ! -x "$ftp" ]; then
  echo "Error. Can not execute $ftp. Make sure its there and executable by the user running this bot."
  exit 0
fi


proc_test() {
  echo "Testing that everything works as it should."
  echo "It should log in and show the total bw"
  echo "Running: echo -e \"user $user $pass\nsite traffic\" | $ftp -vn $host $port"

  until [ -n "$go" ]; do
    echo -n "Ready to go? [Y]es [N]o: "
    read go
    case $go in
      [Nn])
        exit 0
        continue
        ;;
      [Yy])
        echo " "
        go=n
        ;;
      *)
       unset go
       continue
       ;;
    esac
  done
  unset go

  echo ""
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port
  echo ""
  echo "If you see the traffic info the login is good. You must make sure he has"
  echo "permissions to view traffic stats (set with -traffic in glftpd.conf)."
}

if [ "$1" = "test" -a "$teston" = "TRUE" ]; then
  proc_test
  exit 0
fi

if [ -z "$dontgrepfor" ]; then
  dontgrepfor="ojr3jlfJji"
fi

## Show all traffic.
if [ "`echo "$1" | tr '[:lower:]' '[:upper:]'`" = "ALL" ]; then
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | egrep "$grepfor|200- \| " | egrep -v "$dontgrepfor" | cut -d ' ' -f2-

elif [ "`echo "$1" | tr '[:lower:]' '[:upper:]'`" = "TOTAL" ]; then
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | egrep "$grepfor| Total " | egrep -v "$dontgrepfor"| cut -d ' ' -f2-

elif [ "`echo "$1" | tr '[:lower:]' '[:upper:]'`" = "MONTH" ]; then
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | egrep "$grepfor| Month " | egrep -v "$dontgrepfor"| cut -d ' ' -f2-

elif [ "`echo "$1" | tr '[:lower:]' '[:upper:]'`" = "WEEK" ]; then
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | egrep "$grepfor| Week " | egrep -v "$dontgrepfor"| cut -d ' ' -f2-

elif [ "`echo "$1" | tr '[:lower:]' '[:upper:]'`" = "DAY" ]; then
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | egrep "$grepfor| Day " | egrep -v "$dontgrepfor"| cut -d ' ' -f2-

else
  unset $1
fi

if [ -z "$1" ]; then
  echo "Tur-Bandwidth_List $VER"
  echo "Specify one of the following modes:"
  echo "All   = Display all traffic modes."
  echo "Total = Display total traffic."
  echo "Month = Display traffic this month."
  echo "Week  = Display traffic this week."
  echo "Day   = Display traffic this day."
  exit 0
fi

exit 0
