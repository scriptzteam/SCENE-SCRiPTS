#!/bin/bash

#######################################################################
#   (clean_link.sh) KLink Cleaner v0.1 by kulgan                      #
#                                                                     #
#                                                                     #
#    Instructions:                                                    #
#                                                                     #
#  1. Put this file in your bin for glftpd (/glftpd/bin/ usually)     #
#  2. Set sections for your site (case sensitive)                     #
#  3. Make the file executable by doing chmod +x clean_link.sh        #
#  4. Add these in your glftpd.conf:				      #
#           - site_cmd CLEAN        EXEC    /bin/clean_link.sh        #
#           - custom-clean 1 2 7                                      #
#  5. Run by typing in root dir of your site (site clean)             #
#                                                                     #
#                                                                     #
#  CHANGELOG:                                                         #
#                                                                     #
#  2004-11-23: Initial release				              #
# 							              #
#######################################################################

VER=0.1

SECTIONS="
GAMES
XXX
REQUESTS
XBOXDVD
SERIES
DVD-R
"


for files in $SECTIONS ; do
   for file in $files/* ; do
      if [ ! -e "$file" ] ; then
         echo "Removing $file..."
            rm -rf "$file"
      fi
   done
done

