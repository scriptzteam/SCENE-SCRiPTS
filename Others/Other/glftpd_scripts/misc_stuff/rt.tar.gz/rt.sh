#!/bin/bash
#
# this was not coded by me i take no credit for it.
# edit this and chmod a+x rt.sh
ver=2.0
installdir=/glftpd/ftp-data/
supervisor=user
groupsdir=groups

#
# Dont touch anything below...! plz!
#
#########################################################
rm -f /tmp/tempprefile3
rm -f /tmp/groupsfile
rm -f /tmp/nongroupsfile
rm -f /tmp/tempprefile2
if [ "$2" = "root" ];then
xferlog=$installdir/logs/xferlog
msgdir=$installdir/msgs/
glftpdlog=$installdir/logs/glftpd.log
bleh="--------------------------------------------------------------------"
else
xferlog=/ftp-data/logs/xferlog
msgdir=/ftp-data/msgs/
glftpdlog=/ftp-data/logs/glftpd.log
fi
searchdata=$1
dat=1;data=1;data2=1;data3=1;i=0;j=0;k=0;l=0;m=0;n=0
out=""

################################################################################################
user=`basename $USER`
if [ "$1" = "" ];then
echo "You must enter a release dir or group"
else
search=`cat $xferlog | grep "$1" | awk '{print $8 ":" $9 ":" $12 ":" $14 ":" $15}'`
[ "$search" != "" ] || exit 0
for x in `echo $search`
do
        if [ "`echo $x | awk -F ':' '{print $3}'`" = "o" ];then
                echo "$x" >> /tmp/tempprefile2
        else
                echo "$x" >> /tmp/tempprefile3
        fi
done
[ -f "/tmp/tempprefile2" ] || touch /tmp/tempprefile2
[ -f "/tmp/tempprefile3" ] || touch /tmp/tempprefile3
cat /tmp/tempprefile2 | grep "$groupsdir" >> /tmp/groupsfile
cat /tmp/tempprefile2 | grep -v "$groupsdir" >> /tmp/nongroupsfile
#####################################################################################
x=0
# grab incoming traffic
for x in `cat /tmp/tempprefile3 | awk -F ':' '{print $1}'`
do
        x=$[x / 1024]
        dat=$[dat + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/tempprefile3 | awk -F ':' '{print $4}' | sort -n | uniq `
do
        i=$[i + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/tempprefile3 | awk -F ':' '{print $5}' | sort -n | uniq `
do
        l=$[l + 1]
done
#####################################################################################
# grab groups dir traffic
x=0
for x in `cat /tmp/groupsfile | awk -F ':' '{print $1}'`
do
        x=$[x / 1024]  
        data=$[data + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/groupsfile | awk -F ':' '{print $4}' | sort -n | uniq `
do
        j=$[j + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/groupsfile | awk -F ':' '{print $5}' | sort -n | uniq `
do
        m=$[m + 1]
done
#####################################################################################
# grab traffic without groups dir
x=0
for x in `cat /tmp/nongroupsfile | awk -F ':' '{print $1}'`
do
        x=$[x / 1024]
        data2=$[data2 + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/nongroupsfile | awk -F ':' '{print $4}' | sort -n | uniq`
do
        k=$[k + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/nongroupsfile | awk -F ':' '{print $5}' | sort -n | uniq`
do
        n=$[n + 1]
done
echo -e "======================================"
echo -e "Data traffic stats for \2$1\2"
echo -e "$bleh"
if [ "$dat" = "1" ];then
        dat="Pre Release"
else
        dat=$[dat / 1024]
        dat="$dat MB"
fi
if [ "$dat" = "0 MB" ];then
        dat="Pre Release"
fi
echo -e "Amount Uploaded:                     : $dat"
echo -e "Uploaded by:                            : $i Users from $l Groups"
echo -e "$bleh"
if [ "$data2" = "1" ];then
        data2="No Traffic"
else
        data2=$[data2 / 1024]
        data2="$data2 MB"
fi
if [ "$data2" = "0 MB" ];then
        dat="No Traffic"
fi  
echo -e "Amount Downloaded:                 : $data2"
echo -e "Downloaded by:                        : $k Users from $n Groups"
echo -e "$bleh"
fi
echo -e "======================================"
####################################################################
rm -f /tmp/tempprefile3  
rm -f /tmp/groupsfile
rm -f /tmp/nongroupsfile
rm -f /tmp/tempprefile2
