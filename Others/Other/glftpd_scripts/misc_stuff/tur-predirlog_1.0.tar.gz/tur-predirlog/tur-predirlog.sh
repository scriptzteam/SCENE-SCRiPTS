#!/bin/bash
VER=1.0
#--[ Intro ]--------------------------------------------#
#                                                       #
# Tur-PreDirLog. A service to your affiliated groups    #
# so they can see who was last in their predir(s).      #
#                                                       #
#--[ Install ]------------------------------------------#
#                                                       #
# Note that POST scripts can not show error messages,   #
# so its important that you follow these instructions   #
# to the letter. This is a "dont /msg turranius" script #
#                                                       #
# Copy tur-predirlog.sh to your glftpd's /bin dir.      #
# chmod it 755 (chmod 755 /glftpd/bin/tur-predirlog.sh) #
#                                                       #
# Make SURE you have the following binaries in glftpd's #
# /bin dir: dirname, date, grep, egrep, tail            #
#                                                       #
#--[ Settings ]-----------------------------------------#
#                                                       #
# PRECHECK  = A simple word or part of the path that    #
#             part of all the predirs. Like just _PRE   #
#             or /GROUPS. The / is there so it dosnt    #
#             execute on Cool.Dir.By.GROUPS.Ost, etc.   #
#             Dont specify a trailing / though.         #
#                                                       #
#             Why have this here when we have PREDIRS   #
#             below? Because its faster to check for a  #
#             single word in $PWD then to enter a       #
#             'for each' loop in PREDIRs everytime      #
#             someone enters a dir.                     #
#             I dont want to slow down races or so.     #
#                                                       #
# PREDIRS   = All your predirs, starting with /site     #
#             space seperated. Do not add the predirs   #
#             Just the parents of the predirs (ie, no   #
#             groupnames here).                         #
#             Do not enter a trailing /                 #
#                                                       #
# LOGFILE   = Since POST scripts cant echo, this is a   #
#             debug log it will write to instead. Leave #
#             it set and have a look at it while        #
#             changing dirs on the site. It should spam #
#             pretty good.                              #
#             Once the script works, set this to "" to  #
#             disable the debug logging.                #
#                                                       #
#             Hint: If you leave this set, this script  #
#             becomes an excellent tool for checking    #
#             which dirs the users entered.             #
#             But if the log grows too large, it might  #
#             slow things down.                         #
#                                                       #
# TESTUSER  = With this set, it will only work for that #
#             user. This is for testing so it dosnt     #
#             spam the log from other people or create  #
#             files while you are testing it. To make   #
#             it work for everyone, set this to "".     #
#             Until you are happy with this script, set #
#             this to your name ONLY.                   #
#                                                       #
# UEXCLUDE  = Users that will never be added to the     #
#             logfile.                                  #
#             Seperate users with a | and do NOT use    #
#             spaces or chars that breaks egrep.        #
#             Using this setting kinda breaks the       #
#             concept of this script, but I dont care   #
#             what you do =)                            #
#                                                       #
# GEXCLUDE  = Groups that should never be added to the  #
#             logfile. It only works on primary group.  #
#             Seperate groups with a | and no spaces or #
#             any chars that will break egrep.          #
#                                                       #
# TMP       = A temporary dir, seen chrooted. Make SURE #
#             it exists and has 777 permissions.        #
#             /glftpd/tmp is not there by default.      #
#                                                       #
# FILE      = Which filename should be used for the     #
#             list? This will be created in each groups #
#             predir.                                   #
#                                                       #
#             Add it to the show_diz setting in         #
#             glftpd.conf to automatically display it   #
#             whenever someone enters the dir.          #
#             ( show_diz .message .prelog )             #
#                                                       #
# NUMBER    = How many last users should we show in the #
#             log?                                      #
#                                                       #
# HEADER    = The header of the FILE created. Try it    #
#             with the default before changing it.      #
#                                                       #
#             Note, if you change the HEADER or FOOTER  #
#             then all existing FILEs will get real     #
#             ugly. Remove all old FILEs before         #
#             changing these two.                       #
#                                                       #
# FOOTER    = The footer of the file. Try it with the   #
#             default before changing it.               #
#                                                       #
# DATESET   = The format of the date to add to the log. #
#             date --help for ... help.                 #
#                                                       #
# TIMESET   = The format of the time to add to the log. #
#                                                       #
# Change these settings below and AFTER that, add this  #
# to your glftpd.conf file:                             #
#                                                       #
#  cscript CWD POST /bin/tur-predirlog.sh               #
#                                                       #
# Now, verify that its working by following "Testing"   #
# below and then, edit your glftpd.conf and search for  #
# show_diz. To that, add .prelog                        #
# Also search for hidden_files and add .prelog there    #
# too. Now, the list will be shown when you enter the   #
# predir but it will not be deletable since its hidden. #
#                                                       #
# Should you not have show_diz or hidden_files already  #
# in your glftpd.conf, simply add it as:                #
# show_diz .prelog                                      #
# and/or                                                #
# hidden_files .prelog                                  #
#                                                       #
#--[ Testing ]------------------------------------------#
#                                                       #
# Try running it from shell without arguments. It will  #
# not say anything and just quit. Thats just to check   #
# the you didnt mess up the config.                     #
#                                                       #
# After that, log on to the site and enter a few dirs.  #
# It should make the LOGFILE and write stuff in it.     #
# If it dosnt, set 777 on your logs dir or something.   #
# You'll see what happens when you enter a defined      #
# predir by viewing the log.                            #
#                                                       #
# Once you DO enter a predir, the FILE will be created  #
# with your name, date and time in it.                  #
#                                                       #
# If it does, you ALL SET. Woo                          #
#                                                       #
#--[ Info ]---------------------------------------------#
#                                                       #
# Because of the nature of this script, no support will #
# be given for it. You're on your own. If you edit how  #
# the FILE will look, expect problems.                  #
# Do not make HEADER or FOOTER empty. They must contain #
# something.                                            #
#                                                       #
# If you run into problems, load it as a PRE script     #
# instead. It will hang as soon as you enter a dir but  #
# not before spitting out an error, if there were any.  #
#                                                       #
# This was a quick hack, so dont expect miracles or     #
# proper formatting of the FILE                         #
#                                                       #
# If you change HEADER or FOOTER, all existing FILEs    #
# will be destroyed.                                    #
#                                                       #
#--[ Configuration ]------------------------------------#

PRECHECK="/GROUPS"
PREDIRS="/site/svcd/GROUPS /site/divx/GROUPS /site/vcd/GROUPS"
LOGFILE=/ftp-data/logs/test.log
TESTUSER="YourFtpNameHere"

UEXCLUDE="User1|User2"
GEXCLUDE="Group1|Group2"

TMP=/tmp
FILE=".prelog"
NUMBER=10

HEADER="#.-----[ Last 10 people in predir ]------.#"
FOOTER="#.---------------------------------------.#"

DATESET=`date +%D`
TIMESET=`date +%R`

#--[ Script Start ]-------------------------------------#

if [ "$TESTUSER" ]; then
  if [ "$USER" != "$TESTUSER" ]; then
    exit 0
  fi
fi

if [ -z "$( echo "$PWD" | grep "$PRECHECK" )" ]; then
  if [ "$LOGFILE" ]; then
    echo "$USER/$GROUP is in $PWD. Not a defined predir. quitting." >> $LOGFILE
  fi
  exit 0
fi

for PREDIR in $PREDIRS; do
  if [ "$( dirname $PWD )" = "$PREDIR" ]; then
    if [ "$LOGFILE" ]; then
      echo "$USER/$GROUP is in $PWD defined as $PREDIR" >> $LOGFILE
    fi
    GOTDIR="TRUE"
    break
  fi
done
if [ -z "$GOTDIR" ]; then
  if [ "$LOGFILE" ]; then
    echo "$USER/$GROUP is in a $PRECHECK dir, but not a group dir. Quitting" >> $LOGFILE
  fi
  exit 0
fi

if [ "$UEXCLUDE" ]; then
  if [ "$( echo "$USER" | egrep "$UEXCLUDE" )" ]; then
    if [ "$LOGFILE" ]; then
      echo "$USER/$GROUP is an excluded user. Quitting" >> $LOGFILE
    fi
    exit 0
  fi
fi

if [ "$GEXCLUDE" ]; then
  if [ "$( echo "$GROUP" | egrep "$GEXCLUDE" )" ]; then
    if [ "$LOGFILE" ]; then
      echo "$USER/$GROUP is an excluded group. Quitting" >> $LOGFILE
    fi
    exit 0
  fi
fi

## If no log exists in this dir:
if [ ! -e "$PWD/$FILE" ]; then
  if [ "$LOGFILE" ]; then
    echo "-> $USER/$GROUP is in $PREDIR dir for the first time. Creating $PWD/$FILE" >> $LOGFILE
  fi
  echo "$HEADER" > "$PWD/$FILE"
  echo "$USER/$GROUP -> $DATESET -> $TIMESET" >> "$PWD/$FILE"
  echo "$FOOTER" >> "$PWD/$FILE"
else
  if [ "$LOGFILE" ]; then
    echo "-> $USER/$GROUP is in $PREDIR dir. Adding his name to list" >> $LOGFILE
  fi
  NUMBER=$[$NUMBER-1]
  for rawdata in `cat $PWD/$FILE | grep -vF -- "$HEADER" | grep -vF -- "$FOOTER" | tr ' ' '^' | tail -n $NUMBER`; do
    loguser=`echo "$rawdata" | cut -d '^' -f1`
    logdate=`echo "$rawdata" | cut -d '^' -f3`
    logtime=`echo "$rawdata" | cut -d '^' -f5`

    if [ "$LOGFILE" ]; then
      echo "Got old info: $loguser - $logdate - $logtime" >> $LOGFILE
    fi

    if [ -z "$FIRST" ]; then
      echo "$HEADER" >> $TMP/prelog.tmp
      FIRST=SET
    fi 
    echo "$loguser -> $logdate -> $logtime" >> $TMP/prelog.tmp
  done
  echo "$USER/$GROUP -> $DATESET -> $TIMESET" >> $TMP/prelog.tmp
  echo "$FOOTER" >> $TMP/prelog.tmp
  cp -f $TMP/prelog.tmp $PWD/$FILE
  rm -f $TMP/prelog.tmp
fi

exit 0