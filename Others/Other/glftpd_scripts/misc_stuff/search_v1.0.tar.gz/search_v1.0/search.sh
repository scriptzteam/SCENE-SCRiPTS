# Dirs to ignore on search!
IGNORE="/pre|CD1|CD2|CD3|CD4|CD5|CD6|Test|Sample|\[incomplete\]"

# MSG MAX! REST WILL BE IGNORED OR DCC SEND!
MAX=10

# DCC SEND HITS IF MORE THAN 10 (TRUE/FALSE)
DCC="TRUE"

# RESULT FROM SEARCH FILE.
DCCFILE="/glftpd/ftp-data/logs/searchlog"

# WHERE IS STRINGS LOCATED
STRINGS="/glftpd/bin/strings"

# WHERE IS YOUR DIR LOG LOCATED
DIRLOG="/glftpd/ftp-data/logs/dirlog"

##########################
#### NO NEED TO EDIT BELOW
##########################

if [ "$1" != "" ] ;then
	SEARCH=`$STRINGS $DIRLOG |grep -F -i $1|egrep -vi $IGNORE|tr -d ' '`
fi

if [ "$2" != "" ]; then
	SEARCH=`$STRINGS $DIRLOG |grep -F -i $1|grep -F -i $2|egrep -vi $IGNORE`
fi

if [ "$3" != "" ]; then
	SEARCH=`$STRINGS $DIRLOG |grep -F -i $1|grep -F -i $2|grep -F -i $3|egrep -vi $IGNORE`
fi

if [ "$4" != "" ]; then
	SEARCH=`$STRINGS $DIRLOG |grep -F -i $1||grep -F -i $2|grep -F -i $3|grep -F -i $4|egrep -vi $IGNORE`
fi

if [ "$SEARCH" != "" ]; then
	for COUNT in $SEARCH; do
		let NUM=$NUM+1
	done
fi

if [ "$SEARCH" != "" ]; then
	if [ "$NUM" -ge "$MAX" ]; then
		if [ "$DCC" == "TRUE" ]; then
			SENDTYPE="DCC"
		else
			SENDTYPE="MSG"
		fi
	else
			SENDTYPE="MSG"
	fi
fi

if [ "$SEARCH" == "" ]; then
        MESSAGE="NONE NONE NONE"
fi

if [ "$SEARCH" != "" ]; then
	MESSAGE="$SENDTYPE $NUM $DCCFILE"
fi

echo $MESSAGE

if [ "$MESSAGE" != "NONE" ]; then
	rm $DCCFILE
	for HIT in $SEARCH; do
        	let NUMBER=$NUMBER+1
		        LAST="$( basename $HIT )"
        	        for DIR in `echo $HIT | tr -s '/' ' '`; do
        	        	if [ $DIR != "site" ]; then
	        	        	RELEASE=$RELEASE/$DIR
	        	        fi
	                done
			if [ $SENDTYPE == "MSG" ]; then
				if [ $MAX -ge $NUMBER ]; then
					echo $RELEASE >> $DCCFILE 
					RELEASE=""
				fi
			else
				echo $RELEASE >> $DCCFILE
				RELEASE=""
			fi
	done
fi
