#!/bin/bash
VER=1.0

#-----------------------------------------------------------#
#                                                           #
# Tur-Version_Check. A script that checks if your tur-      #
# scripts are using the latest versions.                    #
#                                                           #
# It dosnt update the scripts or anything, just checks a    #
# list of scripts and their versions from my place and      #
# compares it to what you have installed. If the version    #
# differs, it will let you know.                            #
#                                                           #
#--[ Install ]----------------------------------------------#
#                                                           #
# Copy it to /glftpd/bin and chmod it to 700 (root exec).   #
#                                                           #
# Change the settings in it.                                #
#                                                           #
# BIN_DIR      = Path to your /glftpd/bin dir, where you    #
#                keep all your fine tur- scripts.           #
#                                                           #
# LINK         = Link to the file with latest versions.     #
#                Should not need to change this.            #
#                                                           #
# IGNORE_SCRIPTS = If you do not want notification of a     #
#                  script, add its name here. Add several   #
#                  seperated by |                           #
#                                                           #
#--[ Running ]----------------------------------------------#
#                                                           #
# Run it with 'debug' to see what it does. Run it without   #
# debug to only say something if it finds a version         #
# mismatch in your scripts.                                 #
#                                                           #
# While you can crontab this as often as you like, it will  #
# keep saying "version mismatch" each time it runs, even if #
# it already told you that, so if you crontab it too often  #
# you might get mailed bombed by crontab =)                 #
#                                                           #
# Also, you'll get banned by me for grabbing the file too   #
# often. Try once per day or similar if you want to crontab #
# it.                                                       #
#                                                           #
# It requires wget to be installed.                         #
#                                                           #
#--[ Contact ]----------------------------------------------#
#                                                           #
# http://www.grandis.nu/glftpd or http://grandis.mine.nu    #
#                                                           #
#--[ Settings ]---------------------------------------------#

BIN_DIR=/glftpd/bin

LINK="http://www.grandis.nu/glftpd/scripts/turranius/script_versions.txt"

IGNORE_SCRIPTS="tur-space.sh"


#--[ Script Start ]-----------------------------------------#

if [ "$1" = "debug" ]; then
  DEBUG="TRUE"
fi

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$*"
  fi
}

cd /tmp

if [ -e "script_versions.txt" ]; then
  rm -f "script_versions.txt"
fi

proc_debug "Getting latest versions..."

if [ "$DEBUG" = "TRUE" ]; then
  wget -T 5 --cookies=off $LINK
  echo ""
else
  wget -q -T 5 --cookies=off $LINK
fi

if [ ! -e "script_versions.txt" ]; then
  proc_debug "Error. Could not get list of current versions. Try again later."
  exit 0
fi

if [ -z "$IGNORE_SCRIPTS" ]; then
  IGNORE_SCRIPTS="Rj3jr3uI_Eat_Cheese3hj3"
fi

for rawdata in `cat script_versions.txt`; do
  script="`echo "$rawdata" | cut -d '^' -f1 | tr -d [:cntrl:]`"
  latest_version="`echo "$rawdata" | cut -d '^' -f2 | tr -d [:cntrl:]`"

  if [ -e "$BIN_DIR/$script" ] && [ -z "`echo "$script" | egrep "$IGNORE_SCRIPTS"`" ]; then
    proc_debug ""
    proc_debug "Checking $BIN_DIR/$script"

    current_version="`head -n4 "$BIN_DIR/$script" | egrep -i "^VER\=|^VERSION\=" | cut -d '=' -f2 | tr -d '"'`"
    if [ -z "$current_version" ]; then
      current_version="Unknown. Probably oooold."
    fi
    proc_debug "Latest version of $script is $latest_version. Installed version is $current_version"

    if [ "$latest_version" != "$current_version" ]; then
      while [ -z "`echo "$script" | grep "..................."`" ] ; do
        script="$script "
      done
      while [ -z "`echo "$latest_version" | grep "......"`" ]; do
        latest_version="$latest_version "
      done
      echo "Official version of $script : $latest_version - Your version: $current_version"
      UPDATE_FOUND="TRUE"
    elif [ "$latest_version" = "$current_version" ]; then
      proc_debug "$script is up to date."
    fi
  fi
     
done

if [ -z "$rawdata" ]; then
  echo "Hm, cant read script_versions.txt for some reason.."
  exit 0
fi

if [ "$UPDATE_FOUND" = "TRUE" ]; then
  echo "Please visit http://www.grandis.nu/glftpd or http://grandis.mine.nu/glftpd"
fi

rm -f "script_versions.txt"

exit 0
