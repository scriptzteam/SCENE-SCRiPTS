#!/bin/bash
VER=1.1

#-[ Script Start (Dont edit below here) ]---------------------#

## Load config file
config="$( dirname $0 )/tur-recommend.conf"
if [ ! -e "$config" ]; then
  echo "Error. Cant read config file. It needs to be in the same dir as tur-recommend.sh"
  echo "Make sure 'dirname' exists in /glftpd/bin too."
  exit 1
fi

. $config

## Are we in glftpd or shell ?
if [ -z "$FLAGS" ]; then
  DESTDIR=$GLROOT$DESTDIR
  if [ "$GLLOG" ]; then
    GLLOG=$GLROOT$GLLOG
  fi
  TMP=$GLROOT$TMP
  mode="shell"
else
  mode="gl"
fi

## Convert cookies to text.
proc_cookies() {
  if [ "$RECNAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%RECNAME%/$RECNAME/g" )"
  fi
  if [ "$USER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%USER%/$USER/g" )"
  fi
  if [ "$RANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%RANK%/$RANK/g" )"
  fi
  if [ "$RANKTOP" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%RANKTOP%/$RANKTOP/g" )"
  fi
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

## Procedure for showing help (duh).
proc_help() {

  if [ "$mode" = "shell" ]; then
    usercmd=`basename $0`
  else
    usercmd="site recommend"
  fi

  echo "#-----------------------------------------------"
  echo "# Tur-Recommend $VER by Turranius - 2003 "
  echo "#-----------------------------------------------"
  echo "#"
  echo "# Usage: ENTER THE DIR you wish to recommend and issue:"
  echo "# $usercmd add"
  echo "#   It will guide you further from there."

  if [ "$USERSPECIFIC" != "TRUE" -a "$mode" = "shell" ]; then
    proc_showdelhelp
  fi
  if [ "$USERSPECIFIC" = "TRUE" -a "$mode" = "gl" ]; then
    proc_showdelhelp
    echo "#   No <releasename> = List your own recommendations only."
  elif [ "$USERSPECIFIC" != "TRUE" -a "$mode" = "gl" ]; then
    proc_showdelhelp
  fi

  if [ "$mode" = "shell" ]; then
    echo "#"
    echo "# $usercmd update"
    echo "#    Go through all created symlinks and update what"
    echo "#    they point to, if the release has moved."

    echo "#"
    echo "# $usercmd rank/rankr/rankb <maxhits>"
    echo "#   List ranking iMDB style."
    echo "#   rank = Top / rankr = Low / rankb = Both"
    echo "#   Note, from shell, this will create the OUTPUT files:"
    echo "#   Top: $OUTFILETOP"
    echo "#   Low: $OUTFILELOW"
    echo "#   IE: It wont display anything on screen."
    echo "#"
    echo "# $usercmd updateall"
    echo "#   Run 'update' then 'rankb'"
    echo "#   One crontab does it all =)"
  else
    if [ "$SHELLONLY" != "TRUE" ]; then
      echo "#"
      echo "# $usercmd rank / rankr"
      echo "#   List ranking iMDB style ($MAXLIMIT max)."
      echo "#   rank = Top / rankr = Low."
    fi
  fi

  if [ "$mode" = "shell" ]; then
    proc_showlisthelp
  elif [ "$LIST" ]; then
    if [ `echo "$FLAGS" | egrep "$LIST"` ]; then
      echo "#"
      FLAGSHOW=`echo "$LIST" | tr -s '|' ' '`
      echo "# Other commands given to users with flag(s): $FLAGSHOW"
      proc_showlisthelp
    fi
  else
    proc_showlisthelp
  fi

  unset usercmd
}

## Part of help
proc_showdelhelp() {
  echo "#"
  echo "# $usercmd del <releasename>"
  echo "#   Removes an already recommended release."
}

## Part of help
proc_showlisthelp() {
  echo "#"
  echo "# $usercmd list/listn <search1|search2>"
  echo "#   Lists all recommended releases."
  echo "#   list = Sort by name. listn = Sort by rank."
  echo "#   Seperate searchwords with a '|'"
  echo '#   To search on rank, use "\[05\]"'
  echo "#"
}


## Procedure for adding a new recommendation.
proc_add() {
  if [ ! -d "$DESTDIR" ]; then
    echo "Error. DESTDIR $DESTDIR does not exist. Create and set chmod 777."
    exit 1
  fi

  RECOMMENDATION=$PWD
  RECNAME=`basename $RECOMMENDATION`

  ## If FORCESECTIONS are set, make sure the user is in one of them.
  if [ "$FORCESECTIONS" ]; then
    for forcesection in $FORCESECTIONS; do
      if [ `echo "$PWD" | grep "$forcesection"` ]; then
        ALLOWED="TRUE"
        break
      fi
    done
    if [ "$ALLOWED" != "TRUE" ]; then
      echo "You are not in a location where you are allowed to add recommendations."
      exit 1
    fi
  fi

  if [ "$MUSTINCLUDE" ]; then
    if [ -z `echo "$RECNAME" | egrep "$MUSTINCLUDE"` ]; then
      echo "Error. Cant add $RECNAME. Dosnt look like a valid release."
      echo "Enter the dir you wish to recommend before adding."
      exit 1
    fi
  fi
 
  if [ -z "$A2" ]; then
    echo "You are about to recommend $RECNAME"
    echo "Please also enter a ranking, at the end, between 1-$RANKTOP where 1 being lousy and $RANKTOP orgasmic"
    exit 1
  fi
  if [ `echo "$A2" | tr -d '[:digit:]'` ]; then
    echo "Please only use digits in ranking."
    exit 1
  fi
  if [ "$A2" -lt "1" -o "$A2" -gt "$RANKTOP" ]; then
    echo "Error. Ranking is between 1 and $RANKTOP only."
    exit 1
  fi

  RANK="$A2"
  if [ -z `echo "$A2" | grep ".."` ]; then
    A2="0$A2"
  fi
 
  if [ -z "$A3" ]; then
    echo "You are about to rank $RECNAME as a $A2/$RANKTOP. Are you sure?"
    echo "If you are, issue the same command again and add 'yes' at the end."
    exit 0
  fi

  if [ "$A3" != "yes" ]; then
    echo "Error. Second arg should be 'yes' if you are sure that you"
    echo "want to add rating $A2 to $RECNAME."
  else
    echo "Recommending $RECNAME as a $A2 out of $RANKTOP possible."
    if [ "$USERSPECIFIC" != "TRUE" ]; then
      if [ "$( ls $DESTDIR | grep "\[$A2\] $RECNAME by $USER" )" ]; then
        echo "Error. That release has already been recommended by you with the same ranking."
        exit 1
      else
        if [ "$( ls $DESTDIR | grep " $RECNAME by $USER$" )" ]; then
          delrel=`ls $DESTDIR | grep " $RECNAME by $USER$" | head -n1`
          echo "Thats already been recommended before by you."
          echo "Replacing old recommendation: $delrel"
          rm -f "$DESTDIR/$delrel"
        fi
        ln -f -s "$RECOMMENDATION" "$DESTDIR/[$A2] $RECNAME by $USER"
      fi
    else
      if [ ! -d "$DESTDIR/$USER" ]; then
        echo "First time recommendation? Creating specific dir for $USER."
        mkdir -m755 "$DESTDIR/$USER"
      fi
      if [ "$( ls $DESTDIR/$USER | grep "\[$A2\] $RECNAME by $USER" )" ]; then
        echo "Error. That release has already been recommended by you with the same ranking."
        exit 1
      else
        if [ "$( ls $DESTDIR/$USER | grep " $RECNAME by $USER$" )" ]; then
          delrel=`ls $DESTDIR/$USER | grep " $RECNAME by $USER$" | head -n1`
          echo "Thats already been recommended before by you."
          echo "Replacing old recommendation: $delrel"
          rm -f "$DESTDIR/$USER/$delrel"
        fi
        ln -f -s "$RECOMMENDATION" "$DESTDIR/$USER/[$A2] $RECNAME by $USER"
      fi
    fi

    ## Announce when someone makes a new recommendation. Not from shell.
    if [ "$GLLOG" -a "$mode" = "gl" -a "$ADDREC" != "" ]; then
      OUTPUT="$ADDREC"
      proc_cookies
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
      unset OUTPUT
    fi
  fi
}


## Procedure for deleting a recommendation.
proc_del() {
  RECDEL="$A2"

  if [ -z "$RECDEL" -a -e "$DESTDIR/$USER" ]; then
    if [ "$USERSPECIFIC" = "TRUE" ]; then
      echo ""
      echo "Recommendations by you:"
      ls -R $DESTDIR/$USER | grep "^\[.*\] " | sort -k1,1 -n -r
    else
      proc_help
      echo " "
    fi
    echo "Error. No release specified."
    exit 1
  fi

  if [ `echo "$RECDEL" | grep "^\["` ]; then
    echo "Error. Only specify release name, not ranking."
    exit 1
  fi

  if [ "$USERSPECIFIC" != "TRUE" ]; then
    if [ "$( ls $DESTDIR | grep " $RECDEL by $USER$" )" ]; then
      delrel=`ls $DESTDIR | grep " $RECDEL by $USER$" | head -n1`
      echo "Ok, removing $delrel from recommended releases."
      rm -f "$DESTDIR/$delrel"

      proc_delreqannounce

      exit 0
    elif [ "$( ls $DESTDIR | grep " $RECDEL " )" ]; then
      delrel=`ls $DESTDIR | grep " $RECDEL " | head -n1`
      echo "Found the recommended release, but it wasnt made by you."
      if [ "$mode" = "shell" ]; then
        echo "Override enabled by shell."
        echo "Ok, removing $delrel from recommended releases."
        rm -f "$DESTDIR/$delrel"
        exit 0
      else
        if [ `echo "$FLAGS" | egrep "$DELETE"` ]; then
          echo "Override enabled by flag."
          echo "Ok, removing $delrel from recommended releases."
          rm -f "$DESTDIR/$delrel"
          exit 0
        else
          exit 1
        fi
      fi
    else
      echo "Could not find a recommendation named $RECDEL."
      exit 1
    fi
  else
    if [ "$mode" = "shell" ]; then
      USER=`proc_list | grep " $RECDEL " | tr -s ' ' '^' | cut -d '^' -f4`
    fi
    if [ ! -d "$DESTDIR/$USER" ]; then
      echo "Hm, cant even see that you made any recommendations yet (no $USER dir)."
      exit 1
    fi
    if [ "$( ls "$DESTDIR/$USER" | grep " $RECDEL " )" ]; then
      delrel=`ls "$DESTDIR/$USER" | grep " $RECDEL " | head -n1`
      echo "Removing $delrel from recommended releases."
      rm -f "$DESTDIR/$USER/$delrel"

      proc_delreqannounce

    else
      echo "Cant find any recommendations by you with that name."
      exit 1
    fi
  fi
}

## Used when removing recommendations.
proc_delreqannounce() {
  if [ "$GLLOG" -a "$mode" = "gl" -a "$DELREC" != "" ]; then
    RECNAME=`echo "$delrel" | cut -d ' ' -f2`
    RANK=`echo "$delrel" | cut -d ' ' -f1 | tr -d '[' | tr -d ']'`
    OUTPUT="$DELREC"
    proc_cookies
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
    unset OUTPUT
  fi
}


## Procedure for listing all recommendations ( this one was easy =] )
proc_list() {
  if [ "$mode" = "gl" -a "$LIST" ]; then
    if [ `echo "$FLAGS" | egrep "$LIST"` ]; then
      echo "----------------------------------"
      if [ "$A2" ]; then
        GREPPER="$A2"
        echo "Displaying all recommended releases, containing $GREPPER"
      else
        GREPPER="."
        echo "Displaying all recommended releases"
      fi
      if [ "$SORTBYRANK" = "TRUE" ]; then
        ls -R $DESTDIR | grep "^\[.*\] " | sort -k1,1 -n -r | egrep -i "$GREPPER"
      else
        ls -R $DESTDIR | grep "^\[.*\] " | sort -k2,2 | egrep -i "$GREPPER"
      fi
    else
      echo "You do not have access to this command."
      exit 1
    fi
  fi
}  


## Procedure for keeping symlinks updated
## This one was a bitch.
proc_update() {
  if [ "$mode" = "gl" ]; then
    echo "Error. update is only used from shell."
    exit 1
  fi

  ## Pain in the ass check coming up ! Check each symlink, path to it, etc etc.
  for rawdata in `ls -al -R $DESTDIR | tr -s ' ' '^'`; do
    unset symlink; unset rel; unset realloc; unset go; unset string

    if [ `echo "$rawdata" | grep "^$GLROOT/site/...."` ]; then
      symloc=`echo "$rawdata" | cut -d ':' -f1`
    fi
    if [ `echo "$rawdata" | grep "^l..."` ]; then
      symlinkdata="["`echo "$rawdata" | cut -d '[' -f2- | cut -d '>' -f1`

      relname=`echo "$rawdata" | cut -d ']' -f2 | cut -d '^' -f2`
      location=$GLROOT`echo "$rawdata" | cut -d '>' -f2 | cut -d '^' -f2`

      echo "Checking $location"
      ## Does it still exist where the symlink points to?
      if [ ! -e "$location" ]; then

        ## Get symlink name
        for each in `echo "$symlinkdata" | tr -s '^' ' '`; do
          if [ "$each" = "-" ]; then
            break
          fi
          if [ -z "$symlink" ]; then
            symlink="$each"
          else
            symlink="$symlink $each"
          fi
        done

        echo ""
        echo "$relname has moved from $location. Checking."

        ## Check if its in dirlog.
        string=`strings $DIRLOG | grep "$relname" | tr -d '[:cntrl:]'`

        ## Seems it was. Clear up result (crap in dirlog).
        if [ "$string" ]; then
          for part in `echo $string | tr -s '/' ' '`; do
            if [ "$go" = "yepp" ]; then
              if [ -z "$rel" ]; then
                rel="/$part"
              else
                rel="$rel/$part"
              fi
            fi
            if [ "$part" = "site" ]; then
              go="yepp"
              unset rel
            fi
            if [ "$relname" = "$part" ]; then
              unset go
            fi
          done
          realloc="/site$rel"

          if [ -e "$GLROOT$realloc" ]; then
            echo "Found it in $realloc - Updating Symlink in $symloc"
            rm -f "$symloc/$symlink"
            ln -f -s "$realloc" "$symloc/$symlink"
          else
            tempvar=`dirname $realloc`
            echo "dirlog said its in $tempvar, but I dont see it there. Skipping it."
            echo "Its very important that you keep dirlog updated (site search) if you want"
            echo "this script to work. Use Tur-DirLogClean (hint hint)."
            echo ""
            unset tempvar
          fi

        ## It wasnt in dirlog either..
        else
          echo "Seems its removed. Cant find it in dirlog anyway. Removing symlink. =("
          rm -f "$symloc/$symlink"
        fi

      fi
    fi

  done
}

proc_rank() {
  if [ "$SHELLONLY" = "TRUE" -a "$mode" = "gl" ]; then
    echo "You do not have access to this command"
    exit 1
  fi

  if [ "$mode" = "gl" ]; then
    if [ "$A1" = "rankb" ]; then
      echo "You do not have access to this command."
      exit 1
    fi
    echo "Please wait. This could take a while."
  else
    if [ "$A2" ]; then
      if [ `echo "$A2" | tr -d '[:digit:]'` ]; then
        echo "When specifying number of max hits, only use numbers."
        exit 1
      else
        MAXLIMIT="$A2"
      fi
    fi
  fi


  if [ -e "$TMP/tur-recommend.rank.tmp" ]; then
    rm -f "$TMP/tur-recommend.rank.tmp"
  fi

  if [ "$RANKREVERSE" = "TRUE" ]; then
    OUTPUT="$OUTPUTLOW"
    HEADER="$HEADERLOW"
    FOOTER="$FOOTERLOW"
    OUTFILE="$OUTFILELOW"
    unset SORTCMD
  else
    OUTPUT="$OUTPUTTOP"
    HEADER="$HEADERTOP"
    FOOTER="$FOOTERTOP"
    OUTFILE="$OUTFILETOP"
    SORTCMD="-r"
  fi

  votes=1
  rank=0
  totalvotes=0

  for rawdata in `ls -R $DESTDIR | grep "^\[.*\] " | sort -k2,2 | tr -s ' ' '^'`; do
    totalvotes=$[$totalvotes+1]
    relname=`echo "$rawdata" | cut -d '^' -f2`
    relrank=`echo "$rawdata" | cut -d '[' -f2 | cut -d ']' -f1`
    if [ "$relname" = "$lastrelname" ]; then
      votes=$[$votes+1]
      if [ -z "$totalrank" ]; then
        totalrank=`expr "$lastrelrank" \+ "$relrank"`
      else
        totalrank=`expr "$totalrank" \+ "$relrank"`
      fi
    else
      if [ "$totalrank" ]; then
        if [ "$votes" -gt "$NOTCOUNT" ]; then 
          ranking=`echo "$totalrank / $votes" | bc -l | tr -d ' '`
          rank1=`echo "$ranking" | cut -d '.' -f1`
          rank2=`echo "$ranking" | cut -d '.' -f2 | cut -c1`
          ranking="$rank1.$rank2"
          if [ -z `echo "$ranking" | grep "...."` ]; then
            ranking=" $ranking"
          fi

          if [ `echo "$votes" | grep "...."` ]; then
            votes=" $votes"
          elif [ `echo "$votes" | grep "..."` ]; then
            votes="  $votes"
          elif [ `echo "$votes" | grep ".."` ]; then
            votes="   $votes"
          elif [ `echo "$votes" | grep "."` ]; then
            votes="    $votes"
          fi
          echo "$ranking $votes  $lastrelname" >> $TMP/tur-recommend.rank.tmp
        fi
        unset totalrank
      fi
      votes=1
    fi

    lastrelrank="$relrank"
    lastrelname="$relname"
  done

  if [ -e "$TMP/tur-recommend.rank.tmp" ]; then
    if [ "$mode" = "shell" ]; then

      ## We are in shell. Write output to OUTPUT file.

      if [ -e "$OUTFILE" ]; then
        rm -f "$OUTFILE"
      fi
      if [ "$HEADER" ]; then
        echo "$HEADER" >> $OUTFILE
      fi
      echo "Rank   Vts  Release" >> $OUTFILE
      cat "$TMP/tur-recommend.rank.tmp" | sort -k 1,1 -n $SORTCMD | head -n$MAXLIMIT >> $OUTFILE
      echo "            Total recommendations ever made: $totalvotes" >> $OUTFILE
      if [ "$FOOTER" ]; then
        echo "$FOOTER" >> $OUTFILE
      fi
      if [ "$ADDDATE" = "TRUE" ]; then
        DATENOW=`date`
        echo "Last Updated: $DATENOW" >> $OUTFILE
      fi
    else

      ## We are in glftpd. Just echo the output.

      if [ -e "$OUTFILE" ]; then
        rm -f "$OUTFILE"
      fi
      if [ "$HEADER" ]; then
       echo "$HEADER"
      fi
      echo "Rank   Vts  Release"
      cat "$TMP/tur-recommend.rank.tmp" | sort -k 1,1 -n $SORTCMD | head -n$MAXLIMIT
      echo "            Total recommendations ever made: $totalvotes"
      if [ "$FOOTER" ]; then
        echo "$FOOTER"
      fi
    fi
  else
    echo "No recommendations with more then $NOTCOUNT votes found."
    exit 0
    
  fi
}

## Set arguments to .. other arguments ?
A1="$1"
A2="$2"
A3="$3"

## Main menu.
case $A1 in
  add) proc_add; exit 0;; 
  del) proc_del; exit 0;;
  list) SORTBYRANK="FALSE"; proc_list; exit 0;;
  listn) SORTBYRANK="TRUE"; proc_list; exit 0;;
  rank) proc_rank; exit 0;;
  rankr) RANKREVERSE="TRUE"; proc_rank; exit 0;;
  rankb) proc_rank; RANKREVERSE="TRUE"; proc_rank; exit 0;;
  update) proc_update; exit 0;;
  updateall) proc_update; proc_rank; RANKREVERSE="TRUE"; proc_rank; exit 0;;
  help) proc_help; exit 0;; 
  *) proc_help; exit 0;; 
esac
