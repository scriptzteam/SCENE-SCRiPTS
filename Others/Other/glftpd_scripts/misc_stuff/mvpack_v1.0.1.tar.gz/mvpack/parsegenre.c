#include <stdio.h>
#include <string.h>

#define MAX_LINE_SIZE 255
#define LEFT_PART "- ( "
#define RIGHT_PART " ) -"

/* Arguments: <string> */
int main(int argc, char ** argv) {

 char str[MAX_LINE_SIZE];
 char newstr[MAX_LINE_SIZE];
 char * tempstr;
 char * lpos;
 char * rpos;
 int n, k;

 /* Checking the external arguments */
 if (argc < 2 ) {
   	printf("Error! Not enough parameters ...\n");
   	printf("Syntax: %s <genre_tag_string>\n", argv[0]);
   	return(1);
 }
 else {
 	strcpy(str, argv[1]);
	strcpy(newstr, "");
	lpos = strstr(str, LEFT_PART);
	if (lpos != NULL) {
		rpos = strstr(lpos, RIGHT_PART);
		if (rpos != NULL) {
			tempstr = lpos + strlen(LEFT_PART);
			n = strlen(tempstr);
			k = strlen(rpos);
			strncpy(newstr, tempstr, n-k);
			newstr[n-k] = '\0';
			printf("%s", newstr);
		}
	}
	return(0);
 }
}
