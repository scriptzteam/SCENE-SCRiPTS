#!/bin/sh
# Version 1.0.1 by eur0dance
# This is a post_check script in order to retrieve the genre from mvid releases, from the .nfo
#
# If your mvids dir located here: /site/MUSICVIDEOS then this script should be
# placed in glftpd's bin dir and added to glftpd.conf as: post_check /bin/mvscript.sh /site/MUSICVIDEOS/*.nfo
# right BEFORE your regular (general purpose) zipscript, for example zipscript-c or jzipscript. It's important you
# put it before it and not after!
#
# If you use Dark0n3 zipscript-c or project-zs zipscript you should add the following to dZSbot.tcl file:
# 1. to set msgtypes(DEFAULT) "..." add MVGENRE
# 2. set disable(MVGENRE)         0
# 3. set variables(MVGENRE)     "%rlname %custsection %genre"
# 4. set announce(MVGENRE)      "-%sitename- \[%custsection\] - Got %custsection info for %bold%rlname%bold. The genre is: %bold%genre%bold"
#
# This script gets these parameters from glftpd:
# $1 - the name of file uploaded
# $2 - the directory the file was uploaded to
# $3 - CRC from calc_crc, not used here

# Fix from 1.0 --> 1.0.1: There was a bug is this file with genre that contained a space, like "Other Pop" for example.


### CONFIG ###

# Site name
sitename="dS"

# Announce section
section="MUSICVIDEOS"

# Glftpd chrooted datapath in glftpd
datapath="/ftp-data"


### CODE ###

echo "mvscript v1.0.1 by eur0dance (C) 2002"
case $1 in
	*.[nN][fF][oO])
		genre=`/bin/getmvpreinfo $2 $1`
		echo "The following genre has been retrieved: $genre"
		touch $2/"[$sitename] - ( $genre ) - [$sitename]"
		if [ "$genre" != "Unknown" ]; then
			rlname=`basename $2`
			echo `date "+%a %b %d %T %Y"` MVGENRE: \"$rlname\" \"$section\" \""$genre"\" >> $datapath/logs/glftpd.log
		fi 
		exit 0
	;;
	*)
		exit 0
	;;
esac
