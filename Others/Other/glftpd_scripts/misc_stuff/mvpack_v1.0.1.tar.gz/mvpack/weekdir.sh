#!/bin/bash
# Week dirs creating script (for musicvideos mainly). 
# New week starts at 00:00 on Monday (Sunday/Monday night).
# Version 1.0
#
# Edit the 'CONFIG' section and add an entry to the root crontab for the script, it should look
# something like this: 0 0 * * 1   /glftpd/bin/weekdir.sh >/dev/null 2>&1 

### CONFIG ###

# Full path to the site dir
sitepath="/glftpd/site"

# Path to the dir containing week dirs
mainpath="MUSICVIDEOS"

# Link name to "today"'s weekdir
currentweek="week-mv"


### CODE ###

newweek=`date +%W`
newweek=`expr $newweek + 1`
weeksize=`expr length $newweek`
if [ "$weeksize" -eq "1" ]; then
   newweek="0$newweek"
fi
mkdir "$sitepath/$mainpath/Week$newweek"
chmod 777 "$sitepath/$mainpath/Week$newweek"
cd "$sitepath/"
rm -f $currentweek
ln -sf "$mainpath/Week$newweek" $currentweek
exit
