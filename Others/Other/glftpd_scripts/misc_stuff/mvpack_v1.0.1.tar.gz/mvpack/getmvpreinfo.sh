#!/bin/sh
# Version 1.0 by eur0dance
#
# $1 - path to the release dir

### CONFIG ###

sitename="dS"


### CODE ##

genre="Unknown"
cd $1
for file in *.nfo; do
	if [ $file != "*.nfo" ]; then
		tempgenre=`/bin/getmvpreinfo "$1" "$file"`
		if [ $genre = "Unknown" ]; then
			genre=$tempgenre
		fi
	fi
done
touch "[$sitename] - ( $genre ) - [$sitename]"
echo "MUSICVIDEOS - Genre: $genre"


