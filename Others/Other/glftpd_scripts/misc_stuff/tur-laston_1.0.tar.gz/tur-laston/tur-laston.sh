#!/bin/bash
VER=1.0
#-------------------------------------------------------#
# Tur-LastSeen - A small "seen" script for checking     #
# when the user last logged on to the site.             #
# This is basically a smaller version of Tur-UserInfo   #
# as it just checks the last logged on information.     #
#                                                       #
#-[ Installation ]--------------------------------------#
#                                                       #
# Copy tur-lastseen.sh to /glftpd/bin. Make it chmod 755#
# or similar.                                           #
# Copy tur-lastseen.tcl and load it in the bots config  #
# file. Edit it if you want to change path or trigger.  #
#                                                       #
#-[ Settings ]------------------------------------------#
#                                                       #
# USERDIR = Where users are stored.                     #
# DATEBIN = Full path to the 'date' binary.             #
# EXCLUDE = Any users or similar that should not be     #
#           able to be checked. Space in between.       #
#                                                       #
# At the bottom of the script you will find a echo line.#
# That is the output. Change it as you see fit.         #
# Scroll through it and you'll see what it does.        #
#                                                       #
#-[ Usage ]---------------------------------------------#
#                                                       #
# !seen <username>                                      #
#                                                       #
#-[ Contact ]-------------------------------------------#
#                                                       #
# http://www.grandis.nu/glftpd                          #
# Support on the forum there or msg me on efnet.        #
# ( Turranius. Usually in #glftpd )                     #
#                                                       #
#-------------------------------------------------------#


USERDIR=/glftpd/ftp-data/users
DATEBIN=/glftpd/bin/date
EXCLUDE="default.user backup glftpd"

#-[ Script Start ]--------------------------------------#

## Yeah yeah.
USER="$1"

## If no username was given.
if [ -z "$USER" ]; then
  echo "Specify a username to check please."
  exit 0
fi

## Check that there are only alphanumerical chars in name.
if [ "$( echo "$USER" | tr -d [:alpha:] | tr -d [:digit:] )" ]; then
  echo "Please only use alphanumerical chars."
  exit 0
fi

## Check if its excluded and quit if so.
if [ "$( echo "$EXCLUDE" | grep -w "$USER" )" ]; then
  echo "Cant check $USER. Thats none of your business."
  exit 0
fi

## Does the userdir exist ?
if [ ! -d "$USERDIR" ]; then
  echo "USERDIR does not exist or is not a directory. Check paths."
  exit 0
fi

## Does the userfile exist in the userdir ?
if [ ! -e "$USERDIR/$USER" ]; then
  echo "$USER does not exist."
  exit 0
fi

## Is the userfile readable ?
if [ ! -r "$USERDIR/$USER" ]; then
  echo "Cant read userfile for $USER. Check perms."
  exit 0
fi

## Procedure for calculating time since last on.
proc_laston() {
  ## NOTE: Parts on timediff taken from timediff.sh by Mihly Gyulai (2000-03-04)

  cd $USERDIR

  datum_1="$( $DATEBIN +%s )"
  datum_2="$( grep "^TIME " $USERDIR/$USER | cut -d ' ' -f3 )"

  ## Check if we got the time from the DATEBIN
  if [ -z "$datum_1" ]; then
    echo "Error. DATEBIN didnt return any time."
    exit 0
  fi

  ## Check if we got the time from the userfile
  if [ -z "$datum_2" ]; then
    echo "Couldnt read TIME field from $USER"
    exit 0
  fi

  let DIFF=$datum_2-$datum_1;
 
  if [ $DIFF -lt 0 ]; then 
    let DIFF=DIFF*-1
  fi

  let PERC=$DIFF/60;
  let ORA=$PERC/60;
  let NAP=$ORA/24;
  let ORA_DIFF=$ORA-24*$NAP;
  let PERC_DIFF=$PERC-60*$ORA
  let MP_DIFF=$DIFF-60*$PERC

  ## If there was more then 365 days ago, say this..
  if [ "$NAP" -gt "365" ]; then
    LASTON="more than a year"
  else

    ## Add days and hours to output.
    LASTON="$NAP days, $ORA_DIFF hours"

    ## Add minutes to output.
    if [ "$PERC_DIFF" -gt "1" ]; then
      LASTON="$LASTON, $PERC_DIFF minutes"
    else
      LASTON="$LASTON, $PERC_DIFF minute"
    fi

    ## Add seconds to output.
    if [ "$MP_DIFF" -gt "1" ]; then
      LASTON="$LASTON, $MP_DIFF seconds"
    else
      LASTON="$LASTON, $MP_DIFF second"
    fi

  fi
}

## run the procedure aboce ( Why did I make that a proc? Just friggin run it ).
proc_laston

## This is the output. You must NOT change this. Naaah just kidding. Change away.
echo "$USER was last seen logging on $LASTON ago."

exit 0
