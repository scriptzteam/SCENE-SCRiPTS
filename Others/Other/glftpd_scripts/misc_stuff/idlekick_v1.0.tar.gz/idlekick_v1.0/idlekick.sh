#!/bin/bash
# fulhack (C) vip3r@i386.net / wh3e@hugbox.net
#####

# Where your ftp binary is located
ftp=/bin/ftp

#Login for the bot to use on your site
user=sitebot

#Password for the bot to use on your site
pass=heyb2ed

# Host to your glftpd site
host=213.114.77.22

# Port to your glftpd site
port=9922

# Where  your ftpwho binary is located
ftpwho=/glftpd/bin/ftpwho

###############NO EDIT BELOW##############
INDEX=0
IDLEUSER=`$ftpwho|grep Idle|awk '{print $4}'`
USERNAME=`$ftpwho|grep Idle|awk '{print $2}'`
COMMAND="user $user $pass"
for ARGS in $IDLEUSER; do
index=$[$index+1]
COMMAND=$COMMAND"\nsite kill $ARGS"
done
RESULT=`echo -e $COMMAND | $ftp -vn $host $port`
echo $USERNAME
