# CONFIGURATION ------------------------------------------------------------------------------------.
#   `-----------------------------------------------------------------------------------------------'

GLCONF="/etc/glftpd.conf"				# glftpd.conf location
TMPFLDR="/glftpd/tmp"					# temp storage
TURFTPWHO="/glftpd/bin/tur-ftpwho"			# path to tur-ftpwho

PREOUT="[SERVER] -"					# start of each output line

USERDIR="/glftpd/ftp-data/users"			# path to userfiles

NCFTPLS="/usr/local/bin/ncftpls"			# path to ncftpls

SAFEFLAGS="1|4|7"					# flags for users not to be kicked

GLUSER="iono"						# username for sitebot kicking
GLPASS="circles"					# password for sitebot username

GLHOST="localhost"					# your ftp host
GLPORT="29181"						# your ftp port

BOTCOMMAND="!ishutdown"					# irc command (needs to be defined in tcl too)

#   .-----------------------------------------------------------------------------------------------.
# CONFIGURATION END --------------------------------------------------------------------------------'

# check for glftpd.conf
if [ ! -r $GLCONF ]; then
  echo "Error - Could not read \"$GLCONF\" Check configuration/chmod."
  exit 0
fi

#check for temp folder
if [ ! -d $TMPFLDR ]; then
  echo "Error - Could not access \"$TMPFLDR\" Check configuration."
  exit 0
fi

#check for turftpwho
if [ ! -x $TURFTPWHO ]; then
  echo "Error - Could not exec \"$TURFTPWHO\" Check configuration/chmod."
  exit 0
fi

#check for args
if [ $# -eq 0 ]; then
  if [ $UID = "0" ]; then
    echo "$PREOUT Syntax: ./iono-shutdown status or ./iono-shutdown.sh <1/0> [kick] - Specify \"1\" if you want to shutdown, or \"0\" if you want to open the site."
      else
    echo "$REOUT Syntax: $BOTCOMMAND status or $BOTCOMMAND <1/0> [kick] - Specify \"1\" if you want to shutdown, or \"0\" if you want to open the site."
  fi
  exit 0
fi

# convert any letters in $1 to lower case
FIRSTARG="$( echo "$1" | tr '[:upper:]' '[:lower:]' )"

# check for status command
if [ "$FIRSTARG" = "status" ]; then
  shutdownstatus="$( grep ^shutdown $GLCONF )"
  if [ "$shutdownstatus" = "shutdown 0" ]; then
    echo "$PREOUT Site is currently open."
  else
    echo "$PREOUT Site is currently closed."
  fi
  exit 0
fi

#check for $1 status
if [ "$1" = "0" ]; then
  SHUTDOWN="FALSE"
elif [ "$1" = "1" ]; then
  SHUTDOWN="TRUE"
else
  if [ "$UID" = "0" ]; then
    echo "$PREOUT Syntax: ./iono-shutdown.sh <1/0> [kick] - Your first arguemnt \"$1\" is invalid!"
   else
#special case due to eggdrop passing blank args if not specified.
    if [ "$1" = "" ]; then  
      echo "$PREOUT Syntax: $BOTCOMMAND <1/0> [kick]"
    else
      echo "$PREOUT Syntax: $BOTCOMMAND <1/0> [kick] - Your first arguemnt \"$1\" is invalid!"
    fi
  fi
  exit 0
fi

#convert $2 to lower case
KICKARG="$( echo "$2" | tr '[:upper:]' '[:lower:]' )"

#check for strange combination of args
if [ $1 = "0" ]; then
  if [ "$KICKARG" = "kick" ]; then
    echo "$PREOUT Only specify \"kick\" as 2nd arguement if you are shutting down the site, you don't need to kick anyone to open the site"
    exit 0
  fi
fi

#modify glftpd.conf to set new shutdown status
if [ $SHUTDOWN = "FALSE" ]; then
  sed '/^shutdown 1/s//shutdown 0/g' $GLCONF > $TMPFLDR/glftpd.conf.edit
  cp -f $TMPFLDR/glftpd.conf.edit $GLCONF  
  echo "$PREOUT Site has been re-opened!"
elif [ $SHUTDOWN = "TRUE" ]; then
  sed '/^shutdown 0/s//shutdown 1/g' $GLCONF > $TMPFLDR/glftpd.conf.edit
  cp -f $TMPFLDR/glftpd.conf.edit $GLCONF
  if [ "$KICKARG" != "kick" ]; then
    echo "$PREOUT Site is now not taking new connections!"
  fi
fi

#set $num_kicked starting val
num_kicked="0"

#kick users loop
if [ "$KICKARG" = "kick" ]; then
  for pid in `$TURFTPWHO | tr -d ' '`; do
    username="$( echo $pid | cut -d '^' -f1 )"
    pid="$( echo $pid | cut -d '^' -f2 )"
     if [ "$username" = "NoUsersCurrentlyOnSite!" ]; then
      echo "$PREOUT Server shut down! - No users were online"
      exit 0
     fi
    if [ -z "$( grep "^FLAGS " $USERDIR/$username | egrep "$SAFEFLAGS" )" ]; then
     NONEXEMPT="TRUE"
      if [ "$UID" = "0" ]; then
       kill $pid
       num_kicked=$( echo "$num_kicked + 1" | bc -l )
        if [ -z "$msg" ]; then
          msg="$username"
        else
          msg="$msg, $username"
        fi
      else
        $NCFTPLS -u$GLUSER -p$GLPASS -P$GLPORT -Y"site kill $pid" ftp://$GLHOST 2> /dev/null > /dev/null
        num_kicked=$( echo "$num_kicked + 1" | bc -l )
          if [ -z "$msg" ]; then
            msg="$username"
          else
            msg="$msg, $username"
          fi
      fi
    fi
  done
if [ "$NONEXEMPT" = "TRUE" ]; then
  if [ "$num_kicked" = "1" ]; then
    echo "$PREOUT Server shut down! - User ( $msg ) kicked!"
  else
    echo "$PREOUT Server shut down! - $num_kicked users ( $msg ) kicked!"
  fi
else
  echo "$PREOUT Server shut down! - No non-exempt users online"
fi
fi

exit 0
