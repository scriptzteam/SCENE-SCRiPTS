#!/bin/bash

                         ##                      ##
                        ##  delgroup 1.0 by ugly  ##
                         ##                      ##


ftpuser="user"          # username of the siteop login
ftppass="pass"     # password for the username
ftphost="127.0.0.1"    # site hostname or bnc (can be an IP or host)
ftpport="1337"         # site port
lftp_path="/bin/lftp"  # chrooted path to 'lftp'


### FAILSAFES ###

if [ $# -lt 1 ] || [[ $1 = "help" && -z $2 ]]; then
  echo -e "Syntax: site delgroup [-force] [-purge] <group>\r"
  exit 0
fi

if [ $1 = "-readd" ] && [[ -z $2 || $2 = help || $2 = "-purge" || $2 = "-force" ]];
  then
    echo -e "Syntax: site readdgroup <group>\r"
    exit 0
fi

if [ $# -gt 1 ] && [ $1 != "-force" ] && [ $1 != "-purge" ] && [ $1 != "-readd" ];
  then
    echo -e "Syntax: site delgroup [-force] [-purge] <group>\r"
    exit 0
fi

if [ $# -gt 2 ] && [ $2 != "-force" ] && [ $2 != "-purge" ]; then
  echo -e "Syntax: site delgroup [-force] [-purge] <group>\r"
  exit 0 
fi

if [ $1 = "-readd" ] && [ $# -gt 2 ]; then
  echo -e "Syntax: site delgroup [-force] [-purge] <group>\r"
  exit 0
fi

if [ $# -gt 3 ]; then
  echo -e "Syntax: site delgroup [-force] [-purge] <group>\r"
  exit 0
fi

if [ ! -f "$lftp_path" ]; then
  echo -e "You need 'lftp' in your glftpd/bin dir."
  exit 0
fi

siteop=`grep FLAGS /ftp-data/users/$USER | grep 1`
if [ -z "$siteop" ]; then
  echo -e "You must be a siteop to use this script.\r"
  exit 0
fi

case $# in
  1)
    group=$1
  ;;
  2)
    group=$2
  ;;
  3)
    group=$3
  ;;
esac

site_groups=`cat /etc/group | awk -F ":" '{print $1}'`
group_exists=`echo "$site_groups" | grep -i "$group"`
if [ -z "$group_exists" ]; then
  echo -e ""$group" does not exist!  Use 'site groups' for a list of valid groups."
  exit 0
fi


### DELETE/READD USERS ###

commands="open ftp://"$ftpuser":"$ftppass"@"$ftphost":"$ftpport""

# READD
if [ $1 = "-readd" ];
  then
    for readduser in /ftp-data/users/*; do
      ingroup=`grep GROUP "$readduser" | grep -i "$group" | awk '{print $2}'`
      ingroup_caps=`echo "$ingroup" | tr '[:lower:]' '[:upper:]'`
      group_caps=`echo "$group" | tr '[:lower:]' '[:upper:]'`
      deleted=`grep FLAGS "$readduser" | grep 6`
      name=`basename "$readduser"`
      if [ ! -z "$ingroup" ] && [ "$ingroup_caps" = "$group_caps" ] && \
         [ ! -z "$deleted" ]; then
        commands=""$commands"\nsite readd "$name""
      fi
    done
fi

# DELETE - NO FORCE
if [ $1 != "-readd" ] && [ $1 != "-force" ] && [[ -z $2 || $2 != "-force" ]];
  then
    for deluser in /ftp-data/users/*; do
      num_groups=`grep GROUP "$deluser" | wc -l`
      del_group=`grep GROUP "$deluser" | grep -i "$group" | awk '{print $2}'`
      delgrp_caps=`echo "$del_group" | tr '[:lower:]' '[:upper:]'`
      group_caps=`echo "$group" | tr '[:lower:]' '[:upper:]'`
      name=`basename "$deluser"`
      if [ "$num_groups" -gt 1 ] && [ ! -z "$del_group" ] && \
         [ "$delgrp_caps" = "$group_caps" ]; then
        nodeletelist=""$nodeletelist" "$name""
        if [ $1 = "-purge" ] || [[ ! -z $2 && $2 = "-purge" ]]; then
          commands=""$commands"\nsite chgrp "$name" "$del_group""
        fi
      fi
      if [ ! -z "$del_group" ] && [ "$num_groups" -eq 1 ] && \
         [ "$delgrp_caps" = "$group_caps" ]; then
        online=`/bin/ftpwho | awk '{print $2}' | grep "$name"`
        if [ ! -z "$online" ]; then
          commands=""$commands"\nsite kick "$name""
        fi
        if [ $1 != "-purge" ] && [[ -z $2 || $2 != "-purge" ]];
          then
            commands=""$commands"\nsite deluser "$name""
          else
            commands=""$commands"\nsite deluser "$name"\nsite purge "$name""
        fi
      fi
    done
    if [ $1 = "-purge" ] || [[ ! -z $2 && $2 = "-purge" ]];
      then
        commands=""$commands"\nsite grpdel $group"
    fi
    echo -e "$commands" | "$lftp_path" | sed -e 's/200 //g' -e 's/200- //g'
    if [ ! -z "$nodeletelist" ]; then
      echo -e "\nThe following users were not deleted or purged because \nthey're in groups other than "$del_group", and -force wasn't specified:\n "$nodeletelist"\n"
    fi
fi

# DELETE - WITH FORCE
if [ $1 != "-readd" ] && [ $1 = "-force" ] || [[ ! -z $2 && $2 = "-force" ]];
  then
    for deluser in /ftp-data/users/*; do
      groups=`grep GROUP "$deluser" | grep -i "$group" | awk '{print $2}'`
      groups_caps=`echo "$groups" | tr '[:lower:]' '[:upper:]'`
      group_caps=`echo "$group" | tr '[:lower:]' '[:upper:]'`
      name=`basename "$deluser"`
      if [ ! -z "$groups" ] && [ "$groups_caps" = "$group_caps" ]; then
        online=`/bin/ftpwho | awk '{print $2}' | grep "$name"`
        if [ ! -z "$online" ]; then
          commands=""$commands"\nsite kick "$name""
        fi
        if [ $1 != "-purge" ] && [[ -z $2 || $2 != "-purge" ]];
          then
            commands=""$commands"\nsite deluser "$name""
          else
            commands=""$commands"\nsite deluser "$name"\nsite purge "$name""
        fi
      fi
    done
    if [ $1 = "-purge" ] || [[ ! -z $2 && $2 = "-purge" ]]; then
      commands=""$commands"\nsite grpdel $group"
    fi             
    echo -e "$commands" | "$lftp_path" | sed -e 's/200 //g' -e 's/200- //g'
fi

exit 0
