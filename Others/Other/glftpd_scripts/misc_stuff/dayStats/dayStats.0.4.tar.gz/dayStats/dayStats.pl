#!/usr/bin/perl
##
## Dayly Statistic Script made by pnG
## 
## This script reads glftpd.log and sums todays events and
## posts it back to glftpd.log so that a bot can output it.
##
## // pnG
############
# Settings #
##################################
## glftpd dir?                  ##
##################################
$gldir = "/glftpd";

#########################################
## how does your PRE string look like? ##
#########################################
$pre = "PRE";

######################################################################
## Im going to try to guess what group that made the pre, so please ##
## help me by giving the pregroups names 			    ##
## This is the only groups I will look for			    ##
######################################################################
@pregrps = ('SPiCE', 'RSK', 'AND_SO_ON');

#####################################################################
## Here you can configure a list of folders to separate stats from ##
## Add as many as you like					   ##
#####################################################################
@folders = ('MP3', 'ISO');

################################################################################
## Which section do you want to display on your dayup?			      ##
## this should be the number of your section orderd by your glftpd.conf file  ##
## This can be max 3                                                          ##
################################################################################
$section = "1";

##################
## Section name ##
##################
$sectionname = "default";

##########################################################
## Number of users to display on dayup? 		##
## If you change this, remember to change it in your	##
## sitebotconfig aswell!				##
##########################################################
$dayupcnt = 5;

##########################[ Thats all, now watch the magic ]##

my $logins = 0;
my $newdirs = 0;
my $nukes = 0;
my $pres = 0;
my @folderstats;
my @prerels;
my $count = 0;
my $completes = 0;
my @nukees;
my $bcount = 0;
my @nukeescnt;
$dayupcnt--;

$arraylng = $#folders+1;
while ($count != $arraylng) {
	$folderstats[$count] = "0";
	$count++;
};
$count = 0;

$arraylng = $#pregrps+1;
while ($count != $arraylng) {
        $prerels[$count] = "0";
        $count++;
};


$count = 0;

$date = scalar localtime(time);
print "Reading statistics for today ($date)\n";
@dates = split(/ +/, $date);
open GLOG, "< $gldir/ftp-data/logs/glftpd.log" or die "Cant open your glftpd.log file!\n";
@gllog = <GLOG>;
close GLOG;

foreach $thing (@gllog) {
	@things = split(/ +/, $thing);
	##print "'$things[0]' '$things[1]' '$things[2]' '$things[3]' '$things[4]'\n";
	if ($things[0] eq $dates[0] and 
	    $things[1] eq $dates[1] and
	    $things[2] eq $dates[2] and
	    $things[4] eq $dates[4]) 
	{
		if ($things[5] eq "LOGIN:") {$logins++};
                if ($things[5] eq "NEWDIR:") {$newdirs++};
		if ($things[5] eq "NUKE:") {

			$nukes++;
			
	                $nc = $#nukees+1;
			$tmpcnt++;

                        $nukee = $things[8];
                        $nukee =~ s/\"//g;
			
			$tmpcnt = 0;
			foreach $nucke (@nukees) {
				if ($nucke eq $nukee) {
					$found = "1";
					$numberofnukes = $nukeescnt[$tmpcnt];
					$numberofnukes++;
					$nukeescnt[$tmpcnt] = $numberofnukes;
				}
				$tmpcnt++;
			}

			if ($found != 1) {
				$nukeescnt[$tmpcnt] = 1;
				$nukees[$nc] = "$nukee";
			} else {$found = 0};
		};
		if ($things[5] eq $pre) {
			$pres++;
			($dtsh, $preline) = split(/\"/, $thing);
			foreach $group (@pregrps) {
				if ($preline =~ /$group/) {
					$prerels[$bcount] = $prerels[$bcount]+1;
				}
				$bcount++;
			}
			$bcount = 0; 
		};
		if ($things[5] eq "COMPLETE:") {
			$things[6] =~ /\/CD(\d*)\"$/;
			if ($1 <= 1 or $1 eq "") {
			$completes++;
			@dirsplitt = split(/\//, $things[6]);
			foreach $folder (@folders) {
				if ($thing =~ /$folder/) {
					$folderstats[$count] = $folderstats[$count]+1;
				};
			$count++;
			};
			$count = 0;
			}
		};
	};
} 

## Top Loaders
$cnt = 0;
opendir(DIR, "$gldir/ftp-data/users");
my @files = readdir(DIR);
for my $file (@files) {
        $readfile = "$gldir/ftp-data/users/$file";
        open(INFO, $readfile) or die "Cant open $readfile stupid!\n";
        @lines = <INFO>;
        close(INFO);
        foreach $thing (@lines) {
                if ($thing =~ /GROUP (\w*)/) {$group = $1};
                if ($section == 1) {
                        if ($thing =~ /DAYUP (\d*) (\d*) (\d*)/) {if ($2) {$up = $2/1024^2}};
                } elsif ($section == 2) {
                        if ($thing =~ /DAYUP (\d*) (\d*) (\d*) (\d*) (\d*) (\d*)/) {if ($5) {$up = $5/1024^2}};
                } elsif ($section == 3) {
                        if ($thing =~ /DAYUP (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*)/) {if ($8) {$up = $8/1024^2}};
                } else {
                        print "This script only supports 3 sections, sorry\n";
                }
        };
        if ($up) {
                if (!$group) {$group = "noGroup"};
                $dayup[$cnt] = "$up!!$file!!$group";
                $cnt++;
        };
        $group = "";
        $up = "";

};
$cnt = 0;
opendir(DIR, "$gldir/ftp-data/users");
my @files = readdir(DIR);
for my $file (@files) {
        $readfile = "$gldir/ftp-data/users/$file";
        open(INFO, $readfile) or die "Cant open $readfile stupid!\n";
        @lines = <INFO>;
        close(INFO);
        foreach $thing (@lines) {
                if ($thing =~ /GROUP (\w*)/) {$group = $1};
                if ($section == 1) {
                        if ($thing =~ /DAYDN (\d*) (\d*) (\d*)/) {if ($2) {$up = $2/1024^2}};
                } elsif ($section == 2) {
                        if ($thing =~ /DAYDN (\d*) (\d*) (\d*) (\d*) (\d*) (\d*)/) {if ($5) {$up = $5/1024^2}};
                } elsif ($section == 3) {
                        if ($thing =~ /DAYDN (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*) (\d*)/) {if ($8) {$up = $8/1024^2}};
                } else {
                        print "This script only supports 3 sections, sorry\n";
                }
        };
        if ($up) {
                if (!$group) {$group = "noGroup"};
                $daydn[$cnt] = "$up!!$file!!$group";
                $cnt++;
        };
        $group = "";
        $dn = "";

};

## Transfers
open XFLOG, "< $gldir/ftp-data/logs/xferlog" or die "Cant open your xferlog file!\n";
@xflog = <XFLOG>;
close XFLOG;
foreach $thing (@xflog) {
        @xfthings = split(/ +/, $thing);

        if ($xfthings[0] eq $dates[0] and
            $xfthings[1] eq $dates[1] and
            $xfthings[2] eq $dates[2] and
            $xfthings[4] eq $dates[4])
        {
		if ($xfthings[11] eq "o") {
			## This is what I do if I find outgoing
			$outgoing = $outgoing + $xfthings[7];
                        $xfcnt = 0;
                        foreach $user (@downloaders) {
                                if ($user eq $xfthings[13]) {
                                        $found = 1;
                                        $downloaded[$xfcnt] = $downloaded[$xfcnt]+$xfthings[7];
                                        print "$user now has $downloaded[$xfcnt] bytes down\n";
                                }
                                $xfcnt++;
                        }
                        if ($found != 1) {
                                print "Added $xfthings[13] as a downloader\n";
                                $downloaders[$#downloaders+1] = $xfthings[13];
                        } else {$found = 0};
		} elsif ($xfthings[11] eq "i") {
			## If I find incoming
			$incoming = $incoming + $xfthings[7];
			$xfcnt = 0;
			foreach $user (@uploaders) {
				if ($user eq $xfthings[13]) {
					$found = 1;
					$uploaded[$xfcnt] = $uploaded[$xfcnt]+$xfthings[7];
					print "$user now has $uploaded[$xfcnt] bytes up\n";
				}
				$xfcnt++;
			}
			if ($found != 1) {
				print "Added $xfthings[13] as a uploader\n";
				$uploaders[$#uploaders+1] = $xfthings[13];
			} else {$found = 0};
		};
	}
};

$incoming = $incoming/1048576;
$outgoing = $outgoing/1048576;
$incoming =~ s/\.(\d*)//;
$outgoing =~ s/\.(\d*)//;

#### Done
print "Logins: $logins\n";
print "Newdirs: $newdirs\n";
print "Pres: $pres\n";
print "\n";
print "Today we had:\n";
$cnt = 0;
foreach $thing (@folders) {
	print "$folderstats[$cnt] new $thing\n";
	$cnt++;
};
print "That makes a total of: $completes releases\n";
print "\nNukes: $nukes\n";
if ($nukes != 0) {
print "Nukees: \n";

$tmpcnt = 0;
foreach $thing (@nukees) {
	print "$thing($nukeescnt[$tmpcnt])\n";
	$tmpcnt++;
};
};
print "Groups that prereleased:\n";
$cnt = 0;
foreach $thing (@pregrps) {
        print "$thing preed $prerels[$cnt] time(s)\n";
        $cnt++;
};


print "\nTotal incoming: $incoming mB\n";
print "Total outgoing: $outgoing mB\n";

$log = "$date DAYSTATS \"$logins\" \"$newdirs\" \"$pres\" \"";
$cnt = 0;
foreach $thing (@pregrps) {
        if ($prerels[$cnt] != 0) {$log .= "$thing($prerels[$cnt]), "};
        $cnt++;
};
$log =~ s/, $//;
$log .= "\" \"";
$cnt = 0;
foreach $thing (@folders) {
        $log .= "$thing($folderstats[$cnt]), ";
	$cnt++;
};
$log =~ s/, $//;
$log .= "\" \"$nukes\" \"";
$tmpcnt = 0;
foreach $thing (@nukees) {
      	$log .= "$thing($nukeescnt[$tmpcnt]), ";
        $tmpcnt++;
}
$log =~ s/, $//;
$log .= "\" \"$incoming\" \"$outgoing\"";

$counter = 1;

@ranked = reverse sort { $a <=> $b } @daydn;
($mbup, $user, $grp) = split(/!!/, $daydn[0]);

$log .= " \"$sectionname\" ";
$log .= " \"$user\@$grp\ with $mbup mBs\"";
print "Todays downloader is: $user\@$grp with $mbup mBs down\n";

@ranked = reverse sort { $a <=> $b } @dayup;
($mbup, $user, $grp) = split(/!!/, $dayup[1]);
$log .= " \"$user\@$grp\ with $mbup mBs\" ";
print "Todays uploader is: $user\@$grp with $mbup mBs up\n";

print "This was todays top uploaders:\n";
foreach $thing (@ranked) {
        ($mbup, $user, $grp) = split(/!!/, $thing);
        $log .= "\"$user\@$grp\" \"$mbup mB\" ";
        print "$counter: $user\@$grp with $mbup mBs up\n";
        $counter++;
};

if ($counter < $dayupcnt) {
        while ($counter != 6) {
                print "$counter: noone\n";
                $log .= "\"noone\" \"nothing\" ";
                $counter++;
        };
};


open LOG, ">> $gldir/ftp-data/logs/glftpd.log" or die "Cant open glftpd.log!\n";
print LOG "$log\n";
close LOG;

$cnt = 0;
foreach $user (@uploaders) {
	print "$user @ $uploaded[$cnt]\n";
	$topuploaders[$cnt] = $uploaded[$cnt]."!!".$user;
	$cnt++;
};
$cnt = 0;
foreach $user (@downloaders) {
        $topdownloaders[$cnt] = $downloaded[$cnt]."!!".$user;
        $cnt++;
};

@rankedup = reverse sort { $a <=> $b } @topuploaders;
($mbup, $user) = split(/!!/, $topuploaders[0]);
print "Allup: $user @ $mbup\n";

@rankeddn = reverse sort { $a <=> $b } @topdownloaders;
($mbdn, $user) = split(/!!/, $topdownloaders[0]);
print "Allup: $user @ $mbdn\n";


