#!/bin/bash

###################################################################
#   (newdate.sh) MP3/0DAY Auto Date Creator v1.3 by kulgan        #
#             							  #
#    CRONTAB Entry:						  #
#    0 24 * * * root /glftpd/bin/newdate.sh >> /dev/null 2>&1	  #
#    								  #
#    Instructions:				   		  #
#    								  #
#  1. Put this file in your bin for glftpd (/glftpd/bin/ usually) #
#  2. Set variables for your glftpd system                        #
#  3. Make the file executable by doing chmod +x newdate.sh.      #
#  4. Add crontab entry, and let it run. :)			  #
#  5. To zipscript-c add:					  #
#     -> To set msgtypes(DEFAULT) add KULSCRIPT                   # 
#     -> set chanlist(KULSCRIPT) "#chan"	  		  #
#     -> set disable(KULSCRIPT) 0 				  #
#     -> set variables(KULSCRIPT) "%msg"			  #
#     -> set announce(KULSCRIPT) "%msg"			 	  #
#								  #
#								  #
#  CHANGELOG:							  #
#								  #
#  2004-11-15: - Fix: stupidly put, 0DAYLINK= to    		  #
#	                0DAYLINK=0day_yesterday fixed now     	  #
#	   - Add: Option to enable/disable 0DAYOLDLINK &	  #
#		    MP3OLDLINK					  # 	
#	   - Add: Config file for easier updates without          #
#		    having to keep adjusting your settings here	  # 	
#  2004-10-11: - Forgot to add the Crontab entry for prev rls     #
#	         - Adjusted some of the code that wasn't needed   #
#								  #
#  2004-10-04: - Created choice to have either mp3/0day creation  #
#              - Editable output for both mp3/0day                # 
#								  #
#  2004-10-03: - Start of the script, only allowing mp3           #
#						                  #
###################################################################

VER=1.3

cfg="newdate.conf"
. $cfg

##### DO NOT ALTER BEYOND THIS LINE UNLESS YOU KNOW WHAT YOUR DOING #####

###### CREATE YESTERDAY SYMLINKS FOR MP3 ######

MP3OLD_YES() {

if [ ! -e $MP3DIR/$YESTERDAY ]; then

     mkdir $MP3DIR/$YESTERDAY

  fi 

  if [ ! -e $MP3DIR/$TODAY ]; then
   
     mkdir $MP3DIR/$TODAY

  fi

  chmod 777 $MP3DIR/$TODAY
  chmod 755 $MP3DIR/$YESTERDAY

  cd $GLROOT

  rm -rf $MP3LINK
  rm -rf $MP3OLDLINK

  ln -s $MP3DIR/$TODAY $MP3LINK
  ln -s $MP3DIR/$YESTERDAY $MP3OLDLINK

  echo `date "+%a %b %e %T %Y"` KULSCRIPT: $MP3OUTPUT >> $GLLOG

}

###### CREATE YESTERDAY SYMLINKS FOR 0DAY ######

DAYOLD_YES() {

if [ ! -e $DAYDIR/$YESTERDAY ]; then

     mkdir $DAYDIR/$YESTERDAY

  fi 

  if [ ! -e $DAYDIR/$TODAY ]; then
   
     mkdir $DAYDIR/$TODAY

  fi

  chmod 777 $DAYDIR/$TODAY
  chmod 755 $DAYDIR/$YESTERDAY

  cd $GLROOT

  rm -rf $DAYLINK
  rm -rf $DAYOLDLINK

  ln -s $DAYDIR/$TODAY $DAYLINK
  ln -s $DAYDIR/$YESTERDAY $DAYOLDLINK

  echo `date "+%a %b %e %T %Y"` KULSCRIPT: $DAYOUTPUT >> $GLLOG

}

################### MAIN PROC ###################

############## MP3 PROC ############## 

if [ $ENABLE_MP3 != 0 ]; then

  if [ $ENABLE_MP3OLD == 1 ]; then
     
	MP3OLD_YES
  
  fi

  if [ $ENABLE_MP3OLD == 0 ]; then

    if [ ! -e $MP3DIR/$TODAY ]; then
   
       mkdir $MP3DIR/$TODAY

    fi

    chmod 777 $MP3DIR/$TODAY

    cd $GLROOT

    rm -rf $MP3LINK

    ln -s $MP3DIR/$TODAY $MP3LINK

    echo `date "+%a %b %e %T %Y"` KULSCRIPT: $MP3OUTPUT >> $GLLOG

  fi

fi


############## 0DAY PROC ############## 

if [ $ENABLE_0DAY != 0 ]; then

  if [ $ENABLE_0DAYOLD == 1 ]; then
     
	DAYOLD_YES
  
  fi

  if [ $ENABLE_0DAYOLD == 0 ]; then

    if [ ! -e $DAYDIR/$TODAY ]; then
   
       mkdir $DAYDIR/$TODAY

    fi

    chmod 777 $DAYDIR/$TODAY

    cd $GLROOT

    rm -rf $DAYLINK

    ln -s $DAYDIR/$TODAY $DAYLINK

    echo `date "+%a %b %e %T %Y"` KULSCRIPT: $DAYOUTPUT >> $GLLOG

  fi

fi
