#!/bin/bash
VER=1.0
#------------------------------------------------------#
#                                                      #
# Tur-MySQLSearch. Used for searching the searchdb     #
# database from irc and/or glftpd.                     #
#                                                      #
# As this script only READS the database, you'll need  #
# to have tur-mysqlsearchdb.sh already setup and       #
# crontabbed.                                          #
#                                                      #
#--[ Setup ]-------------------------------------------#
#                                                      #
# * Copy tur-mysqlsearch.sh to /glftpd/bin. Chmod 755. #
#                                                      #
# * Copy tur-mysqlsearch.tcl to your bots scripts dir  #
#   load it in the config and .rehash the bot.         #
#   You might want to change the trigger in the tcl.   #
#   I'll leave that part up to you.                    #
#                                                      #
# * If you plan to allow your users to search from     #
#   glftpd, you need a working mysql client inside     #
#   glftpds chrooted enviroment. I recomend you        #
#   download tur-trial3 and have a look at the         #
#   mysql_stuff/README.mysql file for instructions.    #
#   Then load it in glftpd.conf. Something like:       #
#   site_cmd sqlsearch  EXEC   /bin/tur-mysqlsearch.sh #
#   custom-sqlsearch *                                 #
#                                                      #
# * Change the options below.                          #
#                                                      #
# * Run it from shell to verify that it works.         #
#   No arguments echoes a short helptext.              #
#   Feel free to change it. Search for proc_help()     #
#                                                      #
#--[ Configuration ]-----------------------------------#

## These should be self explaining. SQLBIN is hardcoded to
## /bin/mysql if executed from inside glftpd.
SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"
SQLDB="searchdb"
SQLTB="searchdb"

## This servers sitename. Should be the same as in tur-mysqlsearchdb.sh
sitename="xXx"

## REGEXP for what not to display. Generally, you do not have to escape
## characters here. Play around some. MySQL's REGEXP is a bit... funny IMO.
dontshow="/GROUPS/|/_PRE/"

## Only show releases which have onsite=1 in the database?
## If you do not keep non-existing releases in the database (set in 
## tur-mysqlsearchdb.sh), you might as well set this to FALSE.
show_only_onsite="FALSE"

## Only show releases from this site? Kinda breaks the purpose of the 
## database if you set it to TRUE.
show_only_this_sitename="FALSE"

## Since the database stores the full path to the releases, you might want
## to cut out a part so it does not show /glftpd/site/blabal.
## Setting this to "/site" cuts out /site and everything infront of it, 
## leaving /blabal - Looks much better in the output.
split_path_from="/site"

## Maximum hits to return when searching from shell/irc.
max_hits_irc="20"

## Maximum hits to return when searching from glftpd.
max_hits_gl="50"

## Dont touch these. Used for bold and underline in the output.
B=""  ## Dont touch
U=""  ## Dont touch

## Shows some extra info on execution. Be SURE do set it to FALSE
## before any user runs it as it WILL show the username/password
## for the MySQL server.
DEBUG="FALSE"

## This is echoed for each release it finds.
## Cookies are:
## ${site}      = Sitename as stored in database.
## ${fullpath}  = Full path to release, after $split_path_from=
## ${path}      = Only the releasename, no path.
## ${size}      = If you chose to keep sizes in the database, this will be it.
## ${B}         = Starts/Stops bold text.
## ${U}         = Starts/Stops underlined text.
##                The B and U cookies are stripped when running from inside
##                glftpd as it just looks stupid from in there.
proc_output() {
  echo "${B}[${site}]${B} ${fullpath} [${size}]"
}

## If a search results in more hits then allowed, this is displayed
## at the end. Cookies are ${HITS} and ${HITLIMIT}. Also ${B} and ${U}
proc_showhits() {
  echo "[ ${B}${HITS}${B} total hits found. Displaying ${HITLIMIT} ]"
}

## If no hits was found, this is announced.
proc_shownohits() {
  echo "[ No results found ]"
}



#--[ Script Start ]------------#

proc_testcon() {
  if [ -z "$( $SQL "select ID from $SQLTB limit 1" )" ]; then
    echo "No connection to database or nothing has yet to be indexed."
    exit 0 # Yes, 0. Otherwise it wont be announced in chan.
  fi
}

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "DEBUG: $*"
  fi
}

proc_help() {
  echo "#------------------------------------------------------------------------------#"
  echo "# Tur-Search (MySQL Edition) $VER. Used for searching multiple sites at once."
  echo "# Usage: Enter any searchwords. If you use \"word1 word2\", the order does"
  echo "# not matter. However, if you use \"word1%word2\", it does."
  echo "# "
  echo "# To exclude words, prefix the word with $colon, for example: \"word1 ${colon}word2\""
  echo "# This works for the path as well."
  echo "#"
  echo "# You may specify as many searchwords and excludes as you like."
  echo "# You may specify part of the path as searchword. For example: \"/DVDR/ word1\""
  echo "#------------------------------------------------------------------------------#"
  exit 0
}

if [ -z "$FLAGS" ]; then
  SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"
  RUN_MODE="irc"
  HITLIMIT="$max_hits_irc"
  addpath="$addpath_irc"
  colon="!"
else
  SQL="/bin/mysql -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"
  RUN_MODE="gl"
  HITLIMIT="$max_hits_gl"
  addpath="$addpath_gl"
  colon="!!"
  unset B
  unset U
fi
proc_debug "Mode:$RUN_MODE - HitLimit:$HITLIMIT - SQL:$SQL"

proc_testcon

if [ -z "$1" ] || [ "$1" = "help" ] || [ "$1" = "-help" ]; then
  proc_help
  exit 0
fi

VARS="`echo " $@ "`"
proc_debug "Setting VARS:$VARS"

for rawdata in $VARS; do
  if [ "`echo "$rawdata" | grep "^!"`" ]; then
    rawdata="`echo "$rawdata" | cut -c2-`"
    COMMANDRAW="$COMMANDRAW path^not^like^'%${rawdata}%'"
  else
    COMMANDRAW="$COMMANDRAW path^like^'%${rawdata}%'"
  fi
done

for each in $COMMANDRAW; do
  each="`echo "$each" | tr '^' ' '`"
  if [ -z "$SQLQUERY" ]; then
    SQLQUERY="where $each"
  else
    SQLQUERY="$SQLQUERY and $each"
  fi
done
proc_debug "1:SQLQUERY:$SQLQUERY"

if [ "$show_only_onsite" = "TRUE" ]; then
  SQLQUERY="$SQLQUERY and onsite = '1'"
fi

if [ "$show_only_this_sitename" = "TRUE" ]; then
  SQLQUERY="$SQLQUERY and site = '$sitename'"
fi

if [ "$dontshow" ]; then
  SQLQUERY="$SQLQUERY and path not REGEXP '$dontshow'"
fi

SQLQUERY_OLD="$SQLQUERY"

if [ "$HITLIMIT" ]; then
  SQLQUERY="$SQLQUERY limit $HITLIMIT"
fi
proc_debug "4:SQLQUERY:$SQLQUERY"

proc_debug "Running: $SQL \"select path, site, size from $SQLTB $SQLQUERY\""
proc_debug "----------------------------------------"

for rawdata in `$SQL "select path, site, size from $SQLTB $SQLQUERY"  | tr '\t' "'" | tr ' ' '^'`; do
  fullpath="`echo "$rawdata" | cut -d "'" -f1 | tr '^' ' '`"
  site="`echo "$rawdata" | cut -d "'" -f2 | tr '^' ' '`"
  size="`echo "$rawdata" | cut -d "'" -f3 | tr '^' ' '`"

  if [ "$split_path_from" ]; then
    fullpath="`echo "$fullpath" | awk -F"${split_path_from}" '{print $2}'`"
  fi

  size="${size}MB"
  path="`basename "$fullpath"`"

  proc_output

done

HITS="`$SQL "select count(ID) from $SQLTB $SQLQUERY_OLD"`"
if [ -z "$HITS" ] || [ "$HITS" = "0" ]; then
  proc_shownohits
  exit 0
fi

if [ "$HITS" -gt "$HITLIMIT" ]; then
  proc_showhits
fi
