#!/bin/bash
VER=1.0

#---------------------------------------------------------------#
#                                                               #
# This is a script which indexes all your releases into a mysql #
# database for use like 'site search'.                          #
#                                                               #
# Why would you want this? You probably dont. Site search is    #
# good enough if you combine it with glupdate/olddirclean2 (or  #
# use tur-dirlogclean). However, in this script, you set your   #
# sitename which is stored with each release.                   #
# Therefor, if you have multiple sites running, you can let     #
# them all run this script towards the same mysql database in a #
# central location. Users searching will then get hits from all #
# sites and can easely see where it is.                         #
#                                                               #
# Is it faster? Well, searching probably is a little faster,    #
# but hardly noticable. Indexing all the dirs on your sites     #
# takes about the same amount of time as running                #
# tur-dirlogclean.                                              #
# This is of course if du_command and keep_deleted are both     #
# set to FALSE.                                                 #
#                                                               #
# Note, all THIS script does is index your releases into a      #
# database and keeping it up to date.                           #
# You then need other scripts for searching, etc.               #
#                                                               #
#--[ Setup ]----------------------------------------------------#
#                                                               #
# * Setup the database and tables using the setup_database.sh   #
#   script.                                                     #
#                                                               #
# * Copy tur-mysqlsearchdb.sh to /glftpd/bin.                   #
#                                                               #
# * Configure the settings, then run it as                      #
#   ./tur-mysqlsearchdb debug                                   #
#                                                               #
#--[ Settings ]-------------------------------------------------#
#                                                               #
# These should be self explaining. Either set full path to your #
# mysql client or leave it as "mysql" if its in your path.      #
# SQLBIN="mysql"                                                #
# SQLHOST="localhost"                                           #
# SQLUSER="root"                                                #
# SQLPASS="password"                                            #
# SQLDB="searchdb"                                              #
# SQLTB="searchdb"                                              #
#                                                               #
# sitename=  Short name of your site. Make sure its unique      #
#            between your sites.                                #
#                                                               #
# glroot=    "/glftpd/site" - Path to your /site dir.           #
#                                                               #
# tuls=      "/glftpd/bin/tuls" - This script requires tuls.    #
#            A standalone "ls" binary found at www.grandis.nu   #
#            Read the instructions that comes with it and make  #
#            sure it works.                                     #
#            This is the full path to it.                       #
#                                                               #
# du_command= "du -s -m" - The size of the release is           #
#             calculated using this. If you do not want to      #
#             store sizes in the database, leave this as ""     #
#             Doing that makes this script A LOT faster.        #
#                                                               #
# keep_size_updated= "TRUE/FALSE"                               #
#                    Only used if du_command above is set.      #
#                    If TRUE and a release it checks is already #
#                    in the database, it will make sure the     #
#                    is correct.                                #
#                                                               #
# keep_deleted=      "TRUE/FALSE"                               #
#                    If a release disapears from the site, do   #
#                    you want to keep it in the database?       #
#                    If FALSE, it will simply be deleted.       #
#                    if TRUE, it will be kept, but the onsite   #
#                    value in the table will be set to 0 instead#
#                    of 1.                                      #
#                    Unless you have a good reason for keeping  #
#                    old stuff (replacement for 'site dupe'?)   #
#                    you should leave this as FALSE.            #
#                                                               #
# keep_only_same_rels= "TRUE/FALSE"                             #
#                    Only value if keep_deleted="TRUE".         #
#                    If TRUE, it will check if the release      #
#                    exists in another path (archived?). If it  #
#                    does exists elsewhere, it will be deleted. #
#                    If it does not, onsite will be set to 0.   #
#                                                               #
# sections=  Specify each section on your site that you want to #
#            search for releases in.                            #
#                                                               #
#            HINT: This is the SAME setup as in tur-dirlogclean #
#                  so if you want, you can copy this part from  #
#                  that script (providing you use it of course) #
#                                                               #
#            NOTE: This is only used if no path is specified    #
#                  when executing this script. You can do       #
#                  ./tur-mysqlsearchdb.sh /glftpd/site/blabla   #
#                  as well.                                     #
#                                                               #
#            Add :DEEP to the end to dive one dir into that     #
#            (for dated dirs).                                  #
#                                                               #
#            Add :2xDEEP to the end to dive two dirs down.      #
#                                                               #
#            Finally, :3xDEEP is also accepted to jump 3 levels #
#            down the dir structure.                            #
#                                                               #
#            Example: Say you have the following path:          #
#             $glroot/Archive/0DAYS/0DAYS1/2004/0102            #
#            Now, instead of adding 0101 / 0102, etc, you can:  #
#             $glroot/Archive/0DAYS/0DAYS1/2004:DEEP            #
#            Or:                                                #
#             $glroot/Archive/0DAYS/0DAYS1:2xDEEP               #
#            Or:                                                #
#             $glroot/Archive/0DAYS:3xDEEP                      #
#                                                               #
#            If you have a space in your sections               #
#            then use [:space:]                                 #
#                                                               #
# exclude=   This is only if you specify :DEEP 2xDEEP 3xDEEP.   #
#            What NOT to add to dirlog? Pre folders etc.        #
#            Only directories will be added, so you do not have #
#            to exclude symlinks or files.                      #
#                                                               #
#            Note, this is a simple egrep -vi line, so if you   #
#            specify, for example PRE, it will skip any dir     #
#            containing that word. To specify only the dir      #
#            use ^PRE$ and it will only match on the dir thats  #
#            actually named PRE.                                #
#                                                               #
#--[ Running it ]-----------------------------------------------#
#                                                               #
# This script takes 4 arguments:                                #
# debug    = Enables debug mode. Will show what its doing.      #
# noclean  = Do not run the cleanup part at the end. Only add   #
#            new releases.                                      #
# clear    = Clear out the table from releases coming from this #
#            sitename.                                          #
# clearall = Clear out the entire table and start fresh.        #
#                                                               #
# You may also specify one or more paths you want it to run in. #
# For example:                                                  #
# ./tur-mysqlsearchdb.sh /glftpd/site/DVDR                      #
# or if you have dated dirs:                                    #
# ./tur-mysqlsearchdb.sh /glftpd/site/0DAYS/`date +%y%m`        #
# This will then override the sections= setting.                #
#                                                               #
# Crontab this script to run whenever you like.                 #
# like:                                                         #
# 1 1 * * * /glftpd/bin/tur-mysqlsearchdb.sh                    #
# to run it 01:01AM each day.                                   #
#                                                               #
# Since this script does not add stuff on upload, like the      #
# dirlog does, you might want to run it a few times during the  #
# day as well. Something like:                                                                              #
# */60 * * * * /glftpd/bin/tur-mysqlsearchdb.sh noclean /glftpd/site/0DAYS/`date +%y%m` /glftpd/site/MP3/`date +%y%m`
# To run it every hour in your dated dirs, but do not do the    
# cleanup phase at the end.                                     #
#                                                               #
#-[ Contact ]---------------------------------------------------#
# WEB: http://www.grandis.nu                                    #  
#-[ Settings ]--------------------------------------------------#

SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"
SQLDB="searchdb"
SQLTB="searchdb"

sitename="xXx"
glroot="/glftpd/site"
tuls="/glftpd/bin/tuls"

# du_command="du -s -m"
keep_size_updated="FALSE"
keep_deleted="FALSE"
keep_only_same_rels="FALSE"

sections="
$glroot/DVDR
$glroot/Archive/DVDR:DEEP
$glroot/XBOX
$glroot/Archive/XBOX:DEEP
$glroot/REQUESTS
$glroot/0DAYS:DEEP
$glroot/Archive/0DAYS:2xDEEP
"

exclude="^GROUPS$|^lost\+found$|^All$|\[NUKED\]"


#-[ Script Start ]--------------------------------#

SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"

proc_debug() {
  if [ "$debug" = "TRUE" ]; then
    echo "$*"
  fi
}

proc_testcon() {
  sqldata="`$SQL "show table status" | tr -s '\t' '^' | cut -d '^' -f1`"
  if [ -z "$sqldata" ]; then
    unset ERRORLEVEL
    echo "Mysql error. Check server!"
    exit 0
  fi
}

## Go through each argument given and set the options accordingly.
for each in $*; do
  if [ "`echo "$each" | grep -i "^debug$"`" ]; then
    debug="TRUE"
  elif [ "`echo "$each" | grep -i "^clear$"`" ]; then
    if [ -z "$DID_CLEANED" ]; then
      DID_CLEANED="TRUE"
      proc_debug "Clearing out table from $sitename stuff: $SQLTB"
      $SQL "delete from $SQLTB where site = '$sitename'"
    fi
  elif [ "`echo "$each" | grep -i "^clearall$"`" ]; then
    if [ -z "$DID_CLEANED_ALL" ]; then
      DID_CLEANED_ALL="TRUE"
      proc_debug "Clearing out everything from table: $SQLTB"
      $SQL "delete from $SQLTB"
    fi
  elif [ "`echo "$each" | grep -i "^noclean$"`" ]; then
    if [ -z "$NOCLEAN" ]; then
      proc_debug "NoClear set. Will not run cleanup phase."
    fi
    NOCLEAN="TRUE"
  else
    if [ "`echo "$each" | grep "/"`" ]; then
      if [ -z "$newsections" ]; then
        newsections="$each"
      else
        newsections="$newsections $each"
      fi
    else
      echo "Unknown command: $each."
      echo "Commands are: debug, noclean, clear, clearall"
      echo "To specify paths (overrides sections=), a / must be included somewhere."
      exit 1
    fi
  fi
done
unset DID_CLEANED; unset DID_CLEANED_ALL
if [ "$newsections" ]; then
  sections="$newsections"
  proc_debug "Manual sections specified: $sections"
fi


proc_list_and_add() {
  for release in `$tuls "$searcharea" | grep "^d" | egrep -v "::::\.::::|::::\.\.::::" | awk -F"::::" '{print $4}' | egrep -v "$exclude" | tr ' ' '^'`; do
    if [ -z "`echo "$release" | grep "....."`" ]; then
      proc_debug "Skipping $release - Too short ?!"
    else
      release="`echo "$release" | tr '^' ' '`"
      fullpath="`echo "${searcharea}/${release}" | tr -s '/'`"

      rawstuff="`$SQL "select path, size, onsite from $SQLTB where path = '$fullpath' and site = '$sitename' limit 1" | awk '{print $1"^"$2"^"$3"^"$4}'`"
      ## Nothing found? Add it.
      if [ -z "$rawstuff" ]; then

        ## Get size 
        size="-1"
        if [ "$du_command" ]; then
          size="`$du_command "$fullpath" | cut -f1`"

          if [ -z "$size" ]; then
            size="-1"
          fi
        fi

        proc_debug "Inserting $fullpath ${size}MB"
        $SQL "insert into $SQLTB (path, site, size, onsite) VALUES ('$fullpath', '$sitename', '$size', '1')"
      else

        fullpath="`echo "$rawstuff" | cut -d '^' -f1`"

        ## If sizes should be kept updated, check size now and in db. Update if needed.
        if [ "$du_command" ] && [ "$keep_size_updated" = "TRUE" ]; then
          dbsize="`echo "$rawstuff" | cut -d '^' -f2`"

          size="`$du_command "$fullpath" | cut -f1`"
          if [ -z "$size" ]; then
            size="-1"
          fi
          if [ "$size" != "$dbsize" ]; then
            proc_debug "Updating size on ${release} from $dbsize to $size"
            $SQL "update $SQLTB set size = '$size' where path = '$fullpath' and site = '$sitename'"
          fi
        fi

        ## If a release is back and keep_deleted is true, set onsite = 1 again.
        if [ "$keep_deleted" = "TRUE" ]; then
          dbonsite="`echo "$rawstuff" | cut -d '^' -f3`"
          if [ "$dbonsite" = "0" ]; then
            proc_debug "$fullpath is BACK. Setting onsite back to 1."
            $SQL "update $SQLTB set onsite = '1' where path = '$fullpath' and site = '$sitename'"
          fi
        fi
  
      fi
    fi
  done
}

if [ -z "$exclude" ]; then
  exclude="fje093jf93"
fi
proc_debug "Setting exclude: \"$exclude\""

for section in $sections; do
  dated="`echo $section | cut -d ':' -f2`"
  section="`echo "$section" | sed -e 's/\[\:space\:\]/ /g' | cut -d ':' -f1`"

  if [ "$dated" != "DEEP" ] && [ "$dated" != "2xDEEP" ] && [ "$dated" != "3xDEEP" ]; then
    proc_debug "Entering \"$section\""
    cd "$section"
    searcharea="$section"
    proc_list_and_add
  else
    if [ ! -d "$section" ]; then
      echo "Error. \"$section\" does not exist. Skipping."
    else
      cd "$section"
      LIST="`$tuls | grep "^d" | egrep -v "::::\.::::|::::\.\.::::" | awk -F"::::" '{print $4}' | egrep -v "$exclude"`"
      for folder in $LIST; do
        if [ "$dated" = "2xDEEP" ]; then
          LIST2="`$tuls "$folder" | grep "^d" | egrep -v "::::\.::::|::::\.\.::::" | awk -F"::::" '{print $4}' | grep -v "$exclude"`"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
              proc_debug "Not a dir: $section/$folder/$folder2 - Skipping."
            else
              searcharea="$section/$folder/$folder2"
              proc_debug "Entering (2xDEEP) \"$searcharea\""
              proc_list_and_add
            fi
          done

        elif [ "$dated" = "3xDEEP" ]; then
          LIST2="`$tuls "$folder" | grep "^d" | egrep -v "::::\.::::|::::\.\.::::" | awk -F"::::" '{print $4}' | grep -v "$exclude"`"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
              proc_debug "Not a dir: $section/$folder/$folder2 - Skipping."
            else
              LIST3="`$tuls "$folder/$folder2" | grep "^d" | egrep -v "::::\.::::|::::\.\.::::" | awk -F"::::" '{print $4}' | grep -v "$exclude"`"
              for folder3 in $LIST3; do
                if [ ! -d "$section/$folder/$folder2/$folder3" ]; then
                  proc_debug "Not a dir: $section/$folder/$folder2/$folder3 - Skipping."
                else
                  searcharea="$section/$folder/$folder2/$folder3"
                  proc_debug "Entering (3xDEEP) \"$searcharea\""
                  proc_list_and_add
                fi
              done
            fi
          done

        else
          if [ ! -d "$section/$folder" ]; then
            proc_debug "Not a dir: $section/$folder - Skipping."
          else
            searcharea="$section/$folder"
            proc_debug "Entering (DEEP) \"$searcharea\""
            proc_list_and_add
          fi
        fi

      done
    fi
  fi
done

if [ "$NOCLEAN" = "TRUE" ]; then
  exit 0
fi

proc_debug "Checking for dirs that does not exist anymore. This could take some time."

for path in `$SQL "select path from $SQLTB where site = '$sitename' and onsite = '1'"`; do
  if [ ! -d "$path" ]; then
    if [ "$keep_deleted" = "FALSE" ]; then
      proc_debug "Removing $path"
      $SQL "delete from $SQLTB where path = '$path' and site = '$sitename'"
    else
      if [ "$keep_only_same_rels" = "TRUE" ]; then
        release="`basename "$path"`"
        if [ "`$SQL "select path from $SQLTB where path like '%$release' and path != '$path' and site = '$sitename'"`" ]; then
          proc_debug "Removing $release - Exists as $path"
          $SQL "delete from $SQLTB where path = '$path' and site = '$sitename'"
        else
          proc_debug "Removing (onsite 0) $path"
          $SQL "update $SQLTB set onsite = '0' where path = '$path' and site = '$sitename'"
        fi
      else
        proc_debug "Removing (onsite 0) $path"
        $SQL "update $SQLTB set onsite = '0' where path = '$path' and site = '$sitename'"
      fi
    fi
  fi
done

proc_debug ""
proc_debug "Optimizing table."
$SQL "optimize table $SQLTB" > /dev/null
proc_debug "All done."

exit 0
