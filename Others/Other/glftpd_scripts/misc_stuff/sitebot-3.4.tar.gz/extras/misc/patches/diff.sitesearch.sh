*** extras/sitesearch.sh	Sun Nov 16 22:50:02 2003
--- /glftpd/sitebot/extras/sitesearch.sh	Thu Dec  4 12:16:38 2003
***************
*** 3,6 ****
--- 3,8 ----
  #---------------------------------------------------------------------------#
  # Tur-BotSearch by Turranius. Edited by F|owman to fit Sitebot              #
+ # Edited again by psxc to fit the sitebot installer, and for it to work on  #
+ # bsd systems.                                                              #
  # Combine this with Tur-DirLogClean to keep the dirlog nicely updated!!     #
  #---------------------------------------------------------------------------#
***************
*** 24,28 ****
  #             Use a . to define * ( /CD.)                                   #
  #                                                                           #
! # showsize=   If this is TRUE, it will run 'du -ms' on the dir it finds and #
  #             reports its size in MB for every hit.                         #
  #                                                                           #
--- 26,30 ----
  #             Use a . to define * ( /CD.)                                   #
  #                                                                           #
! # showsize=   If this is TRUE, it will run 'du -hs' on the dir it finds and #
  #             reports its size in MB for every hit.                         #
  #                                                                           #
***************
*** 41,46 ****
  #                                                                           #
  #---------------------------------------------------------------------------#
! dirlog=/glftpd/ftp-data/logs/dirlog
! strings=/usr/bin/strings
  maxhits=10
  minlenght=4
--- 43,47 ----
  #                                                                           #
  #---------------------------------------------------------------------------#
! 
  maxhits=10
  minlenght=4
***************
*** 46,52 ****
  minlenght=4
  ignoredirs='/GROUPS/|/CD.|/Sample|\[incomplete\]'
- 
  showsize=TRUE
! sitedir=/glftpd/site
  
  #############################################################################
--- 47,60 ----
  minlenght=4
  ignoredirs='/GROUPS/|/CD.|/Sample|\[incomplete\]'
  showsize=TRUE
! 
! # The following is a modification done by psxc.
! # If the variables listed below is commented (default), they will be grabbed
! # from you glftpd.conf. Do not comment out glftpd_conf if you wish this to
! # work!
! glftpd_conf=/etc/glftpd.conf
! #strings=/usr/bin/strings
! #dirlog=/glftpd/ftp-data/logs/dirlog
! #sitedir=/glftpd/site
  
  #############################################################################
***************
*** 62,65 ****
--- 70,90 ----
  fi
  
+ # Mod by psxc - let's grab some variables
+ if [ ! -z "$glftpd_conf" ] && [ -e $glftpd_conf ]; then
+  glroot=`cat $glftpd_conf | grep -e "^rootpath" | head -n 1 | awk '{print $2}'`
+  datapath=`cat $glftpd_conf | grep -e "^datapath" | head -n 1 | awk '{print $2}'`
+  minhomedir=`cat $glftpd_conf | grep -e "^min_homedir" | head -n 1 | awk '{print $2}'`
+  if [ -z "$dirlog" ]; then
+   dirlog=$glroot$datapath/logs/dirlog
+  fi
+  if [ -z "$sitedir" ]; then
+   sitedir=$glroot$minhomedir
+  fi
+  if [ -z "$strings" ]; then
+   PATH=$PATH:/bin:/usr/bin:/usr/local/bin:$glroot/bin:/sbin:/usr/sbin:/usr/local/sbin
+   strings=`which strings`
+  fi
+ fi
+ 
  ## Check that first arg isnt *. Probably not needed but cant hurt.
  if [ "$1" = '*' ]; then
***************
*** 88,92 ****
  ## Complain if lenght is too short (size dosnt matter!).
  if [ "$minlenght" ]; then
!   if [ `echo $1 | wc -L | tr -d ' '` -lt "$minlenght" -a "$2" = "" ]; then
      echo "error^Search must be a minumum of $minlenght chars with only one argument."
      exit 0
--- 113,117 ----
  ## Complain if lenght is too short (size dosnt matter!).
  if [ "$minlenght" ]; then
!   if [ `echo $1 | wc -m | tr -d ' '` -lt "$minlenght" -a "$2" = "" ]; then
      echo "error^Search must be a minumum of $minlenght chars with only one argument."
      exit 0
***************
*** 166,170 ****
      else
        unset size
!       size=`du -ms $sitedir$rel | cut -f1`
        if [ -z "$size" ]; then
    
--- 191,195 ----
      else
        unset size
!       size=`du -hs $sitedir$rel | cut -f1`
        if [ -z "$size" ]; then
    
***************
*** 174,178 ****
  
        ## This is what it says when reporting size.
!       echo "body^$rel -> $size MB"
      fi
  
--- 199,203 ----
  
        ## This is what it says when reporting size.
!       echo "body^$rel -> ${size}B"
      fi
  
