#!/bin/bash
VER=1.0
#--[ Intro ]-------------------------------------------------#
#                                                            #
# Tur-SlotInfo. A script to display number of users, number  #
# of gadmins and number of slots (ratio and leech) for a     #
# specific group in irc.                                     #
# Works for both glftpd 1 and 2.                             #
#                                                            #
#--[ Installation ]------------------------------------------#
#                                                            #
# Copy tur-slotinfo.sh to /glftpd/bin and chmod to 755.      #
#                                                            #
# Copy tur-slotinfo.tcl to your bots scripts dir and load it #
# in the config file.                                        #
# Edit tur-slotinfo.tcl and read the information within.     #
# THIS IS IMPORTANT OR IT WONT RUN FROM IRC.                 #
# Rehash the bot.                                            #
#                                                            #
#--[ Settings ]----------------------------------------------#
#                                                            #
# usersdir    = Full path to the users dir.                  #
# gl_version  = Set which glftpd version you are running.    #
#               Set either 1 or 2 (no 1.32 etc).             #
# groupsdir   = If gl_version is 2, set the full path to the #
#               groupsdir here.                              #
#               If gl_version is 1, you can leave it or      #
#               remove it..                                  #
#                                                            #
#--[ Testing ]-----------------------------------------------#
#                                                            #
# Run it from shell as ./tur-slotinfo.sh groupname           #
# Try !slotinfo from irc. If it dosnt respond, you are in    #
# the wrong channel or you didnt read the info in the tcl.   #
#                                                            #
#--[ Settings ]----------------------------------------------#

usersdir=/glftpd/ftp-data/users
gl_version=1

groupsdir=/glftpd/ftp-data/groups


#--[ Script Start ]------------------------------------------#

if [ ! -d "$usersdir" ]; then
  echo "$usersdir does not exist."
  exit 0
fi

if [ -z "$1" ]; then
  echo "Specify a group too."
  exit 0
fi

if [ "$gl_version" = "1" ]; then
  groupstop="$"
else
  groupstop="\ [0-1]$"
fi

cd $usersdir

total=0
leech=0
free_slots=0
free_leech=0
gadmins=0

if [ -z "`grep "^GROUP $1$groupstop" *`" ]; then
  echo "Group $1 does not exist."
  exit 0
fi

for user in `grep "^GROUP $1$groupstop" * | cut -d ':' -f1`; do
  unset ISGADMIN; unset SLOTS; unset LEECH_SLOTS

  ## Plus 1 to total users found.
  total=$[$total+1]

  ## Check if this user is a group admin. Set ISGADMIN=TRUE if so.
  if [ "$gl_version" = "1" ]; then
    if [ "`grep "^GROUP\ "  $user | head -n1 | cut -d ' ' -f2`" = "$1" ] && [ "`grep "^FLAGS\ " $user | grep "2"`" ]; then
      ISGADMIN="TRUE"
      GADMINS="$GADMINS $user"
    fi
  else
    if [ "`grep "^GROUP $1 1" $user`" ] && [ "`grep "^FLAGS\ " $user | grep "2"`" ]; then
      ISGADMIN="TRUE"
      GADMINS="$GADMINS $user"
    fi
  fi

  if [ "$ISGADMIN" = "TRUE" ]; then

    if [ "$gl_version" = "1" ]; then
      gadmins=$[$gadmins+1]
      ## Get slots from this gadmin.
      SLOTS="`grep "^SLOTS\ " $user | cut -d ' ' -f2`"
      LEECH_SLOTS="`grep "^SLOTS\ " $user | cut -d ' ' -f3`"

      ## If slots is -1, its unlimited slots...
      if [ "$SLOTS" = "-1" ]; then
        echo "Warning: $user is gadmin of $1 and has -1 slots (unlimited)."
        free_slots="99999"
      else
        free_slots=$[$free_slots+$SLOTS]
      fi
      ## If leech slots is -1, its unlimited slots...
      if [ "$LEECH_SLOTS" = "-1" ]; then
        echo "Warning: $user is gadmin of $1 and has -1 leech slots (unlimited)."
        leech_slots="99999"
      else
        leech_slots=$[$leech_slots+$LEECH_SLOTS]
      fi

    else

      ## Verify that we can find the group file for the group.
      if [ ! -e "$groupsdir/$1" ]; then
        echo "Error. Glftpd set to version 2, but no group file for $1 in $groupsdir"
        exit 0
      fi
      gadmins=$[$gadmins+1]

      if [ -z "$CHECK_SLOTS_ALREADY" ]; then
        ## Get slots from this group, only once (see above).
        SLOTS="`grep "^SLOTS\ " $groupsdir/$1 | cut -d ' ' -f2`"
        LEECH_SLOTS="`grep "^SLOTS\ " $groupsdir/$1 | cut -d ' ' -f3`"

        ## If slots is -1, its unlimited slots...
        if [ "$SLOTS" = "-1" ]; then
          echo "Warning: group $1 has -1 slots (unlimited)."
          free_slots="99999"
        else
          free_slots=$[$free_slots+$SLOTS]
        fi
        ## if leech slots is -1, its unlimited slots.
        if [ "$LEECH_SLOTS" = "-1" ]; then
          echo "Warning: $1 has -1 leech slots (unlimited)."
          leech_slots="99999"
        else
          leech_slots=$[$leech_slots+$LEECH_SLOTS]
        fi
        ## Set this so we dont check it again if theres more gadmins.
        CHECK_SLOTS_ALREADY="TRUE"
      fi

    fi    
  fi

  ## Plus 1 to leech if user has leech in default section.
  if [ "`grep "^RATIO 0" $user`" ]; then
    leech=$[$leech+1]
  fi

  # echo "$user gadmin:$ISGADMIN - Slots:$SLOTS - Leech:$LEECH_SLOTS"

done

## If no gadmins were found, just output total number of users in the group.
if [ "$gadmins" = "0" ]; then
  echo "Total users for group $1: $total - No gadmins found."
  exit 0
fi

## Clean up gadmins.
GADMINS="`echo $GADMINS`"

## Add together used and free slots.
totalslots=$[$total+$free_slots]
totalleech=$[$leech+$leech_slots]

echo "Total users for group $1: $total - # of gadmins: $gadmins ($GADMINS)"
echo "Total slots: $totalslots ($total used, $free_slots free)."
echo "Leech slots: $totalleech ($leech used, $leech_slots free)."
