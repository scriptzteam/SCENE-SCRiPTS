#!/bin/sh

#xL-ipchanger v1.3

#(C) 2003 xoLax 

#put this file in /glftpd/bin/ and chmod a+x

log="/glftpd/ftp-data/logs/xl-ipchanger.log"
#You need to create this file and chmod it 777 or something :)

user="/glftpd/ftp-data/users/$2"
#The path were you have the user files

tmp="/glftpd/ftp-data/logs/xl-ipchanger.tmp"
#This file will be created and deleted everytime the script runs
#Make sure the bot has correct permissions in this dir

#Force user to add ident? (YES/NO)
forceident="YES"

#Allowed numbers of IP's before user has to start deleting?
maxip="3"

#Minimum specified numbers (1-4)
#i.e minnum="3" will only allow IP's where the first three parts are specified
minnum="2"

###END OF CONFIG###

export group=`grep -w -m 1 GROUP $user | cut -d ' ' -f2`

#List IP's belonging to user
if [ "$1" = "LISTIP" ]; then
echo "IP's belonging to "$2"/"$group""
echo "`grep IP $user | sed s/"IP "//`"
exit
fi

#Output the 10 last ipadds
if [ "$1" = "IPADDS" ]; then
tail -n 10 $log
exit
fi

export numip=`grep IP $user | grep -n IP | grep "$maxip":`

username=$2
ip=$3
nick=$4
host=$5

export foundip=`grep IP $user | grep -w -m 1 $3 | cut -d ' ' -f2`

#Add ip and log the action
if [ "$1" = "ADDIP" ]; then
  touch $tmp
  echo "$3" | sed s/@/" @ "/ | sed sZ\\.Z\ Zg >> $tmp
  export v1=`grep "" $tmp | cut -d ' ' -f1`
  export v2=`grep "" $tmp | cut -d ' ' -f2`
  export v3=`grep "" $tmp | cut -d ' ' -f3`
  export v4=`grep "" $tmp | cut -d ' ' -f4`
  export v5=`grep "" $tmp | cut -d ' ' -f5`
  export v6=`grep "" $tmp | cut -d ' ' -f6`
  rm $tmp
  
  if [ "$minnum" == "1" ]; then
    if [ "$v3"  == "*" ];then
      echo "You must specify at least the first number of the IP"
      exit
    fi
  fi
  if [ "$minnum" == "2" ]; then
    if [ "$v3"  == "*" -o "$v4" == "*" ];then
      echo "You must specify at least the two first numbers of the IP"
      exit
    fi
  fi
  if [ "$minnum" == "3" ]; then
    if [ "$v3"  == "*" -o "$v4" == "*" -o "$v5" == "*" ];then
      echo "You must specify at least the three first numbers of the IP"
    exit
    fi
  fi
  if [ "$minnum" == "4" ]; then
    if [ "$v3"  == "*" -o "$v4" == "*" -o "$v5" == "*" -o "$v6" == "*" ];then
      echo "You must specify all numbers of the IP"
    exit
    fi
  fi
  if [ "$v1" == "" -o "$v2" != "@" -o "$v3" == "" -o "$v4" == "" -o "$v5" == "" -o "$v6" == "" ]; then
    echo "$3 is not a valid IP"
    exit
  fi
  export ident=`echo $3 | sed s/@/"@ "/ | cut -d ' ' -f1`
  if [ "$ident" = "*@" -a "$forceident" = "YES" ]; then
    echo "IP must contain an ident!"
    exit
  fi
  if [ "$numip" != "" ]; then
    echo "Maximum number of IP's is $maxip. Use !delip to delete and !listip to list your IP's"
    exit
  fi
  if [ "$foundip" == "$3" ]; then
     echo "ERROR - "$3" is already added to "$2"/"$group""
     exit
  fi
 
  echo ADDIP: `/bin/date '+%a %b %d %X %Y'` -"$4""($5)" added "$3" to user "$2" >> "$log"
  echo IP "$3" >> "$user"
  echo ""$3" added to "$2"/"$group"" 
fi

#Delete ip and log the action
  if [ "$1" = "DELIP" ]; then
    if [ "$foundip" == "" ]; then
      echo "ERROR - Can't delete "$3" from "$2"/"$group" - IP not found"
      exit
    fi
    echo DELIP: `/bin/date '+%a %b %d %X %Y'` -"$4""($5)" deleted "$3" from user "$2" >> "$log"
    grep -v $3 $user > $user.tmp
    mv $user.tmp $user
    echo "Deleted "$3" from "$2"/"$group""
  fi
