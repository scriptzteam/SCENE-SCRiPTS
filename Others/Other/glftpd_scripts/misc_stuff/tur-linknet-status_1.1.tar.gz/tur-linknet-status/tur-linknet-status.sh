#!/bin/bash
VER=1.1
#-----------------------------------------------#
#                                               #
# Tur-Linknet-Status. A small script to show    #
# linkstatus of all linknet servers. Can also   #
# display all servers using argument 'all'      #
#                                               #
#--[ Install ]----------------------------------#
#                                               #
# Copy the .sh to anywhere you like. Make it    #
# executable (chmod 755).                       #
# Copy the .tcl to your bots scripts dir, edit  #
# it and change location of .sh and if you want #
# change the trigger too.                       #
#                                               #
# Only one setting. LINK. Its just where to get #
# the server list for linknet.                  #
#                                               #
# Run the script from shell to make sure it     #
# works. Rehash the bot and try it from irc.    #
#                                               #
#--[ Requirements ]-----------------------------#
#                                               #
# wget, basename, mv, grep, cut, tail           #
#                                               #
#--[ Changelog ]--------------------------------#
#                                               #
# 1.1 : Fixed by bah_ so it works with new      #
#       linknet webpage.                        #
#                                               #
#--[ Contact ]----------------------------------#
#                                               #
# Contact Turranius on efnet/linknet. Usually   #
# in #glftpd on efnet.                          #
# http://www.grandis.nu/glftpd                  #
# This script is NOT supported.                 #
#                                               #
#--[ Settings ]---------------------------------#

LINK="http://www.link-net.org/index.php?sec=4"

#--[ Scripts Start ]----------------------------#

## Get the source webpage.
wget -T 5 -q --cookies=off $LINK

## Check that it got it ok. Rename it to linklist.
newname="$( basename $LINK )"
if [ ! -e "$newname" ]; then
  echo "Error. Couldnt get webpage."
  exit 0
else
  mv "$newname" "linklist"
fi

# Replace <tr><td> with newlins, not a pretty way to do this, but I lack the skills :)
awk '{ gsub(/<tr><td>/, "\n"); print }' linklist > linklist2
awk '{ gsub(/ /, ""); print }' linklist2 > linklist1
awk '{ gsub(/\"/, ""); print }' linklist1 > linklist2
## Grab the info we want and announce it.
for each in `grep -E "(Linked|Split)" linklist2`; do
	if [ -n "$( echo "$each" | grep "Split" )" ]; then
		export servername=`echo $each | awk '{ split($1, val, "</td><td>"); print val[1] }'`
		echo "$servername is split"
		found=yes

	else
          if [ "$1" = "all" ]; then
		if [ -n "$( echo "$each" | grep "Linked" )" ]; then
		        export servername=`echo $each | awk '{ split($1, val, "</td><td>"); print val[1] }'`
		        echo "$servername is Linked"
						
		fi
          fi
	fi
done


## If no split servers was found.
if [ -z "$found" ]; then
  echo "All servers seems linked."
fi

## Remove the temp linklist and exit.
rm -f "linklist"
rm -f "linklist1"
rm -f "linklist2"
exit 0
