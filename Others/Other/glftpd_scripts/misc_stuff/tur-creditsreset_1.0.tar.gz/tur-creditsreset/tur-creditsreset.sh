#!/bin/bash
VER=1.0
#--[ Intro ]------------------------------------------------------#
#                                                                 #
# Tur-CreditsReset. A script to reset credits for specific        #
# groups and/or flags down to a specific value if they are above  #
# it. Designed by request of BoGuS.                               #
#                                                                 #
#--[ Installation ]-----------------------------------------------#
#                                                                 #
# Copy tur-creditsreset.sh to /glftpd/bin. chmod it so its        #
#  executable (chmod 700 tur-creditsreset.sh = root only ).       #
#                                                                 #
# Configure the settings below:                                   #
#                                                                 #
# USERSDIR     = The location of your users.                      #
#                                                                 #
# LOG          = If you want to log whenever it resets the creds  #
#                on someone, define where here. Otherwise, leave  #
#                this one empty or put a # infront of it.         #
#                                                                 #
# TMP          = Just a temporary dir this script uses to store   #
#                umm.. temporary stuff in.                        #
#                                                                 #
# GROUPSR      = Groups to reset. Sepearate by a space. Case      #
#                sensitive. You can add as many groups as you     #
#                want here.                                       #
#                Set to "" to disable doing this for groups (or   #
#                put a # infront of it).                          #
#                                                                 #
# FLAGSR       = Flags to reset. If a user has any of these flags #
#                , seperated by a space, he/she will be reset.    #
#                Set to "" to disable doing this for flags (or    #
#                put a # infront of it).                          #
#                                                                 #
#                Both GROUPSR and FLAGSR can not be disabled at   #
#                the same time. If you want to run this on ALL    #
#                users, set FLAGSR to "3" or something that all   #
#                users have.                                      #
#                                                                 #
# EXCLUDEDUSERS= Users that should not be reset, even if they are #
#                in one of the groups or has one of the flags.    #
#                Add as many as you like, space seperated.        #
#                Set to "" to disable, bla bla                    #
#                                                                 #
# SETTO        = Here you set the limit, in MB. If they are over  #
#                this value when this script runs, they will be   #
#                reset to this value.                             #
#                                                                 #
# TEST         = TRUE/FALSE. When this is TRUE its the same as    #
#                running the script with argument 'test'. Just    #
#                a safety while you test it incase you forgot to  #
#                specify 'test' when running it.                  #
#                                                                 #
#--[ Testing ]----------------------------------------------------#
#                                                                 #
# There is only one argument. test                                #
# Running 'tur-creditsreset.sh test' will NOT reset credits on    #
# anyone. It will only show you what it would have done. It will  #
# also show what it will do an egrep on and what it will exclude. #
#                                                                 #
#--[ Crontabbing ]------------------------------------------------#
#                                                                 #
# This script will run whenever you crontab it or if you prefer   #
# to just run it manually. If you dont know how to crontab then   #
# here is a good guide:                                           #
# http://www.unixgeeks.org/security/newbie/unix/cron-1.html       #
#                                                                 #
#--[ Contact ]----------------------------------------------------#
#                                                                 #
# Turranius on Efnet/Linknet. I usually hang on in #glftpd(efnet) #
# http://www.grandis.nu/glftpd <-> http://grandis.mine.nu/glftpd  #
#                                                                 #
#--[ Settings ]---------------------------------------------------#

USERSDIR=/glftpd/ftp-data/users
LOG=/glftpd/ftp-data/logs/tur-creditsreset.log
TMP=/tmp
GROUPSR="SiTEOPS iND"
FLAGSR="7 8"
EXCLUDEUSERS="turranius ostnisse"
SETTO="10000"
TEST="TRUE"


#--[ Script Start ]-----------------------------------------------#

## Debug mode?
if [ "$1" = "test" -o "$TEST" = "TRUE" ]; then
  DEBUG="TRUE"
  echo "$0 starting in test mode."
fi

## Build the list of users affected.
unset LIST; unset EXCLUDE

if [ "$GROUPSR" ]; then
  for groupname in $GROUPSR; do
    if [ -z "$LIST" ]; then
      LIST="^GROUP $groupname$"
    else
      LIST="$LIST|^GROUP $groupname$"
    fi
  done
fi
if [ "$FLAGSR" ]; then
  for flagtype in $FLAGSR; do
    if [ -z "$LIST" ]; then
      LIST="^FLAGS [0-9]*$flagtype"
    else
      LIST="$LIST|^FLAGS [0-9]*$flagtype"
    fi
  done
fi

## Did we get anything to egrep on?
if [ -z "$LIST" ]; then
  echo "Did not find any users fitting any of the defined criteria."
  exit 1
fi

## Build the exclude list.
if [ "$EXCLUDEUSERS" ]; then
  for euser in $EXCLUDEUSERS; do
    if [ -z "$EXCLUDE" ]; then
      EXCLUDE="^$euser$"
    else
      EXCLUDE="$EXCLUDE|^$euser$"
    fi
  done
else
  EXCLUDE="CrapValueSoWeGetNoHitsAtAll"
fi   

## Procedure for outputting debug text.
proc_debug() {
 if [ "$DEBUG" = "TRUE" ]; then
   echo "$@"
 fi
}

## Procedure for logging.
proc_log() {
 if [ "$LOG" ]; then
   echo `date +'%a %b %e %T %Y'` ": $@" >> $LOG
 fi
}

if [ "$LOG" ]; then
  if [ ! -e "$LOG" ]; then
    proc_debug "$LOG was not found. Creating it."
    touch $LOG
  fi
fi

## Echo info if were in debug mode.
proc_debug "List to check: $LIST"
proc_debug "Excludes are : $EXCLUDE"

## Check if the usersdir amd tmp dir exists and are indeed dirs.
if [ ! -d "$USERSDIR" ]; then
  echo "Error. $USERSDIR does not exist or isnt a directory."
  exit 1
fi
if [ ! -d "$TMP" ]; then
  echo "Error. TMP dir, defined as $TMP, does not exist or is not a directory."
  exit 1
fi

## Multiply the SETTO value by 1024 to get the KB value.
newcreds=$[$SETTO*1024]

## Echo crap again.
proc_debug "New credit set to $newcreds KB ( from setting of $SETTO MB )"
proc_debug ""

## Enter the USERSDIR and start the checking.
cd $USERSDIR
for CURUSER in `egrep "$LIST" * | cut -d ':' -f1 | sort -u | egrep -v "$EXCLUDE"`; do
  proc_debug "Checking user $CURUSER"
  curcreds=`grep "^CREDITS\ " $CURUSER | cut -d ' ' -f2`
  curcredsmb=$[$curcreds/1024]
  proc_debug "Current credits are: $curcreds ($curcredsmb MB)."
  if [ "$curcreds" -gt "$newcreds" ]; then
    proc_debug "$CURUSER is over the limit. Resetting"

    if [ "$DEBUG" != "TRUE" ]; then
      ## Resetting value in userfile and log it.
      proc_log "$CURUSER reset from $curcreds KB ($curcredsmb MB) to $newcreds ($SETTO MB)."  
      sed -e "s/^CREDITS [0-9]* /CREDITS $newcreds /" $CURUSER > $TMP/$CURUSER.TMP
      cp -f $TMP/$CURUSER.TMP $USERSDIR/$CURUSER
      rm -f $TMP/$CURUSER.TMP 
    fi

  else
    proc_debug "$CURUSER is under or at the limit. Not doing anything."
  fi
  proc_debug ""
done

proc_debug "All done. Exiting."
exit 0