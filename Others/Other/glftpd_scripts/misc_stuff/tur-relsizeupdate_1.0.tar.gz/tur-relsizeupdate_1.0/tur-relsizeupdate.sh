#!/bin/bash
VER=1.0

#-----------------------------------------------------#
#                                                     #
# Tur-RelSizeUpdate. Small script to store release    #
# sizes into a mysql database.                        #
#                                                     #
#--[ Setup ]------------------------------------------#
#                                                     #
# Copy tur-relsizeupdate.sh to /glftpd/bin. Chmod 700 #
#                                                     # 
# Run the mysql_stuff/setup_database.sh script to set #
# up .. um, the database.                             #
#                                                     #
# Set all the options below.                          #
#                                                     #
# Run it. This script takes no arguments. "debug" is  #
# always on.                                          #
#                                                     #
# Crontab as often as you like. It goes pretty fast   #
# to index stuff so do it quite often.                #
# Something like:                                     
# */120 * * * * /glftpd/bin/tur-relsizeupdate.sh >/dev/null
# To run it every 2 hours.
#                                                     #
#--[ Settings ]---------------------------------------#

## Self explaining.
SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"
SQLDB="relsize"
SQLTB="relsize"

## Full path to the sections to index.

## If you want to use todaydirs, just make a new option.
## Something like:  todaydir="`date +%m%d`"
## Then you can use /glftpd/site/0DAYS/$todaydir

SECTIONS="
/glftpd/site/DVDR
/glftpd/site/XBOX
/glftpd/site/ISO-UTILS
"

## How to run du. Should give megabyte output.
DU_COMMAND="du -s -m"

## Egrep for dirs to skip.
EXCLUDE="^GROUPS$|incomplete|^\_NUKED|\[NUKED\]"


#--[ Script Start ]----------------------------------#

SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"

if [ -z "$EXCLUDE" ]; then 
  EXCLUDE="fkjekJLKWJDLW"
fi

proc_testcon() {
  sqldata="`$SQL "show table status" | tr -s '\t' '^' | cut -d '^' -f1`"
  if [ -z "$sqldata" ]; then
    unset ERRORLEVEL
    echo "Mysql error. Check server!"
    exit 0
  fi
}

proc_testcon

for SECTION in $SECTIONS; do
  if [ -e "$SECTION" ]; then
    ##  Commit release sizes
    for release in `ls -1 $SECTION | egrep -iv "$EXCLUDE" | grep -v 'lost+found'`; do
      unset size; unset existtest; unset sizesb; unset namedb
      size="$( $DU_COMMAND "$SECTION/$release" | awk '{print $1}' )"
      existtest="$( $SQL "select size, name from relsize where name ='$release' limit 1" | awk '{print $1"^"$2}' )"
      if [ -z "$existtest" ]; then
        echo "Inserting $size $release"
        $SQL "insert into relsize (size, name) VALUES ('$size', '$release')"
        update="no"
      else
        sizedb="$( echo $existtest | awk -F"^" '{print $1}' )"
        namedb="$( echo $existtest | awk -F"^" '{print $2}' )"
        update="yes"
      fi
      if [ "$size" != "" -a "$sizedb" != "" -a "$update" = "yes" ]; then
        if [ "$sizedb" != "$size" ]; then
          echo "- Dont match. DB: $sizedb $namedb -- DU: $size $release"
          $SQL "update relsize set size = '$size' where name = '$release'"
        fi
      fi
    done
  fi
done

exit 0
