#!/bin/bash
VER=1.4
#---------------------------------------------------------------------------#
# Tur-BotSearch by Turranius.                                               #
# Two small scripts that allow users to do like 'site search' from irc.     #
# Combine this with Tur-DirLogClean to keep the dirlog nicely updated!!     #
#---------------------------------------------------------------------------#
# Installation:                                                             #
# Put tur-botsearch in /glftpd/bin                                          #
# Put tur-botsearch.tcl in your bots scripts folder and load it in the bots #
# config file. Rehash the bot and make sure it says that its loading it.    #
# Make tur-botsearch.sh executable with chmod 755 tur-botsearch.sh          #
# Change the settings below:                                                #
#                                                                           #
# dirlog=     The full path to your dirlog file.                            #
# strings=    The full path to the strings binary ( which strings ).        #
# maxhits=    Maximum number of hits to return.                             #
# minlenght=  Minimum lenght to search for when only search with one        #
#             argument. Set to "" to disable.                               #
#                                                                           #
# ignoredirs= Ignore these words in search. Good to add the name of the pre #
#             dirs here. Use /PRE to prevent anything starting with PRE to  #
#             be displayed. Use /PRE/ to match the exact foldername.        #
#             Predirs should not be in the dirlog anyway, but better safe.. #
#             Seperate ignores with a |  ( '/GROUPS/|Animalporn|ost' )      #
#             Any weird chars should be marked with \ ( \[inco.. )          #
#             Use a . to define * ( /CD.)                                   #
#                                                                           #
# showsize=   If this is TRUE, it will run 'du -ms' on the dir it finds and #
#             reports its size in MB for every hit.                         #
#                                                                           #
# sitedir=    If the above is TRUE, what is your sitedir? /glftpd/site as   #
#             default. When doing a search, check the path. This is what    #
#             needs to be before the path for 'du' to find it.              #
#                                                                           #
# Run tur-botsearch.sh from shell and make sure it works.                   #
# When you test it from the bot you might get an error like "permission     #
# denied /root/.bashrc".                                                    #
# Check the (general) FAQ on the website on how to fix that.                #
#                                                                           #
# Note; when searching, it checks the full path from inside /site. So you   #
# can use the section as one of the search arguments. Max args are 5.       #
# Running it without arguments gives you a short help.                      #
#                                                                           #
#---------------------------------------------------------------------------#
# Note to people wondering what the frell I am doing in the for each line.. #
# There is some crap in the dirlog. If you do 'strings dirlog' you will see #
# it. What I do is look for the word 'site' and start there. Then end the   #
# line before the filename. Crude, but it works.                            #
#---------------------------------------------------------------------------#
# Contact: Turranius on efnet/linknet. Usually in #glftpd.                  #
# http://www.grandis.nu/glftpd/                                             #
#---------------------------------------------------------------------------#
# Changelog:                                                                #
# 1.4   : Will work with releases and sections with spaces in them now.     #
#         Will use ~ as a tempchar for space, so if you have dirs with ~ in #
#         them, they will be a space in search. Just search for '~' and     #
#         change that to some other char you dont use if you dont like it.  #
#         Thanks liquid- for testing it for me.                             #
#                                                                           #
# 1.3   : When using 3 arguments, it first searched on 2, then again with   #
#         3, making it take double the time to finish.                      #
#                                                                           #
#         Added options showsize and sitedir. Check explanation above.      #
#         This will return MB value of release. If it is not found, it will #
#         say '-> Deleted?'. If it was found, but couldnt check size of it, #
#         size will be set to '?'.                                          #
#         There are some explanation texts down in the script if you want   #
#         to change the text.                                               #
#                                                                           #
#         Expanded it to allow 5 search words instead of just 3. REPLACE    #
#         the TCL if you want to use this.                                  #
#                                                                           #
#         In 'ignoredirs' you can use '.' as '*'                            #
#         So... replaced all CD1 etc with CD.                               #
#                                                                           #
#         A oneliner telling the user what he searched on is echoed as a    #
#         header for each search.                                           #
#                                                                           #
#         Added check that first arg is not a *. Could hang the bot.        #
#                                                                           #
# 1.2   : Search may now start with -                                       #
# 1.1   : Ignoredirs are no longer case sensitive. Also added a few extra   #
#         to the default so you wont get those pesky CD1 CD2 etc etc.       #
#         Remember to escape any non "normal" chars (whatever their names   #
#         are). IE [incomplete] = \[incomplete\]                            #
#    Upg: change all lines with contains:                                   #
#         egrep -v $ignoredirs to egrep -vi $ignoredirs                     #
#         Paste the new ignoredirs into your old script.                    #
#         Update the version at the top to 1.1 =))                          #
#                                                                           #
# 1.0   : First public version.                                             #
#---------------------------------------------------------------------------#

dirlog=/glftpd/ftp-data/logs/dirlog
strings=/usr/bin/strings
maxhits=15
minlenght=4
ignoredirs='/GROUPS/|/CD.|/Sample|\[incomplete\]'

showsize=TRUE
sitedir=/glftpd/site

#############################################################################
# Change everything below here. Naaah kidding. Dont change a thing.         #
#############################################################################

## Show help if no arguments.
if [ -z "$1" ]; then
  echo "Tur-BotSearch $VER by Turranius. Used for searching on site."
  echo "Enter up to 5 arguments to search for."
  echo "One of them can be used for sectionname. Only $maxhits hits will be shown."
  exit 0
fi

## Check that first arg isnt *. Probably not needed but cant hurt.
if [ "$1" = '*' ]; then
  echo "No go on that on bud."
  exit 0
fi

## Check if we can read dirlog. Rather.. if we cant.
if [ ! -r $dirlog ]; then
  echo "Cant read from dirlog. Ask siteops to fix path and/or perms."
  exit 0
fi

## Check if strings exists
if [ ! -x $strings ]; then
  echo "Strings is not executable or does not exist."
  exit 0
fi

## If first argument is the same as the other..
if [ "$1" = "$2" ]; then
  echo "Please dont use the same arguments twice."
  exit 0
fi

## Complain if lenght is too short (size dosnt matter!).
if [ "$minlenght" ]; then
  if [ `echo $1 | wc -L | tr -d ' '` -lt "$minlenght" -a "$2" = "" ]; then
    echo "Search must be a minumum of $minlenght chars with only one argument."
    exit 0
  fi
fi

## Make a lame fix incase ignoredirs are empty.
if [ "$ignoredirs" = "" ]; then
  ignoredirs="kJEFKLejJd3jd"
fi

## Build oneliner
if [ "$5" ]; then
  text5=" and *$5*"
fi
if [ "$4" ]; then
  text4=" and *$4*"
fi
if [ "$3" ]; then
  text3=" and *$3*"
fi
if [ "$2" ]; then
  text2=" and *$2*"
fi
if [ "$1" ]; then
  text1="containing *$1*"
fi

## Do the search depending on amount of args used.
if [ "$5" ]; then
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | grep -F -i "$3" | grep -F -i -- "$4" | grep -F -i -- "$5" | egrep -vi $ignoredirs| tr ' ' '~' | tail -n $maxhits )"

elif [ "$4" ]; then
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | grep -F -i "$3" | grep -F -i -- "$4" | egrep -vi $ignoredirs| tr ' ' '~' | tail -n $maxhits )"

elif [ "$3" ]; then
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | grep -F -i "$3" | egrep -vi $ignoredirs| tr ' ' '~' | tail -n $maxhits )"

elif [ "$2" ]; then
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | egrep -vi $ignoredirs | tr ' ' '~' | tail -n $maxhits )"

else
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | egrep -vi $ignoredirs | tr ' ' '~' | tail -n $maxhits )"
fi

## Echo header.
echo "Starting search for releases $text1$text2$text3$text4$text5."

## Fix each entry as they contain C.R.A.P otherwise.
num="0"
for each in $LIST; do
  gotone="yes"
  num=$[$num+1]
  end="$( basename $each )"
  for part in `echo $each | tr -s '/' ' '`; do
    if [ "$go" = "yepp" ]; then
      if [ -z "$rel" ]; then
        rel="/$part"
      else
        rel="$rel/$part"
      fi
    fi
    if [ "$part" = "site" ]; then
      go="yepp"
      unset rel
    fi
    if [ "$end" = "$each" ]; then
      unset go
    fi
  done
  if [ "$showsize" = "TRUE" ]; then
    checkdir="`echo "$sitedir$rel" | tr '~' ' '`"
    if [ ! -e "$checkdir" ]; then

      ## If the dir was not found at all, say this.
      echo "$rel -> Deleted?" | tr '~' ' '

    else
      unset size
      size=`du -ms "$checkdir" | cut -f1`
      if [ -z "$size" ]; then
  
        ## IF size was not found for some reason, size will be set to this.
        size="?"
      fi

      ## This is what it says when reporting size.
      echo "$rel -> $size MB" | tr '~' ' '
    fi

  else

    ## showsize is not TRUE. Just echo release path.
    echo "$rel" | tr '~' ' '

  fi

  ## If the user reached maximum allowed hits.
  if [ "$num" = "$maxhits" ]; then
    echo "$maxhits Maximum hits returned. Be more specific."
    exit 0
  fi
done

## No hits? Say this.
if [ "$gotone" != "yes" ];then
  echo "0 Results Returned"
else

  ## If only one hit was found.
  if [ "$num" = "1" ]; then
    echo "$num hit found."

  ## If more then one hit was found.
  else
    echo "$num hits found."
  fi
fi

exit 0
