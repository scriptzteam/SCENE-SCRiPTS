<?php
    //
    // vnStat PHP frontend 1.3 (c)2006-2007 Bjorge Dijkstra (bjd@jooz.net)
    //
    // This program is free software; you can redistribute it and/or modify
    // it under the terms of the GNU General Public License as published by
    // the Free Software Foundation; either version 2 of the License, or
    // (at your option) any later version.
    //
    // This program is distributed in the hope that it will be useful,
    // but WITHOUT ANY WARRANTY; without even the implied warranty of
    // MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    // GNU General Public License for more details.
    //
    // You should have received a copy of the GNU General Public License
    // along with this program; if not, write to the Free Software
    // Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    //
    //
    // see file COPYING or at http://www.gnu.org/licenses/gpl.html 
    // for more information.
    //
    require 'config.php';
    require 'vnstat.php';
            
    function init_image()
    {
        global $im, $xlm, $xrm, $ytm, $ybm, $iw, $ih,$graph, $cl;

        if ($graph == 'none')
            return;

        //
        // image object
        //    
        $xlm = 40;
        $xrm = 10;
        $ytm = 20;
        $ybm = 60;
        if ($graph == 'small')
        {
            $iw = 300 + $xrm + $xlm;
            $ih = 100 + $ytm + $ybm;    
        }
        else
        {
            $iw = 600 + $xrm + $xlm;
            $ih = 200 + $ytm + $ybm;
        }

        $im = imagecreate($iw,$ih);

        //
        // colors
        //
        $cl['white'] = imagecolorallocate($im, 255, 255, 255);
        $cl['black'] = imagecolorallocate($im, 0, 0, 0);
        $cl['grey']  = imagecolorallocate($im, 100, 100, 128);
        $cl['grid_stipple_1'] = imagecolorallocate($im, 140,140,140);
        $cl['grid_stipple_2'] = imagecolorallocate($im, 200,200,200);	
        $cl['background'] = imagecolorallocate($im, 250, 250, 250);
        $cl['rx'] = imagecolorallocate($im,  60, 130,  60);
        $cl['tx'] = imagecolorallocate($im,  130,  60,  60);

        imagefilledrectangle($im,0,0,$iw,$ih,$cl['background']);
    }

    function draw_border()
    {
        global $im,$cl,$iw,$ih;

        imageline($im,     0,    0,$iw-1,    0, $cl['black']);
        imageline($im,     0,$ih-1,$iw-1,$ih-1, $cl['black']);
        imageline($im,     0,    0,    0,$ih-1, $cl['black']);  
        imageline($im, $iw-1,    0,$iw-1,$ih-1, $cl['black']);
    }
    
    function draw_grid($x_ticks, $y_ticks)
    {
        global $im, $cl, $iw, $ih, $xlm, $xrm, $ytm, $ybm;

        $x_step = ($iw - $xlm - $xrm) / $x_ticks;
        $y_step = ($ih - $ytm - $ybm) / $y_ticks;

        $ls = array($cl['grid_stipple_1'],$cl['grid_stipple_2']);
        imagesetstyle($im, $ls);
        for ($i=$xlm;$i<=($iw-$xrm); $i += $x_step)
        {
            imageline($im, $i, $ytm, $i, $ih - $ybm, IMG_COLOR_STYLED);
        }
        for ($i=$ytm;$i<=($ih-$ybm); $i += $y_step)
        {
            imageline($im, $xlm, $i, $iw - $xrm, $i, IMG_COLOR_STYLED); 
        }
        imageline($im, $xlm, $ytm, $xlm, $ih - $ybm, $cl['black']);
        imageline($im, $xlm, $ih - $ybm, $iw - $xrm, $ih - $ybm, $cl['black']);
    }
    
    
    function draw_data($data)
    {
        global $im,$cl,$iw,$ih,$xlm,$xrm,$ytm,$ybm;

        sort($data);
        $x_ticks = count($data);
        $y_ticks = 10;
        $y_scale = 1;
        $prescale = 1;
        $unit = 'K';
        $offset = 0;
        $gr_h = $ih - $ytm - $ybm;
        $x_step = ($iw - $xlm - $xrm) / $x_ticks;
        $y_step = ($ih - $ytm - $ybm) / $y_ticks;
        $bar_w = ($x_step / 2) - 1;

        //
        // determine scale
        //
        $low = 99999999999;
        $high = 0;
        for ($i=0; $i<$x_ticks; $i++)
        {
            if ($data[$i]['rx'] < $low)
            $low = $data[$i]['rx'];
            if ($data[$i]['tx'] < $low)
            $low = $data[$i]['tx'];
            if ($data[$i]['rx'] > $high)
            $high = $data[$i]['rx'];
            if ($data[$i]['tx'] > $high)
            $high = $data[$i]['tx'];
        }

        while ($high > ($prescale * $y_scale * $y_ticks))
        {
            $y_scale = $y_scale * 2;
            if ($y_scale >= 1024)
            {
            $prescale = $prescale * 1024;
            $y_scale = $y_scale / 1024;
            if ($unit == 'K') 
                $unit = 'M';
            else if ($unit == 'M')
                $unit = 'G';
            else if ($unit == 'G')
                $unit = 'T';
            }
        }
    
        //
        // graph scale factor (per pixel)
        //
        $sf = ($prescale * $y_scale * $y_ticks) / $gr_h;

        if ($data[0] == 'nodata')
        {
            $font = 6;
            $text = 'no data available';
            $textwidth = imagefontwidth($font) * strlen($text);
            imagestring($im, $font, $xlm + (300 - ($textwidth/2)), $ytm + 80, $text, $cl['black']);
        }
        else
        {
            //
            // draw bars
            //      
            for ($i=0; $i<$x_ticks; $i++)
            {
            $x = $xlm + ($i * $x_step);
            $y = $ytm + ($ih - $ytm - $ybm) - (($data[$i]['rx'] - $offset) / $sf);
            imagefilledrectangle($im, $x, $y, $x + $bar_w, $ih - $ybm, $cl['rx']);
	    
	    $bovenkant = $y; //hij tekent een bar van boven naar beneden. De 'niuewe' bovenkant moet dus de positie van de vorige bovenkant zijn+de hoogte van de 2e balk
	    $onderkant = $ih - $ybm;

            $y = $ytm + ($ih - $ytm - $ybm) - (($data[$i]['tx'] - $offset) / $sf);
            imagefilledrectangle($im, $x+$bar_w+2, $y, $x+$x_step, $ih - $ybm, $cl['tx']);
	    
	    //imagefilledrectangle($im, $x+2, $nieuwebovenkant, $x + $bar_w, ($ih - $ybm) , $cl['tx']);
            }
    
            //
            // axis labels
            //
            $font = 2;  
            for ($i=0; $i<=$y_ticks; $i++)
            {
                $label = ($i * $y_scale).$unit;
                $textwidth = imagefontwidth($font) * strlen($label);
                imagestring($im, $font, $xlm - $textwidth - 3, ($ih - $ybm) - ($i * $y_step) - 8, $label, $cl['black']);
            }
$x_ticks--;
            for ($i=0; $i<=$x_ticks; $i++)
            {
               
		$label = $data[$i]['img_label'];
                $textwidth = imagefontwidth($font) * strlen($label);    
                imagestring($im, $font, $xlm + ($i * $x_step) + ($x_step / 2) - ($textwidth / 2), $ih - $ybm + 5, $label, $cl['black']);
            }
        }

        draw_border();
        draw_grid($x_ticks, $y_ticks);

        //
        // legend 
        //
        imagefilledrectangle($im, $xlm, $ih-$ybm+25, $xlm+8,$ih-$ybm+33,$cl['rx']);
        imagestring($im, 2, $xlm+14, $ih-$ybm+22,'bytes in',$cl['black']);
        imagefilledrectangle($im, $xlm, $ih-$ybm+39, $xlm+8,$ih-$ybm+47,$cl['tx']);
        imagestring($im, 2, $xlm+14, $ih-$ybm+36,'bytes out',$cl['black']);
	$updateText = "Laatste update: ".date("m.d.y") . " om ". date("H:i:s");
	imagestring($im, 2, $xlm+375, $ih-$ybm+39,$updateText,$cl['black']);
	
    }

    function output_image()
    {
        global $page,$hour,$day,$month,$im,$iface;

        if ($page == 'summary')
            return;

        init_image();

        if ($page == 'h')
        {
		draw_data($hour);
        }
        else if ($page == 'd')
        {
            draw_data($day);
        }
        else if ($page == 'm')
        {
            draw_data($month);
        }
	
        header('Content-type: image/png');	
        imagepng($im);
    }

    validate_input();
    get_vnstat_data();
    output_image();
?>        
