#!/bin/bash
###########################################################################
# IRCNEW 1.3 by ragusallad
#
# Nifty script that will output the newest
# dirs of stated sections into an irc-channel
#
# INC		tag of incomplete dirs, so we won't show them
# GROUPDIR	The dir of your PRE-groups, so we won't show the PREdir
# SECTIONS	Your sections, name:where it's located relative to siteroot
#
# Added a new function to show newest pres in a certain section
#
# LOGPRE	What is the special output in your log when a pre is made?
#
###########################################################################

INC="(incomplete)"
GROUPDIR="PRE"
SITEROOT="/glftpd/site/"
today="$( date +%m%d )"
SECTIONS="
apps:Apps/ISO
games:Games/ISO
divx:DivX
svcd:SVCD
vcd:VCD
dox:Games/DOX
0day:Apps/0day/$today
"
##For new pres:
LOG="/glftpd/ftp-data/logs/glftpd.log"
LOGPRE="PRE:"

if [ "$2" = "pre" ]; then
for each in $SECTIONS; do
    SECTION="$(echo $each | cut -d':' -f1)"
    DIR="$(echo $each | cut -d':' -f2)"
    if [ "$( echo $SECTION | grep -wi "$1")" ]; then
	NEWDIR="$(cat $LOG | grep $LOGPRE | grep "/$DIR" |tail -n5 | tac | awk -F" " '{print $7}' | awk -F"/" '{print $NF}' | awk -F"\"" '{print $1}')"
	for each in $NEWDIR; do
	    echo "5 Newest pres in $SECTION"
	    echo $each
	done
    fi
done

fi

if [ "$1" = "" ]; then
for SECTION in $SECTIONS; do
    SEC="$(echo $SECTION | cut -d':' -f1)"
    if [ "$SEC2" ]; then
	SEC2="$SEC2 $SEC"
    else
	SEC2="$SEC"
    fi
done
    echo "Usage: !xxxnew/!xxxpre, available sections = $SEC2"
fi

if [ "$2" = "" ]; then
for each in $SECTIONS; do
    SECTION="$(echo $each | cut -d':' -f1)"
    DIR="$(echo $each | cut -d':' -f2)"
    if [ "$( echo $SECTION | grep -wi "$1")" ]; then
	new="$( ls -t $SITEROOT$DIR | grep -v $INC | grep -v $GROUPDIR | head -n5 )"
        echo "5 Newest $SECTION"
        echo "$new"
        exit 0
    fi
done
fi