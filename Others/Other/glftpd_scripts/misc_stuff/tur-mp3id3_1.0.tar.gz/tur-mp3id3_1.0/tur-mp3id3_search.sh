#!/bin/bash
VER=1.0

#-----------------------------------------------------#
#                                                     #
# This is an addon to tur-mp3id3.sh and is not        #
# required if you plan on using your id3 database     #
# for other things. This script will make it possible #
# for users to search on releases by the id3 tag(s).  #
#                                                     #
#--[ Setup ]------------------------------------------#
#                                                     #
# Copy tur-mp3id3_search.sh to /glftpd/bin. Chmod it  #
# to 755.                                             #
#                                                     #
# If you want to allow your users to use this search  #
# from inside glftpd, you need to setup the mysql     #
# client to work inside glftpd. If you run into       #
# problems here, the best advice I can give you is to #
# download tur-trial 3.+ and look at the              #
# /mysql_stuff/README.mysql document for help.        #
#                                                     #
#--[ Settings ]---------------------------------------#
#                                                     #
# SQLBIN   = Path to the mysql client binary. If its  #
#            in your path, you may leave it as just   #
#            "mysql". This path is only used from     #
#            shell/irc. From inside glftpd, its       #
#            always set to "/bin/mysql"               #
#                                                     #
# SQLHOST  = IP/hostname of your mysql server. If you #
#            get problems with "localhost", try       #
#            "127.0.0.1" instead, and vice versa.     #
#                                                     #
# SQLUSER  = Username to be used with mysql. Must     #
#            have select rights in the mp3id3 db.     #
#                                                     #
# SQLPASS  = Password of above user.                  #
#                                                     #
# SQLDB    = Database to use.                         #
#                                                     #
# SQLTB    = Table to use.                            #
#                                                     #
# HITLIMIT_IRC = How many hits to allow from irc.     #
# HITLIMIT_GL  = How many hits to allow from glftpd.  #
#                                                     #
# STRIP_FIRST_CHARS_FROM_PATH=                        #
#                This is a number. In the database,   #
#                it stores the full path to the dirs. #
#                Since you might not want to show     #
#                /glftpd/site/blabl/bla and instead   #
#                just /blabl/bla, set this to 13 and  #
#                the first 13 chars are stripped from #
#                the fullpath.                        #
#                This only affects the $fullpath      #
#                cookie when used.                    #
#                                                     #
# SHOW_ONLY_ONSITE= TRUE/FALSE. If set to TRUE, only  #
#                   releases with onsite=1 in the     #
#                   database will be shown.           #
#                                                     #
# NO_SHOW_DIRS = This is a standard REGEXP for on the #
#                path. Here you can decide which dirs #
#                that should not be searchable. This  #
#                is good if mp3id3 indexes stuff in   #
#                your groups predirs. If they are     #
#                called GROUPS you can specify        #
#                Seperate excludes with |.            #
#                In general, you do not have to type  #
#                \/GROUPS\/ and /GROUPS/ should work  #
#                just fine. Dont use [] or \[\] here. #
#                You may use .+ to specify "anything" #
#                so for nuked dirs: NUKED.+- works.   #
#                                                     #
#                Note that the path stores the full   #
#                path including the releasename, so   #
#                if you set, for example ^\/glftpd    #
#                then no hits will be displayed.      #
#                                                     #
#                Hint: If you do not want to show     #
#                releases by some group, you can      #
#                specify the groupname(s) here like:  #
#                \-groupname1$|\-groupname2$          #
#                                                     #
# B= & U=        Dont touch these. They are used to   #
#                start and stop bold and underline.   #
#                They are not used from inside glftpd.#
#                                                     #
# NOTE: The proc_ settings should look as they do.    #
#       Do NOT change the proc_ name or the setup.    #
#       Only change the "echo" text.                  #
#                                                     #
# proc_announce_full = If you use the -full setting   #
#                      when searching, this is what   #
#                      will be presented. Cookies are:#
#                                                     #
#                      ${fullpath} ( full path to rel)#
#                      ${path} (only dirname)         #
#                      ${file} (filename)             #
#                      ${artist}                      #
#                      ${title}                       #
#                      ${album}                       #
#                      ${year}                        #
#                      ${genre}                       #
#                      ${B}  Start/stop BOLD output.  #
#                      ${U}  Start/stop Underlining.  #
#                                                     #
# proc_announce_single= What to display when -full is #
#                       NOT used. Same cookies as     #
#                       above.                        #
#                                                     #
# proc_showhits =      After a search where the user  #
#                      gets more hits then what is    #
#                      allowed to show, this is shown.#
#                      Cookies are:                   #
#                      ${HITS}      = Hits found.     #
#                      ${HITLIMIT}  = Max hits to     #
#                      show.                          #
#                      ${B}  Start/stop BOLD output.  #
#                      ${U}  Start/stop Underlining.  #
#                                                     #
# proc_shownohits =    What to show when no hits are  #
#                      found.                         #
#                                                     #
# DEBUG =              TRUE/FALSE. Show extended      #
#                      information when searching.    #
#                                                     #
#                      This only works if the you are #
#                      logged on as root so it SHOULD #
#                      not show in irc or glftpd by   #
#                      mistake.                       #
#                                                     #
#-----------------------------------------------------#

SQLBIN="mysql"
SQLHOST="192.168.101.33"
SQLUSER="root"
SQLPASS="apollo"
SQLDB="mp3id3"
SQLTB="mp3id3"

HITLIMIT_IRC="3"
HITLIMIT_GL="500"

STRIP_FIRST_CHARS_FROM_PATH="13"

SHOW_ONLY_ONSITE="TRUE"

NO_SHOW_DIRS="/GROUPS/|_PRE/|NUKED.+-"

B=""  ## Dont touch
U=""  ## Dont touch

proc_announce_full() {
  echo "Location: ${fullpath}"
  echo "Filename: ${file}"
  echo "[ Artist: ${B}${artist}${B} ][ Title: ${B}${title}${B} ][ Album: ${B}${album}${B} ][ Year: ${B}${year}${B} ][ Genre: ${B}${genre}${B} ]"
  echo "."
}

proc_announce_single() {
  echo "${path} [Artist:${B}${artist}${B}][Genre:${B}${genre}${B}][Year:${B}${year}${B}]"
}

proc_showhits() {
  echo "[ ${B}${HITS}${B} total hits found. Displaying ${HITLIMIT} ]"
}

proc_shownohits() {
  echo "[ No results found ]"
}

DEBUG="FALSE"


#--[ Script Start ]-----------------------------------#

proc_debug() {
  if [ "$DEBUG" = "TRUE" ] && [ "$USER" = "root" ]; then
    echo "DEBUG: $*"
  fi
}

if [ -z "$FLAGS" ]; then
  SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"
  RUN_MODE="irc"
  HITLIMIT="$HITLIMIT_IRC"
else
  SQL="/bin/mysql -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"
  RUN_MODE="gl"
  HITLIMIT="$HITLIMIT_GL"
  unset B
  unset U
fi
proc_debug "Mode:$RUN_MODE - HitLimit:$HITLIMIT - SQL:$SQL"

proc_testcon() {
  if [ -z "$( $SQL "select ID from $SQLTB limit 1" )" ]; then
    echo "No connection to database or nothing has yet to be indexed."
    exit 0 # Yes, 0. Otherwise it wont be announced in chan.
  fi
}

proc_testcon

proc_help() {
  if [ "$RUN_MODE" = "gl" ]; then
    echo "Usage: site mp3find <arguments>"
  else
    echo "Usage: !mp3find <arguments>"
  fi
  echo "Arguments can be one or more of the following:"
  echo "-artist:?? = Search on Artist name."
  echo "-title:??  = Search on song title."
  echo "-album:??  = Search on album name."
  echo "-year:???? = Search on year."
  echo "-genre:??  = Search on genre."
  echo "-rel:??    = Releasename (dirname)."
  echo "-file:??   = Filename."
  echo ""
  echo "You can combine the above. For example:"
  if [ "$RUN_MODE" = "gl" ]; then
    echo "site mp3find -artist:jennifer -genre:techno -year:2005"
  else
    echo "!mp3find -artist:jennifer -genre:techno -year:2005"
  fi
  echo "Use % instead of space in search, like -artist:jennifer%lopez"
  echo "Or -file:point%of%no%return"
  echo "If you are unsure of the order, -artist:jennifer -artist:lopez also works."
  echo ""
  echo "You may also use the following options:"
  echo "-full         = Show more info on each hit then otherwise shown."
  echo "-nd           = No dupes. Only show one hit per found directory."
  echo ""
  echo "Maximum hits: gLFTPd:$HITLIMIT_GL iRC:$HITLIMIT_IRC."
}

if [ -z "$1" ] || [ "$1" = "help" ] || [ "$1" = "-help" ]; then
  proc_help
  exit 0
fi

VARS="`echo " $@ "`"
proc_debug "Setting VARS:$VARS"

for rawdata in $VARS; do
  if [ "`echo "$rawdata" | grep -- "-[aA][rR][tT][iI][sS][tT]:"`" ]; then
    ARTIST="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$ARTIST" ]; then
      echo "Forgot to specify artist in -artist: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW artist^like^'%${ARTIST}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[tT][iI][tT][lL][eE]:"`" ]; then
    TITLE="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$TITLE" ]; then
      echo "Forgot to specify title in -title: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW title^like^'%${TITLE}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[aA][lL][bB][uU][mM]:"`" ]; then
    ALBUM="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$ALBUM" ]; then
      echo "Forgot to specify album in -album: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW album^like^'%${ALBUM}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[yY][eE][aA][rR]:"`" ]; then
    YEAR="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$YEAR" ]; then
      echo "Forgot to specify year in -year: ?"
      exit 0
    elif [ -z "`echo "$YEAR" | grep "^....$"`" ]; then
      echo "Year should be YYYY."
      exit 0
    elif [ "`echo "$YEAR" | tr -d '[:digit:]'`" ]; then
      echo "Year should be YYYY. Only numbers."
      exit 0
    else
      COMMANDRAW="$COMMANDRAW (year=$YEAR)"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[gG][eE][nN][rR][eE]:"`" ]; then
    GENRE="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$GENRE" ]; then
      echo "Forgot to specify genre in -genre: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW genre^like^'%${GENRE}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[rR][eE][lL]:"`" ]; then
    REL="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$REL" ]; then
      echo "Forgot to specify releasename in -rel: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW path^like^'%${REL}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[fF][iI][lL][eE]:"`" ]; then
    FILE="`echo "$rawdata" | cut -d ':' -f2`"
    if [ -z "$FILE" ]; then
      echo "Forgot to specify filename in -file: ?"
      exit 0
    else
      COMMANDRAW="$COMMANDRAW file^like^'%${FILE}%'"
    fi
  elif [ "`echo "$rawdata" | grep -- "-[fF][uU][lL][lL]"`" ]; then
    FULL_INFO="TRUE"
  elif [ "`echo "$rawdata" | grep -- "-[nN][dD]"`" ]; then
    NO_DUPES="TRUE"
  else
    echo "Skipping unknow command: $rawdata"
  fi
done

if [ -z "$COMMANDRAW" ]; then
  proc_help
  exit 0
fi

for each in $COMMANDRAW; do
  each="`echo "$each" | tr '^' ' '`"
  if [ -z "$SQLQUERY" ]; then
    SQLQUERY="where $each"
  else
    SQLQUERY="$SQLQUERY and $each"
  fi
done
proc_debug "1:SQLQUERY:$SQLQUERY"

if [ "$SHOW_ONLY_ONSITE" = "TRUE" ]; then
  SQLQUERY="$SQLQUERY and onsite = '1'"
fi

if [ "$NO_SHOW_DIRS" ]; then
  SQLQUERY="$SQLQUERY and path not REGEXP '$NO_SHOW_DIRS'"
fi 

proc_debug "2:SQLQUERY:$SQLQUERY"

SQLQUERY_OLD="$SQLQUERY"

if [ "$NO_DUPES" = "TRUE" ]; then
  SQLQUERY="$SQLQUERY group by path"
fi
proc_debug "3:SQLQUERY:$SQLQUERY"

if [ "$HITLIMIT" ]; then
  SQLQUERY="$SQLQUERY limit $HITLIMIT"
fi
proc_debug "4:SQLQUERY:$SQLQUERY"

proc_debug "Running: $SQL \"select path, file, artist, title, album, year, tracknr, genre, onsite from $SQLTB $SQLQUERY\""
proc_debug "----------------------------------------"

for rawdata in `$SQL "select path, file, artist, title, album, year, tracknr, genre, onsite from $SQLTB $SQLQUERY"  | tr '\t' "'" | tr ' ' '^'`; do
  fullpath="`echo "$rawdata" | cut -d "'" -f1 | tr '^' ' '`"
  file="`echo "$rawdata" | cut -d "'" -f2 | tr '^' ' '`"
  artist="`echo "$rawdata" | cut -d "'" -f3 | tr '^' ' '`"
  title="`echo "$rawdata" | cut -d "'" -f4 | tr '^' ' '`"
  album="`echo "$rawdata" | cut -d "'" -f5 | tr '^' ' '`"
  year="`echo "$rawdata" | cut -d "'" -f6 | tr '^' ' '`"
  tracknr="`echo "$rawdata" | cut -d "'" -f7 | tr '^' ' '`"
  genre="`echo "$rawdata" | cut -d "'" -f8 | tr '^' ' '`"
  onsite="`echo "$rawdata" | cut -d "'" -f9 | tr '^' ' '`"

  path="`basename $fullpath`"

  if [ "$STRIP_FIRST_CHARS_FROM_PATH" ]; then
    fullpath="`echo "$fullpath" | cut -c${STRIP_FIRST_CHARS_FROM_PATH}-`"
  fi

  if [ "$FULL_INFO" = "TRUE" ]; then
    proc_announce_full
  else
    proc_announce_single
  fi
done

HITS="`$SQL "select count(ID) from $SQLTB $SQLQUERY_OLD"`"
if [ -z "$HITS" ] || [ "$HITS" = "0" ]; then
  proc_shownohits
  exit 0
fi

if [ "$HITS" -gt "$HITLIMIT" ]; then
  proc_showhits
fi

