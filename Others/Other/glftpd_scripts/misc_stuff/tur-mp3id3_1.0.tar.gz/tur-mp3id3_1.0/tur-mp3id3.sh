#!/bin/bash
VER=1.0
#----------------------------------------------------------------#
#                                                                #
# Tur-Mp3ID3. A script, using findmp3, which will go through     #
# your site and add the ID3 info from .mp3 files into a mysql    #
# database. What you do with this info afterwards is up to you.  #
# Also included in this script is tur-mp3id3_search.sh which is  #
# a good start for a search script, using the database, but more #
# on that later. This script is only used for getting the info   #
# into the database.                                             #
#                                                                #
#--[ Installation ]----------------------------------------------#
#                                                                #
# Copy tur-mp3id3.sh to /glftpd/bin or where ever you like. This #
# script works fine without gltpd if you want to.                #
# Chmod it to 700. Only root needs to use it anyway.             #
#-                                                              -#
# Download findmp3 0.7+ from http://www.vanheusden.com/findmp3   #
# Compile it using 'make' and copy the findmp3 binary to         #
# /glftpd/bin (or where ever you like).                          #
#-                                                              -#
# In the mysql_stuff, you'll find two scripts. One to create the #
# database and one to wipe it out (should you want to start from #
# scratch for some reason).                                      #
# Start by running the setup_database.sh and follow the          #
# instructions.                                                  #
#-                                                              -#
# Once the database is set up, change the settings as follows:   #
#                                                                #
# SQLBIN  = Path to your mysql binary. If its in your path, you  #
#           may leave it as "mysql".                             #
#                                                                #
# SQLHOST = Host of the mysql server. If its local, try setting  #
#           localhost. If you run into problems, try 127.0.0.1   #
#                                                                #
# SQLUSER = Username that will connect to the mysql DB. Must     #
#           have full access to it.                              #
#                                                                #
# SQLPASS = Password of the above username (this is the reason   #
#           we chmod this script to 700. No other user should    #
#           see the password then).                              #
#                                                                #
# SQLDB   = Database to use. The default is fine unless you      #
#           specified something else when creating the database. #
#                                                                #
# SQLTB   = Table to use. As above, the default is usually fine. #
#                                                                #
# FINDMP3 = Full path to the findmp3 binary. Include the findmp3 #
#           "word" as well.                                      #
#                                                                #
# FINDMP3_VARS   = Variables to use for findmp3. Dont change     #
#                  unless you really have to.                    #
#                                                                #
# TODAY          = If you use dated dirs, you may configure date #
#                  here so it points to your todaydir. You may   #
#                  then use $TODAYDIR in MP3DIRS_SINGLE (below)  #
#                  to only check one dated dir (todays).         #
#                                                                #
# YESTERDAY      = Same as above, but yesterday. You can         #
#                  actually make your own here and specify them  #
#                  in the MP3DIRS_* below as well. These are     #
#                  just examples.                                #
#                  Note: For "-d -1 day", you need a GNU date    #
#                  binary. FBSD users does not have this by      #
#                  default. Either leave YESTERDAY="" or compile #
#                  the sh-utils and use gdate here instead.      #
#                                                                #
# MP3DIRS_SINGLE = You may run this script in two modes where it #
#                  either goes through the entire mp3 archive    #
#                  or just a single dir. Here you specify the    #
#                  dir(s) to go through when checking single.    #
#                                                                #
#                  Note that the findmp3 binary will             #
#                  automatically go through every subdir below   #
#                  what you specify here.                        #
#                                                                #
# MP3DIRS_FULL   = Here you specify all your mp3 dirs, space     #
#                  or newline seperated. If you do not specify   #
#                  'single' when running it, these paths will be #
#                  used instead. You should also specify the dir #
#                  in MP3DIRS_SINGLE here.                       #
#                                                                #
# KEEP_NON_EXISTING = TRUE/FALSE. If a release/song no longer    #
#                     exists on disk, do you want to remove the  #
#                     entry in the database? If so, specify      #
#                     FALSE and its removed.                     #
#                     If you specify TRUE, non existing releases #
#                     will be kept, but the onsite field will be #
#                     set to 0 (1 if it exists, 0 if it dosnt).  #
#                                                                #
# ENTER_SUBDIRS  = TRUE/FALSE. When TRUE, it will go through     #
#                  each dir seperatly, from what you specifed in #
#                  MP3DIRS_*. Why? When findmp3 goes through     #
#                  each subdir, it grabs the info but the script #
#                  will store each result in memory until the    #
#                  the findmp3 binary is finished.               #
#                                                                #
#                  This can make it very slow if you have 100    #
#                  "daily dirs" below the MP3DIRS_*.             #
#                                                                #
#                  Setting this to TRUE will instead cause the   #
#                  the script to run findmp3 in every subdir it  #
#                  finds, making it faster.                      #
#                                                                #
#                  In other words, if you have dated dirs,       #
#                  specify TRUE. If you do not, specify FALSE.   #
#                  It does not matter HOW the dated dirs look as #
#                  findmp3 goes through every subdir too.        #
#                                                                #
#                  If you have predirs inside your specified     #
#                  MP3DIRS_*, you'll want to set this to TRUE    #
#                  and then EXCLUDE the predirs below. Otherwise #
#                  the findmp3 binary will index the mp3 files   #
#                  inside the predirs too. Not too good.         #
#                                                                #
# EXCLUDE        = This is only valid if ENTER_SUBDIRS is TRUE.  #
#                  If so, this is a standard egrep line for      #
#                  which subdirs it should NOT enter.            #
#                  Enter any predirs and similar inside the      #
#                  MP3DIRS_* to not index the contents of.       #
#                                                                #
# MAX_CHECK_EXIST_PER_RUN = At the end of each run, it will go   #
#                           through the database and look at     #
#                           every unique path found where onsite #
#                           is still 1 (for "yeah, it exists").  #
#                           Now, if you have 100.000 Mp3dirs,    #
#                           this might take a while. Here you    #
#                           can specify a maximum number of dirs #
#                           it will lookup before quitting.      #
#                                                                #
#                           Setting this too high (or to "")     #
#                           will make it quite slow to run but   #
#                           the database will always be up to    #
#                           date.                                #
#                           Setting it too low will make it fast #
#                           but there might be stuff that the    #
#                           database is still on site (onsite:1) #
#                           even though they are not.            #
#                                                                #
#                           You can override this setting by     #
#                           using the argument 'clean' and it    #
#                           will go through every path in the    #
#                           database to see if they still exist. #
#                           In clean mode, it will NOT add new   #
#                           releases.                            #
#                                                                #
#--[ Running ]---------------------------------------------------#
#                                                                #
# Running the script without arguments will give you a short     #
# help. I'm adding some stuff here below anyway.                 #
#                                                                #
# Run it as ./tur-mp3id3.sh single or ./tur-mp3id3.sh full       #
# depending on which MP3DIRS_ you want to use.                   #
# The first time you should run "full debug" to make sure all    #
# your mp3s are indexed.                                         #
#                                                                #
# You may also specify 'clean' and it will go through every      #
# path in the database, verifying that they still exist,         #
# disregarding the MAX_CHECK_EXIST_PER_RUN setting.              #
# This is not needed to start with though.                       #
#                                                                #
# After that, you might crontab 'single' every day and 'full'    #
# once per week or so. 'clean' might be good once per week/month #
# too.                                                           #
# Its quite slow to index, but it does not take much CPU so      #
# should be fine anyway.                                         #
# If you use the $TODAY dir or similar, you can of course run it #
# more then once per day.                                        #
#                                                                #
# Recomended for sites is to specify the today and perhaps the   #
# yesterdaydir in MP3DIRS_SINGLE and run this script with        #
# 'single' a few times a day. Set MAX_CHECK_EXIST_PER_RUN to     #
# 100 or something.                                              #
# Then, in MP3DIRS_FULL, specify all the mp3 dirs and run 'full' #
# once every two days or so.                                     #
# Run it with 'debug' and make your own schedule on what you     #
# this is acceptable runtime for the script.                     #
#                                                                #
# Optionally, you can set MAX_CHECK_EXISTS_PER_RUN="1" and put   #
# a 'clean' crontab job once a week or similar.                  #
# That is probably recomended.                                   #
#                                                                #
#--[ More information ]------------------------------------------#
#                                                                #
# This script does two things, no matter which mode you run it   #
# in (part from 'clean' which only does #2).                     #
# 1: Add all releases not already in the database.               #
# 2: Go through entries in the database to make sure its         #
#    still on disk. If its not, its either deleted or the onsite #
#    value is set to 0 (depending on KEEP_NON_EXISTING).         #
#                                                                #
# You may specify 'debug' as first or second argument and it     #
# will show what its doing on screen. Good the first time you    #
# run it. Note that you must have patience with the findmp3      #
# binary as it can take a while to start printing debug stuff.   #
#                                                                #
#--[ Settings ]--------------------------------------------------#

SQLBIN="mysql"
SQLHOST="192.168.101.33"
SQLUSER="root"
SQLPASS="apollo"
SQLDB="mp3id3"
SQLTB="mp3id3"

FINDMP3="/glftpd/bin/findmp3"
FINDMP3_VARS="-verbose -x -artist . --"

TODAY="`date +%m%d`"
## Disabled. Remove the # to enable.
# YESTERDAY="`date "-d -1 day" +%m%d`"

MP3DIRS_SINGLE="
/glftpd/site/mp3/$TODAY
"

MP3DIRS_FULL="
/glftpd/site/mp3
/glftpd/site/mp3-archive
"

KEEP_NON_EXISTING="TRUE"

ENTER_SUBDIRS="TRUE"
EXCLUDE="_pre|groups"

MAX_CHECK_EXIST_PER_RUN="5"


#--[ Script Start ]----------------------------------------------------#

SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"

proc_debug() {
  if [ "$debug" = "TRUE" ]; then
    echo "$*"
  fi
}

proc_testcon() {
  sqldata="`$SQL "show table status" | tr -s '\t' '^' | cut -d '^' -f1`"
  if [ -z "$sqldata" ]; then
    unset ERRORLEVEL
    echo "Mysql error. Check server!"
    exit 0
  fi
}

if [ "$1" = "debug" ] || [ "$2" = "debug" ] || [ "$3" = "debug" ]; then
  debug="TRUE"
fi

if [ "$1" = "single" ] || [ "$2" = "single" ] || [ "$3" = "single" ]; then
  MP3DIRS="$MP3DIRS_SINGLE"
  proc_debug "single specified. Using $MP3DIRS"
elif [ "$1" = "full" ] || [ "$2" = "full" ] || [ "$3" = "full" ]; then
  MP3DIRS="$MP3DIRS_FULL"
  proc_debug "full specified. Using $MP3DIRS"
elif [ "$1" = "clean" ] || [ "$2" = "clean" ] || [ "$3" = "clean" ]; then
  unset MP3DIRS_FULL
  unset MP3DIRS_SINGLE
  unset MAX_CHECK_EXIST_PER_RUN
  proc_debug "Running 'clean' mode. Will go through each entry in the database"
  proc_debug "looking for non existing releases."
else
  echo "Specify either 'single' or 'full' depending on which MP3DIRS_? you want to use."
  echo "You may also add 'debug' and it will show you what its doing."
  echo ""
  echo "Specifying 'clean' will go through each entry in the database, checking if"
  echo "any releases are removed."
  exit 0
fi
  
proc_testcon

## Adding stuff to DB
if [ "$MP3DIRS" ]; then
  proc_debug "Adding new releases. This WILL take a while to start. Be patient."
fi

for section in $MP3DIRS; do
  if [ ! -d "$section" ]; then
    proc_debug "Can not find $section - Skipping."
  else
    cd "$section"
    proc_debug "Entering $section, looking for subdirs."

    if [ "$ENTER_SUBDIRS" = "TRUE" ]; then
      subdirs="`ls -1`"
    else
      subdirs="dummy"
    fi

    for subdir in $subdirs; do

      if [ "$subdirs" = "dummy" ]; then
        unset subdir
      else
        subdir="/$subdir"
      fi

      if [ "`echo "$subdir" | egrep -i "$EXCLUDE"`" ]; then
        proc_debug "Skipping $subdir. Excluded path."
      else
        proc_debug ""
      

        if [ ! -d "$section$subdir" ]; then
          proc_debug "Not a dir: $section$subdir - skipping."
        else
          proc_debug " - Running \"$FINDMP3 $FINDMP3_VARS $section$subdir\""
          proc_debug " - This WILL take a while. Be patient."
  
          for rawdata in `$FINDMP3 $FINDMP3_VARS $section$subdir | tr ' ' '^'`; do
            fullpath="`echo "$rawdata" | cut -d '"' -f1`"
            path="`dirname "$fullpath" | tr '^' ' '`"
            file="`basename "$fullpath" | tr '^' ' '`"
            file="`echo $file`"
            artist="`echo "$rawdata" | cut -d '"' -f2 | tr '^' ' ' | tr -s ' ' | tr -d "'"`"
            title="`echo "$rawdata" | cut -d '"' -f4 | tr '^' ' ' | tr -s ' ' | tr -d "'"`"

            DB_PATH="`$SQL "select path from $SQLTB where file = '$file' and artist = '$artist' and title = '$title'"`"
            if [ "$DB_PATH" ] && [ "$DB_PATH" != "$path" ]; then
              proc_debug "$file / $artist exists elsewhere. Updating path to $path"
              $SQL "update $SQLTB set path = '$path' where file = '$file' and artist = '$artist' and title = '$title'"
              $SQL "update $SQLTB set onsite = '1' where path = '$path'"
            elif [ "$DB_PATH" = "$path" ]; then
              proc_debug "Already exists $path - skipping."
              unset DB_PATH
            else
              proc_debug "New: $file  ($path)"
              album="`echo "$rawdata" | cut -d '"' -f6 | tr '^' ' ' | tr -s ' ' | tr -d "'"`"
              year="`echo "$rawdata" | cut -d '"' -f8 | tr '^' ' ' | tr -s ' ' | tr -d "'" | tr -d '[:alpha:]'`"

              if [ -z "`echo "$year" | grep "^....$"`" ] || [ "$year" = "0000" ]; then
                proc_debug "Messed up year on $file ($year). Setting 1901 instead."
                year="1901"
              fi

              comment="`echo "$rawdata" | cut -d '"' -f10 | tr '^' ' ' | tr -s ' ' | tr -d "'"`"
              tracknr="`echo "$rawdata" | cut -d '"' -f12 | tr '^' ' ' | tr -s ' ' | tr -d "'" | tr -d '[:alpha:]'`"
              genre="`echo "$rawdata" | cut -d '"' -f14 | tr '^' ' ' | cut -d ')' -f2- | tr -s ' ' | tr -d "'"`"

              if [ "$fullpath" = "." ]; then
                proc_debug "Skipping $file, $artist, $title - fullpath is '.'"
              else
                $SQL "insert into $SQLTB (path, file, artist, title, album, year, comment, tracknr, genre, onsite) VALUES ('$path', '$file', '$artist', '$title', '$album', '$year', '$comment', '$tracknr', '$genre', '1')"
              fi
            fi
          done
        fi
      fi
    done
  fi
done


proc_debug ""
proc_debug "---------------------------------------"

if [ "$MAX_CHECK_EXIST_PER_RUN" ]; then
  LIMIT="limit $MAX_CHECK_EXIST_PER_RUN"
  proc_debug "Checking $MAX_CHECK_EXIST_PER_RUN entries, if they still exist."
else
  proc_debug "Checking for deleted or moved releases."
fi
proc_debug "Running: $SQL \"select path from $SQLTB where onsite = '1' group by path $LIMIT\""
proc_debug ""

for path in `$SQL "select path from $SQLTB where onsite = '1' group by path order by ID $LIMIT"`; do
  if [ ! -d "$path" ]; then
    if [ "$KEEP_NON_EXISTING" = "TRUE" ]; then
      proc_debug "Gone: $path - Changing onsite to 0"
      $SQL "update $SQLTB set onsite = '0' where path = '$path'"
    else
      proc_debug "Gone: $path - Wiping from database."
      $SQL "delete from $SQLTB where path = '$path'"
    fi
  fi
done
