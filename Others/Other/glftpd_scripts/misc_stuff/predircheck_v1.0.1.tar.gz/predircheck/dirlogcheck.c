#include <sys/param.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <syslog.h>
#include <sys/file.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdio.h>
#include <time.h>

#define DIRLOGFILEPATH "/ftp-data/logs/dirlog"

struct dirlog {
        ushort status;     // 0 = NEWDIR, 1 = NUKE, 2 = UNNUKE, 3 = DELETED
        time_t uptime;
        ushort uploader;    /* Libc6 systems use ushort in place of uid_t/gid_t */
        ushort group;
        ushort files;
        long bytes;
        char dirname[255];
        struct dirlog *nxt;
        struct dirlog *prv;
};
	
int main (int argc, char *argv[]) {
   FILE *fp;
   struct dirlog buffer;
   char searchstr[1024];
   int result=4;

   if (argc != 3) {
     printf("Error! Not enough parameters: %s <dir_name_to_find> <path_to_the_dir>\n", argv[0]);
     return 1;
   }

   /* Checking if it's a CD */
   if (((argv[1][0] == 'c') || (argv[1][0] == 'C')) && ((argv[1][1] == 'd') || (argv[1][1] == 'D'))) {
     printf("4");
     return 0;
   }

   if((fp = fopen(DIRLOGFILEPATH, "r")) == NULL) {
     printf("Unable to open dirlog");
     return 1;
   }

   sprintf(searchstr, "%s/%s", argv[2], argv[1]);
   while(!feof(fp)) {
     if (fread(&buffer, sizeof(struct dirlog), 1, fp) < 1)
       break;
     if ((strcasecmp(buffer.dirname, searchstr) == 0) || (strstr(buffer.dirname, argv[1]) != 0)) {
       result=buffer.status; 
     }
   }

   fclose(fp);
   printf("%d", result);
   return 0;
}

