#!/bin/bash
# Secure invite script v0.9 by pexi
# This script is in development stage.
# USE AT OWN RISK.
# Please report any bugs, ideas or comments!
# irc: pexi @ efnet
# mail: me@pexi.net 

# PURPOSE:
# Some sites have invite from irc disabled due to security reasons.
# With this script users can add their irc bnc/host from site and get
# invited from irc. The script checks if users host matches with the one he
# has added if it does, the bot invites him.
# The script can also announce invite messages to channel (also bad invites)
# Allowed format for hosts is:
# ident@*.domain.host.com ident@host.com ident@ip.ip.ip.*


# INSTALLATION:
# cp px-inv.tcl -> bot script folder and load it to your eggdrop
# cp px-inv.sh /glftpd/bin
# cp px-inv_verify.sh /glftpd/bin
# IF YOU DONT HAVE PASSCHK IN YOUR GLFTPD BIN FOLDER THEN:
# gcc -lcrypt -O2 -o passchk passchk.c
# and cp passchk /glftpd/bin
# the passchk binary that comes with darkon3's zs is ok. 
# edit px-inv.sh, px-inv_verify.sh and px-inv.tcl
# add 
# site_cmd irc_inv         EXEC    /bin/px-inv.sh
# custom-irc_inv           *
# to glftpd.conf
# make px-inv.sh px-inv_verify.sh px-inv.tcl executable (chmod +x)
# touch /glftpd/ftp-data/misc/px-inv.data (this is the default path)
# make sure px-inv.data can be read and write.
# done.

# USAGE:
# From site:
# site irc_inv (shows valid commands)
# site irc_inv list (shows users currently added irc host)
# site irc_inv add ident@host (adds users irc host)
# From irc:
# /msg botname !invite(or what your trigger is) user pass


# -[ CONFIGURE ]-

# This is where px-inv.data will be stored (dont add glftpd path before this)
datafolder=/ftp-data/misc
# Require ident?
ident=yes
# Tmp folder
tmp=/tmp

# -[ CONFIGURE DONE ]-



if [ -z "$1" ];then

 echo "Usage: site irc_inv add ident@host site irc_inv list"
 exit
fi

add_host ()
{

if [ "`cat $datafolder/px-inv.data|grep ":$USER:"`" = "" ];then
 echo "No previous entries found, adding $1"
 echo :$USER:$1 >> $datafolder/px-inv.data
 exit
  else
   echo "Previous host entry found, overwriting it"
   cat $datafolder/px-inv.data |grep -v ":$USER:" >> $tmp/px-inv.tmp
   echo ":$USER:$1" >> $tmp/px-inv.tmp
    if [ $? != 0 ];then
     echo "ERROR: Failed to write tmpfile, contact siteop!"
      exit
       fi
 mv $tmp/px-inv.tmp $datafolder/px-inv.data
 echo "Done."
fi
}
hostname=`echo $2| cut -d '@' -f 2|tr "*" -|tr . " "`
verify_ip ()
{
hostname=`echo $1| cut -d '@' -f 2|tr "*" -|tr . " "`
 until [ "$number" = "3" ];do
 let "number = $number + 1"
 n="$"$number
 d=`echo $hostname |awk '{ print '$n' }'`
case $d in
*[a-zA-Z])
 echo "Please be more specific"
 exit
;;
-)
 echo "Please be more specific"
 exit
esac
done
add_host $1
}


bnc_check ()
{
hostname=`echo $1| cut -d '@' -f 2|tr "*" -|tr . " "`
if [ $ident = "yes" ] && [ "`echo $1 |awk -F@ '{ print $1 }'`" = "*" ];then
 echo "Ident is required"
 exit
fi

f1=`echo $1| cut -d '@' -f 2|tr "*" -|tr . " " |awk '{ print $1 }'`
if [[ $f1 == --* ]];then
 echo "dont try to cheat"
 exit
fi

ipcheck=`echo $hostname| cut -d '@' -f 2|tr "*" -|tr . " " |awk '{ print $4 }'`

if [ "$ipcheck" = "-" ];then
 verify_ip $1
 exit
fi
for i in \'$hostname\';do
 let "count=$count + 1"
done
number=1
until [ $number = "$count" ];do
 let "number = $number + 1"
 n="$"$number
 d=`echo $hostname |awk '{ print '$n' }'`
if [ "$d" = "-" ];then
  echo "Please be more specific, allowed format is ident@*.domain.host.com or ident@host"
exit
fi
if [ "`echo $hostname|awk '{ print $1 }'`" = "-" ];then
case $d in
*[0-9])
 echo "Trying to add an ip?"
 echo "If so, the correct format is: x.x.x.* or your full ip"
 exit
esac
fi 
case $d in
*-[a-zA-Z])
 echo "Please be more specific"
 exit
;;
[a-zA-Z]*-)
 echo "Please be more specific"
 exit
;;
*-*)
 echo "Please be more specific"
 exit
;;
esac
done

if [ "`echo $hostname|awk '{ print $2 }'`" = "" ];then
 echo "Please be more specific, allowed format is ident@*.domain.host.com or ident@host"
 exit
fi
if [ "`echo $hostname|awk '{ print $1 }'`" = "-" ] && [ "`echo $hostname|awk '{ print $4 }'`" = "" ];then
 echo "Please be more specific"
 exit
fi
if [ "$hostname" = "-" ];then
 echo "Please be more specific, allowed format is ident@*.domain.host.com or ident@host"
 exit
fi
add_host $1
}

if [ $1 = "add" ];then
 bnc_check $2
fi
if [ $1 = "list" ];then
 if [ "`cat $datafolder/px-inv.data |grep :"$USER":|awk -F: '{ print $3 }'`" = "" ];then
  echo "No hosts found! Use site irc_inv add ident@host to add your host."
   else
    echo "Your current irc bnc/host is: `cat $datafolder/px-inv.data |grep :"$USER":|awk -F: '{ print $3 }'`" 
  fi
fi
