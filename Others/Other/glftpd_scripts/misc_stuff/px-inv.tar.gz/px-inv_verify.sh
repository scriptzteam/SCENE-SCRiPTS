#!/bin/bash

# CONFIGURE
# This must be the same as in px-inv.sh 
# (WITH /glftpd/ or wherever your glftpd is installed to)
datafolder=/glftpd/ftp-data/misc
# DONE

check="`cat $datafolder/px-inv.data |grep :"$1":|gawk -F: '{ print $3 }'`"
if [ "$check" = "" ];then
echo "NOTFOUND"
else
echo $check
fi


