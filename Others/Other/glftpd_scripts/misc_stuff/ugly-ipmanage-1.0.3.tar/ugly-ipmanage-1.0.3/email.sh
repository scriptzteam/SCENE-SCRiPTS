#!/bin/sh

email_db="/ftp-data/misc/email.db"  # path to the email database that you
                                    # created

siteop_clean_only=YES               # if "YES", then only siteops will be able
                                    # to use the '-clean' argument with this
                                    # script, which clears the db of users who
                                    # no longer exist on the site

users_dir="/ftp-data/users"         # path to the dir containing your userfiles

encrypted_db=YES                    # if your email db is encrypted, set to YES
encrypted_cipher="aes256"           # cipher used to encrypt/decrypt the db - 
                                    # see 'openssl enc ?' for a list of ciphers

keystore="/ftp-data/keystore/key"   # file to store passkey for encrypted db
                                    # THIS FILE SHOULD BE TEMPORARY! - a ramdisk
                                    # (aka memory disk) is temp storage 

siteop_decrypt_only=YES             # if "YES", then only siteops will be able
                                    # to set a key for decrypting the email db

enable_show=YES                     # if "YES", then [only] siteops will be
                                    # able to use the 'site email -show <user>'
                                    # command, which shows the email address of
                                    # a certain user - if "NO", then NO ONE will
                                    # be able to use this function (including
                                    # siteops)
                                    #
                                    # this command is useful when a siteop wants
                                    # to make use of a user's email address (for
                                    # emailing passwords, etc.)


### END CONFIG ###


if [ ! -w "$email_db" ]; then
  echo -e "Email db not writable!\r"
  exit 2
fi

# too few or too many arguments
if [ $# -lt 1 ] || [ $# -gt 2 ]; then
  echo -e "Syntax: site email -clean|-unset|-show <user>|-pass <key>|<email@address>\r"
  exit 2
fi

# STORE KEY
siteop=`grep -E "^FLAGS.*1.*" /ftp-data/users/"$USER"`  # var for db clean too
if [ $1 = "-pass" ]; then
  if [ "$siteop_decrypt_only" = YES ] && [ -z "$siteop" ]; then
    echo -e "Only siteops can specify a passkey!\r"
    exit 2
  fi
  if [ "$encrypted_db" != YES ]; then
    echo -e "Script not configured to use encrypted databases!\r"
    echo -e "Set: encrypted_db=YES\r"
    exit 2
  fi
  # missing key arg
  if [ -z $2 ]; then
    echo -e "Syntax: site email -clean|-unset|-show <user>|-pass <key>|<email@address>\r"
    exit 2
  fi
  echo "$2" > "$keystore"
  exit 0
fi

# check for improperly formatted email addresses
if [ $1 != "-clean" ] && [ $1 != "-unset" ] && [ $1 != "-stats" ] && \
   [ $1 != "-pass" ] && [ $1 != "-show" ]; then
  format=`echo $1 | grep -Ei "^[a-z0-9-_\.]+\@[a-z0-9-_\.]+\.[a-z]+$"`
  if [ -z "$format" ]; then
    echo -e "Email address formatted incorrectly!\r"
    exit 2
  fi
fi

# ENCRYPTED DB CHECKS
if [ "$encrypted_db" = YES ]; then
text=`openssl enc -bf -salt -d -in "$email_db" -pass pass:testing 2>&1 | grep "bad magic number"`
  if [ ! -z "$text" ]; then
    echo -e "Email database not encrypted!\r"
    echo -e "Use: openssl enc -<cipher> -salt -e -in email.db -out email.db.new\r"
    echo -e "Then rename email.db.new to email.db.\r"
    exit 2
  fi
  if [ ! -w "$keystore" ]; then
    echo -e "Keystore file not writable!\r"
    exit 2
  fi
  if [ -z "$encrypted_cipher" ]; then
    echo -e "You did not specify a cipher!\r"
    exit 2
  fi
  encrypted_cipher=`echo "$encrypted_cipher" | sed -e 's/^-//'`
fi

# DETECT STORED KEY
if [ "$encrypted_db" = YES ] && [ -z `cat "$keystore"` ]; then
  echo -e "Key not stored for email database!  Use: site email -pass <key>\r"
  exit 2
fi

# PUT EMAIL DB INTO $e_output
if [ "$encrypted_db" = YES ];
  then
    e_output=`openssl enc -$encrypted_cipher -salt -d -in "$email_db" \
              -pass file:"$keystore" 2>&1`
    if [ $? != 0 ]; then
      echo -e "An error occurred while decrypting the email database!  Bad key?\r"
      exit 2
    fi
  else
    e_output=`cat "$email_db"`
fi

# UNSET EMAIL ADDRESS
if [ $1 = "-unset" ]; then
  exists=`echo "$e_output" | grep -Fw "$USER"`
  if [ ! -z "$exists" ];
    then
      e_output=`echo "$e_output" | grep -Fwv "$USER"`
      echo -e "Email address removed from the database.\r"
    else
      echo -e "Email address not currently set!\r"
  fi
fi

# STATS
if [ $1 = "-stats" ]; then
  emails=`echo "$e_output" | grep -c ""`
  all_users=`ls -1 "$users_dir" | grep -vc "default.user"`
  deleted=`grep -E "^FLAGS.*6" "$users_dir"/* | grep -c ""`
  total_users=$(( $all_users - $deleted ))
  echo -e "$emails users have set email addresses out of $total_users total users.\r"
  exit 0
fi

# SHOW
if [ $1 = "-show" ]; then
  if [ "$enable_show" != YES ]; then
    echo -e "This command has been disabled!\r"
    exit 2
  fi
  if [ -z "$siteop" ]; then
    echo -e "You must be a siteop to show a user's email address!\r"
    exit 2
  fi
  if [ -z "$2" ]; then
    echo -e "You did not specify a username!\r"
    exit 2
  fi
  address=`echo "$e_output" | grep -Fw "$2" | awk '{print $2}'`
  if [ -z "$address" ]; then
    echo -e "User $2 does not have an email address set!\r"
    exit 2
  fi
  echo -e "$2: "$address"\r"
  exit 0
fi

# DB CLEANING
if [ $1 = "-clean" ]; then
  if [ $siteop_clean_only = "YES" ] || [ $siteop_clean_only = "yes" ]; then
    if [ -z "$siteop" ]; then
      echo -e "You must be a siteop to clean the database!\r"
      exit 2
    fi
  fi
  delusers=0
  for i in `echo "$e_output" | awk '{print $1}'`; do
    if [ ! -f /ftp-data/users/"$i" ]; then
      e_output=`echo "$e_output" | grep -Fwv "$i"`
      delusers=$(( $delusers + 1 ))
    fi
  done
  echo -e "Database cleaned.  $delusers users deleted.\r"
fi

# CHANGE/SET EMAIL ADDRESS
if [ $1 != "-clean" ] && [ $1 != "-unset" ] && [ $1 != "-stats" ] && \
   [ $1 != "-pass" ] && [ $1 != "-show" ]; then
  exists=`echo "$e_output" | grep -Fw "$USER"`
  old_email=`echo "$exists" | awk '{print $2}'`
  if [ ! -z "$exists" ];
    then
      e_output=`echo "$e_output" | sed -e "s/$old_email/$1/"`
      echo "Email address was previously set to "$old_email".  Updated."
    else
      e_output=""$e_output"
$USER $1"
  fi
fi

# WRITE CHANGES
if [ "$encrypted_db" = YES ];
  then
    echo "$e_output" | openssl enc -$encrypted_cipher -salt -e \
    -out "$email_db" -pass file:"$keystore"
  else
    echo "$e_output" > "$email_db"
fi

exit 0
