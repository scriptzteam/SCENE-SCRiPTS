#!/bin/bash

affil_dir[0]="/site/mp3/groups"  # affil group path(s)
affil_dir[1]="/site/drive2/divx/groups"
affil_dir[2]="/site/drive2/xxx/groups"
affil_dir[3]="/site/mv/groups"

dir_exception[0]="/site/requests" # path(s) that are exempted from affil-check
                                  # NOTE: affil dirs do not need to be specified
                                  # as they are exempted in the affil_dir list

latepre_log="/ftp-data/misc/latepres" # path to your latepres database


### END CONFIG ###

today=`date +%m%d`

for exception in ${dir_exception[@]} ${affil_dir[@]}
  do
    match_exc=`echo "$2" | grep "$exception"`
      if [ ! -z "$match_exc" ]; then
        exempt="YES"
      fi
done

index=0
while [ $index -lt ${#affil_dir[@]} ] && [ -z "$exempt" ];
  do
    for affil in `ls -1 ${affil_dir[$index]}`; do
      case "$1" in
        *-"$affil")
          if [ ! -d "$2"/"$1" ]; then
            echo -e "Don't race affils!  Affil's late pre logged.\r"
            logcontents=`cat "$latepre_log"`
            dupe=`echo "$logcontents" | grep "$1"`
            if [ -z "$dupe" ]; then
              echo ""$today" - "$1"" >> "$latepre_log"
            fi
            exit 2
          fi
        ;;
     esac
   done
index=$(( $index + 1 ))
done

exit 0
