#!/bin/sh

                         ##                     ##
                        ##  latepre 1.0 by ugly  ##
                         ##                     ##


latepre_log="/ftp-data/misc/latepres"    # set this to the same value as
                                         # specified in your pre_dir_check
                                         # script


### END CONFIG ###


if [ "$1" = "help" ];
  then
    echo "Syntax: SITE LATEPRE [clean]: Display or erase the late pre log."
    exit 0
fi

if [ "$1" = "clean" ];
  then
    echo -n > "$latepre_log"
    exit 0
fi

echo "+------------------------LATE PRE-RELEASES------------------------+"
echo ""
cat "$latepre_log"
echo ""
echo "+-------------------------------END------------------------------+"

exit 0
