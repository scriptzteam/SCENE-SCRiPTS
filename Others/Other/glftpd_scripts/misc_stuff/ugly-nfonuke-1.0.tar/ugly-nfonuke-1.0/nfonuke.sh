#!/bin/bash

                        ##                     ##
                       ##  nfonuke 1.0 by ugly  ##
                        ##                     ##



glftpd_root="/jail/glftpd"
nuke_hours="3"             # minimum age before a rel gets nuked
nukeuser="user"            # nuker username (flags should be set to +4A)
multiplier="5"             # nuke multiplier
exceptions=( "groups" "EXMPL2" ) # dirs matching these strings will not be nuked

today=`date +%m%d`   # MMDD format - read 'man date' for info
this_week=`date +%V`

# you can add more variables to the above, like
# yesterday=`date --date '-1 days' +%m%d` and then add it the the paths listed
# below (i.e. /site/mp3/incoming/$yesterday)

DIRS=(
/site/mp3/incoming/$today
/site/mv/WEEK$this_week
/site/drive2/xxx
/site/drive2/divx
)


if [ `uname` = "Linux" ];
  then
    DATE="date"
  else
    DATE="/usr/local/bin/gdate"
    if [ ! -f "$DATE" ]; then
      echo "'gdate' doesn't exist!  Please install sh-utils."
      echo "  http://www.gnu.org/software/shellutils/shellutils.html"
      echo; echo "(available in any *BSD's ports tree)"
      exit 0
    fi
fi

secs=$(( $nuke_hours * 3600 ))

index=0
DIR_COUNT=${#DIRS[@]}
while [ "$index" -lt "$DIR_COUNT" ];
  do
    CURRENT_DIR=${DIRS["$index"]}
    for nfodir in "$glftpd_root"/"$CURRENT_DIR"/*/; do
      nuked=`echo "$nfodir" | grep "NUKED"`
      unset exempt
      for exc in ${exceptions[@]}
        do
          if [ ! -z `echo "$nfodir" | grep "$exc"` ]; then
            exempt="YES"
          fi
      done
      age_gnusecs=`"$DATE" -r "$nfodir" +%s`
      current_gnusecs=`"$DATE" +%s`
      age=`echo "$current_gnusecs" - "$age_gnusecs" | bc`
      nfoexists=`find "$nfodir" -name "*.nfo" | head -n 1`
      sfvexists=`find "$nfodir" -name "*.sfv" | head -n 1`
      if [ -z "$nfoexists" ] && [ -z "$nuked" ] && [ "$age" -ge "$secs" ] && \
         [ ! -z "$sfvexists" ] && [ -z "$exempt" ];
        then
          nuke_path=""$CURRENT_DIR"/`basename "$nfodir"`"
          "$glftpd_root"/bin/nuker -N $nukeuser -n "$nuke_path" $multiplier NFO still missing after $nuke_hours hours > /dev/null 2>&1
      fi
    done
  index=$(( $index + 1 ))
done

exit 0
