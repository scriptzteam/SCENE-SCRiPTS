#!/bin/bash

### START EDITING ###

GLROOT=/glftpd/glftpd
USERDIR=$GLROOT/ftp-data/users
GLCONF=/glftpd/glftpd.conf

### STOP EDITING ###

USER=$1

if [ -e $USERDIR/$USER ]; then

   WKUP=`cat $USERDIR/$1 | grep "WKUP" | cut -d ' ' -f3 `
   WKUP=`expr $WKUP / 1024`
   MNUP=`cat $USERDIR/$1 | grep "MONTHUP" | cut -d ' ' -f3`
   MNUP=`expr $MNUP / 1204`
   ALUP=`cat $USERDIR/$1 | grep "ALLUP" | cut -d ' ' -f3`
   ALUP=`expr $ALUP / 1024`

   WKSTAT=`$GLROOT/bin/stats -r $GLCONF -u -w | grep "$USER" | awk '{print $1}' | sed -e 's/\[//' | sed -e 's/\]//' | sed -e 's/^0//' `
   MNSTAT=`$GLROOT/bin/stats -r $GLCONF -u -m | grep "$USER" | awk '{print $1}' | sed -e 's/\[//' | sed -e 's/\]//' | sed -e 's/^0//' `
   ALSTAT=`$GLROOT/bin/stats -r $GLCONF -u -a | grep "$USER" | awk '{print $1}' | sed -e 's/\[//' | sed -e 's/\]//' | sed -e 's/^0//' `

   if [ "$WKSTAT" == "" ]; then

      WKSTAT="NONE"

   fi

   if [ "$MNSTAT" == "" ]; then

      MNSTAT="NONE"

   fi

   if [ "$ALSTAT" == "" ]; then

      ALSTAT="NONE"

   fi


   echo "$USER -> WKUP: $WKSTAT @ $WKUPMB - MNUP: $MNSTAT @ $MNUPMB - ALUP: $ALSTAT @ $ALUPMB"

else 

   echo "Sorry, No Such User"

fi
