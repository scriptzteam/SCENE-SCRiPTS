#!/bin/bash

clear
echo ""
echo "   ####  ####  ##### ####  #   #  #### #     ##### ##### ####  ####  "
echo "   #   # #   # #     #   # #   # #     #     #       #   #   # #   # "
echo "   ####  ####  ####  ####  ##### # ### #     ####    #   ####  #   # "
echo "   #     #   # #     #         # #   # #     #       #   #     #   # "
echo "   #     #   # ##### #         #  #### ##### #       #   #     ####  "
echo ""   
echo "   PREPARE 4 GLFTPD - THE LITTLE HELPING SCRIPT (lol) "
echo ""
echo "by d*x*c "
echo ""
echo "Based on an installation of Debian 6 x86 Netinst."
echo "Execute this script right after you have finished the Debian 6 x86 Netinst."
echo ""
echo "I am not a coder, this is only for installing needed packages,"
echo "downloading/unpacking glftpd (32bit) and starting glftpd install script."
echo ""
echo "Downloading and installing pzs-ng r2500 1.2.0 and eggdrop 1.6.20 will be done, too."
echo ""
echo "Configuring everything properly is up to you, this script is not able to do that for you :-P"
echo ""
echo "Best usage is:"
echo "Copy script to /home directory and start it with ./prepare4glftpd.sh"
echo ""
echo "If you do not like it, do not use it. Thank you."
echo ""
echo -n "Press <enter> to continue installation or CTRL + C to abort."
read randomkey
echo ""
echo "The following packages are needed (most of them, some only added if needed for later use and to make sure they are really installed ;) )."
echo ""
echo "nano, zip, tcl8.4-dev, unzip, lynx, curl, bzip2, gzip, xinetdm, libssl-dev, gcc, g++, automake, autoconf, ssh, ftp-ssl"
echo ""
echo "These packages will be downloaded and installed now."
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
echo "Running the following command:"
echo ""
echo "apt-get -y install nano tar wget gzip bzip2 gcc g++ automake autoconf zip unzip tcl8.4-dev lynx curl xinetd libssl-dev ssh ftp-ssl"
echo ""
apt-get -y install nano tar wget gzip bzip2 gcc g++ automake autoconf zip unzip tcl8.4-dev lynx curl xinetd libssl-dev ssh ftp-ssl
echo ""
echo "Now we are downloading and unpacking glftpd 2.01 32 bit to the /home directory using the following commands:"
echo ""
echo "cd /home"
echo "wget http://glftpd.dk/files/glftpd-LNX_2.01.tgz"
echo "tar xfz glftpd-LNX_2.01.tgz"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
cd /home
wget http://glftpd.dk/files/glftpd-LNX_2.01.tgz
tar xfz glftpd-LNX_2.01.tgz
echo ""
echo "Changing folder and starting installgl.sh."
echo ""
echo "cd glftpd-LNX_2.01"
echo "./installgl.sh"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
# cd glftpd-LNX_2.01
# ./installgl.sh
echo ""
echo "Downloading and unpacking pzs-ng to the /home directory using the following commands:"
echo ""
echo "cd /home"
echo "wget http://pzs-ng.com/stable/project-zs-ng_r2500-v1.2.0.tar.gz"
echo "tar xfz project-zs-ng_r2500-v1.2.0.tar.gz"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
cd /home
wget http://pzs-ng.com/stable/project-zs-ng_r2500-v1.2.0.tar.gz
tar xfz project-zs-ng_r2500-v1.2.0.tar.gz
echo ""
echo "Changing folder and configuring pzs-ng."
echo ""
echo "cd project-zs-ng_r2500-v1.2.0"
echo "./configure"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
cd project-zs-ng_r2500-v1.2.0
./configure
echo ""
echo "Now you have to configure zsconfig.h to suit your needs."
echo ""
echo "nano zipscript/conf/zsconfig.h"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
nano zipscript/conf/zsconfig.h
echo ""
echo "Doing make && make install to install pzs-ng."
echo ""
echo "make && make install"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
# make && make install
echo ""
echo "Done with installing glftpd 2.01 32 bit and pzs-ng r2500 1.2.0."
echo ""
echo "Have fun..."
echo ""
echo "Downloading and unpacking eggdrop1.6.20.tar.gz to the /home directory with the following commands:"
echo ""
echo "cd /home"
echo "wget http://www.egghelp.org/files/eggdrop/eggdrop1.6.20.tar.gz"
echo "tar xfz eggdrop1.6.20.tar.gz"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
cd /home
wget http://www.egghelp.org/files/eggdrop/eggdrop1.6.20.tar.gz
tar xfz eggdrop1.6.20.tar.gz
echo ""
echo "Changing directory and configuring the eggdrop."
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
echo "cd eggdrop1.6.20"
echo "./configure"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
cd eggdrop1.6.20
./configure
echo ""
echo "Configuring the eggdrop modules and installing the eggdrop with the following commands:"
echo ""
echo "make config"
echo "make && make install"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
make config
make && make install
echo ""
echo "Making a directory for the eggdrop in the /home directory and copying eggdrop files."
echo ""
echo "mkdir -p /home/eggdrop"
echo "cp -R /root/eggdrop1.6.20/* /home/eggdrop"
echo ""
echo -n "Press <enter> to continue installation. "
read randomkey
echo ""
mkdir -p /home/eggdrop
cp -R /root/eggdrop1.6.20/* /home/eggdrop
echo ""
echo "Make sure to chown the eggdrop diretory to the user that will run the eggdrop (e.g. chown -R username: /home/eggdrop) and setting the correct permissions "
echo ""
echo "Have fun."
echo ""
echo "end of script"
echo ""
echo "Good luck! Do NOT support p2p, torrents, public ftp's, warez web sites, ......"
echo ""