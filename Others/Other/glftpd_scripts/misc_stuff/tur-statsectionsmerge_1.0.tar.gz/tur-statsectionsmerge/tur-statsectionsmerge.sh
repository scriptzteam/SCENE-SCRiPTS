#!/bin/bash
VER=1.0
#-[ Intro ]------------------------------------------------------#
#                                                                #
# Tur-StatSectionsMerge. A script for those that are tired of    #
# using multiple stats/credits section and simply want to merge  #
# them down the the DEFAULT section without loosing the current  #
# stats. If you just change to one stat section in glftpd.conf,  #
# all the stats for the other sections are lost, so...           #
#                                                                #
# This script supports merging of up to 9 stat/credits sections. #
#                                                                #
#-[ Requirements ]-----------------------------------------------#
#                                                                #
# Apart from standard binaries, it also needs basename and bc    #
# installed. bc is used for all calulcations since both expr and #
# bash's internal calculator overflow on very large numbers.     #
#                                                                #
#-[ Configure ]--------------------------------------------------#
#                                                                #
# Copy this script anywhere you want and do chmod 755 on it.     #
# Change settings to match your setup.                           #
#                                                                #
# USERS      = Location of users dir.                            #
# MERGE      = Which stats to merge. Default is all of them.     #
# MERGECREDS = With this on TRUE, it will also look for more     #
#              then one credits section and add those too.       #
#              There is no harm in having this on TRUE, but set  #
#              it to FALSE anyway if you dont need it.           #
# TMP        = A temp dir.                                       #
# DEBUG      = With this on TRUE, it will output what it will do #
#              to the screen and not actually do it. You can     #
#              also start this script with the argument test and #
#              it will do the same thing.                        #
#                                                                #
#-[ Usage ]------------------------------------------------------#
#                                                                #
# Do this in this particular order!                              #
# 1) Shut down the site and kick all users on it.                #
# 2) Make a backup of the users directory just incase.           #
# 3) Run this script with DEBUG set to TRUE. See what it outputs #
#    and verify it manually for a few users. When checking stats,#
#    it goes like this: WKUP 100 999 100                         #
#                                                                #
#    That is for if you one have one section. First number is nr #
#    of files. 999 is KB uploaded (WKUP) and the last 100 is the #
#    speed. Speed will not be merged since theres no point.      #
#                                                                #
#    However, you wouldnt run this script if you only had one    #
#    stat sections, so it probably looks somethings like:        #
#    WKUP 100 999 100 200 1500 250                               #
#                                                                #
#    That is if you have 2 sections defined. 3 numbers per       #
#    section. This script will merge 100+200 and 999+1500 and    #
#    make the total: WKUP 300 2499 200                           #
#    So, verify that the numbers the debug mode outputs are      #
#    correct.                                                    #
#                                                                #
#    When it comes to credits, its just CREDITS and then one     #
#    number per credits section.                                 #
#                                                                #
# 4) Once you think the debug numbers looks good, set DEBUG to   #
#    false and run it again. It will stay quiet while running.   #
# 5) Verify a user or five that it looks good.                   #
# 6) Remove the extra stat_sections from glftpd.conf. Remember   #
#    to leave the DEFAULT section because that MUST be there.    #
# 7) Log in yourself and check your stats in the ftp.            #
# 8) Satisfied? Open site if so. Otherwise, restore the backup   #
#    and make your own stats moving script =)                    #
#                                                                #
#-[ Settings ]---------------------------------------------------#

USERS=/glftpd/ftp-data/users_test
MERGE="DAYUP DAYDN WKUP WKDN MONTHUP MONTHDN ALLUP ALLDN"
MERGECREDS=FALSE
TMP=/tmp
DEBUG=TRUE

#-[ Script Start ]-----------------------------------------------#

## If first argument is test, set DEBUG to TRUE.
if [ "$1" = "test" ]; then
  DEBUG="TRUE"
fi

## Check if bc works.
if [ "$( echo "100 + 100" | bc -l )" != "200" ]; then
  echo "You dont have bc installed? Thats needed."
  exit 0
fi

## Umm yeah. Guess.
cd $USERS

## Go loop for each user.
for userraw in `grep "^FLAGS " $USERS/* | cut -d ':' -f1`; do
  user=`basename $userraw`

  if [ "$MERGECREDS" = "TRUE" ]; then
    if [ "$user" != "$lastuser" -a "$DEBUG" = "TRUE" ]; then
      echo " "
    fi

    unset CREDITS; unset CREDITS2; unset CREDITS3; unset CREDITS4; unset CREDITS5; unset CREDITS6; unset CREDITS7
    unset CREDITS8; unset CREDITS9; unset DEFAULTCREDS

    CREDITS="$( grep "^CREDITS " $user | cut -d ' ' -f2 )"
    DEFAULTCREDS="$CREDITS"

    ## Check and add the other sections to merg.
    CREDITS2="$( grep "^CREDITS " $user | cut -d ' ' -f3 )"
    if [ "$CREDITS2" ]; then
      CREDITS3="$( grep "^CREDITS " $user | cut -d ' ' -f4 )"
      if [ "$CREDITS3" ]; then
        CREDITS4="$( grep "^CREDITS " $user | cut -d ' ' -f5 )"
        if [ "$CREDITS4" ]; then
          CREDITS5="$( grep "^CREDITS " $user | cut -d ' ' -f6 )"
          if [ "$CREDITS5" ]; then
            CREDITS6="$( grep "^CREDITS " $user | cut -d ' ' -f7 )"
            if [ "$CREDITS6" ]; then
              CREDITS7="$( grep "^CREDITS " $user | cut -d ' ' -f8 )"
              if [ "$CREDITS7" ]; then
                CREDITS8="$( grep "^CREDITS " $user | cut -d ' ' -f9)"
                if [ "$CREDITS8" ]; then
                  CREDITS9="$( grep "^CREDITS " $user | cut -d ' ' -f10 )"
                  if [ "$CREDITS9" ]; then
                    CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4+$CREDITS5+$CREDITS6+$CREDITS7+$CREDITS8+$CREDITS9" | bc -l )"
                    if [ "$DEBUG" = "TRUE" ]; then
                      echo "-> Nine credits sections found for $user - Total:$CREDITS"
                    fi
                  else
                    CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4+$CREDITS5+$CREDITS6+$CREDITS7+$CREDITS8" | bc -l )"
                    if [ "$DEBUG" = "TRUE" ]; then
                      echo "-> Eight credits sections found for $user - Total:$CREDITS"
                    fi
                  fi
                else
                  CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4+$CREDITS5+$CREDITS6+$CREDITS7" | bc -l )"
                  if [ "$DEBUG" = "TRUE" ]; then
                    echo "-> Seven credits sections found for $user - Total:$CREDITS"
                  fi
                fi
              else
                CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4+$CREDITS5+$CREDITS6" | bc -l )"
                if [ "$DEBUG" = "TRUE" ]; then
                  echo "-> Six credits sections found for $user - Total:$CREDITS"
                fi
              fi
            else
              CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4+$CREDITS5" | bc -l )"
              if [ "$DEBUG" = "TRUE" ]; then
                echo "-> Five credits sections found for $user - Total:$CREDITS"
              fi
            fi
          else
            CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3+$CREDITS4" | bc -l )"
            if [ "$DEBUG" = "TRUE" ]; then
              echo "-> Four credits sections found for $user - Total:$CREDITS"
            fi
          fi
        else
          CREDITS="$( echo "$CREDITS+$CREDITS2+$CREDITS3" | bc -l )"
          if [ "$DEBUG" = "TRUE" ]; then
            echo "-> Three credits sections found for $user - Total:$CREDITS"
          fi
        fi
      else
        CREDITS="$( echo "$CREDITS+$CREDITS2" | bc -l )"
        if [ "$DEBUG" = "TRUE" ]; then
          echo "-> Two credits sections found for $user - Total:$CREDITS "
        fi
      fi
      NADA="Yepp"
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "-> One credit section found for $user $CREDITSME - Total:$CREDITS"
      fi        
    fi
    if [ "$DEFAULTCREDS" != "$CREDITS" ]; then
      if [ "$CREDITS" != "0" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          sed -e "s/^CREDITS .*/CREDITS $CREDITS/" $user > $TMP/$user.tmp
          cp -f $TMP/$user.tmp $user
          rm -f $TMP/$user.tmp
        fi
      else
        if [ "$DEBUG" = "TRUE" ]; then
          echo "NO change in credits for $user (its 0)."
        fi
      fi
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "No change in credits for $user"
      fi
    fi
  fi


  for README in $MERGE; do
    unset READ; unset READ2; unset READ3; unset READ4; unset READ5; unset READ6; unset READ7; unset READ8; unset READ9
    unset FIRST; unset THIRD; unset DEFAULTSEC
    FIRST=0; FIRST2=0; FIRST3=0; FIRST4=0; FIRST5=0; FIRST6=0; FIRST7=0; FIRST8=0, FIRST9=0

    if [ "$user" != "$lastuser" -a "$MERGECREDS" != "TRUE" -a "$DEBUG" = "TRUE" ]; then
      echo " "
    fi

    FIRST="$( grep "^$README " $user | cut -d ' ' -f2 )" ## FILES
    READ="$( grep "^$README " $user | cut -d ' ' -f3 )"  ## KB
    THIRD="$( grep "^$README " $user | cut -d ' ' -f4 )" ## SPEED
    DEFAULTSEC="$READ"

    ## Check and add the other sections to README.
    FIRST2="$( grep "^$README " $user | cut -d ' ' -f5 )"
    READ2="$( grep "^$README " $user | cut -d ' ' -f6 )"
    if [ "$READ2" ]; then
      FIRST3="$( grep "^$README " $user | cut -d ' ' -f8 )"
      READ3="$( grep "^$README " $user | cut -d ' ' -f9 )"
      if [ "$READ3" ]; then
        FIRST4="$( grep "^$README " $user | cut -d ' ' -f11 )"
        READ4="$( grep "^$README " $user | cut -d ' ' -f12 )"
        if [ "$READ4" ]; then
          FIRST5="$( grep "^$README " $user | cut -d ' ' -f14 )"
          READ5="$( grep "^$README " $user | cut -d ' ' -f15 )"
          if [ "$READ5" ]; then
            FIRST6="$( grep "^$README " $user | cut -d ' ' -f17 )"
            READ6="$( grep "^$README " $user | cut -d ' ' -f18 )"
            if [ "$READ6" ]; then
              FIRST7="$( grep "^$README " $user | cut -d ' ' -f20 )"
              READ7="$( grep "^$README " $user | cut -d ' ' -f21 )"
              if [ "$READ7" ]; then
                FIRST8="$( grep "^$README " $user | cut -d ' ' -f23)"
                READ8="$( grep "^$README " $user | cut -d ' ' -f24)"
                if [ "$READ8" ]; then
                  FIRST9="$( grep "^$README " $user | cut -d ' ' -f26 )"
                  READ9="$( grep "^$README " $user | cut -d ' ' -f27 )"
                  if [ "$READ9" ]; then
                    FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4+$FIRST5+$FIRST6+$FIRST7+$FIRST8+$FIRST9" | bc -l )"
                    READ="$( echo "$READ+$READ2+$READ3+$READ4+$READ5+$READ6+$READ7+$READ8+$READ9" | bc -l )"
                    if [ "$DEBUG" = "TRUE" ]; then
                      echo "-> Nine stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
                    fi
                  else
                    FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4+$FIRST5+$FIRST6+$FIRST7+$FIRST8" | bc -l )"
                    READ="$( echo "$READ+$READ2+$READ3+$READ4+$READ5+$READ6+$READ7+$READ8" | bc -l )"
                    if [ "$DEBUG" = "TRUE" ]; then
                      echo "-> Eight stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
                    fi
                  fi
                else
                  FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4+$FIRST5+$FIRST6+$FIRST7" | bc -l )"
                  READ="$( echo "$READ+$READ2+$READ3+$READ4+$READ5+$READ6+$READ7" | bc -l )"
                  if [ "$DEBUG" = "TRUE" ]; then
                    echo "-> Seven stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
                  fi
                fi
              else
                FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4+$FIRST5+$FIRST6" | bc -l )"
                READ="$( echo "$READ+$READ2+$READ3+$READ4+$READ5+$READ6" | bc -l )"
                if [ "$DEBUG" = "TRUE" ]; then
                  echo "-> Six stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
                fi
              fi
            else
              FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4+$FIRST5" | bc -l )"
              READ="$( echo "$READ+$READ2+$READ3+$READ4+$READ5" | bc -l )"
              if [ "$DEBUG" = "TRUE" ]; then
                echo "-> Five stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
              fi
            fi
          else
            FIRST="$( echo "$FIRST+$FIRST2+$FIRST3+$FIRST4" | bc -l )"
            READ="$( echo "$READ+$READ2+$READ3+$READ4" | bc -l )"
            if [ "$DEBUG" = "TRUE" ]; then
              echo "-> Four stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
            fi
          fi
        else
          FIRST="$( echo "$FIRST+$FIRST2+$FIRST3" | bc -l )"
          READ="$( echo "$READ+$READ2+$READ3" | bc -l )"
          if [ "$DEBUG" = "TRUE" ]; then
            echo "-> Three stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
          fi
        fi
      else
        FIRST="$( echo "$FIRST+$FIRST2" | bc -l )"
        READ="$( echo "$READ+$READ2" | bc -l )"
        if [ "$DEBUG" = "TRUE" ]; then
          echo "-> Two stat sections found for $user $README - Total new: $FIRST $READ $THIRD"
        fi
      fi
      NADA="Yepp"
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "-> One stat section found for $user $README - Total new: $FIRST $READ $THIRD"
      fi        
    fi

    if [ "$DEFAULTSEC" != "$READ" ]; then
      if [ "$READ" != "0" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          sed -e "s/^$README .*/$README $FIRST $READ $THIRD/" $user > $TMP/$user.tmp
          cp -f $TMP/$user.tmp $user
          rm -f $TMP/$user.tmp
        fi
      else
        if [ "$DEBUG" = "TRUE" ]; then
          echo "NO change in stats for $user in $README (its 0)."
        fi
      fi
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "No change in stats for $user in $README"
      fi
    fi
    lastuser=$user
  done
  lastuser=$user
done

exit 0


