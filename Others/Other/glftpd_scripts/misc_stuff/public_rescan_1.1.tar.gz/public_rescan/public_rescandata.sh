## Data file for public_rescan.sh
## No changes should be made in this one.

siteroot=$1
folder=$2
rescan=$3
tmp=$4

cd $siteroot/$folder
$3
rm -f $tmp/public_rescan.lock
