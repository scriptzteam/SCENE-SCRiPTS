#!/bin/bash
VER=1.1
#############################################################
# Public Rescan by Turranius.                               #
#-----------------------------------------------------------#
# Welp, I love eur0dance's public undupe, so why not a      #
# public rescan script? :)                                  #
# This will let anyone in your IRC channel rescan a release.#
#-----------------------------------------------------------#
# Please note. This script is a major security risk because #
# of how it is used. If you have shell users on your box, I #
# do NOT suggest you use this script. Read on.              #
#-[ Installation ]------------------------------------------#
#                                                           #
# Copy this script and public_rescandata.sh to /glftpd/bin  #
# Make them both executable for the user that runs the bot. #
# Make sure you have a working rescan bin in /glftpd/bin.   #
# (rescan comes with Dark0n3s zipscript-c and should already#
# been set up before using this script.)                    #
# Copy public_rescan.tcl to your bots scripts folder and    #
# add it to the bots config file.                           #
#                                                           #
# Now for the insecure part. Copy chroot to /glftpd/bin and #
# do a "chmod +s chroot" on it. This is why the script is   #
# insecure. If anyone has a better idea of doing it, let me #
# know :)                                                   #
# I recomend you rename the version you just did +s on and  #
# set the new filename in the "chroot" setting below.       #
# I guess you could chmod it 700 and chown it to the user   #
# running the bot. A bit more secure.                       #
#                                                           #
# Set up the options below. Most of it should be ok in      #
# default mode if you run the standard glftpd installation. #
#                                                           #
# Now, run public_rescan.sh from shell and give it a try on #
# a few folders or something to make sure it works from     #
# shell. Once it does, rehash the bot and try !rescan from  #
# the irc channel.                                          #
# Remember to give the full path to the dir (after /site).  #
#                                                           #
# This script uses a lockfile so 2 people cant rescan at    #
# same time. If it happens to crap out and leave the        #
# lockfile, do !rescan removelock'. You can change that to  #
# some other word if you like (first line after "No changes #
# below here" ).                                            #
#-----------------------------------------------------------#
# Contact Turranius/Turran on efnet. Usually in #glftpd.    #
# WEB: http://www.grandis.nu & http://grandis.mine.nu       #
# EMAIL: turranius@hotmail.com                              #
#-[ Changelog ]---------------------------------------------#
# 1.1   : Add: Removed all the file listing the bot was     #
#              spitting out when it rescanned. It will now  #
#              only give the result.                        #
#              If you dont like this, remove the            #
#              | grep -v "File:                             #
#              near the end.                                #
#                                                           #
# 1.0   : Initial release.                                  #
#############################################################
#-[ Settings ]-

chroot=/glftpd/bin/chroot.gl    # Chroot binary
glroot=/glftpd                  # glftpd root

## Options below are relative to glroot above

siteroot=/site                  # Site root
tmp=/tmp                        # Temp storage
rescan=/bin/rescan              # Rescan binary
data=/bin/public_rescandata.sh  # Datascript path


######################################################
# No changes below here                              #
######################################################

if [ "$1" = "removelock" ]; then
  if [ -e $glroot$tmp/public_rescan.lock ]; then
    rm -f $glroot$tmp/public_rescan.lock
    echo "Lock file removed."
    exit 0
  else
    echo "No lockfile found for public_rescan."
    exit 0
  fi
fi

if [ "$1" = "version" ]; then
  echo "Public_Rescan $VER by Turranius"
  exit 0
fi

if [ -e $glroot$tmp/public_rescan.lock ]; then
  echo "Another rescan seems to be in progress. Please wait."
  exit 0
fi

folder=""
if [ "$1" = "" ]; then
  echo "Please specify full path to folder to rescan."
  exit 0
fi

if [ -e $glroot$siteroot/$1 ]; then
  folder=$1
  echo "Rescan found $1 and rescan is complete."
else
  echo "Can not find $1 to rescan."
  exit 0
fi

if [ "$folder" != "" ]; then
  touch $glroot$tmp/public_rescan.lock
  $chroot $glroot $data $siteroot $folder $rescan $tmp | grep -v "File:"
fi

exit 0
