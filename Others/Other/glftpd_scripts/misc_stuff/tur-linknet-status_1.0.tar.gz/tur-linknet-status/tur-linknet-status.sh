#!/bin/bash
VER=1.0
#-----------------------------------------------#
#                                               #
# Tur-Linknet-Status. A small script to show    #
# linkstatus of all linknet servers. Can also   #
# display all servers using argument 'all'      #
#                                               #
#--[ Install ]----------------------------------#
#                                               #
# Copy the .sh to anywhere you like. Make it    #
# executable (chmod 755).                       #
# Copy the .tcl to your bots scripts dir, edit  #
# it and change location of .sh and if you want #
# change the trigger too.                       #
#                                               #
# Only one setting. LINK. Its just where to get #
# the server list for linknet.                  #
#                                               #
# Run the script from shell to make sure it     #
# works. Rehash the bot and try it from irc.    #
#                                               #
#--[ Requirements ]-----------------------------#
#                                               #
# wget, basename, mv, grep, cut, tail           #
#                                               #
#--[ Contact ]----------------------------------#
#                                               #
# Contact Turranius on efnet/linknet. Usually   #
# in #glftpd on efnet.                          #
# http://www.grandis.nu/glftpd                  #
#                                               #
#--[ Settings ]---------------------------------#

LINK="http://www.link-net.org/home/nw.php"


#--[ Scripts Start ]----------------------------#

## Get the source webpage.
wget -T 5 -q --cookies=off $LINK

## Check that it got it ok. Rename it to linklist.
newname="$( basename $LINK )"
if [ ! -e "$newname" ]; then
  echo "Error. Couldnt get webpage."
  exit 0
else
  mv "$newname" "linklist"
fi

## Grab the info we want and announce it.
for each in `grep '<td bgcolor="#F0F0F0">' linklist | tr -s ' ' '^'`; do
  if [ "$( echo "$each" | grep "irc://" )" ]; then
    servername=`echo $each | cut -d '/' -f3 | cut -d '"' -f1`
  fi
  if [ "$( echo "$each" | grep "color=red" )" ]; then
    echo "$servername is split"
    found=yes
  else
    if [ "$1" = "all" ]; then
      if [ "$( echo "$each" | grep "Linked" )" ]; then
        echo "$servername is linked"
      fi
    fi
  fi
done

## If no split servers was found.
if [ -z "$found" ]; then
  echo "All servers seems linked."
fi

## Get the "last updated" time/date from source too.
TIME="$( grep '<IMG height=10 src="/images/arrow_r.jpg"' linklist | grep "M - " | cut -d '>' -f2 | cut -d '<' -f1 | tail -n1 )"
## Announce it.
echo "Serverlist time: $TIME"

## Remove the temp linklist and exit.
rm -f "linklist"
exit 0