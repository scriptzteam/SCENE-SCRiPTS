#!/bin/bash
VER=1.1
#--[ Intro ]-----------------------------------------------#
#                                                          #
# Tur-Bw. A script to show total bandwidth usage on the    #
# site.                                                    #
# Can also display an average bandwidth under a shorter    #
# period.                                                  #
#                                                          #
#--[ Installation ]----------------------------------------#
#                                                          #
# Copy tur-bw.sh to /glftpd/bin. chmod 755 tur-bw.sh       #
#                                                          #
# Copy tur-bw.tcl to your bots config dir. Change command  #
# it triggers on if you wish. Dont forget to rehash bot.   #
# Load it after the script your previously used for !bw if #
# you are too lazy to remove the old functionality.        #
#                                                          #
#--[ Settings ]--------------------------------------------#
#                                                          #
# WHOBIN  = This script uses tur-ftpwho (3.0+). This is    #
#           the full path to it. tur-ftpwho is a seperate  #
#           package available at my site. Running          #
#           tur-ftpwho -v should display atleast v 3.0.    #
#           If it shows no info, its not 3.0 =)            #
#                                                          #
# DIREXCLUDES = Dirs or part of dirs where it will not add #
#               the bandwidth from. If you dont want it to #
#               report bw from predirs, you can add those  #
#               here. Set to "" to show all bandwidth.     #
#                                                          #
# SHOWTOTAL = This is just how many users you allow at the #
#             same time on the site. Im too lazy to read   #
#             it from glftpd.conf.                         #
#                                                          #
# AVERAGE_RUNS  = If you wish to run tur-bw a few times &  #
#                 show the average bandwidth, set how many #
#                 times to loop the bandwidth check here.  #
#                 Set to "" or "0" to disable this.        #
#                                                          #
# DISPLAY_EACH_RUN = If you want to display the bw for     #
#                    each time it loops. Set this to TRUE  #
#                    or set FALSE to only show the average.#
#                    Only valid if AVERAGE_RUNS is set.    #
#                                                          #
# DISPLAY_AVERAGE  = If you want to show the average bw    #
#                    then set this to TRUE. Some people    #
#                    might only want to use                #
#                    DISPLAY_EACH_RUN=TRUE instead, so I   #
#                    made the average output optional.     #
#                    Only valid if AVERAGE_RUNS is set.    #
#                                                          #
# DELAY_BETWEEN_EACH = How many seconds to sleep between   #
#                      each run. Note that the bot will    #
#                      actually halt while running this    #
#                      script so setting this to 60 and    #
#                      AVERAGE_RUNS="3" will most likely   #
#                      cause the bot to timeout from the   #
#                      irc network.                        #
#                      Only valid if AVERAGE_RUNS is set.  #
#                                                          #
# FAKESPEED = "1.0" means it shows real speed. 2.0 would   #
#             fake the speed to be double of what it       #
#             actually is.                                 #
#             Can also set this one to "" for 1.0          #
#             Depending on regional settings, you might    #
#             have to set it to 1,0                        #
#                                                          #
# OUTPUT    = This is what it will say. See above it for   #
#             available cookies.                           #
#             There are 3 OUTPUT fields but two are        #
#             disabled with a #. Its just different ways   #
#             of doing it for examples.                    #
#                                                          #
# AVERAGE_OUTPUT = As OUTPUT, but will be used for showing #
#                  the average output line.                #
#                                                          #
#--[ Contact ]---------------------------------------------#
#                                                          #
#    http://www.grandis.nu                                 #
#                                                          #
#--[ Changelog ]-------------------------------------------#
#                                                          #
# 1.1 : Added support to show average bandwidth over a few #
#       runs.                                              #
#       If upgrading, make sure to replace the .tcl file   #
#       as well.                                           #
#                                                          #
#       Will now only show, for example, 150Kb/Sec instead #
#       of 150.75Kb/Sec.                                   #
#                                                          #
#--[ Configuration ]---------------------------------------#

WHOBIN=/glftpd/bin/tur-ftpwho

DIREXCLUDES="
/GROUPS
/site/DIVX/GROUPS
"

SHOWTOTAL=20

AVERAGE_RUNS=3
DISPLAY_EACH_RUN=TRUE
DISPLAY_AVERAGE=TRUE
DELAY_BETWEEN_EACH=2

FAKESPEED="1.0"

#--[ Cookies for OUTPUT ]----------------------------------#
#                                                          #
# %UPTOT%     = Total number of uploaders.                 #
# %UP%        = Speed of all uploaders.                    #
# %DNTOT%     = Total number of downloaders.               #
# %DN%        = Speed of all downloaders.                  #
# %TOTTRAN%   = Total number of up/downloaders.            #
# %TOTSPEED%  = Combined speed of up/downloads.            #
#                                                          #
# %IDLERS%    = All pure idlers.                           #
# %OTHER%     = Users doing other stuff (not really idle). #
# %ALLIDLERS% = %IDLERS% + %OTHER% combined.               #
# %TOTAL%     = Total number of users online.              #
# %SHOWTOTAL% = What you specified in SHOWTOTAL.           #
#                                                          #
#--[ Cookies for AVERAGE ]---------------------------------#
#                                                          #
# %UPAVERAGE% = Average speed of uploaders.                #
# %DNAVERAGE% = Average speed of downloaders.              #
# %TOTAVERAGE%= Average speed of uploaders+downloaders.    #
#                                                          #
#--[ Generic cookies ]-------------------------------------#
#                                                          #
# %BOLD%      = Start/Stop bold output.                    #
# %ULINE%     = Start/Stop underlined text.                #
# %COL%       = Color. Must be followed by a number.       #
#               For example %COL%1 would be black.         #
#               3 green, 4 red, 8 yellow etc.              #
#               Press ctrl-k in mirc to get a list (0-15)  #
#                                                          #
#               NOTE: Color number will show when running  #
#               from shell but it will look ok from irc.   #
#----------------------------------------------------------#

## Clean output (disabled).
#OUTPUT="-xXX- [BW] - [ UP: %UPTOT%/%UP%Kb/Sec ]-[ DN: %DNTOT%/%DN%Kb/Sec ]-[ Total: %TOTTRAN%/%TOTSPEED%Kb/Sec ]-[ Idle: %IDLERS% Other: %OTHER% (%ALLIDLERS%) ]-[ Online: %TOTAL%/%SHOWTOTAL% ]"

## Bold usage (enabled).
OUTPUT="-xXx- [BW] - [ UP: %BOLD%%UPTOT% at %UP%%BOLD% ]-[ DN: %BOLD%%DNTOT% at %DN%%BOLD% ]-[ Total: %BOLD%%TOTTRAN% at %TOTSPEED%%BOLD% ]-[ Idle: %BOLD%%IDLERS%%BOLD% Other: %BOLD%%OTHER%%BOLD% (%ALLIDLERS%) ]-[ Online: %BOLD%%TOTAL%%BOLD%/%SHOWTOTAL% ]"

## Color usage (disabled).
# OUTPUT="%COL%4-xXX-%COL%1 [BW] - [ UP: %COL%12%UPTOT%/%UP%%COL%1 ]-[ DN: %COL%12%DNTOT%/%DN%%COL%1 ]-[ Total: %COL%12%TOTTRAN%/%TOTSPEED%%COL%1 ]-[ Idle: %COL%12%IDLERS% %COL%1Other: %COL%12%OTHER%%COL%1 (%ALLIDLERS%) ]-[ Online: %COL%12%TOTAL%/%SHOWTOTAL%%COL%1 ]"

#---

## If AVERAGE_RUNS is set, show this at the end.
AVERAGE_OUTPUT="-xXx- [BW] - Average [ UP: %BOLD%%UPAVERAGE%%BOLD%Kb/Sec ]-[ DN: %BOLD%%DNAVERAGE%%BOLD%Kb/Sec ]-[ Total: %BOLD%%TOTAVERAGE%%BOLD%Kb/Sec ]"



#--[ Script Start ]----------------------------------------#

if [ ! -x "$WHOBIN" ]; then
  echo "Error. Cant execute $WHOBIN. Check perms and paths."
  exit 0
elif [ -z "$OUTPUT" ]; then
  echo "Error. No OUTPUT defined."
  exit 0
elif [ "`echo "100 + 100" | bc -l`" != "200" ]; then
  echo "Error. bc not installed? You'll need it."
  exit 0
fi

if [ "$DIREXCLUDES" ]; then
  DIREXCLUDES="`echo $DIREXCLUDES | tr -s ' ' '|'`"
else
  DIREXCLUDES="No0Dirs0At0All"
fi

proc_cookies() {
  if [ "$SHOWTOTAL" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SHOWTOTAL%/$SHOWTOTAL/g" )"
  fi
  if [ "$total" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTAL%/$total/g" )"
  fi
  if [ "$UP" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UP%/$UP/g" )"
  fi
  if [ "$UPTOT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UPTOT%/$UPTOT/g" )"
  fi
  if [ "$DN" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DN%/$DN/g" )"
  fi
  if [ "$DNTOT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DNTOT%/$DNTOT/g" )"
  fi
  if [ "$TOTSPEED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTSPEED%/$TOTSPEED/g" )"
  fi
  if [ "$TOTTRAN" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTTRAN%/$TOTTRAN/g" )"
  fi
  if [ "$IDLERS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%IDLERS%/$IDLERS/g" )"
  fi
  if [ "$OTHER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%OTHER%/$OTHER/g" )"
  fi
  if [ "$ALLIDLERS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALLIDLERS%/$ALLIDLERS/g" )"
  fi

  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%COL%//g" )"
}

proc_cookies_average() {
  if [ "$average_up" ]; then
    AVERAGE_OUTPUT="$( echo "$AVERAGE_OUTPUT" | sed -e "s/%UPAVERAGE%/$average_up/g" )"
  fi
  if [ "$average_dn" ]; then
    AVERAGE_OUTPUT="$( echo "$AVERAGE_OUTPUT" | sed -e "s/%DNAVERAGE%/$average_dn/g" )"
  fi
  if [ "$average_total" ]; then
    AVERAGE_OUTPUT="$( echo "$AVERAGE_OUTPUT" | sed -e "s/%TOTAVERAGE%/$average_total/g" )"
  fi
  AVERAGE_OUTPUT="$( echo $AVERAGE_OUTPUT | sed -e "s/%BOLD%//g" )"
  AVERAGE_OUTPUT="$( echo $AVERAGE_OUTPUT | sed -e "s/%ULINE%//g" )"
  AVERAGE_OUTPUT="$( echo $AVERAGE_OUTPUT | sed -e "s/%COL%//g" )"
}



average_up="0"; average_dn="0"; average_total="0"

if [ -z "$AVERAGE_RUNS" ] || [ "$AVERAGE_RUNS" = "0" ]; then
  AVERAGE_RUNS="1"
  DISPLAY_EACH_RUN=TRUE
  DISPLAY_AVERAGE=FALSE
  DELAY_BETWEEN_EACH="0"
fi

average_run="1"

while [ "$average_run" -le "$AVERAGE_RUNS" ]; do
  ## Save OUTPUT= so it dosnt get mashed up on each run.
  OUTPUT_TMP="$OUTPUT"

  ## Reset values to 0.
  total="0"; UP="0"; UPTOT="0"; DN="0"; DNTOT="0"; IDLERS="0"; OTHER="0"

  ## Count average runs + 1
  average_run=$[$average_run+1]
   
  for rawdata in `$WHOBIN | tr -d ' ' | egrep -v "$DIREXCLUDES"`; do
 
    unset speed; unset action

    ## Count total number of users online. +1 per user.
    total=$[$total+1]

    ## get current action from user.
    action="`echo "$rawdata" | cut -d '^' -f3`"

    ## Check if user is uploading or downloading.
    if [ "$action" = "Dn:" -o "$action" = "Up:" ]; then
      speed="`echo "$rawdata" | cut -d '^' -f4 | cut -d '.' -f1`"
 
      if [ "$action" = "Dn:" ]; then
        DN="`echo "$DN + $speed" | bc -l`"
        DNTOT=$[$DNTOT+1]
      else
        UP="`echo "$UP + $speed" | bc -l`"
        UPTOT=$[$UPTOT+1]
      fi

    ## If user is in Idle: state, plus 1 to $IDLERS.
    elif [ "$action" = "Idle:" ]; then
      IDLERS=$[$IDLERS+1]
    else
      ## If user is doing something else, plus 1 to OTHERS.
      OTHER=$[$OTHER+1]
    fi
  done

  ## If fakespeed is set, recalculate values.
  if [ "$FAKESPEED" ]; then
    DN="`echo "$DN * $FAKESPEED" | bc -l | cut -d '.' -f1`"
    UP="`echo "$UP * $FAKESPEED" | bc -l | cut -d '.' -f1`"
  fi

  ## Count total speed for this user.
  TOTSPEED="`echo "$UP + $DN" | bc -l | cut -d '.' -f1`"

  ## If display average is set to true, we need to plus all the ups and down
  ## together, as well as the total bw.
  if [ "$DISPLAY_AVERAGE" = "TRUE" ]; then
    average_up="`echo "$UP + $average_up" | bc -l`"
    average_dn="`echo "$DN + $average_dn" | bc -l`"
    average_total="`echo "$TOTSPEED + $average_total" | bc -l`"
  fi

  ## Number of uploaders and downloaders total.
  TOTTRAN="`echo "$UPTOT + $DNTOT" | bc -l`"

  ALLIDLERS=$[$IDLERS+$OTHER]

  ## If display each run is set, echo the output.
  if [ "$DISPLAY_EACH_RUN" = "TRUE" ]; then
    proc_cookies
    echo "$OUTPUT"
  fi

  if [ "$DELAY_BETWEEN_EACH" != "0" ] && [ "$DELAY_BETWEEN_EACH" ]; then
    sleep $DELAY_BETWEEN_EACH
  fi
  OUTPUT="$OUTPUT_TMP"

done

if [ "$DISPLAY_AVERAGE" = "TRUE" ]; then
  if [ "$average_up" != "0" ]; then
    average_up="`echo "$average_up / $AVERAGE_RUNS" | bc -l | cut -d '.' -f1`"
  fi
  if [ "$average_dn" != "0" ]; then
    average_dn="`echo "$average_dn / $AVERAGE_RUNS" | bc -l | cut -d '.' -f1`"
  fi
  if [ "$average_total" != "0" ]; then
    average_total="`echo "$average_total / $AVERAGE_RUNS" | bc -l | cut -d '.' -f1`"
  fi

  proc_cookies_average
  echo "$AVERAGE_OUTPUT"
fi

exit 0
