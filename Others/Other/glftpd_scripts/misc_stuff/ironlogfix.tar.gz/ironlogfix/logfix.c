#include <stdio.h>
#include <string.h>
#include <time.h>
/**********************************************************/
/* logfix by IronMike 2005                                */
/* Usage: ./logfix <logfile> <number_of_weeks_to_keep>    */
/*                                                        */
/* This sucker cleans your logs from a number of weeks    */
/* which can be sent via commandline or the default       */
/* number which is 2. The logs must have lines starting   */
/* with a date, e.g glftpd.log. I guess this program is   */
/* nice if u want a clean history. And in days like these */
/* we all should have a clean history. I guess its also   */
/* nice if u want to have smaller logfiles.               */
/*                                                        */
/* Compile: gcc logfix.c -o logfix                        */
/* Maybe use it in a daily crontab                        */
/*                                                        */
/*                                                        */
/*Have phun...                                            */
/**********************************************************/

#define MAXLENGTH 500
#define NOFILEERROR 99
#define FILEREADERROR 98
#define WEEKINSECONDS 604800 
#define DEFAULTNUMBEROFWEEKS 2

int main( int argc, char *argv[], int NUMBEROFWEEKS )
{
   FILE    *pfile;
   FILE    *presfile;
   char    tmpLine[MAXLENGTH];
   char    tempstring[9];  
   time_t  thetime;
   struct  tm *ptmstruct;
   int     bHit=0;
   char timebuf[10];
   /*Some nice checks*/
   if( argc < 2 ) 
   {
        /* No file...*/
        fprintf(stderr,"Usage: logfix <filename> <weeks>\n");
        return NOFILEERROR;
   }
   else if (argc < 3)
   {
      NUMBEROFWEEKS = DEFAULTNUMBEROFWEEKS;
   }
   else
   {
      NUMBEROFWEEKS = atoi(argv[2]);
   }
   /*Get the time in seconds. Removed some secs and fix the new date in a nice string*/
   time(&thetime);
   thetime = thetime - WEEKINSECONDS*NUMBEROFWEEKS;
   ptmstruct = localtime(&thetime);
   mktime(ptmstruct);
   strncpy(timebuf,asctime(ptmstruct),10);
   timebuf[10]='\0';
   pfile = fopen(argv[1],"r");
   if( pfile == NULL )
   {
       fprintf(stderr,"Couldn't open the file \"%s\"\n",argv[1]);
       return FILEREADERROR;
   }
   presfile = fopen("temp.log.new","w");
   
   while( fgets(tmpLine,MAXLENGTH,pfile) != NULL )
   {
      strncpy(tempstring, tmpLine, 10);
      if (0 == (strcmp(tempstring, timebuf)) )
      {
         bHit=1;       
      }
      if (bHit)
      {
         fputs(tmpLine,presfile);
      }
   }
   fclose(pfile);
   fclose(presfile);
   if(!bHit)
   {
      printf("%s\n","Found nothing. Log is prolly Ok!");   
   }
   else
   {
      remove(argv[1]);
      rename("temp.log.new", argv[1]);
   }
   return 0;
}
