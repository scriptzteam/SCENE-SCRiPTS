#!/bin/bash
VER=1.0

#--[ Intro ]------------------------------------------------------#
#                                                                 #
# Tur-AntiLeech - A script, by public demand, to stop users with  #
# leech to download raced releases or releases not yet completed. #
# A timelimit may be set that must pass before leechers can DL it #
#                                                                 #
#--[ Installation ]-----------------------------------------------#
#                                                                 #
# Copy tur-antileech.sh to /glftpd/bin. Set chmod 755 on it.      #
#                                                                 #
# Add to glftpd.conf: cscript retr PRE /bin/tur-antileech.sh      #
# (wait until after configuration =)                              #
#                                                                 #
# Requirements in /glftpd/bin:                                    #
# cut, egrep, date (supporting -d), file_date (included).         #
#                                                                 #
#--[ Settings ]---------------------------------------------------#
#                                                                 #
# LOG      = It will log what it does here. Used for debug        #
#            purposes. Create this file and set chmod 666 on it.  #
#            Set this to "" to disable logging. Can get spammy.   #
#                                                                 #
# FILEDATE = Where is file_date? This comes with this script and  #
#            should be compiled.                                  #
#            gcc -o file_date.c /glftpd/bin/file_date             #
#            Its only used if you want a timelimit on releases.   #
#            However, if you only want to block downloads until   #
#            the release is complete, you may skip this step and  #
#            set BLOCKTIME (below) to ""                          #
#                                                                 #
# DATEBIN  = We use date -d with BLOCKTIME. Some distros's date   #
#            binary does not support this. FreeBSD uses needs to  #
#            download and compile the sh-utils package for this.  #
#            Then specify the path to gdate here (gnu date).      #
#            Most users can leave it empty. It will just use date #
#            from path then so I hope its in your /glftpd/bin     #
#                                                                 #
# WORKIN   = Here you specify which dirs this script should run   #
#            in. Its a standard egrep line, so the default line   #
#            will execute this script if the current path contains#
#            either /SVCD/ or /DIVX/ etc.                         #
#            Set to "" to run in ALL dirs (not recomended really) #
#                                                                 #
# DENYFLAGS= If you wish, you may also specify a number of flags  #
#            here, | seperated. If you add one or more flags here #
#            then ONLY users with those flags will be blocked.    #
#            IGNOREFLAGS (below) is the exact opposite and theres #
#            no need to add flags to IGNOREFLAGS if you have this #
#            one set (empty by default).                          #
#                                                                 #
# IGNOREDIR= Same as above, but reversed. If the current dir      #
#            contains any of this, download will automatically be #
#            allowed.                                             #
#            Specify any requests or group predirs here (part of  #
#            the name anyway).                                    #
#            Set to "" to not ignore any dirs.                    #
#                                                                 #
# IGNOREFLAGS = A number of flags, seperated with |. If the user  #
#               has any of these flags, download will be allowed  #
#               and this script will ignore him/her.              #
#               Set to "" to not ignore any flags.                #
#                                                                 #
# IGNOREFILES = Another egrep line. If the user tries to download #
#               a file matching this, it will be allowed.         #
#               \.nfo$ means .nfo. The $ forces end, so .nfo.fix  #
#               will still be denied whereas .nfo will be ok.     #
#               Set to "" to not ignore any files.                #
#                                                                 #
# IGNOREGRP= TRUE/FALSE. Setting this to true will look at the    #
#            users PRIMARY group and see if it matches the rel.   #
#            If it does, download will be allowed. Note that it   #
#            only works on the primary group. Faster that way as  #
#            we dont have to read the userfile to get the group.  #
#                                                                 #
#            This is so affils get access to their own preed rels #
#            even if they have leech and the rel was just preed.  #
#                                                                 #
# IGNOREGROUPS = A number of groupnames, seperated by |           #
#                If the users primary group matches any of these  #
#                then download is automatically accepted.         #
#                Disabled by default ("").                        #
#                                                                 #
# COMPLETE = What does your zipscripts complete dir contain?      #
#            Per default, its " COMPLETE ". Escape any non alpha  #
#            chars with a \ (as with every other setting above).  #
#            Set to "" to skip this check and only use BLOCKTIME. #
#                                                                 #
# BLOCKTIME = If there is no COMPLETE dir in the release, how old #
#             must the release be before we allow leechers to     #
#             download it? This amount is in minutes.             #
#             If you set this to "", we will only allow downloads #
#             when there is a COMPLETE dir in the release. But    #
#             that can be bad. Users with leech wont be able to   #
#             download anything if theres no COMPLETE dir.        #
#             That is, in the WORKIN dirs, and its not IGNOREDIR. #
#                                                                 #
# BLOCKMSG  = What to echo the user incase the file is blocked    #
#             for download. Change the text to suit your setup    #
#             above.                                              #
#                                                                 #
#             If you are using BLOCKTIME, there are two cookies   #
#             you may use in this text.                           #
#             %OLD%  = How old the release is in minutes.         #
#             %LEFT% = How many minutes left until its leechable. #
#             If you dont have BLOCKTIME and FILEDATE defined     #
#             then dont use those cookies.                        #
#                                                                 #
# CHECKDIR  = TRUE/FALSE. If TRUE and BLOCKTIME is enabled, it    #
#             will check the date on the dir itself. If FALSE     #
#             then it will check the time on the file the user is #
#             trying to download. If you remove a file or so in   #
#             the release, the dir date will change to now, thus  #
#             blocking it for leechers again. So FALSE is to      #
#             recomend I guess.                                   #
#                                                                 #
# All settings are by default case sensitive.                     #
#                                                                 #
#--[ Info ]-------------------------------------------------------#
#                                                                 #
# Heres how it works with:                                        #
#                                                                 #
# COMPLETE  = Defined                                             #
# BLOCKTIME = Defined                                             #
# It will check if the dir is old enough to download. If it is    #
# NOT, it will check if there is a COMPLETE dir in the release.   #
# If there is, the user can download it. If theres no COMPLETE dir#
# in the release, the user will be blocked until there is either  #
# a COMPLETE dir in it OR it gets older then the defined # of     #
# minutes.                                                        #
#                                                                 #
# COMPLETE  = Defined                                             #
# BLOCKTIME = Not Defined ("")                                    #
# If there is no COMPLETE dir in the release, the user will be    #
# denied download.                                                #
#                                                                 #
# COMPLETE  = Not Defined ("")                                    #
# BLOCKTIME = Defined                                             #
# If the dir is not old enough, the user will be denied download  #
# of the file.                                                    #
#                                                                 #
# WORKIN, IGNOREDIR, IGNOREFLAGS and IGNOREFILES all come into    #
# account for all above examples, if they are defined that is.    #
# Of course, if the RATIO is not 0, it will allow anything        #
# instantly (thats the first thing it checks).                    #
#                                                                 #
# Problem: Pred dirs are not old enough but they do contain a     #
# COMPLETE dir, thus even leechers get to download it instantly.  #
# If you dont like it, set COMPLETE to "" and it will only check  #
# that the release is old enough. Hope your prescript resets the  #
# date/time of the pred release =)                                #
# Make sure to exclude any groupdirs, requests and archive..      #
#                                                                 #
#-                                                               -#
# Once everything works as you like, you should cut out this      #
# readme part to speed it up a microsecond.                       #
# Its a good idea to set LOG="" unless debugging/testing it.      #
#                                                                 #
#--[ Contact ]----------------------------------------------------#
#                                                                 #
# I've basically stopped supporting my scripts from IRC cause I   #
# dont have the time. Use the forums at my place instead.         #
# http://www.grandis.nu/glftpd or http://grandis.mine.nu/glftpd   #
#                                                                 #
#--[ Settings ]---------------------------------------------------#

LOG=/ftp-data/logs/test.log
FILEDATE=/bin/file_date
DATEBIN=""

WORKIN="\/SVCD\/|\/DIVX\/|\/ISO-UTILS\/|\/0DAYS\/|\/PDA\/|\/XBOX\/|\/VCD\/"
DENYFLAGS=""

IGNOREDIR="\/GROUPS|\/PRE\_\/|\/Archive\/|\/REQUESTS\/"
IGNOREFLAGS="1|7|J"
IGNOREFILES="\.nfo$|\.txt$"
IGNOREGRP=TRUE
IGNOREGROUPS=""

COMPLETE="\ COMPLETE\ "

BLOCKTIME="30"
BLOCKMSG="This release is only %OLD% minutes old. You wont be able to leech it for another %LEFT% mins, leecher."
CHECKDIR="FALSE"

#--[ Script Start ]-----------------------------------------------#

filename=`echo "$1" | cut -d ' ' -f2`
curuser="$USER"

if [ -z "$DATEBIN" ]; then
  DATEBIN="date"
fi

## Is LOG enabled? Check if we can write to it.
if [ "$LOG" ]; then
  if [ ! -w "$LOG" ]; then
    echo "Tur-AntiLeech Error. LOG is defined as $LOG but I cant write to that file. Create it and set 766 perms on it."
    exit 1
  fi
fi

proc_log() {
  if [ "$LOG" ]; then
    echo `$DATEBIN "+%a %b %e %T %Y"` "$USER - $@" >> $LOG
  fi
}

## Does this user have leech? If not, quit.
if [ "$RATIO" != "0" ]; then
  proc_log "Quitting. $USER has ratio $RATIO, not 0."
  exit 0
fi

if [ "$DENYFLAGS" ]; then
  if [ -z "`echo "$FLAGS" | egrep "$DENYFLAGS"`" ]; then
    proc_log "Not running in $PWD - $USER has flags $FLAGS and only $DENYFLAGS are denied."
    exit 0
  fi
fi

if [ "$IGNOREGROUPS" ]; then
  if [ "`echo "$GROUP" | egrep "$IGNOREGROUPS"`" ]; then
    proc_log "Not running in $PWD - $USER's primary group is $GROUP and $IGNOREGROUPS are excluded."
    exit 0
  fi
fi

## If BLOCKTIME is set, can we execute file_date ?
if [ "$BLOCKTIME" ]; then
  if [ ! -x "$FILEDATE" ]; then
    if [ ! -e "$FILEDATE" ]; then
       proc_log "Error. Can not find file_date in $FILEDATE - Allowing download."
       exit 0
    else
      proc_log "Error. Cant execute FILEDATE ($FILEDATE). Check perms on it - Allowing download."
      exit 0
    fi
  fi
fi

if [ "$IGNOREGRP" = "TRUE" ]; then
  if [ "$GROUP" ]; then
    if [ "`echo "$PWD" | egrep "[-\_\.]$GROUP\/|[-\_\.]$GROUP$"`" ]; then
      proc_log "Not running in $PWD - $USER's primary group is $GROUP which matches release."
      exit 0
    fi
  fi
fi

## If WORKIN is set, check if were in a dir we should run in.
if [ "$WORKIN" ]; then
  if [ -z "`echo "$PWD" | egrep "$WORKIN"`" ]; then
     proc_log "Not running in $PWD. Not in any WORKIN paths ($WORKIN)."
     exit 0
  fi
fi

## If IGNOREDIR is set, check if were in an ignored dir.
if [ "$IGNOREDIR" ]; then
  if [ "`echo "$PWD" | egrep "$IGNOREDIR"`" ]; then
    proc_log "Not running in $PWD. Set as ignored dir in IGNOREDIR ($IGNOREDIR)."
    exit 0
  fi
fi

## Is IGNOREFILES set? If so, check if the file about to be downloaded is excluded.
if [ "$IGNOREFILES" ]; then
  if [ "`echo "$filename" | egrep "$IGNOREFILES"`" ]; then
    proc_log "Not running on $filename. Excluded file in IGNOREFILES ($IGNOREFILES)."
    exit 0
  fi
fi

## Check if the user has an excluded flag.
if [ "$IGNOREFLAGS" ]; then
  if [ "`echo "$FLAGS" | egrep "$IGNOREFLAGS"`" ]; then
    proc_log "Skipping check for user $curuser. He has excluded flag"
    exit 0
  fi
fi

## Procedure for calculating time difference.
proc_calctime() {
  DAYDIFF=0
  MINDIFF=0
  SECDIFF=0

  let DIFF=$NOWTIMES-$RELTIMES;
  if [ $DIFF -lt 0 ]; then
    let DIFF=DIFF*-1
  fi

  let MINDIFF=$DIFF/60
}

proc_cookies() {
  if [ "$MINDIFF" ]; then
    BLOCKMSG="$( echo "$BLOCKMSG" | sed -e "s/%OLD%/$MINDIFF/g" )"
    LEFT=$[$BLOCKTIME-$MINDIFF]
  fi
  if [ "$LEFT" ]; then
    BLOCKMSG="$( echo "$BLOCKMSG" | sed -e "s/%LEFT%/$LEFT/g" )"
  fi
}

## If BLOCKTIME is set, check if the dir is old enough. 
if [ "$BLOCKTIME" ]; then
  if [ "$CHECKDIR" = "TRUE" ]; then
    RELTIME=`$FILEDATE $PWD`
  else
    RELTIME=`$FILEDATE $PWD/$filename`
  fi

  RELTIMES=`$DATEBIN -d "$RELTIME" +%s`
  NOWTIMES=`$DATEBIN +%s`

  proc_calctime

  ## If the release isnt old enough yet...
  if [ "$MINDIFF" -le "$BLOCKTIME" ]; then

    ## If COMPLETE is defined, check if that dir exists.
    ## If it dosnt, dont allow this file to be downloaded.
    if [ "$COMPLETE" ]; then
      if [ -z "`ls -1 | egrep "$COMPLETE"`" ]; then
        proc_cookies
        echo -e "550$BLOCKMSG"
        proc_log "Denying download of $filename in $PWD. Only $MINDIFF mins old and no COMPLETE dir."
        exit 1
      else
        proc_log "Allowing $filename in $PWD. Only $MINDIFF mins old, but it has a complete dir."
        exit 0
      fi
    ## If COMPLETE is NOT defined, just block it from being downloaded.
    else
      proc_cookies
      echo -e "550$BLOCKMSG"
      proc_log "Denying download of $filename in $PWD. Only $MINDIFF minutes old."
      exit 1
    fi      
  fi

else

  ## If BLOCKTIME is not set, check if the rel is complete.
  ## If it isnt, deny the download.
  if [ -z "`ls -1 | egrep "$COMPLETE"`" ]; then
    proc_cookies
    echo -e "550$BLOCKMSG"
    proc_log "Denying download of $filename in $PWD. No COMPLETE dir found."
    exit 1
  fi
fi

if [ "$MINDIFF" ]; then
  proc_log "Allowing download of $filename in $PWD - $MINDIFF minutes old."
else
  proc_log "Allowing download of $filename in $PWD - All checks passed."
fi

exit 0
