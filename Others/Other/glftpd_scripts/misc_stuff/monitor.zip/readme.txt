too much to tell, and no motivation.
Sections.txt Sendto.txt and Monitor.txt in your mirc root.
monitor.mrc and presites.dat in the /mirc/monitor dir.
load monitor.mrc
right click on bots with spews.
alter monitor.txt and sendto.txt to make it do what you want.
Sections.txt and the sections monitor.mrc writes are independant.

monitor.mrc tries to stick rls in appropriate sections, but 
presites.dat has the final say on the genre according to what header the 
rls group name is under.

all of this stuff is highly customizable.
not the triggers at the end of monitor.mrc where you can have people 
tell your script to add groups or genres.
to message more than one channel just enter each channel on its own line in sendto.txt

I think weudl (later karli) wrote this. If you see him (i cant find him) thank him.

if you abso-fucking-lutely need help and are willing to give for what you get (heh)
email dave.makie@gmail.com