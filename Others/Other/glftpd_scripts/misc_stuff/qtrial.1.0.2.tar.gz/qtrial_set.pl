#!/usr/bin/perl

#including
require("/glftpd/bin/qtrial_config.pl");
#end of including
#parametrs
$user = @ARGV[0];
if (!$user) {
print $textuserno;

exit(0);
}

#end of parametrs
$userfile = $glftpd."/ftp-data/users/".$user;
if (!(-f $userfile)) {
$a = $textnouser;
$a =~ s/%user%/$user/ig;
print $a;
exit(0);
}

open("userfile","<$userfile");
while(<userfile>) {
if ($_ =~ /^ALLUP (.*)/) {
$allup = $1; 
}
}
@allup = split(' ',$allup);
$upped = 0;
for($i=0;$i<($sections*3);$i=$i+3) {
$upped = $upped+@allup[$i+1];
}
 
if ( $use_mysql eq "yes" ) { print "test\n"; } 
else
{
open("trialfile",">$trialuserdir/$user");
print trialfile `date +%Y`;
print trialfile `date +%m`;
print trialfile `date +%d`;
print trialfile "$upped";
close(trialfile);
}
$a = $textadduser;
$a =~ s/%user%/$user/ig;
print $a;