#!/usr/bin/perl
require("/glftpd/bin/qtrial_config.pl");
open(BOTFILE,">>$glftpd/$botfile");
my ($user, $allup, $istrial, $userfile);
use Date::Calc;
@ls = `ls $glftpd/$trialuserdir`;

foreach $user (@ls) {
$user =~ s/\n//ig;
$userfile = $glftpd."/ftp-data/users/" . $user; 

if(open(USERFILE,"$userfile")) {
while(<USERFILE>) {
if ($_ =~ /^ALLUP (.*)/) {
$allup = $1;
} 

}
close(USERFILE);

@allup = split(' ',$allup);
$upped = 0;
for($i=0;$i<($sections*3);$i=$i+3) {
$upped = $upped+@allup[$i+1];
}
$trialfile = $glftpd."/ftp-data/trial_users/" . $user;
open(TRIALFILE,"$trialfile") || nouser($textnotrial,$user);;
@lines = <TRIALFILE>;
#       Delta_Days
#       $Dd = Delta_Days($year1,$month1,$day1,
#                        $year2,$month2,$day2);
$is[0] = `date +%Y`;
$is[1] = `date +%m`;
$is[2] = `date +%d`;
$roznica = Date::Calc::Delta_Days($lines[0],$lines[1],$lines[2],$is[0],$is[1],$is[2]);
$wasup = $lines[3];
close(TRIALFILE);
#
$upped = $upped-$wasup;
$dni = $tte-$roznica;
$danych = ($mtu-$upped)/1024;
$danych = sprintf("%.1f", $danych);

if ( $upped < $mtu ) {
if ($roznica <= $tte) {

} else {
$deleted=0;
open(USERFILE,"$userfile");
while(<USERFILE>) {
if ($_ =~ /FLAGS.*6.*/) {
$deleted=1;
}
}
close(USERFILE);
if ($deleted==0) { 
open(USERFILE,"$userfile");

$userfiletmp = $userfile.".temp";
open(UFT,">$userfiletmp");
while(<USERFILE>) {
if ($_ =~ /FLAGS.*6.*/) {
$deleted=1;
} else {
s/^FLAGS /FLAGS 6/;
}
print UFT $_;

}
close(USERFILE);
close(UFT);
system("mv $userfiletmp $userfile");

$textdonttrialbw = $textdonttrialb;
$textdonttrialbw =~ s/%user%/$user/ig;
$textdonttrialbw =~ s/%time%/$dni/ig;
$textdonttrialbw =~ s/%toup%/$danych/ig;
print BOTFILE "$textdonttrialbw";

}
}
}
else {
$textendtrialbw = $textendtrialb;
$textendtrialbw =~ s/%user%/$user/ig;
$textendtrialbw =~ s/%time%/$dni/ig;
$textendtrialbw =~ s/%toup%/$danych/ig;
print BOTFILE "$textendtrialbw";
system("rm -rf $trialfile");
}

} else {
nouser($textnouser,$user);
}
}
close(BOTFILE);
sub nouser {
@_[0] =~ s/%user%/@_[1]/ig;
print @_[0];
}