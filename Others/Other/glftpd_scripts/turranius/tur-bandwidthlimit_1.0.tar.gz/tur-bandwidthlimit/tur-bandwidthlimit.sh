#!/bin/bash
VER=1.0

#--[ Intro ]--------------------------------------------#
#                                                       #
# Tur-BandwidthLimit. A script that checks the traffic  #
# your site has generated and takes some action once a  #
# certain limit has been reached. It can also reverse   #
# this procedure with a simple command.                 #
#                                                       #
#-[ Install ]-------------------------------------------#
#                                                       #
# Copy tur-bandwidthlimit.sh to /glftpd/bin.            #
# chmod it to 700.                                      #
#                                                       #
# Make sure you have the binary 'bc' installed. If not, #
# install it.                                           #
#                                                       #
# Decide what you want to do when the limit is reached. #
#                                                       #
# If its an option in glftpd.conf that you want to      #
# change, put that into an external file, like          #
# /etc/glftpd.shutdown.conf.down                        #
#                                                       #
# Also create an opposite file called                   #
# /etc/glftpd/shutdown.conf.open                        #
# in which you reverse these settings.                  #
#                                                       #
# Next, we need to remove those options from the real   #
# glftpd.conf if its already in there and replace it    #
# with an 'include' line for a script.                  #
#                                                       #
# Lets say you want to shutdown the site when closing   #
# and opening it up again when opening.                 #
# Create those two files above. In the .down file, we   #
# add: shutdown !*                                      #
# In the .open file, we add: shutdown *                 #
#                                                       #
# Now, remove the 'shutdown' line in /etc/glftpd.conf   #
# and instead add a line, like:                         #
# include /etc/glftpd.shutdown.conf                     #
# Note that we use a 3rd filename here. Do NOT specify  #
# the .down or .up files here.                          #
#                                                       #
# Why were doing this will become clear soon.           #
# Next, go over these settings:                         #
#                                                       #
#--[ Settings ]-----------------------------------------#
#                                                       #
# ftp  =   Full path to the ftp binary.                 #
#                                                       #
# user   = The username that will log on to the site    #
#          and do the stuff. Make sure he has access to #
#          'site traffic'                               #
#          This user should NOT have flag 5 (color).    #
#                                                       #
# pass   = The above users password.                    #
#                                                       #
# host   = Hostname to log into. Just the hostname.     #
#                                                       #
# port   = Port of above hostname.                      #
#                                                       #
# LOG    = Full path to the log, should you want it.    #
#          Otherwise, set to "".                        #
#                                                       #
# LOGLVL = If above is set, you can set this to either  #
#          1 or 2. If 1, it will only log when closing  #
#          and opening. If its set to 2, it will log    #
#          each time it runs 'close', with the current  #
#          traffic values.                              #
#          Any errors are logged, no matter the level.  #
#                                                       #
# WORK_ON = Which traffic duration do you want it to    #
#           count? Options are:                         #
#           Total, Month, Week or Day                   #
#                                                       #
# UP_LIMIT  = Whats the total upload limit in MB before #
#             you want the script to react. If you dont #
#             want it to react to upload limit, set it  #
#             to "".                                    # 
#                                                       #
# DN_LIMIT  = Same as UP_LIMIT, but for downloaded      #
#             traffic.                                  #
#                                                       #
# TOT_LIMIT = If instead, you want it to react on total #
#             traffic (both up and down), set this to   #
#             the traffic in MB before we react.        #
#                                                       #
#             You can enable just one or all of the     #
#             above 3 options.                          #
#             First one to be reached will trigger the  #
#             script.                                   #
#                                                       #
# SHUTDOWN_CUSTOM =                                     #
#             Ok, here we set what it should do when    #
#             the traffic has been reached.             #
#             As you can see from the example, it       #
#             simply copies our                         #
#             glftpd.shutdown.conf.down file, replacing #
#             the glftpd.shutdown.conf file (which we   #
#             included in glftpd.conf).                 #
#                                                       #
#             It will simply execute what you tell it   #
#             to here, so anything goes (cant pipe).    #
#                                                       #
# OPEN_CUSTOM =                                         #
#             What to do when opening again. As you see #
#             from the example, it just copies our      #
#             glftpd.shutdown.conf.up file, replacing   #
#             the glftpd.shutdown.conf file.            #
#                                                       #
# KICK_ALL_ON_CLOSE = TRUE/FALSE. When the bandwidth is #
#                     reached, do you also want to kick #
#                     all online users? Changes in      #
#                     glftpd.conf dosnt kick in until   #
#                     the users relogin, so this might  #
#                     be a good thing.                  #
#                                                       #
# KICK_ALL_ON_OPEN  = TRUE/FALSE. Same as above, but    #
#                     when opening up again.            #
#                                                       #
# TURFTPWHO = If either if the above two are TRUE,      #
#             you'll need tur-ftpwho.                   #
#             This binary can be found at my webpage as #
#             well and must be working. Set the full    #
#             path to it here.                          #
#                                                       #
#--[ Info ]---------------------------------------------#
#                                                       #
# Running it with argument 'test' will verify if your   #
# ftp settings are correct and that the users specified #
# has access to 'site traffic'.                         #
#-                                                      #
# Running it with no arguments will show the other      #
# commands.                                             #
#-                                                      #
# The idea is that you crontab this script as often as  #
# you like to check if the traffic has been reached.    #
# Then, once a month or so (whenever your bw cap is     #
# reset), you crontab it to open the site again.        #
#                                                       #
# Example, run 'close' every hour and open one minute   #
# past midnight on the 1st of each month.               #
# */60 * * * * /glftpd/bin/tur-bandwidthlimit.sh close  #
# 1 0 1 * * /glftpd/bin/tur-bandwidthlimit.sh open      #
#-                                                      #
# You can put anything in the glftpd.shutdown.conf.*    #
# files as you normally would put in glftpd.conf.       #
#-                                                      #
# While you can not pipe text to another file with      #
# SHUTDOWN_CUSTOM or OPEN_CUSTOM, you can call other    #
# scripts which can.                                    #
# So, if you want it to also announce when closing,     #
# make a shell script that does what you want and echoes#
# to glftpd log with your announce. Then call that file #
# from SHUTDOWN_CUSTOM or OPEN_CUSTOM.                  #
#                                                       #
#--[ Contact ]------------------------------------------#
#                                                       #
# http://www.grandis.nu/glftpd - http://grandis.mine.nu #
#                                                       #
#--[ Settings ]-----------------------------------------#

ftp=/usr/bin/ftp
user=glftpd
pass=glftpd
host=localhost
port=21

LOG=/glftpd/ftp-data/logs/tur-bandwidthlimit.log
LOGLVL=1

WORK_ON="Month"

UP_LIMIT="" # MB
DN_LIMIT="" # MB
TOT_LIMIT="300000" # MB

SHUTDOWN_CUSTOM="cp -f /glftpd/etc/glftpd.shutdown.conf.down /glftpd/etc/glftpd.shutdown.conf"
OPEN_CUSTOM="cp -f /glftpd/etc/glftpd.shutdown.conf.up /glftpd/etc/glftpd.shutdown.conf"

KICK_ALL_ON_CLOSE=FALSE
KICK_ALL_ON_OPEN=FALSE
TURFTPWHO=/glftpd/bin/tur-ftpwho


#--[ Script Start ]-------------------------------------#

if [ ! -x "$ftp" ]; then
  echo "Error. Can not execute $ftp. Make sure its there and executable by the user running this bot."
  exit 1
fi

## Procedure for putting stuff in the log.
proc_log() {
  if [ "$LOG" ]; then
    if [ "$LOGLEVEL" -le "$LOGLVL" ]; then
      echo `date "+%a %b %e %T %Y"` BWLMT: \"$*\" >> $LOG
    fi
  fi
}

## Procedure for running the close procedure.
proc_close() {
  LOGLEVEL=1
  if [ "$FORCE" != "TRUE" ]; then
    proc_log "Running Close procedure. UPMB=$UPSTATS - DNMB=$DOWNSTATS - TOTMB=$TOTALSTATS"
  else
    proc_log "Running Close procedure. Forced close."
  fi  
  if [ "$SHUTDOWN_CUSTOM" ]; then
    $SHUTDOWN_CUSTOM
  fi
  if [ "$KICK_ALL_ON_CLOSE" = "TRUE" ]; then
    proc_kickall
  fi
  closed=true
}

## Procedure for running the open procedure.
proc_open() {
  LOGLEVEL=1
  proc_log "Running Open procedure."
  if [ "$OPEN_CUSTOM" ]; then
    $OPEN_CUSTOM
  fi
  if [ "$KICK_ALL_ON_OPEN" = "TRUE" ]; then
    proc_kickall
  fi
}

## Procedure for kicking everyone on site.
proc_kickall() {
  if [ ! -x "$TURFTPWHO" ]; then
    LOGLEVEL=1
    proc_log "Error when kicking users - $TURFTPWHO is not executable or does not exist."
    exit 1
  fi

  for eachpid in `$TURFTPWHO | tr -d ' ' | cut -d '^' -f2`; do
    # echo "$eachpid kicked"
    kill -9 $eachpid
  done
}

## Procedure for running the test procedure.
proc_test() {
  echo "Testing that everything works as it should."
  echo "It should log in and show the traffic statistics"
  echo "Running: echo -e \"user $user $pass\nsite traffic\" | $ftp -vn $host $port | grep -A11 \"Traffic Statistics\""

  until [ -n "$go" ]; do
    echo -n "Ready to go? [Y]es [N]o: "
    read go
    case $go in
      [Nn])
        exit 0
        continue
        ;;
      [Yy])
        echo " "
        go=n
        ;;
      *)
       unset go
       continue
       ;;
    esac
  done
  unset go

  echo ""
  echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | grep -A11 "Traffic Statistics"
  echo ""
  echo "If you see the traffic info above, the login is good. If not, make sure ftpinfo is correctly"
  echo "defined in the script and that the user has access to 'site traffic' ( -traffic in glftpd.conf )."
  echo ""
}

## Procedure for checking amount of traffic and if its above the limit(s) set.
proc_closecheck() {

  if [ "$FORCE" = "TRUE" ]; then
    proc_close
    exit 0
  fi

  RESULT=`echo -e "user $user $pass\nsite traffic" | $ftp -vn $host $port | grep -A11 "Traffic Statistics" | egrep " Uploads | Downloads " | cut -c8- | tr -d '|' | tr -s ' ' | tr ' ' '^'`

  if [ -z "$RESULT" ]; then
    LOGLEVEL=1
    proc_log "Error. Did not get any result from 'site traffic' query. Check settings and run the test."
    exit 1
  fi

  for rawline in $RESULT; do
    if [ "`echo "$rawline" | grep -i "$WORK_ON"`" ]; then
      if [ "`echo "$rawline" | grep "\^Uploads\^"`" ]; then
        UPSTATS="`echo "$rawline" | cut -d '^' -f4`"
      fi
      if [ "`echo "$rawline" | grep "\^Downloads\^"`" ]; then
        DOWNSTATS="`echo "$rawline" | cut -d '^' -f4`"
      fi
    fi
  done

  if [ -z "$UPSTATS" ] || [ -z "$DOWNSTATS" ]; then
    LOGLEVEL=1
    proc_log "Error. Did not get UPSTATS and/or DOWNSTATS for $WORK_ON."
    proc_log "Upstats read as  : $UPSTATS MB"
    proc_log "Downstats read as: $DOWNSTATS MB" 
    proc_log "------------------------"
    exit 1
  fi

  TOTALSTATS="`echo "$UPSTATS + $DOWNSTATS" | bc -l | tr -d ' '`"
  LOGLEVEL=2
  proc_log "Traffic so far: UPMB=$UPSTATS - DNMB=$DOWNSTATS - TOTMB=$TOTALSTATS"

  if [ "$UP_LIMIT" ]; then
    if [ "$UPSTATS" -ge "$UP_LIMIT" ]; then
      proc_close
    fi
  fi
  if [ "$DN_LIMIT" ] && [ "$closed" != "true" ]; then
    if [ "$DOWNSTATS" -ge "$DN_LIMIT" ]; then
      proc_close
    fi
  fi
  if [ "$TOT_LIMIT" ] && [ "$closed" != "true" ]; then
    if [ "$TOTALSTATS" -ge "$TOT_LIMIT" ]; then
      proc_close
    fi
  fi
}

## Show help.
proc_help() {
  echo ""
  echo "Tur-BandwidthLimit $VER by Turranius"
  echo "Commands are:"
  echo "test  = Test the connection."
  echo "open  = Open the site (reverse any 'close' settings)."
  echo "close = Run the check if site should be closed."
  echo "        Specify 'force' as 2nd arg to force a close."
  echo ""
}

## Main menu.
case $1 in
  [tT][eE][sS][tT]) proc_test; exit 0 ;;
  [oO][pP][eE][nN]) proc_open; exit 0 ;;
  [cC][lL][oO][sS][eE]) if [ "$2" = "force" ]; then FORCE=TRUE; fi; proc_closecheck; exit 0 ;;
  *) proc_help; exit 0 ;;
esac

exit 0
