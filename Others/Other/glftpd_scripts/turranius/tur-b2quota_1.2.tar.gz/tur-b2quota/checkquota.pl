#!/usr/bin/perl -w
#VER=1.2

use HTTP::Request::Common;
use LWP::UserAgent;
use HTTP::Cookies;
my $ua = LWP::UserAgent->new;
$ua->cookie_jar(HTTP::Cookies->new);

sub get_url { 
  my $url = shift;
  my $r = $ua->request(GET $url);
  die "HTTP problem" unless $r->is_success;
  return $r->content;
}

my $answer = $ua->request(
  POST 'http://www.bredband.net/portal/PRIVAT_MITTKONTO_100MBIT',
       Content_Type => 'application/x-www-form-urlencoded',
       Content      => [ server => "www.bredband.net",
                         module     => "com.med.phd.LoginModule",
                         action   => "verify",
                         Username => "username",
                         Password => "password",
                       ],
  )->as_string;;


$answer = $ua->request(
  GET 'http://www.bredband.net/portal/PRIVAT_MITTKONTO_100MBIT',
       Content_Type => 'text/html; charset=ISO-8859-1',
                       
  )->as_string;;

if ($answer =~ /nowrap\>([0-9]+) GB\</)
{
    my $bbbcredits = $1;
    my $updatedate = "0000-00-00";
    my $updatetime = "00:00";
    if ($answer =~ /nowrap\>([0-9]{4}\-[0-9]{2}\-[0-9]{2}) ([0-9]{2}:[0-9]{2}) <\/td>/)
    {
      $updatedate = $1;
      $updatetime = $2;
    }
    print $bbbcredits . " " . $updatedate . " " . $updatetime;
    print "\n";
}
else
{
    print "-1\n";
}
