#!/bin/bash
VER=1.1

#--[ Intro ]------------------------------------------------------#
#                                                                 #
# Tur-User_Traffic_Limit. A script that will monitor and          #
# prohibit users from downloading and/or uploading too much in    #
# a single day/week/month.                                        #
#                                                                 #
# If you'd rather close the site on total traffic used, I         #
# recommend Tur-BandwidthLimit instead/too.                       #
#                                                                 #
#--[ Installation ]-----------------------------------------------#
#                                                                 #
# Copy tur-user_traffic_limit.sh to /glftpd/bin.                  #
#                                                                 #
# Decide upon 2 custom flags, not used for anything else, that    #
# will be used to block downloading and uploading. Per default,   #
# its use L to prevent downloading and K to prevent uploading.    #
# You can change that in the settings later.                      #
#                                                                 #
# Now we need to block users with those flags to upload and       #
# download (note: if you dont plan on adding a block for, say     #
# uploading, you can skip doing that part of course).             #
#                                                                 #
# The easiest way to block this is finding your 'upload' and      #
# 'download' permissions in glftpd.conf and doing something like  #
# this:                                                           #
# upload      *  !K *                                             #
# download    *  !L *                                             #
# That will disable uploading for users with flag K and           #
# downloading will be blocked for users with the L flag.          #
#                                                                 #
# Now go through the settings below                               #
#                                                                 #
#--[ Setup ]------------------------------------------------------#
#                                                                 #
# usersdir      = Path to your usersdir.                          #
#                                                                 #
# msgs          = If you want to send a message on the site to    #
#                 the user whenever access is blocked, specify    #
#                 the path to your msgs dir.                      #
#                 Leave empty for no messages.                    #
#                                                                 #
# log           = If you want blocking/unblocking logged, specify #
#                 the path to your logfile here.                  #
#                                                                 #
#                 Note: This is standard glftpd.log format. So    #
#                 you CAN specify your glftpd.log here and have   #
#                 the bot announce it. If so, it uses the TURGEN  #
#                 trigger as a lot of my other scripts.           #
#                 To change the TURGEN trigger, just search for   #
#                 it (only one location to change).               #
#                                                                 #
#                 I recomend keeping it in a seperate file though.#
#                                                                 #
#                 Leave empty to not log.                         #
#                                                                 #
# duration      = This sets which duration to work on.            #
#                 It should be either DAY, WK or MONTH            #
#                 If set to MONTH, it will read MONTHUP and       #
#                 MONTHDN from the userfiles.                     #
#                 You CAN set this to ALL (for ALLUP/ALLDN) as    #
#                 well, but dont do that unless you have a        #
#                 specific reason.                                #
#                                                                 #
#                 It IS case sensitive.                           #
#                                                                 #
# dllimit       = If you want to block the user once the user has #
#                 downloaded a certain amount of MB, set the MB   #
#                 value here.                                     #
#                 If you only want to block on uploads, leave     #
#                 this setting empty.                             #
#                                                                 #
#                 If you dont want to have this script affect     #
#                 everyone, set this to "0" and rely on the       #
#                 custom_dllimit setting instead.                 #
#                                                                 #
# ullimit       = Same as dllimit, but for uploading. To only     #
#                 block on downloaded traffic, leave this blank.  #
#                                                                 #
#                 If you dont want to have this script affect     #
#                 everyone, set this to "0" and rely on the       #
#                 custom_ullimit setting instead.                 #
#                                                                 #
#                 Setting both dllimit & ullimit empty renders    #
#                 this script useless.                            #
#                                                                 #
# custom_dllimit= If you want specific limits on a user, group or #
#                 flag, add them here. Same setup as in           #
#                 glftpd.conf. So: -turranius:5000 would give     #
#                 turranius a 5000 MB download limit instead of   #
#                 the generic one specified in dllimit=.          #
#                 =SiTEOPS:150 means that users in group SiTEOPS  #
#                 can only leech 150 MB.                          #
#                 4:5000 means that users with flag 4 can leech   #
#                 5000 MB.                                        #
#                                                                 #
#                 Priority rank is user, group, flag. So a flag   #
#                 setting has no effect if the user is in either  #
#                 another =group or the -username matches.        #
#                                                                 #
#                 Add the space seperated as "-user:100 =grp:100" #
#                 or you can do:                                  #
#                 custom_dllimit="                                #
#                 -user:100                                       #
#                 =grp:200                                        #
#                 1:300                                           #
#                 "                                               #
#                                                                 #
# custom_ullimit= Same as above, but for uploads.                 #
#                                                                 #
# ignore_users  = Any excluded users should be entered here,      #
#                 seperated by |                                  #
#                 It is case sensitive.                           #
#                                                                 #
# ignore_groups = Any excluded groups should be entered here,     #
#                 seperated by |                                  #
#                 It is case sensitive.                           #
#                                                                 #
# ignore_flags  = blabla. Guess.                                  #
#                                                                 #
# deny_flag_dl  = Here is where we set which flag the user should #
#                 get once he reaches the dllimit. By default its #
#                 L (for leecher, tihi).                          #
#                                                                 #
# deny_flag_ul  = Defines the flag the user gets if he reaches    #
#                 the ullimit. Default is K (No reason. heh).     #
#                                                                 #
# gl_version    = In order to accuratly exclude on groups         #
#                 (ignore_groups), the script needs to know which #
#                 version of glftpd you are using. Set to either  #
#                 1 or 2. Nothing else.                           #
#                                                                 #
# bot_excluded_text = Text that will be shown when you try to     #
#                     check status on an excluded user.           #
#                     set to "" to not say anything.              #
#                                                                 #
# test          = TRUE/FALSE. With TRUE, it will display on       #
#                 screen what it would have done. Nothing is      #
#                 actually done though.                           #
#                 Set this to false before the final crontab.     #
#                                                                 #
#                                                                 #
# Below this are two proc's called proc_msgtext_dl and            #
# proc_msgtext_ul. This are the settings for how the msgs look    #
# when sent. You may change the text inside the TEXT="" part if   #
# you want to.                                                    #
# If you change the duration, you might want to atleast change    #
# the word 'month' in the TEXT=                                   #
#                                                                 #
# As for count_sections=, see "More" info below..                 #
#                                                                 #
#--[ Running it ]-------------------------------------------------#
#                                                                 #
# This script have 3 functions.                                   #
#                                                                 #
# ./tur-user_traffic_limit.sh botsingle <username>                #
#  this is what the tcl runs to check the status from a user.     #
#                                                                 #
# ./tur-user_traffic_limit.sh crontab <debug>                     #
#  Used for crontabbing (duh) to enforce the rules.               #
#  Use debug or test as second command to run it as if test=TRUE  #
#                                                                 #
# ./tur-user_traffic_limit.sh total                               #
#  You can run this from shell to get the total status.           #
#                                                                 #
#--[ Crontabbing ]------------------------------------------------#
#                                                                 #
# How often you want to run this script is up to your. On each    #
# execution, it will go through each user on site (not excluded)  #
# and calculate the total traffic in the defined duration.        #
#                                                                 #
# If the user already have the deny_flag_*, it will check if hes  #
# below the limit. If so, the flag will be removed again.         #
#                                                                 #
# If the user does not have any of the deny_flag_*, it will check #
# if hes over the limit and if so, toss the flag on the user.     #
#                                                                 #
# You should enable debug mode for a while to test it.            #
# ./tur-user_traffic_limit.sh crontab debug                       #
#                                                                 #
# So, run this after often as you like. One note though, between  #
# crontabs, the user can go over the limit.. he wont be blocked   #
# until the script actually runs. So, once an hour is perhaps     #
# good for most people.                                           #
#                                                                 #
# */60 * * * *  /glftpd/bin/tur-user_traffic_limit.sh crontab     #
#                                                                 #
#--[ More ]-------------------------------------------------------#
#                                                                 #
# Q: I have multiple stat sections. How will that work?           #
# A: Traffic is traffic, no matter in what section, so this       #
#    script simply merges them together into ONE number.          #
#                                                                 #
# Q: But I dont want to count all sections because of various     #
#    reasons (one can be that its moved from MSS and              #
#    not actually coming from this site).                         #
# A: Well then. You'll need a little brainwork here (only a       #
#    little, I swear).                                            #
#    At the bottom of the settings you'll see count_sections=     #
#    This one looks like 3,6,9,12,15,18,21,24,27,30               #
#                                                                 #
#    The userfile has 3 values in each stat section. So if you    #
#    have 2 stat sections, you'll have 6 numbers for each stat.   #
#    Number 3,6 means the Kb values for section 0 and 1.          #
#    (dont worry if you dont have 10 sections.. it wont count     #
#     stuff thats not actually there).                            #
#                                                                 #
#    So each number in count_stats corresponds to a stat section  #
#    stat_section  : 0 1 2 3  4  5  6  7  8  9                    #
#    count_sections= 3 6 9 12 15 18 21 24 27 30                   #
#                                                                 #
#    So to NOT count stat_section 2 (for example), you'll want to #
#    change count_sections to "3,6,12,15...."                     #
#                                                                 #
# Q: Hm, will the user really be blocked if he is on the site?    #
#    Dont you have to logout if you've changed glftpd.conf?       #
# A: Yes, if you change glftpd.conf, the users needs to logout.   #
#    But we dont change glftpd.conf.. We change a flag on the     #
#    user. This is re-read between each file, so they will be     #
#    blocked once they are finished with their current download   #
#    or upload.                                                   #
#                                                                 #
# Q: It dosnt work at all on my MSS slave.. how come?             #
# A: Simple. MSS moves the stats from the slave to the hub. One   #
#    way to solve this is to read up on KEEPSTATS=TRUE in the     #
#    MSS documentation.                                           #
#                                                                 #
#--[ Changelog ]--------------------------------------------------#
#                                                                 #
# 1.1 : It didnt work too well if you only had one stat section.  #
#       Fixed thanks to _n__m_ who found the error and the fix.   #
#                                                                 #
#--[ Settings ]---------------------------------------------------#


usersdir=/glftpd/ftp-data/users
msgs=/glftpd/ftp-data/msgs

log=/glftpd/ftp-data/logs/download_limit.log

duration="MONTH"
dllimit=15000
ullimit=

custom_dllimit="-user1:50000 A:20000 =Friends:10000"

custom_ullimit=""

ignore_users="user1|user2"
ignore_groups="group1|group2"
ignore_flags="1"

deny_flag_dl="L"
deny_flag_ul="K"

gl_version=1

bot_excluded_text="Can not check this user."

test=FALSE

## Change TEXT below to modify the msg sent to users.
proc_msgtext_dl() {
  TEXT="Your downloading is now blocked. Downloaded ${downloaded_mb}Mb this month (${dllimit}Mb limit)."
}
proc_msgtext_ul() {
  TEXT="Your uploading is now blocked. Uploaded ${uploaded_mb}Mb this month (${ullimit}Mb limit)."
}


## Count sections. Dont change unless needed/understood:
count_sections="3,6,9,12,15,18,21,24,27,30"


#-[ Script Start ]---------------------#

## Remake ignore_users so we get an exact match (^bla$)
if [ "$ignore_users" ]; then
  ignore_users="`echo "$ignore_users" | tr '|' ' '`"
  for rawdata in $ignore_users; do
    if [ -z "$ignore_users_temp" ]; then
      ignore_users_temp="^$rawdata$"
    else
      ignore_users_temp="$ignore_users_temp|^$rawdata$"
    fi
  done
  ignore_users="$ignore_users_temp"
else
  ignore_users="felkjf30j3"
fi

if [ "$test" = "TRUE" ]; then
  echo "Ignored users : \"$ignore_users\""
fi

## Remake groups too for easier egrep -v
if [ "$ignore_groups" ]; then
  ignore_groups="`echo "$ignore_groups" | tr '|' ' '`"
  for rawdata in $ignore_groups; do
    if [ "$gl_version" = "1" ]; then
      if [ -z "$ignore_groups_temp" ]; then
        ignore_groups_temp="^GROUP\ $rawdata$"
      else
        ignore_groups_temp="$ignore_groups_temp|^GROUP\ $rawdata$"
      fi
    else
      if [ -z "$ignore_groups_temp" ]; then
        ignore_groups_temp="^GROUP\ $rawdata\ "
      else
        ignore_groups_temp="$ignore_groups_temp|^GROUP\ $rawdata\ "
      fi
    fi
  done
  ignore_groups="$ignore_groups_temp"
else
  ignore_groups="FJEKfj3j"
fi

if [ "$test" = "TRUE" ]; then
  echo "Ignored groups: \"$ignore_groups\""
fi  

proc_log() {
  if [ "$log" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$*\" >> $log
  fi
}

if [ ! -d "$usersdir" ]; then
  echo "Usersdir ($usersdir) does not exist)"
  exit 1
fi
if [ "$msgs" ]; then
  if [ ! -d "$msgs" ]; then
    echo "msgs dir ($msgs) does not exist. Skipping sending message."
    proc_log "msgs dir ($msgs) does not exist. Skipping sending message."
    unset msgs
  fi
fi
if [ "`echo "100 + 100" | bc -l | tr -d ' ' | cut -d '.' -f1`" != "200" ]; then
  echo "You dont seem to have the 'bc' binary installed. Quitting."
  proc_log "You dont seem to have the 'bc' binary installed. Quitting."
  exit 1
fi

## Usedto check which dllimit the user should have as well 
## as recounting the specified value to a KB value.
proc_recount_dllimit() {
  for rawdata in $custom_dllimit; do
    check="`echo $rawdata | cut -d ':' -f1`" 

    if [ "`echo "$check" | cut -c1`" = "-" ]; then
      username="`echo "$check" | cut -c2-`"
      if [ "`echo "$CURUSER" | grep "^${username}$"`" ]; then
        org_dllimit="$dllimit"
        dllimit="`echo $rawdata | cut -d ':' -f2`" 
      fi

    elif [ "`echo "$check" | cut -c1`" = "=" ]; then
      groupname="`echo "$check" | cut -c2-`"
      if [ "$gl_version" = "1" ]; then
        if [ "`grep "^GROUP ${groupname}$" $CURUSER`" ]; then
          org_dllimit="$dllimit"
          dllimit="`echo $rawdata | cut -d ':' -f2`" 
        fi
      else
        if [ "`grep "^GROUP ${groupname} " $CURUSER`" ]; then
          org_dllimit="$dllimit"
          dllimit="`echo $rawdata | cut -d ':' -f2`" 
        fi
      fi

    elif [ "`grep "^FLAGS " $CURUSER | cut -d ' ' -f2 | grep "$check"`" ]; then
      org_dllimit="$dllimit"
      dllimit="`echo $rawdata | cut -d ':' -f2`" 

    fi

  done

  if [ "$dllimit" ]; then
    dllimit_kb="`echo "$dllimit * 1024" | bc -l | tr -d ' ' | cut -d '.' -f1`"
    if [ -z "$dllimit_kb" ]; then
      echo "Something went wrong when calculating kb amount for dllimit. Check settings."
      proc_log "Something went wrong when calculating kb amount for dllimit. Check settings."
    fi
  fi
}


## Used to check which ullimit the user should have as well 
## as recounting the specified value to a KB value.
proc_recount_ullimit() {
  for rawdata in $custom_ullimit; do
    check="`echo $rawdata | cut -d ':' -f1`" 

    if [ "`echo "$check" | cut -c1`" = "-" ]; then
      username="`echo "$check" | cut -c2-`"
      if [ "`echo "$CURUSER" | grep "^${username}$"`" ]; then
        org_ullimit="$ullimit"
        ullimit="`echo $rawdata | cut -d ':' -f2`" 
      fi

    elif [ "`echo "$check" | cut -c1`" = "=" ]; then
      groupname="`echo "$check" | cut -c2-`"
      if [ "$gl_version" = "1" ]; then
        if [ "`grep "^GROUP ${groupname}$" $CURUSER`" ]; then
          org_ullimit="$ullimit"
          ullimit="`echo $rawdata | cut -d ':' -f2`" 
        fi
      else
        if [ "`grep "^GROUP ${groupname} " $CURUSER`" ]; then
          org_ullimit="$ullimit"
          ullimit="`echo $rawdata | cut -d ':' -f2`" 
        fi
      fi


    elif [ "`grep "^FLAGS " $CURUSER | cut -d ' ' -f2 | grep "$check"`" ]; then
      org_ullimit="$ullimit"
      ullimit="`echo $rawdata | cut -d ':' -f2`" 

    fi

  done

  if [ "$ullimit" ]; then
    ullimit_kb="`echo "$ullimit * 1024" | bc -l | tr -d ' ' | cut -d '.' -f1`"
    if [ -z "$ullimit_kb" ]; then
      echo "Something went wrong when calculating kb amount for ullimit. Check settings."
      proc_log "Something went wrong when calculating kb amount for ullimit. Check settings."
    fi
  fi
}


## Used to add a flag to a user.
## Flag must be put in $active_flag arg first.
proc_addflag() {
  if [ -z "$active_flag" ]; then
    echo "Internal error. No active_flag passed to proc_addflag."
    proc_log "Internal error. No active_flag passed to proc_addflag."
    exit 1
  fi

  ## Get current flags
  CURFLAGS="`grep "^FLAGS " $CURUSER | cut -d ' ' -f2`"
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Didnt get current flags from $CURUSER - Skipping."
    proc_log "Error. Didnt get current flags from $CURUSER - Skipping."
  else
    NEWFLAGS="${CURFLAGS}${active_flag}"
    if [ "$test" != "TRUE" ]; then
      grep -v "^FLAGS " $CURUSER > /tmp/newflag.$CURUSER
      echo "FLAGS $NEWFLAGS" >> /tmp/newflag.$CURUSER
      cp -f "/tmp/newflag.$CURUSER" "$CURUSER"
      rm -f "/tmp/newflag.$CURUSER"
    else
      echo "New flags: $NEWFLAGS for $CURUSER"
    fi
  fi
}


## Used to add a flag to a user.
## Flag must be put in $active_flag arg first.
proc_delflag() {
  if [ -z "$active_flag" ]; then
    echo "Internal error. No active_flag passed to proc_delflag."
    exit 1
  fi

  ## Get current flags
  CURFLAGS="`grep "^FLAGS " $CURUSER | cut -d ' ' -f2`"
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Didnt get current flags from $CURUSER - Skipping."
  else
    NEWFLAGS="`echo "$CURFLAGS" | tr -d "$active_flag"`"
    if [ "$test" != "TRUE" ]; then
      grep -v "^FLAGS " $CURUSER > /tmp/newflag.$CURUSER
      echo "FLAGS $NEWFLAGS" >> /tmp/newflag.$CURUSER
      cp -f "/tmp/newflag.$CURUSER" "$CURUSER"
      rm -f "/tmp/newflag.$CURUSER"
    else
      echo "New flags: $NEWFLAGS for $CURUSER"
    fi
  fi
}


## Sending message procedure.
proc_sendmsg() {
  if [ "$TEXT" ] && [ "$msgs" ]; then
    if [ "$test" != "TRUE" ]; then
      echo "" >> "$msgs/$CURUSER"
      echo "!H${TEXT}!0" >> "$msgs/$CURUSER"
      echo "" >> "$msgs/$CURUSER"
      echo "" >> "$msgs/$CURUSER"
      echo "!H${TEXT}!0" >> "$msgs/$CURUSER"
    else
      echo "Sending message: $TEXT"
    fi
  fi
}

## Check if this user is ignored either by username, flag or group.
proc_check_ignore() {
  if [ "$ignore_users" ] && [ "$CURUSER" ]; then
    if [ "`echo "$CURUSER" | egrep "$ignore_users|\.lock$"`" ]; then
      if [ "$test" = "TRUE" ]; then
        echo "Skipping $CURUSER on user ignore."
      fi
      SKIP=TRUE
    fi
  fi 

  if [ "$ignore_flags" ] && [ "$SKIP" != "TRUE" ]; then
    if [ "`grep "^FLAGS " $CURUSER | cut -d ' ' -f2 | egrep "$ignore_flags"`" ]; then
      if [ "$test" = "TRUE" ]; then
        echo "Skipping $CURUSER on flag."
      fi
      SKIP=TRUE
    fi
  fi

  if [ "$ignore_groups" ] && [ "$SKIP" != "TRUE" ]; then
    if [ "`egrep "$ignore_groups" $CURUSER`" ]; then
      if [ "$test" = "TRUE" ]; then
        echo "Skipping $CURUSER on group."
      fi
      SKIP=TRUE
    fi
  fi
}


## Grabs the download stats from the userfiles.. Converts to a MB values as well.
proc_get_dlvalues() {
  if [ -z "$CURUSER" ]; then
    echo "Internal error. No CURUSER passed to proc_get_dlvalues."
    exit 0
  fi

  raw_dn_stats="`grep "^${duration}DN " $CURUSER | cut -d ' ' -f${count_sections}`"

  ## Add it all together.
  if [ "`echo "$raw_dn_stats" | grep "\ "`" ]; then
    ## Multiple stat sections..
    for stat in $raw_dn_stats; do
      downloaded_kb="`echo "$downloaded_kb + $stat" | bc -l | tr -d ' ' | cut -d '.' -f1`"
    done
  else
    ## Single stat sections.
    downloaded_kb="$raw_dn_stats"
  fi

  if [ -z "$downloaded_kb" ]; then
    echo "Error. Didnt get downloaded stats from $CURUSER - skipping"
  else
    downloaded_mb="`echo "$downloaded_kb / 1024" | bc -l | tr -d ' ' | cut -d '.' -f1`"
    if [ -z "$downloaded_mb" ]; then
      downloaded_mb="0"
    fi
  fi
}


## Grabs the uploaded stats from the userfiles.. Converts to a MB values as well.
proc_get_ulvalues() {
  if [ -z "$CURUSER" ]; then
    echo "Internal error. No CURUSER passed to proc_get_ulvalues."
    exit 0
  fi

  raw_ul_stats="`grep "^${duration}UP " $CURUSER | cut -d ' ' -f${count_sections}`"

  ## Add it all together.
  if [ "`echo "$raw_ul_stats" | grep "\ "`" ]; then
    ## Multiple stat sections..
    for stat in $raw_ul_stats; do
      uploaded_kb="`echo "$uploaded_kb + $stat" | bc -l | tr -d ' ' | cut -d '.' -f1`"
    done
  else
    ## Single stat section.
    uploaded_kb="$raw_ul_stats"
  fi

  if [ -z "$uploaded_kb" ]; then
    echo "Error. Didnt get uploaded stats from $CURUSER - skipping"
  else
    uploaded_mb="`echo "$uploaded_kb / 1024" | bc -l | tr -d ' ' | cut -d '.' -f1`"
  fi
}



## Procedure for checking a single user and simply reporting the status.
proc_check_single() {
  if [ -z "$CURUSER" ]; then
    echo "Please specify a username."
    exit 0
  else
    if [ ! -e "$usersdir/$CURUSER" ]; then
      echo "No such user exists."
      exit 0
    fi
  fi

  proc_check_ignore
  if [ "$SKIP" = "TRUE" ]; then
    if [ "$bot_excluded_text" ]; then
      echo "$bot_excluded_text"
    fi
    exit 0
  fi

  downloaded_kb=0
  uploaded_kb=0

  if [ "$dllimit" ] && [ "$deny_flag_dl" ] ; then
    proc_recount_dllimit
    proc_get_dlvalues

    if [ "$downloaded_kb" -ge "$dllimit_kb" ]; then
      echo "$CURUSER is above the download limit with $downloaded_mb MB total ($dllimit MB limit)."
    else
      echo "$CURUSER is below the download limit with $downloaded_mb MB total ($dllimit MB limit)."
    fi
  fi  

  if [ "$ullimit" ] && [ "$deny_flag_ul" ]; then
    proc_recount_ullimit
    proc_get_ulvalues

    if [ "$uploaded_kb" -ge "$ullimit_kb" ]; then
      echo "$CURUSER is above the upload limit with $uploaded_mb MB total ($ullimit MB limit)."
    else
      echo "$CURUSER is below the upload limit with $uploaded_mb MB total ($ullimit MB limit)."
    fi
  fi
}


## Crontab procedure. Does all the work.
proc_run_crontab() {
  if [ "$sec" = "debug" ] || [ "$sec" = "test" ]; then
    test="TRUE"
  fi

  total_dl=0
  total_ul=0

  for CURUSER in `grep "^FLAGS\ " * | cut -d ':' -f1 | egrep -v "default\.user|\.lock$"`; do

    if [ "$test" = "TRUE" ]; then
      echo ""
    fi

    ## Reset limit values if they've changed.
    if [ "$org_dllimit" ]; then
      dllimit="$org_dllimit"
      unset org_dllimit
    fi
    if [ "$org_ullimit" ]; then
      ullimit="$org_ullimit"
      unset org_ullimit
    fi

    unset SKIP
    unset active_flag
    unset TEXT
    unset BAD
    downloaded_kb=0
    uploaded_kb=0
    unset downloaded_mb
    unset uploaded_mb

    proc_check_ignore

    if [ "$SKIP" != "TRUE" ]; then
      if [ "$dllimit" ] && [ "$deny_flag_dl" ] ; then
        proc_recount_dllimit
        proc_get_dlvalues

        if [ "$SKIP" != "TRUE" ] && [ "$dllimit" != "0" ]; then
          if [ -z "`grep "^FLAGS " $CURUSER | cut -d ' ' -f2 | grep "$deny_flag_dl"`" ]; then
            if [ "$downloaded_mb" ]; then
              total_dl=$[$total_dl+$downloaded_mb]
              if [ "$downloaded_kb" -ge "$dllimit_kb" ]; then
                if [ "$test" = "TRUE" ]; then
                  echo "$CURUSER above the download limit with $downloaded_mb MB total ($dllimit limit)."
                else
                  proc_log "$CURUSER above the download limit with $downloaded_mb MB total ($dllimit limit)."
                fi
                active_flag="$deny_flag_dl"
                proc_addflag
                proc_msgtext_dl
                proc_sendmsg
                BAD=YEPP
              fi
            fi
          else
            ## del flag? User already have the dlflag.
            ## Add it all together.
            if [ "$downloaded_kb" ]; then
              total_dl=$[$total_dl+$downloaded_mb]
              if [ "$downloaded_kb" -lt "$dllimit_kb" ]; then
                if [ "$test" = "TRUE" ]; then
                  echo "$CURUSER below the download limit again with $downloaded_mb MB total ($dllimit limit)."
                else
                  proc_log "$CURUSER below the download limit again with $downloaded_mb MB total ($dllimit limit)."
                fi
                active_flag="$deny_flag_dl"
                proc_delflag
                BAD=YEPP
              fi
            fi
          fi
        fi
      fi

      if [ "$ullimit" ] && [ "$deny_flag_ul" ]; then
        proc_recount_ullimit
        proc_get_ulvalues

        if [ "$SKIP" != "TRUE" ] && [ "$ullimit" != "0" ]; then 
          ## Add flag?
          if [ -z "`grep "^FLAGS " $CURUSER | cut -d ' ' -f2 | grep "$deny_flag_ul"`" ]; then
            if [ "$uploaded_mb" ]; then
              total_ul=$[$total_ul+$uploaded_mb]
              if [ "$uploaded_kb" -ge "$ullimit_kb" ]; then
                if [ "$test" = "TRUE" ]; then
                  echo "$CURUSER above the upload limit with $uploaded_mb MB total ($ullimit limit)."
                else
                  proc_log "$CURUSER above the upload limit with $uploaded_mb MB total ($ullimit limit)."
                fi
                active_flag="$deny_flag_ul"
                proc_addflag
                proc_msgtext_ul
                proc_sendmsg
                BAD=YEPP
              fi
            fi
          ## Delete flag again (user already have upload flag).
          else
            if [ "$uploaded_kb" ]; then
              total_ul=$[$total_ul+$uploaded_mb]
              if [ "$uploaded_kb" -lt "$ullimit_kb" ]; then
                if [ "$test" = "TRUE" ]; then
                   echo "$CURUSER below the upload limit again with $uploaded_mb MB total ($ullimit limit)."
                else
                  proc_log "$CURUSER below the upload limit again with $uploaded_mb MB total ($ullimit limit)."
                fi
                active_flag="$deny_flag_ul"
                proc_delflag
                BAD=YEPP
              fi
            fi
          fi
        fi
      fi

      if [ "$BAD" != "YEPP" ] && [ "$SKIP" != "TRUE" ] && [ "$test" = "TRUE" ]; then
        echo -n "$CURUSER - OK"
        if [ "$downloaded_mb" ]; then
          echo -n " - Down:${downloaded_mb}Mb ($dllimit limit)"
        fi
        if [ "$uploaded_mb" ]; then
          echo -n "  - Up:${uploaded_mb}Mb ($ullimit limit)"
        fi
      fi

    fi ## End if SKIP != TRUE

  done

  if [ "$test" = "TRUE" ]; then
    echo ""
    if [ "$total_dl" != "0" ]; then
      echo "Total DL: $total_dl MB"
    fi
    if [ "$total_ul" != "0" ]; then
      echo "Total UL: $total_ul MB"
    fi
  fi

}


## Getting total stats.
proc_check_total() {
  total_users=0
  total_users_x=0
  total_dl=0
  total_ul=0
  total_dl_x=0
  total_ul_x=0

  for CURUSER in `grep "^FLAGS\ " * | cut -d ':' -f1 | egrep -v "default\.user|\.lock$"`; do

    unset SKIP
    downloaded_kb=0
    downloaded_kb_x=0
    uploaded_kb=0
    uploaded_kb_x=0
    unset downloaded_mb
    unset uploaded_mb

    proc_check_ignore

    if [ "$dllimit" ] && [ "$deny_flag_dl" ] ; then
      proc_get_dlvalues

      if [ "$SKIP" != "TRUE" ]; then
        total_dl=$[$total_dl+$downloaded_mb]
      else
        total_dl_x=$[$total_dl_x+$downloaded_mb]
      fi
    fi      
      
    if [ "$ullimit" ]; then
      proc_get_ulvalues

      if [ "$ullimit" ]; then
        total_ul=$[$total_ul+$uploaded_mb]
      else
        total_ul_x=$[$total_ul_x+$uploaded_mb]
      fi
    fi

    if [ "$SKIP" != "TRUE" ]; then
      total_users=$[$total_users+1]
    else
      total_users_x=$[$total_users_x+1]
    fi

  done

  if [ "$total_dl" != "0" ]; then
    echo "Total DL: $total_dl MB"
  fi
  if [ "$total_dl_x" != "0" ]; then
    echo "Total DL for excluded users: $total_dl_x MB"
  fi
  if [ "$total_ul" != "0" ]; then
    echo "Total UL: $total_ul MB"
  fi
  if [ "$total_ul_x" != "0" ]; then
    echo "Total UL for excluded users: $total_ul_x MB"
  fi
  echo "Total users: $total_users"
  echo "Total excludeded users: $total_users_x"
}




cd $usersdir

case $1 in
  [bB][oO][tT][sS][iI][nN][gG][lL][eE]) CURUSER="$2"; proc_check_single; exit 0 ;;
  [cC][rR][oO][nN][tT][aA][bB]) sec="$2"; proc_run_crontab; exit 0 ;;
  [tT][oO][tT][aA][lL]) proc_check_total; exit 0 ;;
  *) echo "unknown command $1 - Use BOTSINGLE, CRONTAB"; exit 1 ;;
esac


echo "How'd you end up here?"
exit 0
