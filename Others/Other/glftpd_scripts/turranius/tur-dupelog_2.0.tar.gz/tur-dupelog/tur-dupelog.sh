#!/bin/sh
VER=2.0

#-[ Intro ]----------------------------------------------------------#
#                                                                    #
# Tur-Dupelog by Turranius ( http://www.grandis.nu/glftpd/ )         #
#                                                                    #
# This script will build a new dupelog based on the sections you     #
# specify. It will not go deeper then those sections, so CD1 and     #
# such crap will not be included in the new one.                     #
#                                                                    #
# It can also add to your current dupelog file and when done, it     #
# will sort it and remove any duped dupes.. ehh. Well. You know.     #
#                                                                    #
# It will always copy the old dupelog to dupelog.old.                #
#                                                                    #
#-[ Notes ]----------------------------------------------------------#
#                                                                    #
# dupelog is used for 'site dupe'. dirlog is used for 'site search'. #
# 'site dupe' is for what WAS on site and 'site search' is for what  #
# IS on the site now. If you want to keep 'site search' updated then #
# grab Tur-DirLogClean instead. Users should not use 'site dupe' to  #
# find releases currently on your site.                              #
#                                                                    #
# If you are simply looking for a way for 'site new' to not show the #
# CD1 and Sample etc, download Tur-LastUl instead.                   #
#                                                                    #
# If you are confident you want a new or updated dupelog, go ahead.  #
#                                                                    #
#-[ Installation ]---------------------------------------------------#
#                                                                    #
# Copy this script to /glftpd/bin and chmod it 755 or so.            #
# Compile file_date as: gcc -o /glftpd/bin/file_date file_date.c     #
#                                                                    #
# Edit the options in settings. They are as follows:                 #
#                                                                    #
# DUPELOG       = Full path of your dupelog.                         #
#                                                                    #
# FILEDATEBIN   = Full path to file_date binary.                     #
#                 We use this file when checking the date on the dir.#
#                 We could use 'ls --full-time' but that dosnt show  #
#                 the same way on all linux distributions.           #
#                                                                    #
#                 Its used in a number of other scripts of mine, so  #
#                 you might already have it.                         #
#                                                                    #
# DATEBIN       = Which date binary to use. Leave it empty and it    #
#                 will just use 'date' in your path (default).       #
#                 FBSD users need to download the sh-utils package   #
#                 and specify the 'gdate' binary that comes with it. #
#                                                                    #
# CLEARDUPEFILE = With this on TRUE, it will build an entire new     #
#                 dupelog file. With it on FALSE, it will add and    #
#                 sort to the current dupelog file.                  #
#                                                                    #
# OLDFIRST      = Which order do you want your dupelog in?           #
#                 TRUE =  Oldest releases first.                     #
#                 FALSE = Newest releases first.                     #
#                                                                    #
# SECTIONS      = Full path to all sections you want me to add rels  #
#                 from.                                              #
#                                                                    #
# DATEDDIRS     = Full path to all sections containing dated dirs.   #
#                 It dosnt HAVE to be dated dirs.. Its just that it  #
#                 will go 1 level deeper in here.                    #
#                                                                    #
# APPENDDIRS    = If you have an offline sections or something, you  #
#                 can specify that here. Something extra will be     #
#                 added to the dupelog for the files contained       #
#                 within. Anything you add here must also be in      #
#                 either SECTIONS and DATEDDIRS too.                 #
#                 Setting this slows it down, so set "" to disable.  #
#                                                                    #
# APPENDWHAT    = What to append to the end of the releases found    #
#                 in the above APPENDDIRS directories ?              #
#                                                                    #
# EXCLUDE       = Anything you want excluded in the SECTIONS         #
#                 sections.                                          #
#                                                                    #
# DATEEXC       = Anything you want excluded in the DATEDDIRS        #
#                 sections.                                          #
#                                                                    #
# CLEAROUT      = If CLEARDUPEFILE is FALSE, meaning you want to     #
#                 keep your existing dupelog and just merge new      #
#                 in it, is there anything you want the script to    #
#                 clear out from it? By default, its:                #
#                 " CD.| Sample| NUKED| Subs| Cover"                 #
#                 Meaning it should clear out stuff starting with    #
#                 CD* (* = any char), stuff starting with Sample     #
#                 etc etc. The initial space after the seperator (|) #
#                 makes it so it must start with it.                 #
#                 "CD1" = Removed. "Fix.CD1" = Kept.                 #
#                                                                    #
#                 It is not case sensitive.                          #
#                                                                    #
#-[ Note ] ----------------------------------------------------------#
#                                                                    #
# Run this script without arguments for usage and explanation.       #
#                                                                    #
#-[ Changelog ]------------------------------------------------------#
#                                                                    #
# 2.0    Rewritten. Only one script instead of two. Works better     #
#        with the use of file_data, yadda yadda.                     #
#                                                                    #
# 1.0    Old one.                                                    #
#                                                                    #
#-[ Contact ]--------------------------------------------------------#
#                                                                    #        
# Contact Turranius on Efnet / Linknet. Usually in #glftpd on efnet. #
# http://www.grandis.nu/glftpd                                       #
#                                                                    #
#-[ Settings ]-------------------------------------------------------#

DUPELOG="/glftpd/ftp-data/logs/dupelog"
FILEDATEBIN="/glftpd/bin/file_date"
DATEBIN=""
CLEARDUPELOG=FALSE
OLDFIRST="FALSE"

SECTIONS="/glftpd/site/VCD /glftpd/site/SVCD /glftpd/site/DIVX /glftpd/site/XXX /glftpd/site/ISO-UTILS"

DATEDDIRS="/glftpd/site/0DAYS"

APPENDDIRS=""
APPENDWHAT=" [OFFLINE]"

EXCLUDE='GROUPS NUKED \[incomplete\]'
DATEEXC='!Today !Yesterday Today Yesterday GROUPS \[incomplete\]'
CLEAROUT=" CD.| Sample| NUKED| Subs| Cover| Allowed"

################################################################################
# No changes needed below here, unless your name is soehest and you run fbsd   #
################################################################################

if [ ! -e "$DUPELOG" ]; then
  echo "Can not find existing dupelog, $DUPELOG."
  echo "Please fix this."
  exit 1
fi

if [ -z "$EXCLUDE" ]; then
  EXCLUDE="ekljfklejfe34989"
fi
if [ -z "$DATEEXC" ]; then
  DATEEXC="efklejfkR3434"
fi
if [ -z "$CLEAROUT" ]; then
  CLEAROUT="JRL3rj3089u9999"
fi

if [ -z "$DATEBIN" ]; then
  DATEBIN="date"
fi

if [ "$OLDFIRST" = "TRUE" ]; then
  SORTORDER="sort"
else
  SORTORDER="sort -r"
fi

proc_help() {
  echo "#-------------[ Tur-DupeLog $VER by Turranius ]--------------"
  echo "#"
  echo "# Options are: "
  echo "# test  =  Show the would-be dupelog on screen"
  echo "# go    =  Backup the old dupelog to .old and create a new one"
  echo "# "
  echo "#-------------------------------------------------------------"
  exit 0
}

proc_go() {
  if [ -e "$DUPELOG.new" ]; then
    rm -f "$DUPELOG.new"
  fi

  cp -f "$DUPELOG" "$DUPELOG.old"

  if [ "$CLEARDUPELOG" = "FALSE" ]; then
    cp -f "$DUPELOG" "$DUPELOG.new"
  fi

  if [ "$TEST" = "TRUE" ]; then
    echo "Test mode enabled. Please wait while I check the defined sections."
    echo "This may take a while, depending on number of folders"
    echo "Dated folders take a longer time"
  fi

  ## Change that space in excludes.
  EXCLUDE="$( echo "$EXCLUDE" | tr -s ' ' '|' )"
  DATEEXC="$( echo "$DATEEXC" | tr -s ' ' '|' )"

  ## Normal sections
  for section in $SECTIONS; do

    if [ ! -d $section ]; then
      echo "-- Cant find SECTIONS: $section or its not a dir. Skipping."
    else

      if [ "$TEST" = "TRUE" ]; then
        echo " "
        echo "-- Entering SECTIONS: $section"
      fi
      cd $section

      for NAME in `ls | egrep -iv $EXCLUDE | tr -s ' ' '^'`; do
        reldate=`$FILEDATEBIN $NAME`
        reldate=`$DATEBIN -d "$reldate" +%y%m%d`
  
        if [ "$APPENDDIRS" ]; then
          for appendfolder in $APPENDDIRS; do
            if [ "$section" = "$appendfolder" ]; then
              NAME="$NAME$APPENDWHAT"
            fi
          done
        fi

        ## Spit it out!
        if [ "$TEST" = "TRUE" ]; then
          echo "$reldate $NAME"
        else
          echo "$reldate $NAME" >> $DUPELOG.new
        fi
      done
    fi
  done

  ##############################################
  ############################# Dated dirs.. zzz
  ##############################################

  if [ "$DATEDDIRS" ]; then
    for dated in $DATEDDIRS; do
      if [ ! -d $dated ]; then
        echo "-- Cant find DATEDIRS: $dated or its not a dir. Skipping."
      else
        if [ "$TEST" = "TRUE" ]; then
          echo " "
          echo "-- Starting work on DATEDIRS: $dated"
        fi
        cd $dated
        for eachf in `ls | egrep -iv $DATEEXC`; do
          if [ ! -d $dated/$eachf ]; then
            echo "tur-dupelog.sh: Cant find $dated/$eachf or its not a dir. Skipping"
          else
            if [ "$TEST" = "TRUE" ]; then
              echo " "
              echo "-- Entering DATEDIRS: $dated/$eachf"
            fi
            cd $dated/$eachf
            for NAME in `ls | egrep -iv $EXCLUDE | tr -s ' ' '^'`; do
              reldate=`$FILEDATEBIN $NAME`
              reldate=`$DATEBIN -d "$reldate" +%y%m%d`          
  
              if [ "$APPENDDIRS" ]; then
                for appendfolder in $APPENDDIRS; do
                  if [ "$dated" = "$appendfolder" ]; then
                    NAME="$NAME$APPENDWHAT"
                  fi
                done
              fi

              ## Spit it out!
              if [ "$TEST" = "TRUE" ]; then
                echo "$reldate $NAME"
              else
                echo "$reldate $NAME" >> $DUPELOG.new
              fi

            done
          fi
        done
      fi
    done

  fi

  if [ "$TEST" = "TRUE" ]; then
    echo "Sorting and replacing dupelog.. (test)"
  else
    if [ ! -e "$DUPELOG.new" ]; then
      echo "Error. Should have sorted new dupelog but $DUPELOG.new dosnt exist."
    else
      cat "$DUPELOG.new" | egrep -vi "$CLEAROUT" | $SORTORDER -u > $DUPELOG.finished
      if [ ! -e "$DUPELOG.finished" ]; then
        echo "Error. After sorting and making $DUPELOG.finished, it cant be found ?!"
        exit 0
      else
        cp -f "$DUPELOG.finished" "$DUPELOG"
        rm -f "$DUPELOG.finished"
      fi
      rm -f "$DUPELOG.new"
    fi
  fi

  exit 0
}

A1="$1"

case $A1 in
  test) TEST="TRUE"; proc_go ;;
  go) proc_go ;;
  *) proc_help ;;
esac

