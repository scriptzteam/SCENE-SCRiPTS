#!/bin/bash
VER=1.6.1
#--[ Intro ]--------------------------------------#
#                                                 #
# Tur-DirlogClean. For a nice and updated search  #
# function in glftpd. Keep the dirlog up to date! #
#                                                 #
# Note: 'site dupe' is not affected by this and   #
#       shouldnt be. 'site dupe' is for what WAS  #
#       on site and 'site search' is for what IS! #
#                                                 #
# All this script really does, is                 #
# 1: Run glupdate on every section you define,    #
#    updating with what is there now. Works for   #
#    dated dirs too.                              #
#                                                 #
# 2  Run olddirclean2, thus removing all releases #
#    that is not on the site anymore / sorts the  #
#    file.                                        #
#                                                 #
#--[ Installation ]-------------------------------#
#                                                 #
# Copy this script to where ever (/glftpd/bin).   #
# Make it executable (chmod 700 tur-dirclean.sh). #
#-                                                #
# If you are running glftpd 1.32, you need to     #
# verify your version of 'glupdate'. If you have  #
# version 2.2, you'll need to compile the 2.2.1   #
# version included. 2.2 has a bug which wont let  #
# you specify location of glftpd.conf.            #
# See changelog below for version 1.5 on how to   #
# compile it.                                     #
#                                                 #
# If you are using glftpd 2.0, you need the fixed #
# glupdate binary found in the forums at          #
# www.glftpd.com (sticky post).                   #
#                                                 #
# If you are running 2.01+, you do not need to    #
# worry about glupdate.                           #
#-                                                #
# When it comes to olddirclean2, its fine too,    #
# however, if you have lots of dirs on your site  #
# like a mp3 or 0day archive, you will want to    #
# modify it or it will crap out. Might as well do #
# it now which we're messing with it anyway.      #
# Edit /glftpd/bin/sources/olddirclean2.c and     #
# find: #define MAXDIRLOGSIZE 10000               #
# Change that number to 150000 or something, save #
# it, then recompile it:                          #
# gcc olddirclean2.c -o /glftpd/bin/olddirclean2  #
#-                                                #
# Edit the settings:                              #
#                                                 #
# glconf=  Full path to your glftpd.conf file.    #
#          This will be added automatically to    #
#          cleanold and glupdate below so         #
#          dont specify it on those settings.     #
#                                                 #
# cleanold=  What to run to clean out old folders #
#            that are not there anymore.          #
#                                                 #
# cleanlog=  Where to log to. Only one day will   #
#            be logged at a time (no point to log #
#            more stuff).                         #
#                                                 #
# glupdate=  Where is glupdate? As with           #
#            olddirclean2, this comes with glftpd #
#            and should be working from shell.    #
#                                                 #
# dirlog=    "/glftpd/ftp-data/logs/dirlog"       #
#            The path to the dirlog file itself.  #
#                                                 #
# keepchmod= What to chmod 'dirlog' above with?   #
#            olddirclean2 sets it to 644, so we   #
#            might need to chmod it so that any   #
#            pre script or whatever can write to  #
#            it. "" = Disable.                    #
#                                                 #
# glroot=    Specify where /site is. This is just #
#            so you can use $glroot/<section> in  #
#            sections below. For lazy people.     #
#                                                 #
# sections=  Specify each section on your site    #
#            that you want to search for releases #
#            in.                                  #
#            Add :DEEP to the end to dive one     #
#            dir into that (for dated dirs).      #
#                                                 #
#            Add :2xDEEP to the end to dive two   #
#            dirs down.                           #
#                                                 #
#            Finally, :3xDEEP is also accepted to #
#            jump 3 levels down the dir structure.#
#                                                 #
#            Example: Say you have the following  #
#            path:                                #
#          $glroot/Archive/0DAYS/0DAYS1/2004/0102 #
#            Now, instead of adding 0101 / 0102,  #
#            etc, you can do:                     #
#          $glroot/Archive/0DAYS/0DAYS1/2004:DEEP #
#            Or:                                  #
#          $glroot/Archive/0DAYS/0DAYS1:2xDEEP    #
#            Or:                                  #
#          $glroot/Archive/0DAYS:3xDEEP           #
#                                                 #
#            If you set this to "", it will only  #
#            remove dir from dirlog that isnt     #
#            there anymore ( from all sections ). #
#                                                 #
#            If you have a space in your sections #
#            then use [:space:]                   #
#                                                 #
# exclude=   This is only if you specify :DEEP    #
#            2xDEEP or 3xDEEP.                    #
#            What NOT to add to dirlog? Pre       #
#            folders, !today symlinks, .message   #
#            file, etc etc. Anything that can be  #
#            in the dirs, but does not belong     #
#            in the dirlog.                       #
#                                                 #
#            Note, this is a simple egrep -vi     #
#            line, so if you specify, for example #
#            PRE, it will skip any dir containing #
#            that word. To specify only the dir   #
#            use ^PRE$ and it will only match on  #
#            the dir thats actually named PRE.    #
#                                                 #
#--[ Running it ]---------------------------------#
#                                                 #
# You may run this script with the argument       #
# 'debug' and it will show you what it is doing.  #
#                                                 #
# Try it by adding a dir from shell in any of     #
# the defined sections. Then search for it with   #
# site search and make sure it does not find it.  #
# Run this script and try and search for it again.#
#                                                 #
# Second try: Remove a dir from site. Search for  #
# it. It should be found still. Now run this      #
# script again and it should be gone when         #
# searching.                                      #
#                                                 #
# Crontab this script to run whenever you like.   #
# like:                                           #
# 1 1 * * * /glftpd/bin/tur-dirlogclean.sh        #
# to run it 01:01AM each day.                     #
#                                                 #
#-[ Contact ]-------------------------------------#
# WEB: http://www.grandis.nu                      #  
#      http://grandis.mine.nu                     #  
#                                                 #
#-[ Changelog ]-----------------------------------####
#                                                    #
# 1.6.1: Chg: Changed the help text for how to       #
#             glupdate and olddirclean2. This should #
#             help those new to this script.         #
#                                                    #
# 1.6  : Add: You may now specify :2xDEEP in sections#
#             to dive 2 dirs into the specifed       #
#             section (whereas :DEEP is only 1 dir)  #
#                                                    #
# 1.5  : Chg: Reversed order. It will now first run  #
#             glupdate and after that, olddirclean2. #
#             This was made because olddirlogclean2  #
#             also sorts the dirlog, making it       #
#             faster to search in (I guess).         #
#             This was done by advice from neewbiee. #
#                                                    #
#        Add: Included a glupdate.c file. If you     #
#             currently run glupdate v2.2, it wont   #
#             work since you can specify path to     #
#             glftpd.conf (cause of a bug).          #
#             If you do, compile glupdate 2.2.1      #
#             instead:                               #
#             gcc -o /glftpd/bin/glupdate glupdate.c #
#                                                    #
#             This is NOT an official update since I #
#             did it myself with the help from       #
#             www.glftpd.com.                        #
#                                                    #
# 1.4  : Add: You can now use [:space:] in sections  #
#             incase you have spaces in them.        #
#                                                    #
#        Add: For all you lazy people, added         #
#             glroot option to specify where /site   #
#             is, then you can use $glroot/section   #
#             in sections.                           #
#                                                    #
# 1.3  : Fix: Some people reporting having problems  #
#             with the '-r $glconf' usage. Changed   #
#             it to -r${glconf} instead.             #
#             Thanks |_SL_|                          #
#                                                    #
# 1.2  : Add: With 'debug' it now shows where it is. #
#                                                    #
#        Add: Added two new settings. dirlog and     #
#             keepchmod. When running olddirclean2,  #
#             changed the chmod on the file to 644.  #
#             With keepchmod set, it will chmod the  #
#             file set in 'dirlog' to that value.    #
#             Pre scripts might have had problems    #
#             adding the rel to dirlog if it was 644.#
#                                                    #
#        Add: Added checks to see if it can find/run #
#             the required binaries.                 #
#                                                    #
#        Chg: Renamed from tur-dirclean.sh to        #
#             tur-dirlogclean.sh. Dont forget to     #
#             change your crontabs.                  #
#             Changed all 'awk' into 'cut'.          #
#                                                    #
# 1.1  : Fix: Added -r options to proggs for those   #
#             that do not have glftpd.conf in /etc   #
#                                                    #
# 1.0. Initial release.                           ####
#                                                 #  ^
#-[ Settings ]------------------------------------#  |
#                                                 Lazy

glconf="/etc/glftpd.conf"

cleanold="/glftpd/bin/olddirclean2"
cleanlog="/glftpd/ftp-data/logs/olddirclean.log"

glupdate="/glftpd/bin/glupdate"

dirlog="/glftpd/ftp-data/logs/dirlog"
keepchmod=666

glroot="/glftpd/site"

sections="
$glroot/DIVX
$glroot/SVCD
$glroot/MP3:DEEP
$glroot/0DAY:DEEP
"

exclude="^GROUPS$|^lost\+found$|^All$"


#-[ Script Start ]--------------------------------#

if [ "$1" = "debug" ]; then
  echo "Verifying existance of required bins.."
fi

if [ ! -x "$cleanold" ]; then
  echo "Error. Cant execute $cleanold. Check existance and perms."
  exit 1
fi
if [ ! -x "$glupdate" ]; then
  echo "Error. Cant execute $glupdate. Check existance and perms."
  exit 1
fi
if [ ! -r "$glconf" ]; then
  echo "Error. Cant read $glconf. Check existance and perms."
  exit 1
fi

if [ "$1" = "debug" ]; then
  echo "Checking for new or moved files to add to db."
fi

for section in $sections; do
  section="`echo "$section" | sed -e 's/\[\:space\:\]/ /g'`"
  dated="$( echo $section | cut -d ':' -f2 )"
  if [ "$dated" != "DEEP" ] && [ "$dated" != "2xDEEP" ] && [ "$dated" != "3xDEEP" ]; then
    if [ "$1" = "debug" ]; then
      echo "Entering \"$section\""
    fi
    $glupdate -r ${glconf} "$section" >> $cleanlog
  else
    section="$( echo $section | cut -d ':' -f1 )"
    if [ ! -d "$section" ]; then
      echo "Error. \"$section\" does not exist. Skipping."
    else
      cd "$section"
      LIST="$( ls -1 | egrep -vi "$exclude" )"
      for folder in $LIST; do

        if [ "$dated" = "2xDEEP" ]; then
          LIST2="$( ls -1 $folder | egrep -vi "$exclude" )"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
              if [ "$1" = "debug" ]; then
                echo "Not a dir: $section/$folder/$folder2 - Skipping."
              fi
            else
              if [ "$1" = "debug" ]; then
                echo "Entering (2xDEEP) \"$section/$folder/$folder2\""
              fi
              $glupdate -r ${glconf} "$section/$folder/$folder2" >> $cleanlog
            fi
          done

        elif [ "$dated" = "3xDEEP" ]; then
          LIST2="$( ls -1 $folder | egrep -vi "$exclude" )"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
               if [ "$1" = "debug" ]; then
                 echo "Not a dir: $section/$folder/$folder2 - Skipping."
               fi
            else
              LIST3="$( ls -1 $folder/$folder2 | egrep -vi "$exclude" )"
              for folder3 in $LIST3; do
                if [ ! -d "$section/$folder/$folder2/$folder3" ]; then
                   if [ "$1" = "debug" ]; then
                     echo "Not a dir: $section/$folder/$folder2/$folder3 - Skipping."
                   fi
                else
                  if [ "$1" = "debug" ]; then
                    echo "Entering (3xDEEP) \"$section/$folder/$folder2/$folder3\""
                  fi
                  $glupdate -r ${glconf} "$section/$folder/$folder2/$folder3" >> $cleanlog
                fi
              done
            fi
          done

        else
          if [ ! -d "$section/$folder" ]; then
            if [ "$1" = "debug" ]; then
              echo "Not a dir: $section/$folder - Skipping."
            fi
          else
            if [ "$1" = "debug" ]; then
              echo "Entering (DEEP) \"$section/$folder\""
            fi
            $glupdate -r ${glconf} "$section/$folder" >> $cleanlog
          fi
        fi

      done
    fi
  fi
done

if [ "$keepchmod" ]; then
  if [ "$1" = "debug" ]; then
    echo "Running chmod $keepchmod $dirlog"
  fi
  chmod $keepchmod $dirlog
fi

echo "" >> $cleanlog

## Run olddircleaner.
if [ "$1" = "debug" ]; then
  echo "Checking for files that does not exist anymore / sorting dirlog. This could take some time."
fi

$cleanold -P -D -r${glconf} > $cleanlog

if [ "$keepchmod" ]; then
  if [ "$1" = "debug" ]; then
    echo "Running chmod $keepchmod $dirlog"
  fi
  chmod $keepchmod $dirlog
fi

exit 0
