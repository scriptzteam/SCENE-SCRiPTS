#!/bin/bash
VER=0.2

## Path to glftpd
GLROOT=/glftpd

## SectionName:PathToSection:MaxSize(Display only)
SECTIONS="
XBOX:/site/XBOX:30
DIVX:/site/DIVX:20
DVDR:/site/DVDR:50
"

## How to run du.
GET_SPACE="du -msh"

## How to output. $* is the message
## To change output texts, search for proc_output below "Script Start".
proc_output() {
  echo "-[SECSPACE]- $*"
}


#--[ Script Start ]---------------#

## Procedure for getting all sectionnames in a list.
proc_get_section_list() {
  for each in $SECTIONS; do
    sec_name="`echo "$each" | cut -d ':' -f1`"
    if [ "$sec_announce" ]; then
      sec_announce="$sec_announce $sec_name"
    else
      sec_announce="$sec_name"
    fi
  done
  sec_announce="All $sec_announce"
}

## If no section was specified.
if [ -z "$1" ]; then
  proc_get_section_list
  proc_output "Specify section. Valid sections are: $sec_announce"
  exit 0
fi

## If using "all" as argument, list all sections.
if [ "`echo "$1" | grep -i "^all$"`" ]; then
  for each in $SECTIONS; do
    selected_section="`echo "$each" | cut -d ':' -f1`"
    section_path="`echo "$each" | cut -d ':' -f2`"
    section_size="`echo "$each" | cut -d ':' -f3`"
    size="`$GET_SPACE $GLROOT$section_path 2>/dev/null | tail -n1 | cut -f1`"
    proc_output "Section $selected_section is $size full out of a maximum of $section_size GB total"  
  done
  exit 0
fi

## Verify that selected section is valid.
for each in $SECTIONS; do
  sec_name="`echo "$each" | cut -d ':' -f1`"
  if [ "`echo "$1" | grep -i "^$sec_name$"`" ]; then
    selected_section="$sec_name"
    selected_full_section_data="$each"
  fi
done

## Echo if the section is not a valid one.
if [ -z "$selected_section" ]; then
  proc_get_section_list
  proc_output "Valid sections are: $sec_announce"
  exit 0
fi

## Split up selected section into path and size (already have name).
section_path="`echo "$selected_full_section_data" | cut -d ':' -f2`"
section_size="`echo "$selected_full_section_data" | cut -d ':' -f3`"

## Run du to get space on the selected directory.
size="`$GET_SPACE $GLROOT$section_path 2>/dev/null | tail -n1 | cut -f1`"

## Output final result.
proc_output "Section $selected_section is $size full out of a maximum of $section_size GB total"

## Exit (duh)
exit 0