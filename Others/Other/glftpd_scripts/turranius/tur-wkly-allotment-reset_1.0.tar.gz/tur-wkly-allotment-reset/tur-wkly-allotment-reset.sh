#!/bin/bash
VER=1.0

#-------------------------------------------------------#
#                                                       #
# Tur-Wkly-Allotment-Reset. A script to make sure the   #
# users does not have more credits then what is         #
# specified at the start of each week.                  #
#                                                       #
# Sometime in glftpd life, the reset binary changed so  #
# that if you have MORE credits than your wkly allotment#
# if would allow you to keep it.                        #
# Previously it would have reset it to the allotment    #
# value anyway.                                         #
# I have been told this will be fixed in glftpd 2.0 or  #
# atleast so you can specify the reset binaries         #
# behaviour. This script should therefor only be needed #
# for glftpd 1.3+                                       #
#                                                       #
# Now, for MSS in particular, this new way of reseting  #
# credits is NO GOOD, since the user can just transfer  #
# credits to the slaves above his allotment value and   #
# simply build the credits up more and more each week.  #
#                                                       #
# Hence this script. It will check if its the correct   #
# day to reset and if any user has more credits then    #
# his allotment value specifies, it will reset him down #
# to that value.                                        #
#                                                       #
# It is a COMPLEMENT to the reset binary and not a      #
# replacement in any kind. reset still handles the      #
# stats and in some occations, the wkly_allotment.      #
#                                                       #
# In case you use MSS, it should be loaded on both the  #
# hub and all the slaves.                               #
#                                                       #
#--[ Installation ]-------------------------------------#
#                                                       #
# Copy tur-wkly-allotment.sh to /glftpd/bin.            #
# Chmod it to 700 or similar (root executable only).    #
#                                                       #
# Change the options as follows:                        #
#                                                       #
# USERS           = Path to your users dir.             #
#                                                       #
# RESET_ON_SUNDAY = If you normally reset your stats    #
#                   on Sundays (US new week), leave     #
#                   this on TRUE.                       #
#                   However, if you specified your      #
#                   reset binary to reset on Mondays    #
#                   (EURO new week) instead, set it to  #
#                   FALSE and this script will do the   #
#                   same.                               #
#                                                       #
# DATE_BINARY     = Path to your date executable.       #
#                   It needs to support %u for showing  #
#                   day of the week as a number where   #
#                   7 is Sunday and 1 is Monday.        #
#                   AFAIK, most date binaries does this.#
#                                                       #
# Now, run it with argument 'debug' or 'test' (same)    #
# and see that it looks good.                           #
# In debug mode, it will create the new userfile in     #
# /tmp (watch output in shell), so you can check that   #
# the userfiles look ok, should you want that.          #
#                                                       #
# Once satisfied, crontab it to run a few minutes after #
# reset in your crontab.                                #
#                                                       #
# So if you have today: 0 0 * * * /glftpd/bin/reset     #
# then also add something like:                         #
# 2 0 * * * /glftpd/bin/tur-wkly_allotment-reset.sh     #
# so that it runs 2 minutes after reset.                #
#                                                       #
# It will just quit if it is not the correct day to run #
# on, so its safe to crontab it every day.              #
# However, should you want to force a reset, specify    #
# 'force' as argument and it will run anyway. If also   #
# specifying 'debug' it wont do anything though.        #
#                                                       #
#--[ Settings ]-----------------------------------------#

USERS=/glftpd/ftp-data/users

RESET_ON_SUNDAY=TRUE
DATE_BINARY=/bin/date


#--[ Script Start ]-------------------------------------#

## Check if first argument or second is test or debug.
if [ "$1" = "test" ] || [ "$1" = "debug" ] || [ "$2" = "test" ] || [ "$2" = "debug" ]; then
  DEBUG="TRUE"
fi

if [ "$1" = "force" ] || [ "$2" = "force" ]; then
  FORCE="TRUE"
fi

## Procedure for showing debug text.
proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$*"
  fi
}

## Safety feature
sleep 1

## Verify that the date binary can be executed.
if [ ! -x $DATE_BINARY ]; then
  echo "Error. Can not execute DATE_BINARY in $DATE_BINARY"
  exit 1
fi
## Verify that the users dir is found and is indeed a directory.
if [ ! -d "$USERS" ]; then
  echo "Error. Can not find the dir $USERS"
  exit 1 
fi

## Check if we should run today.
if [ "$FORCE" != "TRUE" ]; then
  if [ "$RESET_ON_SUNDAY" = "TRUE" ]; then
    if [ "`$DATE_BINARY +%u`" = "7" ]; then
      ACTION_DAY="TRUE"
    fi
  else 
    if [ "`$DATE_BINARY +%u`" = "1" ]; then
      ACTION_DAY="TRUE"
    fi
  fi
else
  ACTION_DAY="TRUE"
  proc_debug "Force enabled. Running, but wont replace any userfiles."
fi

## If we shouldnt run, quit, unless debug mode is on.
if [ "$ACTION_DAY" != "TRUE" ]; then
  if [ "$DEBUG" = "TRUE" ]; then
    echo "Not the correct day. Test mode so running anyway."
  else
    exit 0
  fi
else
  proc_debug "This is the correct day to run."
fi

## Enter the users dir.
cd $USERS

## Go through each user which has allotment set.
for curuser in `grep "^GENERAL [0-9]\,[1-9].*\ " * | cut -d ':' -f1`; do
  proc_debug ""
  proc_debug "Found wkly_allotment user $curuser"
  curcreds="`grep "^CREDITS\ " $curuser | cut -d ' ' -f2`"
  curallotment="`grep "^GENERAL\ " $curuser | cut -d ' ' -f2 | cut -d ',' -f2`"
  proc_debug "Current credits: $curcreds - Current allotment: $curallotment"
  if [ "$curcreds" ] && [ "$curallotment" ]; then
    if [ "$curcreds" -gt "$curallotment" ]; then
      proc_debug "Resetting credits down to $curallotment - new file: /tmp/$curuser.new"
      ## Reset here
      cat $curuser | sed -e "s/^CREDITS [0-9]* /CREDITS $curallotment /" > /tmp/$curuser.new
      if [ "$DEBUG" != "TRUE" ]; then
        cp -f "/tmp/$curuser.new" $curuser
        rm -f "/tmp/$curuser.new"
      fi
    else
      proc_debug "Not touching $curuser"
    fi
  else
    echo "Error. Could not read credits and/or allotment for $curuser"
  fi
done

## Check if we really found any users on allotment.
if [ -z "$curuser" ]; then
  proc_debug "No users found on wkly_allotment..."
fi

exit 0