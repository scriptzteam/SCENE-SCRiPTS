#!/bin/bash
VER=1.0
#--[ Intro ]----------------------------------------------#
#                                                         #
# Tur-SiteMerge. A rather small but useful script for     #
# those who wish to merge the userfiles/passwd/group      #
# files into one. For example if you're about to start    #
# using MSS to link two sites, you'll want to do this and #
# put the merged userfiles/passwd/group files on the hub. #
#                                                         #
# What it does is: You define the locations for site1 &   #
# site2. It will then copy all the userfiles from site2   #
# into /tmp/users.new and then copy all files from site1  #
# into the same dir, overwriting any co-existing users.   #
#                                                         #
# It the goes on to the group files. It copies the group  #
# file from site1 to /tmp/group.new.                      #
# Then, it processes the group file from site2, and if    #
# the groupname does not already exist in the group file  #
# from site1, add it to the group file. The merged group  #
# will get a new gid which is that of +100 from the       #
# highest gid from site1.                                 #
#                                                         #
# On to the passwd. It copes the passwd from site1 to     #
# /tmp/passwd.new. As with the group file it then grabs   #
# the highest uid from the passwd and starts to merge the #
# users from site2 into /tmp/passwd.new. Each user will   #
# get a new uid which is that of +1 of the highest uid    #
# from site1.                                             #
# That is, if the user dosnt already exist in the passwd  #
# in which case it will skip that user from the new file. #
#                                                         #
# After that is done, we need to make sure that the       #
# gid for each user in the passwd corresponds to the gid  #
# of the group which is the users primary group.          #
# So, it will check the users primary group from the      #
# userfile, check the groups gid in /tmp/group.new and    #
# if the gid it gets does not match the gid for the user  #
# in /tmp/passwd.new, it will update /tmp/passwd.new to   #
# the new gid.                                            #
#                                                         #
# If any user existed in both site1 and site2, the info   #
# from site1 will be used. It will warn you with the      #
# usernames of those userfiles which were not used from   #
# site2. Its then up to you to check if this is the same  #
# user on site1 as on site2 (might be two different users #
# with the same username) and if it is, manually add the  #
# credits and/or stats from the site2 userfiles into      #
# the userfiles in /tmp/users.new                         #
#                                                         #
# NOTE: It creates all files in /tmp so the information   #
# from site1 and site2 are not touched. You have to       #
# verify that the information is /tmp is correct and then #
# copy the files in /tmp to /glftpd/etc and to            #
# /glftpd/ftp-data/users yourself.                        #
#                                                         #
# DONT FORGET TO MAKE BACKUPS FIRST!                      #
#                                                         #
# Its recomended that both sites be closed before doing   #
# this operation.                                         #
#                                                         #
#--[ Settings ]-------------------------------------------#

## Site 1
users1=/glftpd/ftp-data/users
passwd1=/glftpd/etc/passwd
group1=/glftpd/etc/group

## Site 2
users2=/other/site/users
passwd2=/other/site/passwd
group2=/other/site/group



#-[ Script Start ]-------------------------------#

echo "Tur-SiteMerge $VER Starting."

if [ ! -e "$group1" ]; then
  echo "Error. group1 ( $group1 ) does not exist."
  exit 1
elif [ ! -e "$group2" ]; then
  echo "Error. group2 ( $group2 ) does not exist."
  exit 1
elif [ ! -e "$passwd1" ]; then
  echo "Error. passwd1 ( $passwd1 ) does not exist."
  exit 1
elif [ ! -e "$passwd2" ]; then
  echo "Error. passwd2 ( $passwd2 ) does not exist."
  exit 1
elif [ ! -d "$users1" ]; then
  echo "Error. users1 ( $users1 ) does not exist or isnt a directory."
  exit 1
elif [ ! -d "$users2" ]; then
  echo "Error. users2 ( $users2 ) does not exist or isnt a directory."
  exit 1
fi

if [ -e "/tmp/users.new" ]; then
  rm -rf "/tmp/users.new"
fi

## Merging userfiles.
echo ""
echo "---------------------------------------------------"
echo "Merging userfiles."
mkdir "/tmp/users.new"
cp -f $users2/* "/tmp/users.new"
cp -f $users1/* "/tmp/users.new"

## Merging group files
echo ""
echo "---------------------------------------------------"
echo "Merging group files"
cp "$group1" "/tmp/group.new"

## Get last GID from file
lastgid="`tail -n1 "/tmp/group.new" | cut -d ':' -f3`"
echo "Lastguid is $lastgid - Starting from $lastgid + 100"

newgid=$[$lastgid+100]
for rawdata in `cat $group2`; do
  groupname="`echo "$rawdata" | cut -d ':' -f1`"
  if [ "`grep "^$groupname:" "/tmp/group.new"`" ]; then
    echo "Group $groupname already exists in /tmp/group.new - Skipping."
  else
    curgid="`echo "$rawdata" | cut -d ':' -f3`"
    newline="`echo "$rawdata" | sed -e "s/:$curgid:/:$newgid:/"`"
    newgid=$[$newgid+100]
    echo "$newline" >> "/tmp/group.new"
  fi
done


## Merging passwd files.
echo "---------------------------------------------------"
echo ""
echo "Merging passwd files."

if [ -e "/tmp/passwd.new" ]; then
  rm -f "/tmp/passwd.new"
fi

for rawdata1 in `cat $passwd1 | tr ':' ' ' | sort -k3,3 -n | tr ' ' ':' `; do
  echo "$rawdata1" >> "/tmp/passwd.new"
done
echo "$passwd1 sorted and put in /tmp/passwd.new"    

## Grab last userid from new passwd..
lastnum="`tail -n1 "/tmp/passwd.new" | cut -d ':' -f3`"
echo "Last uid in $passwd1 is $lastnum - starting from $lastnum +1"

newuid=$[$lastnum+1]
for rawdata2 in `cat $passwd2 | tr ':' ' ' | sort -k3,3 -n | tr ' ' ':' `; do
  username="`echo "$rawdata2" | cut -d ':' -f1`"
  if [ "`grep "^$username\:" "/tmp/passwd.new"`" ]; then
    echo "$username is already in $passwd1 - Skipping."
    SKIPPED="$SKIPPED $username"
  else
    curuid="`echo "$rawdata2" | cut -d ':' -f3`"
    newline="`echo "$rawdata2" | sed -e "s/:$curuid:/:$newuid:/"`"
    newuid=$[$newuid+1]
    echo "$newline" >> "/tmp/passwd.new"
  fi
done


## Verify group gid in passwd matches group file.
echo ""
echo "Updating each users gid in the passwd to match new group file."


cd /tmp/users.new
for username in `ls -1`; do
  if [ -z "`grep "^$username:" /tmp/passwd.new`" ]; then
    echo "$username dosnt exist in passwd - skipping"
  else
    prigroup="`grep "^GROUP " $username | head -n1 | cut -d ' ' -f2`"
    if [ -z "$prigroup" ]; then
      gid=100
    else
      gid="`grep "^$prigroup:" /tmp/group.new | cut -d ':' -f3`"
    fi
    if [ -z "`grep "^$username:" /tmp/passwd.new | grep "^.*:.*:.*:$gid:"`" ]; then
      olddata="`grep "^$username:" /tmp/passwd.new`"
      pass="`echo "$olddata" | cut -d ':' -f2`"
      uid="`echo "$olddata" | cut -d ':' -f3`"
      oldgid="`echo "$olddata" | cut -d ':' -f4`"
      date="`echo "$olddata" | cut -d ':' -f5`"
      bla="`echo "$olddata" | cut -d ':' -f6`"      
      bla2="`echo "$olddata" | cut -d ':' -f7`"
      echo ""
      echo "$username gid mismatch. gid $oldgid should be $gid for $prigroup"
      echo "old: $olddata"
      echo "new: $username:$pass:$uid:$gid:$date:$bla:$bla2"
      grep -v "^$username:" /tmp/passwd.new > /tmp/passwd2.new
      echo "$username:$pass:$uid:$gid:$date:$bla:$bla2" >> /tmp/passwd2.new
      mv -f /tmp/passwd2.new /tmp/passwd.new
    fi
  fi
done

echo ""
echo "---------------------------------------------------"
echo "Doing a new resort of /tmp/passwd.new"

for rawdata1 in `cat /tmp/passwd.new | tr -d '\n' | tr ':' ' ' | sort -k3,3 -n | tr ' ' ':' `; do
  echo "$rawdata1" >> "/tmp/passwd2.new"
done
mv -f "/tmp/passwd2.new" "/tmp/passwd.new"
echo ""
echo "---------------------------------------------------"
echo "All done. New files: /tmp/passwd.new /tmp/group.new"
echo "New users are in /tmp/users.new"

if [ "$SKIPPED" ]; then
  SKIPPED="`echo $SKIPPED`"
  echo ""
  echo "Warning. Note that the following users were not copied from $users2"
  echo "         and has therefor lost their credits and stats from those"
  echo "         userfiles. Add that manually if needed:"
  echo "         $SKIPPED"
  echo ""
fi

echo "---------------------------------------------------"
echo ""

exit 0
