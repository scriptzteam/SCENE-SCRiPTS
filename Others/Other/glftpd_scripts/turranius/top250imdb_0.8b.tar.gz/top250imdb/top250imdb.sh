#!/bin/bash
VER=0.8b
#-[ Intro ]------------------------------------------------------#
#                                                                #
# Top250iMBD. A script for users who wants to keep a "top 250    #
# iMBD" archive. It grabs the top 250 list from iMBD and creates #
# the dir using the rank and real moviename.                     #
#                                                                #
# It then keeps these numbers updated on every execution incase  #
# rankings change.                                               #
#                                                                #
# It will also display which are not filled (EMPTY_) as well as  #
# fill them automatically when complete.                         #
#                                                                #
#-[ Installation ]-----------------------------------------------#
#                                                                #
# Put the script where ever you want. /glftpd/bin perhaps.       #
# Make it executable with chmod 755.                             #
#                                                                #
#-[ Configuration ]----------------------------------------------#
#                                                                #
# Change the values as followes:                                 #
#                                                                #
# DESTDIR     = The full path to the destination directory where #
#               the iMDB dirs will be created. Try not to keep   #
#               anything else in here although it should be fine.#
#               Create this dir and set chmod 777 on it.         #
#                                                                #
#               Set this to some harmless dir somewhere first to #
#               test that it works for you & your distro.        #
#                                                                #
# LIST        = A list with rankings and movienames will be      #
#               created and this is the full path to it.         #
#               You can put it anywhere you want, but preferebly #
#               in the $DESTDIR above.                           #
#                                                                #
# TOP         = Used to force it to stop at a number sooner then #
#               250. You can set what you want it to stop at     #
#               here. For example "50" would make it stop at pos #
#               50 in the list instead of going to 250.          #
#               Leave it empty to get all 250.                   #
#                                                                #
# LINK        = The link from iMBD to grab the list from.        #
#               Default one should be ok.                        #
#                                                                #
# DEL250plus  = When a movie is filled but then falls out of the #
#               250 movie ranking, should it be deleted?         #
#               TRUE  = Yes, delete it.                          #
#               FALSE = No, rename it to 250+                    #
#                                                                #
# FAKE        = iMDB does not allow wget to fetch sources from   #
#               them so we need to fool them by impersonating    #
#               another browser. This is what it will identify   #
#               as. Default should be fine here too.             #
#                                                                #
# LOG         = Full path to the logfile where it will say what  #
#               it does/did. Set to "" to disable logging.       #
#                                                                #
# Next, you will need to crontab this script. You can run it as  #
# often or seldom as you like. I recomend running it atleast 4   #
# times a day for the first week or so while dirs are being      #
# filled. Then change it one or two times a day. But this is up  #
# to you. This line will run it 5 minutes past 9 (9AM) and once  #
# again 5 minutes past 21 (9PM):                                 #
#                                                                #
# 5 9,21 * * *    /glftpd/bin/top250imdb.sh                      #
#                                                                #
#-[ Running ]----------------------------------------------------#
#                                                                #
# Using argument 'debug' (without the '') will display what it   #
# does in shell. Its the same output that goes in the log.       #
# Debug is not test mode. It will still do everything it says.   #
#                                                                #
# Here is how it works for those interested. If you're not, skip #
# down to -[ Contact ]-.                                         #
#                                                                #
# It grabs the list from iMDB. If the movie does not have a dir, #
# it will be created. If the movie switched places, the old      #
# movie in that spot will be renamed to TEMP_blabla and the new  #
# dir will be made or moved.                                     #
#                                                                #
# Once that is all done, it will check all TEMP_ dirs and, by    #
# reading the LIST file, move it to its proper ranking number.   #
#                                                                #
# Next, it will check all dirs starting with EMPTY_ if they are  #
# still empty (below 5000KB). If they are NOT, it will wait 30   #
# seconds. If the size is still the same after that, it will be  #
# remove the EMPTY_ part of it and its considered filled.        #
#                                                                #
# However, if it is NOT the same size after 30 seconds, it will  #
# check again every 30 seconds for 10 total attempts. If its     #
# still not the same size, it will leave it as it is.            #
# This is to prevent that dirs that are being upped, does not    #
# get renamed.                                                   #
#                                                                #
# After this, it will check that all filled dirs (without EMPTY) #
# are not infact empty. If they are, they are renamed EMPTY_     #
# So, newly created dirs are first created as filled, then       #
# renamed as empty further down the script.                      #
#                                                                #
# Movies can still be renamed in mid-upload if they change rank. #
# I dont see this as a big problem though as ranking change very #
# seldom, atleast on the top 200 movies. Users gets to deal with #
# that. But now you are aware that it CAN happen.                #
#                                                                #
#-[ Contact ]----------------------------------------------------#
#                                                                #
# Turranius on Efnet/Linknet. Usually in #glftpd on Efnet.       #
# http://www.grandis.nu/glftpd & http://grandis.mine.nu/glftpd   #
#                                                                #
#-[ Changelog ]--------------------------------------------------#
#                                                                #
# 0.8b= - Fixed for iMDB changes. Probably last fix as this      #
#         script is discontinued (unless its an easy fix as this #
#         was).                                                  #
#                                                                #
# 0.7b= - Added TOP setting. If you want top 50 instead of 250   #
#         set this to "50" and it will stop there. You can not   #
#         set it above 250.                                      #
#         Thanks jimmy for the idea.                             #
#                                                                #
# 0.6b= - Fixed for new IMDB format.                             #
#       - Changed LINK to point to correct place.                #
#       - Debug output changed some to include more infomation.  #
#       - Downloaded sources are deleted at the start of a run,  #
#         to prevent it from reading some old source HTML file.  #
#                                                                #
# 0.5b= - It should no longer produce spaces in releasenames.    #
#         instead its underscores.                               #
#                                                                #
# 0.4b= - Changed to comply with imdbs new format in the top 250 #
#         list. Also added substitution of &#189 to "half" in    #
#         relname (8 1/2. Currently 207)                         #
#                                                                #
# 0.3b= - EMPTY_ dirs were not being renamed to proper position. #
#       - Downloaded sourcefile was not always deleted.          #
#       - Checking if filled releases was actually empty didnt   #
#         work 100%                                              #
#       - test/debug (same thing) added to display on screen.    #
#       - LOG added for logging to file.                         #
#                                                                #
# 0.2b= - Fixed fbsd compability with wc and du.                 #
# 0.1b= - Initial test version.                                  #
#                                                                #
#-[ Settings ]---------------------------------------------------#

DESTDIR="/glftpd/bin/test/imdb"
LIST="/glftpd/bin/test/imdb/imdb.txt"
TOP=""

LINK="http://www.imdb.com/chart/top"
DEL250plus="FALSE"
FAKE="Internet Explorer 6"
LOG="/glftpd/ftp-data/logs/top250.log"


#--[ Script Start ]----------------------------------------------#

## Check that DESTDIR exists.
if [ ! -d "$DESTDIR" ]; then
  echo "ERROR: $DESTDIR does not exist."
  echo "Create and set 777 on it."
  exit 1
fi

## Enter it
cd $DESTDIR

## Remove old sources if there are any.
sourcename="`basename $LINK`"
rm -f "$sourcename"
rm -f $sourcename.[0-9]
unset sourcename

## Remove old list. We'll make a new one.
if [ -e "$LIST" ]; then
  rm -f "$LIST"
fi

## Set DEBUG to TRUE if first argument is TEST or DEBUG.
if [ "$( echo "$1" | egrep "[dD][eE][bB][uU][gG]|[tT][eE][sS][tT]" )" ]; then
  DEBUG="TRUE"
fi

if [ "$DEBUG" = "TRUE" ]; then
  echo `date "+%a %b %e %T %Y"` "Initiating Top250 Grabber by Turranius-2003"
fi

## Get the source from imdb.
if [ "$DEBUG" = "TRUE" ]; then
  wget -U "$FAKE" -T 5 --cookies=off $LINK
else
  wget -U "$FAKE" -T 5 -q --cookies=off $LINK
fi

## Procedure for logging and echoing to shell
proc_log() {
  if [ "$LOG" ]; then
    if [ -z "$FIRSTLOG" ]; then
      echo `date "+%a %b %e %T %Y"` TOP250: \" \" >> $LOG
      echo `date "+%a %b %e %T %Y"` TOP250: \"Initiating Top250 Grabber by Turranius-2003\" >> $LOG     
      FIRSTLOG="TRUE"
    fi
    echo `date "+%a %b %e %T %Y"` TOP250: \"$@\" >> $LOG     
  fi
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$@" 
  fi 
}

## Get name of file. Usually top_250_films
source=`basename $LINK`

## Does it exist?
if [ ! -e "$source" ]; then
  proc_log "Error. Could not get $source file from imdb"
  exit 1
fi

## Add new dirs if they arent there. Make sure they are where they should be.
proc_log "File download complete. Checking if numbers are in order and dirs exists."

for each in `cat $source | grep "Top 250 movies as voted by our users"`; do 

  if [ "$namestart" ]; then
    if [ -z "`echo "$each" | grep ">"`" ]; then
      namestart="$namestart $each"
    else
      namestart="$namestart "`echo "$each" | cut -d '<' -f1`
      FINAL_NAME="`echo "$namestart" | tr ' ' '_' | cut -d '<' -f1`"
      position="$RANK1"
      FINAL_VOTES="$VOTES"
      unset VOTES; unset RANK1; unset namestart

      relname=`echo "$FINAL_NAME" | sed -e 's/#38;//g' | sed -e 's/&#34;//g' | sed -e 's/#34;//g' | sed -e 's/&#228;/�/g' | sed -e 's/&#229/�/g'| sed -e 's/&#233;/�/g' | sed -e 's/&#243;/o/g' | sed -e 's/&#248;/o/g' | sed -e 's/&#237;/i/g' | sed -e 's/&#225;/a/g' | sed -e 's/&#244;/o/g' | sed -e 's/&#251;/u/g' | sed -e 's/&#189;/half/g' | sed -e 's/&#246;/o/g' | sed -e 's/&#230;/ae/g' | sed -e 's/&#227;/a/g' | sed -e 's/&#231;/c/g' | sed -e 's/&#252;/u/g' | sed -e "s/&#189;/half/g" | sed -e 's/&#34;//g' | sed -e 's/&#232;/e/g'`

      if [ "$LIST" ]; then
        echo "$position -> $relname" >> $LIST
      fi

      if [ ! -d "$DESTDIR/$position"_"$relname" ] && [ ! -d "$DESTDIR/EMPTY_$position"_"$relname" ]; then
        CHECKPRE=`ls | egrep "^$position|^EMPTY_$position"`
        if [ "$CHECKPRE" ]; then
          if [ "$( echo "$CHECKPRE" | grep "^EMPTY_" )" ]; then
            MOVENAME=`echo $CHECKPRE | cut -c11-`
          else
            MOVENAME=`echo $CHECKPRE | cut -c5-`
          fi
          proc_log "We got: $CHECKPRE :where: $position"_"$relname :should be. renaming $MOVENAME for now"
          mv "$CHECKPRE" "TEMP_$MOVENAME"
          MOVEDONE="TRUE"
        fi

        EXISTALREADY=`ls | grep "_$relname$"`
        if [ -z "$( echo "$EXISTALREADY" | grep "^EMPTY_" )" ]; then
          if [ -z "$EXISTALREADY" ]; then
            proc_log "Creating $DESTDIR/$position"_"$relname"
            DIR="$position"_"$relname"
            mkdir -m777 "$DESTDIR/$DIR"
          else
            proc_log "Moving > $EXISTALREADY < to > $position"_"$relname <"
            mv -f "$EXISTALREADY" "$position"_"$relname"
          fi
        fi
      fi

    fi
  fi

  if [ "$VOTES" ]; then
    if [ "`echo "$each" | grep "^href"`" ]; then
      namestart="`echo "$each" | cut -d '>' -f2`"
    fi
  fi

  if [ "$RANK" ]; then
    if [ "`echo "$each" | grep "^size\="`" ]; then
      VOTES="`echo "$each" | cut -d '>' -f2 | cut -d '<' -f1`"
      RANK1="$RANK"
      unset RANK
    fi
  fi

  if [ "`echo "$each" | grep "^size\=" | grep "/b"`" ]; then
    RANK="`echo "$each" | cut -d '>' -f3 | cut -d '.' -f1`"

    ## Make sure its only a number we got. unset it otherwise.
    if [ "`echo "$RANK" | tr -d '[:digit:]'`" ]; then
      unset RANK
    else
      if [ "$TOP" ]; then
        if [ "$RANK" -gt "$TOP" ]; then
          break
        fi
      fi

      if [ "$( echo "$RANK" | grep "^[0-9]$" )" ]; then
        RANK="00$RANK"
      elif [ "$( echo "$RANK" | grep "^[0-9][0-9]$" )" ]; then
        RANK="0$RANK"
      fi
    fi

  fi

done

## If a dir was moved to TEMP_, move then to their final rankname.
if [ "$MOVEDONE" = "TRUE" ]; then
  proc_log "Moving back all temporary renamed dirs to their proper position."
  for each in `ls | grep "^TEMP_" | tr ' ' '^' | cut -c6-`; do
    each=`echo "$each" | tr '^' ' '`
    NEWNUM=`grep -w "$each" $LIST | cut -d ' ' -f1`
    if [ "$NEWNUM" ]; then
      proc_log "New number for $each is $NEWNUM. Moving TEMP_$each to $NEWNUM"_"$each"
      mv -f "TEMP_$each" "$NEWNUM"_"$each"
    else
      if [ "$DEL250plus" = "TRUE" ]; then
        proc_log "$each does not seem to be on top 250 anymore. Removing it."
        rm -f "TEMP_$each"
      else
        proc_log "$each does not seem to be on top 250 anymore. Renaming it."
        mv -f "TEMP_$each" "250+_$each"
      fi
    fi
  done
fi  

## Go through all dirs starting with EMPTY and check that they arent really filled.
for each in `ls | grep "^EMPTY_[0-9][0-9][0-9]_" | tr ' ' '^'`; do
  if [ -z "$ANNOUNCEEMPTY" ]; then
    proc_log "Checking if any rels marked EMPTY is not."
    ANNOUNCEEMPTY="FALSE"
  fi
  unset BROKE; unset SAIDIT
  each=`echo "$each" | tr '^' ' '`
  size=`du -kc "$each" | grep "total$" | cut -f1`
  num=10
  if [ "$size" -gt "5000" ]; then
    proc_log "Size on > $each < is greater than 5000kb. Waiting 30 seconds and checking again."
    sleep 30
    size2=`du -kc "$each" | grep "total$" | cut -f1`
    while [ "$size" != "$size2" ]; do
      if [ -z "$SAIDIT" ]; then
        proc_log "Checking size every 30 seconds for max 10 loops to make sure its not being upped still."
        SAIDIT=TRUE
      else
        proc_log "Times left: $num"
      fi
      sleep 30
      size=`du -kc "$each" | grep "total$" | cut -f1`
      if [ "$num" -lt "2" ]; then
         proc_log "Breaking. > $each < is still being upped."
         proc_log " "
         BROKE="TRUE"
         break
      fi
      num=$[$num-1]
    done

    if [ -z "$BROKE" ]; then
      newname=`echo $each | sed -e "s/^EMPTY_//"`
      proc_log " $each < seems filled. Removing the EMPTY_ part."
      mv "$each" "$newname"
    fi

  fi
done

## Go through all filled dirs to make sure they are not really empty.
for each in `ls | grep "^[0-9][0-9][0-9][\_\+]" | tr ' ' '^'`; do
  if [ -z "$ANNOUNCEFULL" ]; then
    proc_log "Checking if any rels marked as full are actually empty."
    ANNOUNCEFULL="FALSE"
  fi
  each=`echo "$each" | tr '^' ' '`
  size=`du -kc "$each" | grep "total$" | cut -f1`
  if [ "$size" -lt "5000" ]; then
    proc_log "Size is 5000kb or less. Renaming $each"
    mv "$each" "EMPTY_$each"
  fi
done

## Delete downloaded sourcefile(s)
cd $DESTDIR
for each in `ls | grep "^$source"`; do
  rm -f $each
done

exit 0