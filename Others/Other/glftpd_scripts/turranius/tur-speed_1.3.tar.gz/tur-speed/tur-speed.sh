#!/bin/bash
VER=1.3
#--------------------------------------------------------------------------#
# TUR-SPEED by Turranius.                                                  #
# A standalone/replacement !speed command for irc.                         #
#                                                                          #
#-[ Installation ]---------------------------------------------------------#
#                                                                          #
# - Copy tur-speed.sh to /glftpd/bin (or whereever you have it.)           #
#   Set chmod 755 on it.                                                   #
#                                                                          #
# - Copy tur-speed.tcl to your bots 'scripts' folder and load in in the    #
#   bots config file. Rehash the bot. Be certain to load it AFTER dark0n3s #
#   zipscript, or whatever you use. The !speed trigger will overwrite what #
#   your normal zipscript uses.                                            #
#   Edit tur-speed.tcl if you like to change the trigger. Its described in #
#   the tcl file.                                                          #
#   You may, of course, also change so your botscript runs tur-speed.sh    #
#   instead, but loading my tcl is probably easier for a lot of people.    #
#                                                                          #
# - Like some of my other scripts, this one uses tur-ftpwho to check who's #
#   online etc etc. This file is a seperate package and must be downloaded #
#   first. Current version of Tur-Speed requires 3.* of tur-ftpwho.        #
#                                                                          #
# Required bins: basename, dirname, bc, cut, tr, sed                       #
#                                                                          #
# Roger oh. That covers the file installation. Lets go over settings below.#
#                                                                          #
# WHOBIN=         Location of tur-ftpwho 3                                 #
#                                                                          #
# USERSFOLDER=    Path to your usersfolder. This will only be used to grep #
#                 the users primary group for the %GROUP% cookie.          #
#                 You may set this to "" and dont use %GROUP% if you like. #
#                                                                          #
# HIDE=           Hide activity in these folders. | separated.             #
#                 Dirs start with /site, so you can exclude /GROUPS/ to be #
#                 sure it only hits on full path, even though it will not  #
#                 show /site in the final output.                          #
#                                                                          #
# FAKESPEED=      If you are using f00-who, you will recognize this one.   #
#                 Basically, 1.0 will show correct speeds.                 #
#                 2.0 will fake the speed by double the amount.            #
#                 Set this one to "" if you do not have 'bc' installed or  #
#                 you will get errors.                                     #
#                                                                          #
# DIRPATH_MODE=   SIMPLE/FULL. Setting this to SIMPLE will only show the   #
#                 release name with the %DIRPATH% cookie. FULL = Show full #
#                 path. If the %DIRPATH% happens to be a CD[0-9], it will  #
#                 jump one more dir up.                                    #
#                                                                          #
# OUTMSG=         This is what the final message will be when a user is    #
#                 either uploading or downloading. There are a number of   #
#                 'cookies' you can use.                                   #
#                 %BOLD% will start and stop bold text in irc.             #
#                 %ULINE% will start and stop underlined text in irc.      #
#                 %USER% translates to the username checked.               #
#                 %GROUP% will fetch the primary group from the userfile   #
#                         providing USERSFOLDER is set.                    #
#                 %PID% is the pid of the specific user session.           #
#                 %STATUS% will be the word uploading or downloading.      #
#                 %SPEED% is the speed of transfer.                        #
#                 %FILE% shows which file is currently transfered.         #
#                 %DIRPATH% is the full path to the release. /site will be #
#                           cut out of the final output.                   #
#                                                                          #
# HIDETEXT=       If the user is uploading or downloading from one of the  #
#                 hidden folders, this is the output. Set it to "" to      #
#                 not say anything.                                        #
#                 This one uses all the cookies, like OUTMSG.              #
#                 You can of course include %SPEED% here anyway, but that  #
#                 will tip the users of that something is happening in     #
#                 the dir. The default makes it look like the user is not  #
#                 online.                                                  #
#                                                                          #
# SINGLEHIDE=     By default, hidden text is only displayed once since it  #
#                 would look rather silly if it said "not online" twice in #
#                 a row. If however, you wish to show speed or so, even if #
#                 the user is in a hidden dir, set this to FALSE and it    #
#                 will announce the HIDETEXT multiple times if the user is #
#                 logged on more then once (and in hidden dir).            #
#                                                                          #
# NOTONLINETEXT=  This is what it will show if the user is not online.     #
#                 Note that only the %USER% and %BOLD% cookies work here.  #
#                                                                          #
# IDLETEXT=       If a user has idled for more then 2-3 seconds, this will #
#                 be the output. As above, only %USER% and %BOLD% works.   #
#                                                                          #
# NOTIDLETEXT=    User is not idling, but is not uploading or downloading  #
#                 either = This is the output. %USER% and %BOLD% only.     #
#                                                                          #
# UPSTATUS=       The words that %STATUS% will output when user is         #
#                 uploading.                                               #
#                                                                          #
# DNSTATUS=       The words that %STATUS% will output when user is         #
#                 downloading.                                             #
#                                                                          #
# NOUSER=         If no user is specified, what to say?                    #
#                 Only %BOLD% works in this one.                           #
#                                                                          #
#-[ Testing ]--------------------------------------------------------------#
#                                                                          #
# Once set up, try and run tur-speed.sh from shell.                        #
# ./tur-trial.sh <user> (test)                                             #
# The 'test' will show you some more info that might be useful for when    #
# debugging. The tcl that runs this only sends one argument though, so     #
# test can never be given from irc.                                        #
#                                                                          #
# Now that it works and you love it, try !speed from irc, unless you       #
# changed the trigger in the tcl.                                          #
#                                                                          #
#-[ Contact ]--------------------------------------------------------------#
#                                                                          #
# Web: http://www.grandis.nu/glftpd or http://grandis.mine.nu              #
#                                                                          #
#-[ Changelog ]------------------------------------------------------------#
#                                                                          #
# 1.3    : Add: Added DIRPATH_MODE=SIMPLE/FULL so you can decide what the  #
#               %DIRPATH% cookie should show.                              #
#                                                                          #
# 1.2.1  : Fix: The %ULINE% cookie didnt work. Thanks GeN^ for the report. #
#                                                                          #
# 1.2    : Fix: Fixed to work with new tur-ftpwho (version 3+)             #
#                                                                          #
# 1.1    : Fix: Problems when user was dn/up twice in a hidden dir with    #
#               SINGLEHIDE=FALSE.                                          #
#          Fix: When user was in a hidden dir but was idle and you had     #
#               cookies in the HIDETEXT, it didnt translate those cookies  #
#               correctly. Will now show the IDLETEXT instead.             #
#          Add: Added %ULINE% cookie for underlined text.                  #
#                                                                          #
#          Note: Everyone should kick all affils cause its a pain in the   #
#                ass to consider predirs in every script. Just doooo it.   #
#                                                                          #
# 1.0      Initial release.                                                #
#                                                                          #
#-[ Settings ]-------------------------------------------------------------#

WHOBIN=/glftpd/bin/tur-ftpwho
USERSFOLDER="/glftpd/ftp-data/users"
HIDE="GROUPS|/PRE/"

FAKESPEED="1.0"

DIRPATH_MODE="FULL"

OUTMSG="%BOLD%%USER%%BOLD%/%GROUP% is %STATUS% at %BOLD%%SPEED%%BOLD% Kb/sec on %FILE% in %DIRPATH%"

HIDETEXT="%BOLD%%USER%%BOLD% is not online"
SINGLEHIDE=TRUE

NOTONLINETEXT="%BOLD%%USER%%BOLD% is %ULINE%not%ULINE% online"
IDLETEXT="%BOLD%%USER%%BOLD% is an idling mofo"
NOTIDLETEXT="%BOLD%%USER%%BOLD% is browsing around the site or is inbetween files"

UPSTATUS="uploading"
DNSTATUS="downloading"

NOUSER="Specify a %BOLD%user%BOLD% to check too."


###################################################################
# No changes below here.                                          #
###################################################################

## Procedure for translating cookies into actual variables.
proc_cookies() {
  if [ "$USER" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%USER%/$USER/g" )"
  fi
  if [ "$GROUP" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%GROUP%/$GROUP/g" )"
  fi
  if [ "$STATUS" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%STATUS%/$STATUS/g" )"
  fi
  if [ "$SPEED" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%SPEED%/$SPEED/g" )"
  fi
  if [ "$DIRPATH" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%DIRPATH%/$DIRPATH/g" )"
  fi
  if [ "$FILE" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%FILE%/$FILE/g" )"
  fi
  if [ "$STATUS" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%STATUS%/$STATUS/g" )"
  fi
  if [ "$PID" ]; then
    CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%PID%/$PID/g" )"
  fi
  CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%BOLD%//g" )"
  CHANGETEXT="$( echo $CHANGETEXT | sed -e "s/%ULINE%//g" )"
}

USER="$1"

## No argument given..
if [ -z "$1" ]; then
  CHANGETEXT="$NOUSER"
  proc_cookies
  echo $CHANGETEXT
  exit 0
fi

## Go check tur-ftpwho and read it.
for OUTPUT in `$WHOBIN | tr -d ' ' | grep "^$1^"`; do
  unset SAIDIT

  ## Start reading the raw data from tur-ftpwho.
  if [ "$SAIDIT" != "TRUE" ]; then
    PID="$( echo $OUTPUT | cut -d'^' -f2 )"
    IDLE="$( echo $OUTPUT | cut -d'^' -f3 )"
    SPEED="$( echo $OUTPUT | cut -d'^' -f4 )"
    if [ "`echo "$SPEED" | tr -d '.' | tr -d '[:digit:]'`" ]; then
      unset SPEED
    fi
    FULLDIRPATH="$( echo $OUTPUT | cut -d'^' -f5 )"
    ## If FULLDATAPATH is empty, it means user is not up or down.
    ## We still need the full path to check with HIDE, so move one up.
    if [ -z "$FULLDIRPATH" ]; then
      FULLDIRPATH="$( echo $OUTPUT | cut -d'^' -f4 )"
      unset SPEED
    fi
    ## Save the fullpath in RAWDATA before we modify it.
    RAWPATH="$FULLDIRPATH"
    ## Remove /site from full path and change all / to ^ (otherwise proc_cookies
    ## will fuck up).
    DIRPATH="$( dirname $FULLDIRPATH | sed -e "s/^\/site\///" )"
    if [ "$DIRPATH_MODE" = "SIMPLE" ]; then
      DIRPATH="$( basename $DIRPATH )"
      if [ "`echo "$DIRPATH" | egrep -i "^CD[1-9]|^SAMPLE$|^SUBS$"`" ]; then
        ## Rather ugly, I know..
        TEMP="$( dirname $FULLDIRPATH )"
        TEMP="$( dirname $TEMP )"
        DIRPATH="$( basename $TEMP )"
        unset TEMP
       fi
    fi
    DIRPATH="$( echo "$DIRPATH" | tr -s '/' '^' )"
    FILE="$( basename $FULLDIRPATH )"

    ## If FAKESPEED is set and we could read the speed then multiply it.
    if [ "$FAKESPEED" -a "$SPEED" ]; then
      ORGSPEED="$SPEED"
      SPEED="$( echo "$SPEED * $FAKESPEED" | bc -l )"
      ## If speed is .??, add a 0 to the start to make it 0.??
      if [ "$( echo $SPEED | cut -c1 )" = '.' ]; then
        SPEED="0$SPEED"
      fi
    fi

    ## Grab the group from userfile unless USERSFOLDER is empty.
    if [ "$USERSFOLDER" ]; then
      GROUP="$( grep "^GROUP " $USERSFOLDER/$USER | head -n1 | cut -d' ' -f2 )"
      if [ -z "$GROUP" ]; then
        GROUP="NoGroup"
      fi
    fi

    ## If user is uploading or downloading, set STATUS to whats defined.
    case $IDLE in
      Up:) STATUS="$UPSTATUS" ;;
      Dn:) STATUS="$DNSTATUS" ;;
    esac

    ## Check if the user is in a hidden path.
    if [ "$( echo $RAWPATH | egrep $HIDE )" ]; then
      ## Check if the user is logged on, except for this session.
      if [ "$SINGLEHIDE" = "TRUE" ]; then
        if [ "$CHECKPIDS" ]; then
          CHECKPIDS="$CHECKPIDS|$PID"
         else
          CHECKPIDS="$PID"
        fi
        unset MORE
        for each in `$WHOBIN | tr -d ' ' | egrep -vw "$CHECKPIDS" | sort | grep "^$1^"`; do
          MORE="TRUE"
          SAIDIT="TRUE"
        done
      fi

      ## If all is ok, then output the HIDETEXT message.
      if [ "$MORE" != "TRUE" ]; then
        if [ "$IDLE" != "Idle:" ]; then
          CHANGETEXT="$HIDETEXT"
          proc_cookies
          CHANGETEXT="$( echo $CHANGETEXT | tr -s '^' '/' )"
          echo $CHANGETEXT
          SAIDIT="TRUE"
        else
          if [ "$IDLETEXT" ]; then
            CHANGETEXT="$IDLETEXT"
            proc_cookies
            echo $CHANGETEXT
            SAIDIT="TRUE"
          fi
        fi
      fi
    fi
  else
    if [ "$SINGLEHIDE" = "TRUE" ]; then
      SAIDIT="TRUE"
    fi
  fi

  ## If the user is idle ..
  if [ "$SAIDIT" != "TRUE" ]; then
    if [ "$IDLE" = "Idle:" ]; then
      if [ "$IDLETEXT" ]; then
        CHANGETEXT="$IDLETEXT"
        proc_cookies
        echo $CHANGETEXT
      fi
      SAIDIT="TRUE"
    fi
  fi

  ## If the user isnt idle yet, but isnt upping or downloading...
  if [ "$SAIDIT" != "TRUE" ]; then
    if [ -z "$( echo "$IDLE" | egrep 'Up:|Dn:' )" ]; then
      if [ "$NOTIDLETEXT" ]; then
        CHANGETEXT="$NOTIDLETEXT"
        proc_cookies
        echo $CHANGETEXT
      fi
      SAIDIT="TRUE"
    fi
  fi

  ## If neither of the above, run the normal output.  
  if [ "$SAIDIT" != "TRUE" ]; then
    CHANGETEXT="$OUTMSG"
    proc_cookies

    CHANGETEXT="$( echo $CHANGETEXT | tr -s '^' '/' )"
    MSG="$( echo $CHANGETEXT | tr -s '^' '/' )"
    if [ "$2" = "test" -o "$2" = "debug" ]; then
      echo "Raw data  : $OUTPUT"
      if [ "$ORGSPEED" ]; then
        echo "Real speed: $ORGSPEED Kb/sec"
        echo "Fake *    : $FAKESPEED"
      fi
      echo "Speed     : $SPEED Kb/sec"
      echo "Full path : $FULLDIRPATH"
      echo "Directory : $DIRPATH"
      echo "Filename: : $FILE"
      if [ "$STATUS" ]; then
        echo "Status    : $STATUS"
      fi
      echo "Command:  : $IDLE"
      echo "Final output:"
    fi

    echo $MSG
    SAIDIT="TRUE"
  fi
done

## We didnt get ANY output from tur-ftpwho
if [ -z "$OUTPUT" ]; then
  if [ "$NOTONLINETEXT" ]; then
    CHANGETEXT="$NOTONLINETEXT"
    proc_cookies
    echo $CHANGETEXT
  fi
fi

