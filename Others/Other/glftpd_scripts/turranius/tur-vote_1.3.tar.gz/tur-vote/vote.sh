#!/bin/bash
VER="1.3"

###---------------------------------------------------------------------------###
# Voting System by Turranius.  ( http://www.grandis.nu/glftpd/ )                #
####                                                                         ####
# With this little baby, you can set up a voting booth on your site.            #
# You set up the vote, and up to 7 things that the users can answer to that     #
# vote. You do all this from inside the site, using different passwords for     #
# either ending a vote and setting up a new vote.                               #
# When you end the vote, the result will be written to a logfile, and if you    #
# wish, also display it in your irc channel.                                    #
####                                                                         ####
# Installation:                                                                 #
# Copy this script to /glftpd/bin, or where ever your set is.                   #
# Make it executable (chmod 755 vote.sh).                                       #
# Edit glftpd.conf, and add:                                                    #
# site_cmd vote           EXEC    /bin/vote.sh                                  #
# custom-vote             *                                                     #
#                                                                               #
# Note: If you get permission denied on votemain and votedata when running it,  #
# set chmod 777 on those files. If they are not there;                          #
# touch /glftpd/tmp/votemain; touch /glftpd/tmp/votedata                        #
# chmod 777 /glftpd/tmp/votemain; chmod 777 /glftpd/tmp/votemain                #
#                                                                               #   
# Set up the paths and settings below.                                          #
# Make sure you change the passwords for ENDVOTE and NEWVOTE. Only those who    #
# know these passwords can end a vote and set up a new one.                     #
# Update: As per v1.2, also change the REMIND password. When this password is   #
# given from site (site vote remind, as default) the bot, if setup, will        #
# announce the current vote and standings in your irc channel. Great to remind  #
# users to vote.                                                                #
#                                                                               #
# If you want new votes and end votes (with results) announced on irc, set      #
# USEBOT to TRUE. If VOTEBOT is also TRUE, users that vote will be announced    #
# too, along with what they voted on. Not always wanted I guess.                #
#                                                                               #
# If you want your votes to show up in the welcome message, add this to your    #
# /glftpd/ftp-data/misc/welcome.msg file:                                       #
# %EXEC/bin/vote.sh                                                             #
#                                                                               # 
# Once you are all set up, try setting up a new vote, using                     #
# site vote What-Ever-You-Set-NEWVOTE-to and it will explain to you what to do. #
#                                                                               #
# When you have archives a number of votes and want to close it, use            #
# site vote What-Ever-You-Set-ENDVOTE-to                                        #
#                                                                               #
# If you wish to change the bot announces, search for $BOTTRIGGER down below.   #
####                                                                         ####
# Setup for bot voting:                                                         #
# Added in v1.1 is the ability for users to vote from irc. This can be disabled #
# by setting BOTVOTING to FALSE, and not loading vote.tcl.                      #
# Botvoting requires username and password to be sent, so incase you are on     #
# Efnet or some other unencrypted irc server, it might not be the best idea to  #
# enable it. Yes, we still have an IP check in glftpd too, but still...         #
#                                                                               #
# If you wish to use it, copy vote.tcl to your bots config folder and load it   #
# in the bots .conf file. If vote.sh is not in /glftpd/bin, then change the     #
# path to it in the .tcl. Rehash the bot.                                       #
# Set BOTVOTING=TRUE.                                                           #
# Set BOTNAME= to the exact name of your bot, so we can tell users who to /msg  #
# to vote.                                                                      #
# Set PASSWD= to the full path of your passwd file.                             #
# Set PASSCHKBIN= to the full path of the passchk binary. This comes with       #
# Dark0n3s zipscript-z. I'll include the source to it. Compile it with          #
# gcc -o passchk passchk.c   if you do not already have it.                     #
# I have also included the binary of it, compiled on Mandrake 8.1.              #
# Make it executable and put it somewhere. Try to run it to make sure it works. #
#                                                                               #
# User can now vote, either from site with 'site vote', or from irc with        #
# /msg botname !vote username password VoteNumber                               #
# Just '/msg botname !vote' will show the vote and current answers for it.      # 
#                                                                               #
# Note: If theres a tie in the vote when closing it, it will select the first   #
# of the tied votes as winner.                                                  #
#                                                                               #
#--[ Zipscript-c Announce ]-----------------------------------------------------#
#                                                                               #
# To change the announce output, you need to search for TURGEN in the script.   #
# Be careful when doing that though =)                                          #
#                                                                               #
# Naturally, if you added the TURGEN trigger for any other script, you dont     #
# need to add it again.                                                         #
#                                                                               #
# Do the following in dZSbot.tcl and rehash the bot.                            #
# To test it, cut and paste this in your shell and it should                    #
# announce "Test Announce" to the channel:                                      #
#--                                                                           --#
# echo `date "+%a %b %e %T %Y"` TURGEN: \"Test Announce\" >> /glftpd/ftp-data/logs/glftpd.log
#--                                                                           --#
#                                                                               #
# To 'set msgtypes(DEFAULT)', add TURGEN                                        #
#                                                                               #
# Add the following in the appropriate places:                                  #
#--                                                                           --#
# set chanlist(TURGEN) "#YourChan"
#
# set disable(TURGEN) 0
#
# set variables(TURGEN) "%msg"
#
# set announce(TURGEN)   "%msg"
#--                                                                           --#
#                                                                               #
###---------------------------------------------------------------------------###
# If you need to contact me, /msg Turranius on Efnet/Linknet.                   #
# http://www.grandis.nu/glftpd                                                  #
#################################################################################
# Changelog:                                                                    #
# 1.3   : Fix: Finally took the time to do standard announces to the bot. See   #
#              instructions for zipscript-c in the install instructions.        #
#         Fix: Rewrote most parts, changing awk to cut, etc etc.                #
#         Fix: The logging said if the user voted from irc or not, but had it   #
#              backwards. Said (from irc) when voting from inside glftpd.       #
#              This was just in the LOGFILE, so no biggie.                      #
#                                                                               #
# 1.2.1 : Fix: Removed some debug stuff that was still in there if the user     #
#              typed in the wrong user/pass with irc voting.                    #
# 1.2   : Add: REMIND password added to settings. If you have the bot set up    #
#              and want to remind the users of the vote, do 'site vote remind'. #
#       : Cln: The vote files are only read once now, at the start, instead of  #
#              once in every function.                                          #
# 1.1.1 : Add: If BOTVOTING is true, it will also explain how to vote from      #
#              there in the messages on site.                                   #
# 1.1   : Add: Bot voting from users with vote.tcl                              #
# 1.0.1 : Fix: Spelling error. Youre replaced with your, etc. Damn Swedes :)    #
# 1.0   : Initial release.                                                      #
#################################################################################
# NOTE: All paths (except ROOTDIR) are relative to ROOTDIR                      #
#################################################################################

ROOTDIR="/glftpd"                      # Rootdir for glftpd.
TEMPDIR="/tmp"                         # Temporary dir to store votemain and votedata in.
LOGFILE="/ftp-data/logs/vote.log"      # Logfile to store.. ehh.. the log.
GLLOGFILE="/ftp-data/logs/glftpd.log"  # Glftpd's logfile, IF you have USEBOT on TRUE.

ENDVOTE="endvote-"                      # Password to end a vote (change this).
NEWVOTE="newvote-"                      # Password to set up a new vote (change this).
REMIND="remind-"                        # Password for a reminder on irc.

USEBOT="TRUE"                          # Want bot announces at all? (write to logfile).
VOTEBOT="TRUE"                         # If USEBOT="TRUE", shall we announce what people vote on too?
HEADER="-xXx- [VOTE] -"                # Header for bot output. \\002 = Start/Stop bold.

BOTVOTING="TRUE"                       # Have you loaded the .tcl and want to use botvoting?
BOTNAME='|xXx|'                        # Name of your bot so we know who we tell the user to /msg :)
PASSWD="/etc/passwd"                   # Path to passwd file incase we want botvoting.
PASSCHKBIN="/bin/passchk"              # Passchk file to use to verify a users password.


#####################################################################################
# No changes below here, bla bla. Yadda yadda, kick nuts etc.                       #
#####################################################################################

## Running from irc(shell) or inside glftpd?
if [ "$1" != "shell" ]; then
  ## Generic header for the Voting System. Yes you can change it if you like...
  echo "#----------------------------------------#"
  echo "# Voting System $VER by Turranius-2002/3"
else
  TEMPDIR="$ROOTDIR$TEMPDIR"
  LOGFILE="$ROOTDIR$LOGFILE"
  GLLOGFILE="$ROOTDIR$GLLOGFILE"
  PASSWD="$ROOTDIR$PASSWD"
  PASSCHKBIN="$ROOTDIR$PASSCHKBIN"
fi

## Can the votedata and votemain file be found?
if [ -e "$TEMPDIR/votedata" ]; then
  if [ -e "$TEMPDIR/votemain" ]; then
    if [ ! -e $LOGFILE ]; then
      echo "# Cant find $LOGFILE."
      echo "# I will make one, but you must set permissions on it."
      echo "# Recomend; chmod 777 $LOGFILE"
      touch $LOGFILE
      exit 1
    fi
  else
    echo "# Cant find $TEMPDIR/votemain."
    echo "# I will try and create it, but you must set permissions on it."
    echo "# Recomend; chmod 777 $TEMPDIR/votemain"
    touch $TEMPDIR/votemain
    exit 1
  fi
else
  echo "# Cant find $TEMPDIR/votedata."
  echo "# I will try and create it, but you must set the permissions on it."
  echo "# Recomend; chmod 777 $TEMPDIR/votedata"
  touch $TEMPDIR/votedata
  exit 1
fi

DATENOW=`date +%D" - "%T`

## Read the votemain file containing the question and possible votes.
QUESTION="$( grep -w QQUESTION= $TEMPDIR/votemain | cut -d '^' -f2 )"
if [ -z "$QUESTION" ]; then
  echo "# No vote set at this time."
  NOVOTE="YES"
else
  ANSWER0="$( grep -w QANSWER0= $TEMPDIR/votemain | cut -d '^' -f2 )"
  ANSWER1="$( grep -w QANSWER1= $TEMPDIR/votemain | cut -d '^' -f2 )"
  ANSWER2="$( grep -w QANSWER2= $TEMPDIR/votemain | cut -d '^' -f2 )"
  ANSWER3="$( grep -w QANSWER3= $TEMPDIR/votemain | cut -d '^' -f2 )"
  ANSWER4="$( grep -w QANSWER4= $TEMPDIR/votemain | cut -d '^' -f2 )"
  ANSWER5="$( grep -w QANSWER5= $TEMPDIR/votemain | cut -d '^' -f2 )"  
  ANSWER6="$( grep -w QANSWER6= $TEMPDIR/votemain | cut -d '^' -f2 )"
  DATE="$( grep -w QDATE= $TEMPDIR/votemain | cut -d '^' -f2 )"
  OWNER="$( grep -w QOWNER= $TEMPDIR/votemain | cut -d '^' -f2 )"
fi

# Check how many votes etc..
if [ -e "$TEMPDIR/votedata" -a "$NOVOTE" != "YES" ]; then
  VANSWER0="0"
  VANSWER1="0"
  VANSWER2="0"
  VANSWER3="0"
  VANSWER4="0"
  VANSWER5="0"
  VANSWER6="0"
  TOTALVOTES="0"

  for line in `cat $TEMPDIR/votedata`; do
    TOTALVOTES="$( expr "$TOTALVOTES" \+ "1" )"
    NUMBER="$( echo "$line" | cut -d '^' -f2 )"
    case $NUMBER in
      0) VANSWER0="$( expr "$VANSWER0" \+ "1" )" ;;    
      1) VANSWER1="$( expr "$VANSWER1" \+ "1" )" ;;    
      2) VANSWER2="$( expr "$VANSWER2" \+ "1" )" ;;    
      3) VANSWER3="$( expr "$VANSWER3" \+ "1" )" ;;    
      4) VANSWER4="$( expr "$VANSWER4" \+ "1" )" ;;    
      5) VANSWER5="$( expr "$VANSWER5" \+ "1" )" ;;    
      6) VANSWER6="$( expr "$VANSWER6" \+ "1" )" ;;    
      *) echo "# Misfire on line $line. Cant read vote."
    esac
  done

  ## Which one has the most votes?  
  TMPVAR="0"
  if [ "$VANSWER0" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER0"; BIG="VANSWER0"
  fi 
  if [ "$VANSWER1" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER1"; BIG="VANSWER1"
  fi  
  if [ "$VANSWER2" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER2"; BIG="VANSWER2"
  fi
  if [ "$VANSWER3" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER3"; BIG="VANSWER3"
  fi  
  if [ "$VANSWER4" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER4"; BIG="VANSWER4"
  fi  
  if [ "$VANSWER5" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER5"; BIG="VANSWER5"
  fi  
  if [ "$VANSWER6" -gt "$TMPVAR" ]; then
    TMPVAR="$VANSWER6"; BIG="VANSWER6"
  fi

  ## Declare the winner as $WIN and votes as $WINNR
  case $BIG in
    VANSWER0)
      WIN="$ANSWER0"; WINNR="$VANSWER0";;
    VANSWER1)
      WIN="$ANSWER1"; WINNR="$VANSWER1";;
    VANSWER2)
      WIN="$ANSWER2"; WINNR="$VANSWER2";;
    VANSWER3)
      WIN="$ANSWER3"; WINNR="$VANSWER3";;
    VANSWER4)
      WIN="$ANSWER4"; WINNR="$VANSWER4";;
    VANSWER5)
      WIN="$ANSWER5"; WINNR="$VANSWER5";;
    VANSWER6)
      WIN="$ANSWER6"; WINNR="$VANSWER6";;
  esac
fi

## Reminder to irc.
if [ "$1" = "$REMIND" ]; then
  echo "# Sending a reminder to irc."
  echo "# Current vote: $QUESTION"

  if [ "$USEBOT" != "TRUE" ]; then
    echo "# Hmm, USEBOT isnt enabled. I wont to this without it."
    exit 1
  fi

  if [ -z "$QUESTION" ]; then
    echo "# Hmm, theres no vote going on? Cant announce what I cant find."
    exit 1
  fi
 
  echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002$USER\\002 reminds you to vote on: \\002$QUESTION\\002\" >> $GLLOGFILE
  echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER0 vts\)\\002 0:\\002 $ANSWER0\" >> $GLLOGFILE
  echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER1 vts\)\\002 1:\\002 $ANSWER1\" >> $GLLOGFILE
  if [ "$ANSWER2" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER2 vts\)\\002 2:\\002 $ANSWER2\" >> $GLLOGFILE
  fi
  if [ "$ANSWER3" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER3 vts\)\\002 3:\\002 $ANSWER3\" >> $GLLOGFILE
  fi
  if [ "$ANSWER4" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER4 vts\)\\002 4:\\002 $ANSWER4\" >> $GLLOGFILE
  fi
  if [ "$ANSWER5" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER5 vts\)\\002 5:\\002 $ANSWER5\" >> $GLLOGFILE
  fi
  if [ "$ANSWER6" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \($VANSWER6 vts\)\\002 6:\\002 $ANSWER6\" >> $GLLOGFILE
  fi

  if [ "$WINNR" -gt "1" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER In the lead is \\002$WIN\\002 with\\002 $WINNR/$TOTALVOTES \\002votes.\" >> $GLLOGFILE
  fi

  echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER Vote with \'\\002site vote\\002\' from site, or \/msg $BOTNAME \!vote \<username\> \<password\> \<\# of vote\>\" >> $GLLOGFILE
  exit 0
fi

## End vote if the "password" is given.
if [ "$1" = "$ENDVOTE" ]; then
  if [ "$TMPVAR" = "0" ]; then
    echo "# No votes at all? Cant find a winner anyway..."
    if [ "$USEBOT" = "TRUE" ]; then
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 closes the vote: \\002$QUESTION\\002, opened by $OWNER at $DATE.\" >> $GLLOGFILE
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER \\002 No\\002 users had voted.\" >> $GLLOGFILE
    fi
    echo "" >  $TEMPDIR/votemain
    echo "" > $TEMPDIR/votedata
    exit 0
  fi

  echo "# Vote opened at $DATE by $OWNER"
  echo "# Vote closed at $DATENOW by $USER"
  echo "#"
  echo "# The question asked was: $QUESTION"
  echo "# Winner with $WINNR/$TOTALVOTES votes was $WIN"
  echo "#"
  echo "# Votes this voting period:"
  echo "# $ANSWER0 got $VANSWER0 votes"
  echo "# $ANSWER1 got $VANSWER1 votes"
  if [ "$ANSWER2" ]; then
    echo "# $ANSWER2 got $VANSWER2 votes"
  fi
  if [ "$ANSWER3" ]; then
    echo "# $ANSWER3 got $VANSWER3 votes"
  fi
  if [ "$ANSWER4" ]; then
    echo "# $ANSWER4 got $VANSWER4 votes"
  fi
  if [ "$ANSWER5" ]; then
    echo "# $ANSWER5 got $VANSWER5 votes"
  fi
  if [ "$ANSWER6" ]; then
    echo "# $ANSWER6 got $VANSWER6 votes"
  fi

  if [ "$USEBOT" = "TRUE" ]; then
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 closes the vote: \\002$QUESTION\\002, opened by $OWNER at $DATE.\" >> $GLLOGFILE
    echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER The winning vote was \\002$WIN\\002 with $WINNR\/$TOTALVOTES votes.\" >> $GLLOGFILE
  fi

  ## Logging
  echo "" >> $LOGFILE
  echo "$DATENOW : Voting closed by $USER for vote:" >> $LOGFILE
  echo "$QUESTION" >> $LOGFILE
  echo "Vote was set up by: $OWNER" >> $LOGFILE
  echo "Winning vote, with $WINNR/$TOTALVOTES was $WIN." >> $LOGFILE
  echo "" >> $LOGFILE
  echo "All scores, in vote order, was:" >> $LOGFILE
  echo "$ANSWER0 got $VANSWER0 votes" >> $LOGFILE
  echo "$ANSWER1 got $VANSWER1 votes" >> $LOGFILE
  if [ "$ANSWER2" ]; then
    echo "$ANSWER2 got $VANSWER2 votes" >> $LOGFILE
  fi
  if [ "$ANSWER3" ]; then
    echo "$ANSWER3 got $VANSWER3 votes" >> $LOGFILE
  fi
  if [ "$ANSWER4" ]; then
    echo "$ANSWER4 got $VANSWER4 votes" >> $LOGFILE
  fi
  if [ "$ANSWER5" ]; then
    echo "$ANSWER5 got $VANSWER5 votes" >> $LOGFILE
  fi
  if [ "$ANSWER6" ]; then
    echo "$ANSWER6 got $VANSWER6 votes" >> $LOGFILE
  fi

  echo "#"
  echo "" > $TEMPDIR/votemain
  echo "" > $TEMPDIR/votedata
  exit 0
fi

## No arguments given. Show current question and possible votes, if there are any.
if [ -z "$1" ]; then
  if [ "$NOVOTE" != "YES" ]; then
    echo "# Set on $DATE by $OWNER"
    echo "#"
    echo "# Question: $QUESTION"
    echo "# Total votes so far: $TOTALVOTES"
    echo "#"
    echo "# Your vote?"
    echo "# 0: $ANSWER0    -[ Votes: $VANSWER0 ]"
    echo "# 1: $ANSWER1    -[ Votes: $VANSWER1 ]"

    if [ "$ANSWER2" != "" ]; then
      echo "# 2: $ANSWER2    -[ Votes: $VANSWER2 ]"
    fi
    if [ "$ANSWER3" != "" ]; then
      echo "# 3: $ANSWER3    -[ Votes: $VANSWER3 ]"
    fi
    if [ "$ANSWER4" != "" ]; then
      echo "# 4: $ANSWER4    -[ Votes: $VANSWER4 ]"
    fi
    if [ "$ANSWER5" != "" ]; then
      echo "# 5: $ANSWER5    -[ Votes: $VANSWER5 ]"
    fi
    if [ "$ANSWER6" != "" ]; then
      echo "# 6: $ANSWER6    -[ Votes: $VANSWER6 ]"
    fi
    echo "#"
    echo "# Use 'site vote <number>' to vote"
    if [ "$BOTVOTING" = "TRUE" ]; then
      echo "# You can also use '/msg $BOTNAME !vote <user> <pass> <# of vote>' to vote."
    fi
    exit 0
  fi
fi

## VOTING FROM IRC !
## If called from bot. botcall
if [ "$1" = "shell" -a "$NOVOTE" != "YES" ]; then
  if [ -e "$GLLOGFILE" ]; then
    if [ -z "$2" ]; then
      ANSWERS="[ 0: $ANSWER0 ($VANSWER0 vts) ]-[ 1: $ANSWER1 ($VANSWER1 vts) ]"
      if [ "$ANSWER2" ]; then
        ANSWERS="$ANSWERS-[ 2: $ANSWER2 ($VANSWER2 vts) ]"
        if [ "$ANSWER3" ]; then 
          ANSWERS="$ANSWERS-[ 3: $ANSWER3 ($VANSWER3 vts) ]"
          if [ "$ANSWER4" ]; then 
            ANSWERS="$ANSWERS-[ 3: $ANSWER4 ($VANSWER4 vts) ]" 
            if [ "$ANSWER5" ]; then 
              ANSWERS="$ANSWERS-[ 5: $ANSWER5 ($VANSWER5 vts) ]"
              if [ "$ANSWER6" ]; then 
                ANSWERS="$ANSWERS-[ 6: $ANSWER6 ($VANSWER6 vts) ]"
              fi
            fi
          fi
        fi
      fi
              
      echo "Current Question is: $QUESTION - Possible answers are $ANSWERS - Vote with 'site vote' from site, or /msg $BOTNAME !vote <username> <password> <# of vote>" 
      exit 0
    fi
    USER="$2"
    PASS="$3"
    VOTE="$4"
    VERIFY="$($PASSCHKBIN $2 $3 $PASSWD)"

    if [ "$VERIFY" = "MATCH" ]; then
      VERIFY="$( grep -w $USER $TEMPDIR/votedata | cut -d '^' -f2 )"
      case $VERIFY in
        0) echo "# You have already voted for $ANSWER0 this period"; exit 0 ;;
        1) echo "# You have already voted for $ANSWER1 this period"; exit 0 ;;
        2) echo "# You have already voted for $ANSWER2 this period"; exit 0 ;;
        3) echo "# You have already voted for $ANSWER3 this period"; exit 0 ;;
        4) echo "# You have already voted for $ANSWER4 this period"; exit 0 ;;
        5) echo "# You have already voted for $ANSWER5 this period"; exit 0 ;;
        6) echo "# You have already voted for $ANSWER6 this period"; exit 0 ;;
      esac

      case $VOTE in
      0)
        echo "$USER^0" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 0 for $ANSWER0 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER0\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER0" ;;
      1)
        echo "$USER^1" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 1 for $ANSWER1 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER1\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER1" ;;
      2)
        if [ "$ANSWER2" = "" ]; then
          if [ "$USEBOT" = "TRUE" ]; then
            if [ "$VOTEBOT" = "TRUE" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to vote, but shoots himself in the leg!\" >> $GLLOGFILE
            fi
          fi
          echo "$VOTE is not an option in this vote!"
          exit 0
        fi
        echo "$USER^2" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 2 for $ANSWER2 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER2\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER2" ;;
      3)
        if [ "$ANSWER3" = "" ]; then
          if [ "$USEBOT" = "TRUE" ]; then
            if [ "$VOTEBOT" = "TRUE" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to vote, but fails horribly!\" >> $GLLOGFILE
            fi
          fi
          echo "$VOTE is not an option in this vote!"
          exit 0
        fi
        echo "$USER^3" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 3 for $ANSWER3 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER3\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER3" ;;
      4)
        if [ "$ANSWER4" = "" ]; then
          if [ "$USEBOT" = "TRUE" ]; then
            if [ "$VOTEBOT" = "TRUE" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 thinks he understands the voting system, but dosnt!\" >> $GLLOGFILE
            fi
          fi
          echo "$VOTE is not an option in this vote!"
          exit 0
        fi
        echo "$USER^4" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 4 for $ANSWER4 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER4\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER4" ;;
      5)
        if [ "$ANSWER5" = "" ]; then
          if [ "$USEBOT" = "TRUE" ]; then
            if [ "$VOTEBOT" = "TRUE" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to step to the left, but missed and falls to the right!\" >> $GLLOGFILE
            fi
          fi
          echo "$VOTE is not an option in this vote!"
          exit 0
        fi
        echo "$USER^5" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 5 for $ANSWER5 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER5\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER5" ;;
      6)
        if [ "$ANSWER6" = "" ]; then
          if [ "$USEBOT" = "TRUE" ]; then
            if [ "$VOTEBOT" = "TRUE" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 is NOT of legal age to vote yet.\" >> $GLLOGFILE
            fi
          fi
          echo "$VOTE is not an option in this vote!"
          exit 0
        fi
        echo "$USER^6" >> $TEMPDIR/votedata
        echo "$DATENOW : $USER voted 6 for $ANSWER6 (from irc)" >> $LOGFILE
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER6\\002 to the vote: $QUESTION\" >> $GLLOGFILE
          fi
        fi
        echo "# You have voted: $ANSWER6";;
      *) echo "Select a vote number from 0-6 too!"; exit 0;;
      esac
      NOVOTE="YES"
      exit 0
    else
      echo "No can do! Wrong username or password. Its !vote <username> <password> <vote 0-6>." # Wrong pass
      exit 0
    fi
  else
    echo "# Not running from shell or bad setup."  # Cant find gllog, so user did site vote shell from site.
    exit 0
  fi
fi

## VOTING FROM INSIDE GLFTPD.
## If first argument is 0-6 then Verify that the user has not already voted.
if [ "$1" = "0" -o "$1" = "1" -o "$1" = "2" -o "$1" = "3" -o "$1" = "4" -o "$1" = "5" -o "$1" = "6" ]; then
  touch $TEMPDIR/votedata
  VERIFY="$( grep -w $USER $TEMPDIR/votedata | cut -d '^' -f2 )"
  case $VERIFY in
    0) echo "# You have already voted for $ANSWER0 this period"; exit 0 ;;
    1) echo "# You have already voted for $ANSWER1 this period"; exit 0 ;;
    2) echo "# You have already voted for $ANSWER2 this period"; exit 0 ;;
    3) echo "# You have already voted for $ANSWER3 this period"; exit 0 ;;
    4) echo "# You have already voted for $ANSWER4 this period"; exit 0 ;;
    5) echo "# You have already voted for $ANSWER5 this period"; exit 0 ;;
    6) echo "# You have already voted for $ANSWER6 this period"; exit 0 ;;
  esac
fi

## Set the votes for this user. Write it to votedata.
if [ "$1" = "0" -o "$1" = "1" -o "$1" = "2" -o "$1" = "3" -o "$1" = "4" -o "$1" = "5" -o "$1" = "6" ]; then
  touch $TEMPDIR/votedata
  case $1 in
    0)
      echo "$USER^0" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 0 for $ANSWER0" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER0\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER0" ;;
    1)
      echo "$USER^1" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 1 for $ANSWER1" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER1\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER1" ;;
    2)
      if [ "$ANSWER2" = "" ]; then
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to vote, but shoots himself in the leg!\" >> $GLLOGFILE
          fi
        fi
        echo "# That is not a correct number!"
        exit 0
      fi
      echo "$USER^2" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 2 for $ANSWER2" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER2\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER2" ;;
    3)
      if [ "$ANSWER3" = "" ]; then
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to vote, but fails horribly!\" >> $GLLOGFILE
          fi
        fi
        echo "# That is not a correct number!"
        exit 0
      fi
      echo "$USER^3" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 3 for $ANSWER3" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER3\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER3" ;;
    4)
      if [ "$ANSWER4" = "" ]; then
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 thinks he understands the voting system, but dosnt!\" >> $GLLOGFILE
          fi
        fi
        echo "# That is not a correct number!"
        exit 0
      fi
      echo "$USER^4" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 4 for $ANSWER4" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER4\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER4" ;;
    5)
      if [ "$ANSWER5" = "" ]; then
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 tries to step to the left, but missed and falls to the right!\" >> $GLLOGFILE
          fi
        fi
        echo "# That is not a correct number!"
        exit 0
      fi
      echo "$USER^5" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 5 for $ANSWER5" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER5\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER5" ;;
    6)
      if [ "$ANSWER6" = "" ]; then
        if [ "$USEBOT" = "TRUE" ]; then
          if [ "$VOTEBOT" = "TRUE" ]; then
            echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 is NOT of legal age to vote yet.\" >> $GLLOGFILE
          fi
        fi
        echo "# That is not a correct number!"
        exit 0
      fi
      echo "$USER^6" >> $TEMPDIR/votedata
      echo "$DATENOW : $USER voted 6 for $ANSWER6" >> $LOGFILE
      if [ "$USEBOT" = "TRUE" ]; then
        if [ "$VOTEBOT" = "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 votes for \\002$ANSWER6\\002 to the vote: $QUESTION\" >> $GLLOGFILE
        fi
      fi
      echo "# You have voted: $ANSWER6"
  esac
  NOVOTE="YES"
fi

## New vote password given.

if [ "$1" = "$NEWVOTE" ]; then
  if [ -z "$2" ]; then
    QUESTION="$( grep -w QQUESTION= $TEMPDIR/votemain | cut -d '^' -f2 )"
    if [ "$QUESTION" ]; then
      echo "# There is already a vote going on."
      echo "# Existing vote is '$QUESTION'"
      echo "# You must first end that vote using the ENDVOTE password."
      exit 0
    else
      echo "# Setting up a new vote."
      echo "# use: site vote $NEWVOTE question choice0 choice1"
      echo "# You can have up to 7 different choices for the user to select from."
      echo "#"
      echo "# Be sure to use _ (underscore) instead of spaces!" 
      echo "# Underscores will be replaces by space when you're done"
      echo "#"
      echo "# Example:"
      echo "# site vote $NEWVOTE Do_I_rock_or_what?? For_sure! Yes! No You_suck!"
      echo "#"
    fi
  else
    QUESTION="$( grep -w QQUESTION= $TEMPDIR/votemain | cut -d '^' -f2 )"
    if [ "$QUESTION" ]; then
      echo "# There is already a vote going on."
      echo "# Existing vote is '$QUESTION'"
      echo "# You must first end that vote using the ENDVOTE password."
      exit 0
    fi

    if [ -z "$3" ]; then
      echo "# You must set atleast 2 possible answers to that question."
      echo "# Try it without any 3rd argument to explanation."
      exit 0
    fi
    if [ -z "$4" ]; then
      echo "# You must set atleast 2 possible answers to that question."
      echo "# Try it without any 3rd argument to explanation."
      exit 0
    fi

    QUEST="$( echo $2 | tr -s '_' ' ' )"
    ANSW3="$( echo $3 | tr -s '_' ' ' )"
    ANSW4="$( echo $4 | tr -s '_' ' ' )"
    if [ "$5" != "" ]; then
      ANSW5="$( echo $5 | tr -s '_' ' ' )"
    fi
    if [ "$6" != "" ]; then
      ANSW6="$( echo $6 | tr -s '_' ' ' )"
    fi
    if [ "$7" != "" ]; then
      ANSW7="$( echo $7 | tr -s '_' ' ' )"
    fi     
    if [ "$8" != "" ]; then
      ANSW8="$( echo $8 | tr -s '_' ' ' )"
    fi
    if [ "$9" != "" ]; then
      ANSW9="$( echo $9 | tr -s '_' ' ' )"
    fi

    echo "QQUESTION=^$QUEST" > $TEMPDIR/votemain
    echo "QANSWER0=^$ANSW3" >> $TEMPDIR/votemain
    echo "QANSWER1=^$ANSW4" >> $TEMPDIR/votemain
    echo "QANSWER2=^$ANSW5" >> $TEMPDIR/votemain
    echo "QANSWER3=^$ANSW6" >> $TEMPDIR/votemain
    echo "QANSWER4=^$ANSW7" >> $TEMPDIR/votemain
    echo "QANSWER5=^$ANSW8" >> $TEMPDIR/votemain
    echo "QANSWER6=^$ANSW9" >> $TEMPDIR/votemain
    echo "QDATE=^$DATENOW" >> $TEMPDIR/votemain
    echo "QOWNER=^$USER" >> $TEMPDIR/votemain

    echo "# Setting up the following vote:"
    echo "# Question: $QUEST"
    echo "# Choice 0: $ANSW3"
    echo "# Choice 1: $ANSW4"
    VOTENUMBERS="0: $ANSW3 .:. 1: $ANSW4"
    if [ "$ANSW5" != "" ]; then
      echo "# Choice 2: $ANSW5"
      VOTENUMBERS="$VOTENUMBERS .:. 2: $ANSW5"
    fi
    if [ "$ANSW6" != "" ]; then
      echo "# Choice 3: $ANSW6"
      VOTENUMBERS="$VOTENUMBERS .:. 3: $ANSW6"
    fi
    if [ "$ANSW7" != "" ]; then
      echo "# Choice 4: $ANSW7"
      VOTENUMBERS="$VOTENUMBERS .:. 4: $ANSW7"
    fi
    if [ "$ANSW8" != "" ]; then
      echo "# Choice 5: $ANSW8"
      VOTENUMBERS="$VOTENUMBERS .:. 5: $ANSW8"
    fi
    if [ "$ANSW9" != "" ]; then
      echo "# Choice 6: $ANSW9"
      VOTENUMBERS="$VOTENUMBERS .:. 6: $ANSW9"
    fi
    echo "#"
    echo "# Try 'site vote' too see it"
 
    if [ "$USEBOT" = "TRUE" ]; then
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 $USER\\002 loads up a new vote. He wants to know: \\002$QUEST\\002\" >> $GLLOGFILE
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER What would you say to that? $VOTENUMBERS\" >> $GLLOGFILE
      if [ "$BOTVOTING" = "TRUE" ]; then
        echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER Use \'\\002site vote\\002\' from site, or \/msg $BOTNAME \!vote \<username\> \<pass\> \<\# of vote\>\" >> $GLLOGFILE
      else
        echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER\\002 Use \'\\002site vote\\002\' from site to vote.\" >> $GLLOGFILE
      fi
    fi

    ## Logwrite
    echo "" >> $LOGFILE
    echo "------------[ Break ]--------------------------" >> $LOGFILE
    echo "$DATENOW : $USER sets up a new vote with the following settings:" >> $LOGFILE
    echo "Question: $QUEST" >> $LOGFILE
    echo "Choice 0: $ANSW3" >> $LOGFILE
    echo "Choice 1: $ANSW4" >> $LOGFILE
    if [ "$ANSW5" ]; then
      echo "Choice 2: $ANSW5" >> $LOGFILE
    fi
    if [ "$ANSW6" ]; then
      echo "Choice 3: $ANSW6" >> $LOGFILE
    fi
    if [ "$ANSW7" ]; then
      echo "Choice 4: $ANSW7" >> $LOGFILE
    fi
    if [ "$ANSW8" ]; then
      echo "Choice 5: $ANSW8" >> $LOGFILE
    fi
    if [ "$ANSW9" ]; then
      echo "Choice 6: $ANSW9" >> $LOGFILE
    fi
    echo "" >> $LOGFILE

    exit 0
  fi
else
  if [ "$NOVOTE" != "YES" ]; then
    if [ "$1" != "shell" ]; then
      echo "# Unknown command $1"
      echo "# Try 'site vote' only for help."
    fi
  fi
fi


exit 0
