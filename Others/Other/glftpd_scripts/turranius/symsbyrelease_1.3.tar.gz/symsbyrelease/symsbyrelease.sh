#!/bin/bash
VER=1.3
#--[ Epilogue ]------------------------------------------------------------#
#                                                                          #
# SymsByRelease by Turranius  ( http://www.grandis.nu/glftpd/ )            #
#                                                                          #
#--[ General info and Usage ]----------------------------------------------#
#                                                                          #
# This script has the ability to go through todays dated dir or the whole  #
# dated structure, looking at the contents and make a symlink of that      #
# release to a different dir.                                              #
#                                                                          #
# Like the default setup, you want to make symlinks of all dirs that       #
# contains the words "Keymaker.Only" or "KeyGen.Only" and make that        #
# symlink to a place called SymsByRelease.                                 #
#                                                                          #
# This SymsByRelease dir contains a number of subdirs, namely;             #
# ABC DEF GHI JKL MNO PQR STU VWX YZ 0-9                                   #
#                                                                          #
# The script will check which dir it should go into, based on the first    #
# letter in the release name, and make a symlink there.                    #
# It can make symlinks of certain releases only, or ALL releases.          #
#                                                                          #
# The script can be run in 2 modes. If you run it with the argument "all"  #
# it will clear out all the symlinks it made and make new ones from the    #
# whole dated structure. This takes some time, but will ensure there are   #
# no "dead" symlinks. If you run it without any arguments, it will only    #
# do todays dated dir, and it will only do this in the FIRST defined FROM  #
# dir, so set the incoming sections dated dir first.                       #
#                                                                          #
# This is faster, but leaves possible symlinks that goes to long gone      #
# releases.                                                                #
#                                                                          #
# Suggest you run it without any arguments on a daily basis and perhaps    #
# once a week run it with the argument "all".                              #
# So, Argument "all" = Remake it from scratch. Nice and clean.             #
# No argument = Only do todays dir. Faster but does not delete anything.   #
#                                                                          #
# Warning: When you run it in 'all' mode, it will delete everything in the #
# TOSTRUCTURE dirs (below). Since those symlinks only work from glftpd     #
# and not from shell, it wont delete the actual releases. Just make sure,  #
# after you run it the first time, that the symlinks does NOT work from    #
# shell and do NOT keep anything you wish to save in the TOSTRUCTURE dirs. #
#                                                                          #
# There are also two other args you can use. test and debug.               #
# With debug, it will will do everything it usually does but output it to  #
# the screen so you can see whats up.                                      #
# test is almost the same as debug. It will output what it does to screen  #
# but it wont actually DO anything. Just shows what it would have done.    #
# The order of all, test and debug does not matter.                        #
#                                                                          #
#--[ Installation ]--------------------------------------------------------#
#                                                                          #
# Installation:                                                            #
# Put this script in /glftpd/bin, or wherever you like really.             #
# Make it executable (chmod 755).                                          #
# Edit the settings below:                                                 #
#                                                                          #
#--[ Settings ]------------------------------------------------------------#
#                                                                          #
# FROM=      The parent dir of the dated dirs (that contains dated dirs)   #
#            You can put more parent dirs here, just separate them with    #
#            a space.                                                      #
#                                                                          #
# TO=        The parent dir of where they should go to. Where the syms     #
#            will go to.                                                   #
#                                                                          #
# TOSTRUCTURE= Important one. How does the dirs insite TO= look like?      #
#              You decide how the dirs are set up. The example is only     #
#              that, an example. You could might as well use               #
#              A B C D, etc.                                               #
#                                                                          #
#              If you want something that starts with A to be archived,    #
#              make sure there is one dir defined here containing A.       #
#              It is NOT case sensitive, so do NOT add A and a.            #
#                                                                          #
#              Just make sure you have a dir for every letter and number   #
#              if you want those letters and numbers moved.                #
#              A letter may NOT appear twice in here.                      #
#                                                                          #
#              Note: The 0-9 dir will automatically take 0123456789        #
#              I just thought it looked stupid with a dir called that :)   #
#              That is the ONLY dir you can do something like that on.     #
#                                                                          #
#              Note2: If it cant find any destination for the dir, it      #
#              will not make any symlinks for that release.                #
#                                                                          #
# MOVE=        What to you want moved to these dirs? Space separated.      #
#              Default is: "Keygen[\_\.\-]Only Keygenerator[\_\.\-]Only"   #
#              The [\_\.\-] means either _ . or -                          #
#                                                                          #
#              If a dir contains any of those, it will make a symlink to   #
#              it.                                                         #
#              This is not case sensitive. KeyGen is the same as keygen.   #
#                                                                          #
#              Set it to "." to make symlinks of ALL releases: MOVE="."    #
#              As dot (.) means everything, if you really just want it to  #
#              react to a dir with a . in it, you need to use \. here.     #
#                                                                          #
# EXCLUDE=     What to exclude? Space separated.                           #
#              As you can see, the default will exclude \[incomplete\].    #
#              [incomplete], in my case, are symlinks created by           #
#              zipscript-c. The copying will probably crap out if there is #
#              a dir containing wierd chars, so make sure you exclude      #
#              em if you have em.                                          #
#                                                                          #
#              Any special chars must be escaped (with \ first).           #
#              HINT: If, for instance, you do NOT want anything made by    #
#                    CORE archived, add \-CORE here.                       #
#                    Add the name of any PRE dirs here too just in case.   #
#                                                                          #
# DATED=       Just a number for how many characters there are in your     #
#              dated dirs. Its for "all" mode only. Basically just a       #
#              verification so the script knows its really a dated dir     #
#              it enters. If the dir does not have this many chars, the    #
#              script wont touch it. So if your dirs looks like 0405,      #
#              thats "4".                                                  #
#                                                                          #
#              Set it to "" if you would rather just go by the EXCLUDE     #
#              line above. This verification wont be used then.            #
#                                                                          #
# ALLNAME=     If you also want a single dir in the TO dir with all syms   #
#              in it, set its name here. It will be created too.           #
#              Otherwise, leave it empty to disable.                       #
#                                                                          #
# today=       This is how your "today" dated dir looks like. The default  #
#              is %m%d, which translates to 0527 for the 27th of May.      #
#              Do a date --help from shell to find out how it works.       #
#              You might have to change this for certain distros.          #
#                                                                          #
#--[ Other ]---------------------------------------------------------------#
#                                                                          #
# Once you have it set up, try and run it from shell with the argument     #
# test ( symsbyrelease test ). That will show you what it was supposed     #
# to have done. If there is no output, it did not find anything to symlink.#
# You can do the same for the all mode ( symsbyrelease.sh all test ).      #
#                                                                          #
# Finally, add it to crontab. Run it a few minutes before midnight each    #
# day so it can grab all the stuff before a new daily dir is created.      #
# Example crontab line:                                                    #
# 55 23 * * * /glftpd/bin/symsbyrelease.sh                                 #
# Will run it at 11:55PM each day.                                         #
#                                                                          #
#--[ Changelog ]-----------------------------------------------------------#
#                                                                          #
# 1.3 : Added ALLNAME setting incase you want a dir in the TO dir with     #
#       symlinks to all the other releases.                                #
#                                                                          #
# 1.2 : MUCH faster in 'all' mode.                                         #
#                                                                          #
#       EXCLUDE is no longer case sensitive.                               #
#                                                                          #
#       Should work on FBSD too now, even with DATED set.                  #
#                                                                          #
#       EXCLUDE changed to space as seperator to match MOVE. In reality    #
#       both space and | can be used as a seperator as it just replaces    #
#       all spaces with |.                                                 #
#                                                                          #
#       Default MOVE changed to [\_\-\.] instead of \. so it catches even  #
#       more.                                                              #
#                                                                          #
#       If you got too many symlinks in one dir, it couldnt delete them    #
#       all when running 'all'. It will now delete the entire dir and      #
#       recreate it with 755 perms instead. If you want some other chmod,  #
#       just search for m755.                                              #
#                                                                          #
# 1.1.1 : Just a documentation error. Its not 'full', its 'all'            #
#                                                                          #
# 1.1 : Faster search of dirs to check if they include any of the words.   #
#       Added argument "debug" to show what it does. "test" still works    #
#       too if you're just testing.                                        #
#                                                                          #
# 1.0 : Initial release.                                                   #
#                                                                          #
#--[ Contact ]-------------------------------------------------------------#
#                                                                          #
# Contact Turranius on efnet (turranius/turran/turr|away/turr|work).       #
#                                                                          #
#--[ Configuration Settings ]----------------------------------------------#

# Glftpd's rootdir
GLROOT="/glftpd"

# Parent dir of dated dirs. Space Separated.
FROM="
/site/0DAYS
/site/Archive/0DAYS-PDA/0DAYS1/2002
/site/Archive/0DAYS-PDA/0DAYS1/2003
/site/Archive/0DAYS-PDA/0DAYS1/2004
"

# Where to put the symlinks?
TO="/site/Archive/0DAYS-PDA/Bookware"

# Read about this one above. These should be in TO above.
TOSTRUCTURE="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z 0-9"

# What to look for in the dirs. Space Separated. "." = ALL
MOVE="Keygen[\_\.\-]Only Keygenerator[\_\.\-]Only"

# Any dirs or releases to ignore?
EXCLUDE='.message \[incomplete\] GROUPS \!Today \!Yesterday Today Yesterday'

# How many chars does your dated dirs have?
DATED="4"

# Create a "all" dir with all syms? Set name here.
ALLNAME="All"

# Todays dated dir.
today="$(date +%m%d)"

#--[ Script Start ]--------------------------------------------------------#

if [ -z "$GLROOT" ]; then
  echo "Your GLROOT is empty. It must not be, or it will actually delete the releases"
  echo "when you run it in 'all' mode."
  exit 1
fi

if [ ! -e $GLROOT$TO ]; then
  echo "Can not find $GLROOT$TO. Nowhere to move to".
  exit 1
fi

for toexists in $TOSTRUCTURE; do
  if [ ! -e "$GLROOT$TO/$toexists" ]; then
    echo "Can not find path $GLROOT$TO/$toexists."
    echo "You must create those dirs yourself and make sure we have permission to move stuff there."
    exit 1
  fi
done

A1=`echo "$1" | tr '[:upper:]' '[:lower:]'`
A2=`echo "$2" | tr '[:upper:]' '[:lower:]'`
A3=`echo "$3" | tr '[:upper:]' '[:lower:]'`

if [ "$A1" = "test" -o "$A2" = "test" -o "$A3" = "test" ]; then
  TEST="TRUE"
fi
if [ "$A1" = "debug" -o "$A2" = "debug" -o "$A3" = "debug" ]; then
  DEBUG="TRUE"
fi
if [ "$A1" = "all" -o "$A2" = "all" -o "$A3" = "all" ]; then
  ALL="TRUE"
fi

MOVE="$( echo $MOVE | tr ' ' '|' )"
EXCLUDE="$( echo $EXCLUDE | tr ' ' '|' )"

if [ "$DEBUG" = "TRUE" ]; then
  echo "Will check for dirs including: \"$MOVE\""
  echo "Excludes are: \"$EXCLUDE\""
  echo " "
fi

if [ "$ALL" = "TRUE" ]; then
  for todir in $TOSTRUCTURE; do
    if [ -e $GLROOT$TO/$todir ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Test: Deleting and recreating $GLROOT$TO/$todir"
      else
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Deleting and recreating $GLROOT$TO/$todir"
        fi
        rm -rf "$GLROOT$TO/$todir"
        mkdir -m755 "$GLROOT$TO/$todir"
      fi
    fi
  done
  if [ "$ALLNAME" ]; then
    if [ "$TEST" = "TRUE" ]; then
      echo "Test: Deleting and recreating $GLROOT$TO/$ALLNAME"
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Deleting and recreating $GLROOT$TO/$ALLNAME"
      fi
      rm -rf "$GLROOT$TO/$ALLNAME"
      mkdir -m755 "$GLROOT$TO/$ALLNAME"
    fi
  fi

  for dir in $FROM; do
    if [ -e "$GLROOT$dir" ]; then
      if [ "$DEBUG" = "TRUE" -o "$TEST" = "TRUE" ]; then echo "Entering $GLROOT$dir"; fi
      cd $GLROOT$dir

      for dateddir in `ls -f -A | egrep -vi $EXCLUDE`; do
        if [ "$DEBUG" = "TRUE" ]; then echo " "; echo "Checking rels in $GLROOT$dir/$dateddir"; fi
        if [ "$DATED" ]; then
          if [ "`echo "$dateddir" | grep -w "...."`" ]; then
            VERIFY="YES"
          else
            unset VERIFY
          fi
        else
          VERIFY="YES"
        fi

        if [ "$VERIFY" = "YES" ]; then
          cd $GLROOT$dir/$dateddir
          for i in `ls -f -A | egrep -vi "$EXCLUDE" | egrep -i "$MOVE"`; do
            LETTER="$( echo "$i" | cut -b -1 )"
            DONEIT="NO"
            for DEST in $TOSTRUCTURE; do
              if [ "$DONEIT" = "NO" ]; then
                if [ "$DEST" = "0-9" ]; then
                  DEST="0123456789"
                fi
                DESTF="$( echo "$DEST" | grep -i $LETTER )"
                if [ "$DESTF" ]; then
                  if [ "$DESTF" = "0123456789" ]; then
                    DESTF="0-9"
                  fi
                  DONEIT="YES"
                  if [ ! -L $GLROOT$TO/$DESTF/$i ]; then
                    if [ "$TEST" = "TRUE" ]; then
                      echo " $DESTF <- $i (test)"
                    else
                      ln -s $dir/$dateddir/$i $GLROOT$TO/$DESTF/$i
                      if [ "$ALLNAME" ]; then
                        ln -s $dir/$dateddir/$i $GLROOT$TO/$ALLNAME/$i
                      fi
                      if [ "$DEBUG" = "TRUE" ]; then echo " $DESTF <- $i"; fi
                    fi
                  else
                    if [ "$DEBUG" = "TRUE" ]; then echo " Symlink already exists for $i"; fi
                  fi
                fi                
              fi
            done
          done
        fi
      done
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Can not find $GLROOT$dir to check in."     
      fi
    fi
  done
  exit 0
fi

for dir in $FROM; do
  if [ "$DEBUG" = "TRUE" ]; then echo "Entering $GLROOT$dir/$today"; fi

  if [ -e "$GLROOT$dir" ]; then
    cd $GLROOT$dir/$today
    for i in `ls -f -A | egrep -vi "$EXCLUDE" | egrep -i "$MOVE"`; do
      LETTER="$( echo "$i" | cut -b -1 )"
      DONEIT="NO"
      for DEST in $TOSTRUCTURE; do
        if [ "$DONEIT" = "NO" ]; then
          if [ "$DEST" = "0-9" ]; then
            DEST="0123456789"
          fi
          DESTF="$( echo $DEST | grep -i $LETTER )"
          if [ "$DESTF" != "" ]; then
            if [ "$DESTF" = "0123456789" ]; then
              DESTF="0-9"
            fi
            DONEIT="YES"
            if [ ! -L $GLROOT$TO/$DESTF/$i ]; then
              if [ "$TEST" = "TRUE" ]; then
                echo "$DESTF <- $i (test)"
              else
                ln -s $dir/$today/$i $GLROOT$TO/$DESTF/$i
                if [ "$ALLNAME" ]; then
                  ln -s $dir/$today/$i $GLROOT$TO/$ALLNAME/$i
                fi
                if [ "$DEBUG" = "TRUE" ]; then echo "$DESTF <- $i"; fi
              fi
              break
            else
              if [ "$DEBUG" = "TRUE" ]; then echo " Symlink already exists for $i"; fi
            fi
          fi
        fi
      done
    done
  else
    if [ "$DEBUG" = "TRUE" ]; then
      echo "Can not find $GLROOT$dir/$today to check in."     
    fi
  fi
  break
done
exit 0
