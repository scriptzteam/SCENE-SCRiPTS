#!/bin/bash
VER=1.0
#-------------------------------------------------------------------#
# Tur-UserInfo by Turranius.                                        #
# Useless script to show info about a user in irc. What it          #
# shows and how is entirely up to you.                              #
#                                                                   #
#-[ Installation ]--------------------------------------------------#
#                                                                   #
# Put tur-userinfo.sh in /glftpd/bin and make it executable         #
# ( chmod 755 tur-userinfo.sh )                                     #
# Put tur-userinfo.tcl in your bots 'scripts' folder, load it in    #
# bots config folder and rehash the bot.                            #
#                                                                   #
# Configure the settings below.                                     #
#                                                                   #
# USERDIR    = Path to users                                        #
# PASSWD     = Path to passwd file                                  #
# STATSBIN   = This script requires the binary 'stats' which comes  #
#              with glftpd. This is the path to it.                 #
# DATEBIN    = Shouldnt need to change this. See Note2 below.       #
# SITENAME   = Name of your site                                    #
# NOUSER     = What to say no user is specified                     #
# NOEXISTS   = What to say if the user specified does not exist     #
#                                                                   #
# Ok, next are some cookie explanations for what you can use in the #
# output. Below that is a 'proc_output() {' line. Everything within #
# those { } is what will be said in the output.                     #
# You can change this as you wish. If you want just one line, just  #
# make one big OUTPUT. Every OUTPUT must be followed by the         #
# proc_cookies; echo "$OUTPUT"                                      #
# (proc_cookies translates cookes to real values and echo $OUTPUT   #
# does the outputting to screen/chan).                              #
#                                                                   #
# Play around with this all you want.                               #
#                                                                   #
# Try running it from shell. If it works from shell, it should work #
# from bot.                                                         #
#                                                                   #
# Note1: This is a quick script that took almost no time to         #
#        make. I'm sure it can be written better and nicer.         #
#                                                                   #
# Note2: This has been tested on RedHat and Mandrake.               #
#        FBSD users wont get this to work out of the box. You need  #
#        to compile sh-utils and use 'gdate' instead of 'date'.     #
#        The FBSD guru silicon^ informs me that you should be able  #
#        to:                                                        #
#        cd /usr/ports/misc/sh-utils                                #
#        make && make install                                       #
#        Then change DATEBIN to ="/usr/local/bin/gdate"             #
#                                                                   #
#-[ Contact info ]--------------------------------------------------#
#                                                                   #
# Contact Turranius on efnet. Usually in #glftpd                    #
# Web: http://www.grandis.nu/glftpd or http://grandis.mine.nu       #
#                                                                   #
#-[ Settings ]------------------------------------------------------#

USERDIR=/glftpd/ftp-data/users
PASSWD=/glftpd/etc/passwd
STATSBIN=/glftpd/bin/stats
DATEBIN=date

SITENAME="-xXx-"
NOUSER="Specify a user to check too"
NOEXISTS="%BOLD%%USER%%BOLD% does %ULINE%not%ULINE% exist on $SITENAME"

## Cookies:
# %BOLD%          = Start and stop bold text
# %ULINE%         = Start and stop underlined text
#
# %USER%          = Username checked
# %GROUP%         = Primary group of user
# %RATIO%         = Users ratio
# %FLAGS%         = Users flags
# %DATEADDED%     = The date the user was added
# %DAYSAGO%       = How many days since user was added
# %ADDEDBY%       = Who added this user
# %TIMESNUKED%    = How many times user got nuked
# %MBNUKED%       = How much in MB was nuked
# %TIMESLOGIN%    = How many times the user logged in
# %LOGINTIMERANK% = Rank users on how many times they logged in
# %LASTON%        = How long since user was last logged on
# %ONTODAY%       = How many minutes the users been online today
#
# %ALUPRANK%      = Users rank on All Uploads
# %ALUPMB%        = Users alltime upload in MB
# %ALUPFILE%      = Users alltime upload in files
# %ALUPSPD%       = Users speed on alltime up.
#
## Other cookies are ALDN, MNUP, MNDN, WKUP, WKDN, DAUP, DADN

## Below is what it will say. Its:
## OUTPUT="Text to say"
## proc_cookies; echo "$OUTPUT"
##
## etc
proc_output() {
  ##############################################################################################################################

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% was added on %DATEADDED% (%DAYSAGO% days ago) by %ADDEDBY%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% has logged in a total of %TIMESLOGIN% times putting %USER% at %BOLD%# %LOGINTIMESRANK%%BOLD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% was last seen logging on %LASTON% ago. Time on today: %ULINE%%ONTODAY%%ULINE% minutes"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% Times nuked: %TIMESNUKED% - MB Nuked: %MBNUKED% - Last nuke was %LASTNUKED% ago"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% ALUP %BOLD%#%ALUPRANK%%BOLD% - %ALUPFILE% files in %ALUPMB% at %ALUPSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% ALDN %BOLD%#%ALDNRANK%%BOLD% - %ALDNFILE% files in %ALDNMB% at %ALDNSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% MNUP %BOLD%#%MNUPRANK%%BOLD% - %MNUPFILE% files in %MNUPMB% at %MNUPSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% MNDN %BOLD%#%MNDNRANK%%BOLD% - %MNDNFILE% files in %MNDNMB% at %MNDNSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% WKUP %BOLD%#%WKUPRANK%%BOLD% - %WKUPFILE% files in %WKUPMB% at %WKUPSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% WKDN %BOLD%#%WKDNRANK%%BOLD% - %WKDNFILE% files in %WKDNMB% at %WKDNSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% DAUP %BOLD%#%DAUPRANK%%BOLD% - %DAUPFILE% files in %DAUPMB% at %DAUPSPD%"
  proc_cookies; echo "$OUTPUT"

  OUTPUT="%BOLD%%SITENAME% [STATS] %USER%%BOLD%/%GROUP% DADN %BOLD%#%DADNRANK%%BOLD% - %DADNFILE% files in %DADNMB% at %DADNSPD%"
  proc_cookies; echo "$OUTPUT"

  ##############################################################################################################################
}

##################################################################################
# No changes below here.                                                         #
##################################################################################

USER="$1"

proc_cookies() {
  if [ "$USER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%USER%/$USER/g" )"
  fi
  if [ "$RATIO" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%RATIO%/$RATIO/g" )"
  fi
  if [ "$FLAGS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%FLAGS%/$FLAGS/g" )"
  fi
  if [ "$GROUP" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%GROUP%/$GROUP/g" )"
  fi
  if [ "$DAYSAGO" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAYSAGO%/$DAYSAGO/g" )"
  fi
  if [ "$USERADDED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DATEADDED%/$USERADDED/g" )"
  fi
  if [ "$ADDEDBY" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ADDEDBY%/$ADDEDBY/g" )"
  fi
  if [ "$TIMESLOGIN" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TIMESLOGIN%/$TIMESLOGIN/g" )"
  fi
  if [ "$LOGINTIMESRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%LOGINTIMESRANK%/$LOGINTIMESRANK/g" )"
  fi
  if [ "$TIMESNUKED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TIMESNUKED%/$TIMESNUKED/g" )"
  fi
  if [ "$MBNUKED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MBNUKED%/$MBNUKED/g" )"
  fi
  if [ "$LASTNUKED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%LASTNUKED%/$LASTNUKED/g" )"
  fi
  if [ "$LASTON" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%LASTON%/$LASTON/g" )"
  fi
  if [ "$ONTODAY" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ONTODAY%/$ONTODAY/g" )"
  fi
  if [ "$SITENAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SITENAME%/$SITENAME/g" )"
  fi
  if [ "$ALUPRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALUPRANK%/$ALUPRANK/g" )"
  fi
  if [ "$ALUPFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALUPFILE%/$ALUPFILE/g" )"
  fi
  if [ "$ALUPMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALUPMB%/$ALUPMB/g" )"
  fi
  if [ "$ALUPSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALUPSPD%/$ALUPSPD/g" )"
  fi
  if [ "$ALDNRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALDNRANK%/$ALDNRANK/g" )"
  fi
  if [ "$ALDNFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALDNFILE%/$ALDNFILE/g" )"
  fi
  if [ "$ALDNMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALDNMB%/$ALDNMB/g" )"
  fi
  if [ "$ALDNSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALDNSPD%/$ALDNSPD/g" )"
  fi
  if [ "$MNUPRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNUPRANK%/$MNUPRANK/g" )"
  fi
  if [ "$MNUPFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNUPFILE%/$MNUPFILE/g" )"
  fi
  if [ "$MNUPMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNUPMB%/$MNUPMB/g" )"
  fi
  if [ "$MNUPSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNUPSPD%/$MNUPSPD/g" )"
  fi
  if [ "$MNDNRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNDNRANK%/$MNDNRANK/g" )"
  fi
  if [ "$MNDNFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNDNFILE%/$MNDNFILE/g" )"
  fi
  if [ "$MNDNMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNDNMB%/$MNDNMB/g" )"
  fi
  if [ "$MNDNSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MNDNSPD%/$MNDNSPD/g" )"
  fi
  if [ "$WKUPRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKUPRANK%/$WKUPRANK/g" )"
  fi
  if [ "$WKUPFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKUPFILE%/$WKUPFILE/g" )"
  fi
  if [ "$WKUPMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKUPMB%/$WKUPMB/g" )"
  fi
  if [ "$WKUPSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKUPSPD%/$WKUPSPD/g" )"
  fi
  if [ "$WKDNRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKDNRANK%/$WKDNRANK/g" )"
  fi
  if [ "$WKDNFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKDNFILE%/$WKDNFILE/g" )"
  fi
  if [ "$WKDNMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKDNMB%/$WKDNMB/g" )"
  fi
  if [ "$WKDNSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WKDNSPD%/$WKDNSPD/g" )"
  fi
  if [ "$DAUPRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAUPRANK%/$DAUPRANK/g" )"
  fi
  if [ "$DAUPFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAUPFILE%/$DAUPFILE/g" )"
  fi
  if [ "$DAUPMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAUPMB%/$DAUPMB/g" )"
  fi
  if [ "$DAUPSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAUPSPD%/$DAUPSPD/g" )"
  fi
  if [ "$DADNRANK" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DADNRANK%/$DADNRANK/g" )"
  fi
  if [ "$DADNFILE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DADNFILE%/$DADNFILE/g" )"
  fi
  if [ "$DADNMB" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DADNMB%/$DADNMB/g" )"
  fi
  if [ "$DADNSPD" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DADNSPD%/$DADNSPD/g" )"
  fi
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

if [ -z "$USER" ]; then
  OUTPUT="$NOUSER"
  proc_cookies
  echo "$OUTPUT"
  exit 0
fi

if [ ! -e "$USERDIR/$USER" ]; then
  OUTPUT="$NOEXISTS"
  proc_cookies
  echo "$OUTPUT"
  exit 0
fi

if [ ! -x $STATSBIN ]; then
  echo "Error: Cant execute STATSBIN: $STATSBIN - Check path and permissions."
  exit 0
fi

GROUP="$( grep "^GROUP " $USERDIR/$USER | cut -d' ' -f2 | head -n1 )"
if [ -z "$GROUP" ]; then
  GROUP="NoGroup"
fi

RATIO="$( grep "^RATIO " $USERDIR/$USER | cut -d' ' -f2 | head -n1 )"
if [ -z "$RATIO" ]; then
  RATIO="?"
fi

FLAGS="$( grep "^FLAGS " $USERDIR/$USER | cut -d' ' -f2 | head -n1 )"
if [ -z "$FLAGS" ]; then
  FLAGS="?"
fi

num=0
for rawdata in `grep "^TIME " $USERDIR/* | sort -k2 -n -r | tr -s ' ' '^'`; do
  let num=$num+1
  username="$( echo $rawdata | cut -d':' -f1 )"
  username="$( basename $username )"
  TIMESLOGIN="$( echo $rawdata | cut -d'^' -f2 )"
  if [ "$username" = "$USER" ]; then
    LOGINTIMESRANK="$num"
    break
  fi
done
if [ -z "$LOGINTIMESRANK" ]; then
  TIMESLOGINRANK="?"
fi
if [ -z "$TIMESLOGIN" ]; then
  TIMESLOGIN="?"
fi

TIMESNUKED="$( grep "^NUKE " $USERDIR/$USER | cut -d' ' -f3 | head -n1 )"
if [ -z "$TIMESNUKED" ]; then
  FLAGS="?"
fi

MBNUKED="$( grep "^NUKE " $USERDIR/$USER | cut -d' ' -f4 | head -n1 )"
if [ -z "$MBNUKED" ]; then
  FLAGS="?"
fi

ADDEDBYRAW="$( grep "^USER " $USERDIR/$USER )"
if [ "$( echo $ADDEDBYRAW | cut -d' ' -f2 )" = "Added" ]; then
  ADDEDBY="$( echo $ADDEDBYRAW | cut -d' ' -f4 )"
else
  ADDEDBY="?"
fi

ONTODAY="$( grep "^TIME " $USERDIR/$USER | cut -d' ' -f5 )"
if [ "$ONTODAY" ]; then
  ONTODAY="$( expr "$ONTODAY" \/ "60" | cut -d'.' -f1 )"
else
  ONTODAY="0"
fi

RAWDATA="$( $STATSBIN -a -u -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  ALUPRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  ALUPFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  ALUPMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  ALUPSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  ALUPRANK="--"
  ALUPFILE="0"
  ALUPMB="0MB"
  ALUPDPD="0KBs"
fi

RAWDATA="$( $STATSBIN -a -d -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  ALDNRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  ALDNFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  ALDNMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  ALDNSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  ALDNRANK="--"
  ALDNFILE="0"
  ALDNMB="0MB"
  ALDNSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -m -u -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  MNUPRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  MNUPFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  MNUPMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  MNUPSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  MNUPRANK="--"
  MNUPFILE="0"
  MNUPMB="0MB"
  MNUPSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -m -d -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  MNDNRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  MNDNFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  MNDNMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  MNDNSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  MNDNRANK="--"
  MNDNFILE="0"
  MNDNMB="0MB"
  MNDNSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -w -u -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  WKUPRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  WKUPFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  WKUPMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  WKUPSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  WKUPRANK="--"
  WKUPFILE="0"
  WKUPMB="0MB"
  WKUPSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -w -d -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  WKDNRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  WKDNFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  WKDNMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  WKDNSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  WKDNRANK="--"
  WKDNFILE="0"
  WKDNMB="0MB"
  WKDNSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -t -u -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  DAUPRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  DAUPFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  DAUPMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  DAUPSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  DAUPRANK="--"
  DAUPFILE="0"
  DAUPMB="0MB"
  DAUPSPD="0KBs"
fi

RAWDATA="$( $STATSBIN -t -d -x 500 | cut -b 1-16,47-80 | grep -w $USER )"
if [ "$RAWDATA" ]; then
  DADNRANK="$( echo $RAWDATA | cut -d' ' -f1 | tr -d '[' | tr -d ']' )"
  DADNFILE="$( echo $RAWDATA | cut -d' ' -f3 )"
  DADNMB="$( echo $RAWDATA | cut -d' ' -f4 )"
  DADNSPD="$( echo $RAWDATA | cut -d' ' -f5 )"
else
  DADNRANK="--"
  DADNFILE="0"
  DADNMB="0MB"
  DADNSPD="0KBs"
fi

proc_timediff() {
  ## NOTE: Parts on timediff taken from timediff.sh by Mihly Gyulai (2000-03-04)

  DATENOW="$( $DATEBIN +%m/%d/%y )"
  USERADDED="$( grep "^$USER:" $PASSWD | cut -d':' -f5 )"
  USERADDED2="$( echo $USERADDED | tr -s '-' '/' )"

  datum_1=`$DATEBIN -d "$USERADDED2" +%s`
  datum_2=`$DATEBIN -d "$DATENOW" +%s`

  let DIFF=$datum_2-$datum_1;
 
  if [ $DIFF -lt 0 ]; then 
    let DIFF=DIFF*-1
  fi

  let PERC=$DIFF/60;
  let ORA=$PERC/60;
  let DAYSAGO=$ORA/24;
}

proc_nukediff() {
  ## NOTE: Parts on timediff taken from timediff.sh by Mihly Gyulai (2000-03-04)

  datum_1="$( $DATEBIN +%s )"
  datum_2="$( grep "^NUKE " $USERDIR/$USER | cut -d ' ' -f2 )" 

  let DIFF=$datum_2-$datum_1;
 
  if [ $DIFF -lt 0 ]; then 
    let DIFF=DIFF*-1
  fi

  let PERC=$DIFF/60;
  let ORA=$PERC/60;
  let NAP=$ORA/24;
  let ORA_DIFF=$ORA-24*$NAP;
  let PERC_DIFF=$PERC-60*$ORA
  let MP_DIFF=$DIFF-60*$PERC

  if [ "$NAP" -gt "365" ]; then
    LASTNUKED="more than a year"
  else
    LASTNUKED="$NAP days, $ORA_DIFF hours"
    if [ "$PERC_DIFF" -gt "1" ]; then
      LASTNUKED="$LASTNUKED, $PERC_DIFF minutes"
    else
      LASTNUKED="$LASTNUKED, $PERC_DIFF minute"
    fi
    if [ "$MP_DIFF" -gt "1" ]; then
      LASTNUKED="$LASTNUKED, $MP_DIFF seconds"
    else
      LASTNUKED="$LASTNUKED, $MP_DIFF second"
    fi
  fi
}

proc_laston() {
  ## NOTE: Parts on timediff taken from timediff.sh by Mihly Gyulai (2000-03-04)

  datum_1="$( $DATEBIN +%s )"
  datum_2="$( grep "^TIME " $USERDIR/$USER | cut -d ' ' -f3 )" 

  let DIFF=$datum_2-$datum_1;
 
  if [ $DIFF -lt 0 ]; then 
    let DIFF=DIFF*-1
  fi

  let PERC=$DIFF/60;
  let ORA=$PERC/60;
  let NAP=$ORA/24;
  let ORA_DIFF=$ORA-24*$NAP;
  let PERC_DIFF=$PERC-60*$ORA
  let MP_DIFF=$DIFF-60*$PERC

  if [ "$NAP" -gt "365" ]; then
    LASTON="more than a year"
  else
    LASTON="$NAP days, $ORA_DIFF hours"
    if [ "$PERC_DIFF" -gt "1" ]; then
      LASTON="$LASTON, $PERC_DIFF minutes"
    else
      LASTON="$LASTON, $PERC_DIFF minute"
    fi
    if [ "$MP_DIFF" -gt "1" ]; then
      LASTON="$LASTON, $MP_DIFF seconds"
    else
      LASTON="$LASTON, $MP_DIFF second"
    fi
  fi
}

proc_laston
proc_nukediff
proc_timediff

proc_output