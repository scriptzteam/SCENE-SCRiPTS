#!/bin/bash
VER=1.1
#-----------------------------------------------------------------------------#
#                                                                             #
# Tur-QuotaCleanup. An addon to Tur-Trial 2.0+ for deleting the worst of a    #
# predefined number of curriers.                                              #
# For example, keeping only the 20 best uppers and deleting the rest.         #
# REQUIRES A WORKING Tur-Trial SET FOR QUOTA!                                 #
#                                                                             #
# Uses the same config as Tur-Trial ( tur-trial.conf ) and utilizes some of   #
# same functions.                                                             #
#                                                                             #
#-[ Installation ]------------------------------------------------------------#
#                                                                             #
# Preferebly, put this script in the same folder.. err dir, as tur-trial.conf.#
# Make it executable ( chmod 755 ).                                           #
#                                                                             #
# There is also a tcl. Its ment to replace tur-trial.tcl so load this one     #
# instead, or load it after tur-trial.tcl.                                    #
#                                                                             #
# Set options below:                                                          #
# TRIALSCRIPT=    Full path to tur-trial.sh                                   #
# SAFE=           How many of the top curriers (that is on quota) should we   #
#                 keep ?.                                                     #
#                                                                             #
# CLEANUPLOG=     Where to log to.                                            #
#                                                                             #
# CACHE=          For each execution, it runs 'tur-trial.sh dummy quota test' #
#                 and uses that list. On slower computers or sites with many  #
#                 users, this can take a while, delaying the output in the    #
#                 channel.                                                    #
#                                                                             #
#                 With CACHE set to a number of minutes, whenever someone     #
#                 executes this script, it will save the list it got from     #
#                 tur-trial and use that one instead of running tur-trial     #
#                 again, for as many minutes as you define here.              #
#                                                                             #
#                 The normal user behavious is that, whenever someone runs    #
#                 !passed, 5 other users do it too right afterwards.          #
#                 This will really speed things up for the remaining 5 users. #
#                                                                             #
#                 So, set this to a number of minutes that you want to keep   #
#                 using the cached output from tur-trial instead of running   #
#                 it again. It should be a fairly low number since the data   #
#                 becomes outdated quite quickly. 2-5 minutes or so.          #
#                                                                             #
#                 Set to "" to disable the cache (dont use 0).                #
#                                                                             #
# config=         Full path to tur-trial.conf. If its in the same dir as this #
#                 script, leave it #                                          #
#                                                                             #
# Run this script with the argument test (tur-quota-cleanup.sh test) to see   #
# what it will do. It wont delete or announce.                                #
#                                                                             #
# Like Tur-Trial, this script will not execute if its not the last day of the #
# duration period, so crontab it to run before midnight each day. Preferebly  #
# 1 minute before tur-trial.sh.                                               #
# Something like: 57 23 * * *     /glftpd/bin/tur-quota-cleanup.sh            #
#                                                                             #
# Ok. We need a better explanation here. The people it checks are the ones    #
# that are displayed as "Safe" when running 'tur-trial.sh dummy quota test'   #
# so those excluded or have not yet passed the monthly quota is not counted   #
# in this script. Tur-Trial handles those that does not pass by deleting them #
# so this script just limits the number of people that can pass quota.        #
# In other words, tur-trial.sh dummy quota still needs to be crontabbed.      #
#                                                                             #
# It deletes users in the same way as Tur-Trial does, reading its config.     #
# that means FLAGDEL for putting flag 6 on users, ADDTOGROUP for moving them  #
# to another group ( back to trial?) or neither, if you just want it logged.  #
#                                                                             #
# If you wish to override any Tur-Trial options, add them below the line that #
# reads '. $config' below. Thats where it reads the options set in the .conf. #
#                                                                             #
# Now then. I suppose users might want to check how they are doing too. Thats #
# why we have a tcl to load. The tcl is a modified tur-trial.tcl that         #
# includes the text from this script, so they are both displayed with the     #
# same trigger.                                                               #
# Play with this how you like, but by default, the new tcl runs tur-trial 1st #
# and then tur-quota-cleanup.sh so they are both displayed when someone       #
# issues the !passed command. Yes, its gets slower this way. Feel free to     #
# improve it.                                                                 #
#                                                                             #
# To change the output, edit it directly in the script. I presume you can use #
# search.                                                                     #
#                                                                             #
# To check a single user from shell, give the argument 'single username'      #
# ( tur-quota-cleanup.sh single turranius ).                                  #
#                                                                             #
# To get a better understanding of what it does, issue this command:          #
# tur-trial.sh dummy quota test | grep Safe | sort -k3,3 -n -r                #
# That will list all users, sorted, who are over the quota limit. THOSE are   #
# the ones this script works with. The first 'SAFE' ones are kept.            #
#                                                                             #
# NOTE: When it displays the ranking ( #5 on quota mnup ), it means #5 of all #
# those who are on quota. Excluded users are NOT counted, so its not a normal #
# mnup list. Its the quota mnup list =)                                       #
#                                                                             #
#-[ Changelog ]---------------------------------------------------------------#
#                                                                             #
# 1.1 :  Added option CACHE= - Read about it in the description above.        #
#                                                                             #
#        Using bash internal counter instead of expr now.                     #
#                                                                             #
#        The tcl changed from using puthelp to putquick. This will help to    #
#        get the "normal" quota information from tur-trial out faster while   #
#        waiting for tur-quota-cleanup to finish.                             #
#        In other words, if you dont already run v1.1 of the tcl, replace it. #
#                                                                             #
#-[ Settings ]----------------------------------------------------------------#

TRIALSCRIPT=/glftpd/bin/tur-trial.sh
SAFE=20
CLEANUPLOG=/glftpd/ftp-data/logs/quotacleanup.log

CACHE=4

## Remove # below to hardset config location
## If not, it will be read from the same folder as tur-trial.sh/tur-quota-cleanup.sh is in.
# config=/glftpd/bin/tur-trial.conf


###############################################################################
# No changes should be needed under here.                                     #
###############################################################################

## Load config file
if [ -z "$config" ]; then
  config="$( dirname $0 )/tur-trial.conf"
fi

. $config

proc_getlist() {
  if [ ! -e "$TRIALSCRIPT" ]; then
    echo "Error. $TRIALSCRIPT not found."
    exit 0
  fi
  $TRIALSCRIPT dummy quota test | grep " - Safe" | sort -k3,3 -n -r | tr -s ' ' '^' > /tmp/quotalist.tmp

  ## Chmod the file if you're root.
  if [ "$USER" = "root" ]; then
    chmod 777 /tmp/quotalist.tmp
  fi
}

num=0
## Check users with tur-trial.sh
proc_checkall() {

  if [ "$CACHE" ]; then
    if [ -e "/tmp/quotalist.tmp" ]; then
      if [ ! -w "/tmp/quotalist.tmp" ]; then
        echo "Error. Cant write to /tmp/quotalist.tmp - Did someone run as root from shell ?"
        echo "Remove the file or chmod it."
      fi
 
      if [ -z "`find \"/tmp/quotalist.tmp" -type f -mmin -$CACHE`" ]; then
        proc_getlist
      fi
    else
      proc_getlist
    fi
  else
    proc_getlist
  fi

## Old way.
##  for rawdata in `$TRIALSCRIPT dummy quota test | grep " - Safe" | sort -k3,3 -n -r | tr -s ' ' '^'`; do
##

  for rawdata in `cat /tmp/quotalist.tmp`; do
    unset status
    num=$[$num+1]
    username="$( echo "$rawdata" | cut -d '^' -f1 )"
    upped="$( echo "$rawdata" | cut -d '^' -f3 )"
    group="$( echo "$rawdata" | cut -d '^' -f6 )"

    if [ "$num" -gt "$SAFE" ]; then
      status="Fail"
    else
      status="Safe"
    fi
  
    if [ "$CHECKING" = "ALL" ]; then
      if [ "$ONLYONCE" != "TRUE" ]; then
        echo "DEBUG: Test mode activated. No users actually delled."
        ONLYONCE="TRUE"
      fi

      if [ "$status" = "Safe" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "$username/$group $upped MB - #$num on $DURNAME - $status."
        else
          echo "$username/$group $upped MB - #$num on $DURNAME - $status." >> $CLEANUPLOG
        fi
      else
        proc_deluser
      fi
    else

      ## Said if the user was found as Safe using 'tur-trial.sh dummy quota test'.
      ##  is bold. Cant just type it though. Use ctrl-b in vi.
      echo "QuotaCleanup: $username/$group $upped MB - #$num on quota $DURNAME - $status. Only top $SAFE users are safe."
    fi
  done
}

## Check a single user.
proc_checksingle() {
  if [ -z "$selection" ]; then

    ## If no argument is given !
    echo "Please choose a user to check too"
    exit 0
  fi

  if [ ! -e "$USERSLOCATION/$selection" ]; then

    ## If the user does not exist !
    echo "User $selection does not exist."
    exit 0
  fi

  data="$( proc_checkall | grep "$selection/" )"

}


proc_checkduration() {
  ## Do we want weekly or monthly trials?
  case $DURATION in
   W)
     DUR="WKUP"
     DURNAME="wkup"
     ;;
   M)
     DUR="MONTHUP"
     DURNAME="mnup"
     ;;
   *)
     echo "Duration not set right. Either W or M"
     exit 0
     ;;
  esac
  
  if [ "$DURATION" = "M" ]; then
    MONTHNOW="$( date +%b )"
    case $MONTHNOW in
      Jan) MONTHTOTAL="31" ;;
      Feb) MONTHTOTAL="28" ;;
      Mar) MONTHTOTAL="31" ;;
      Apr) MONTHTOTAL="30" ;;
      May) MONTHTOTAL="31" ;;
      Jun) MONTHTOTAL="30" ;;
      Jul) MONTHTOTAL="31" ;;
      Aug) MONTHTOTAL="31" ;;
      Sep) MONTHTOTAL="30" ;;
      Oct) MONTHTOTAL="31" ;;
      Nov) MONTHTOTAL="30" ;;
      Dec) MONTHTOTAL="31" ;;
      *) MONTHTOTAL="31" ;;   
    esac
    
    DAYOFMONTH="$( date +%d )"   
    if [ "$MONTHTOTAL" != "$DAYOFMONTH" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Not the end of the month. Test mode, so running anyway."
      else
        echo "Not the end of the month."
        exit 0
      fi
    fi
  fi
  
  if [ "$DURATION" = "W" ]; then
    DAYNOW="$( date +%w )"
    if [ "$EUROWEEK" = "FALSE" ]; then
      if [ "$DAYNOW" != "6" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the month. Test mode, so running anyway."
        else
          exit 0
        fi
      fi
    else
      if [ "$DAYNOW" != "0" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the month. Test mode, so running anyway."
        else
          exit 0
        fi
      fi
    fi
  fi

  if [ "$DEBUG" != "TRUE" ]; then
    if [ "$ANNOUNCE" = "TRUE" ]; then
      echo `date "+%a %b %e %T %Y"` TURTRIAL: \"QuotaCleanup this $DURNAME is finished.\" >> $GLLOG
    fi
  fi
}

## This is where we kick bitches ass.
proc_deluser() {
  cd $USERSLOCATION
  unset DELLED

  ## FLAGDEL is TRUE. Lets put some 6 flags on users.
  if [ "$FLAGDEL" = "TRUE" ]; then
    FLAGS="$( grep "^FLAGS " $username | awk -F" " '{print $2}')"
    if [ "$( echo "$FLAGS" | grep "6" )" ]; then
      DELLED="YES"
      if [ "$DEBUG" = "TRUE" ]; then
        echo "$username/$group $upped MB - #$num on quota $DURNAME. Already delled though."
      else
        echo "$username/$group $upped MB - #$num on quota $DURNAME. Already delled though." >> $CLEANUPLOG
      fi
    fi
    if [ "$DELLED" != "YES" ]; then
      if [ "$DEBUG" != "TRUE" ]; then
        sed -e "s/^FLAGS $FLAGS.*/FLAGS "$FLAGS"6/" $USERSLOCATION/$username > $TMP/$USER.TMP
        mv -f $TMP/$USER.TMP $USERSLOCATION/$username; chmod 777 $USERSLOCATION/$username
      fi
      if [ "$DEBUG" = "TRUE" ]; then
        echo "$username/$group $upped MB - #$num on quota $DURNAME. Putting flag 6."
      else
        echo "$username/$group $upped MB - #$num on quota $DURNAME. Putting flag 6." >> $CLEANUPLOG
      fi
    fi
  else
    ## FLAGDEL isnt TRUE. Lets see..
    FLAGS="$( grep -w FLAGS $username| awk '{print $2}')"
    CHECK="$( echo $FLAGS | grep 6 )"
    if [ "$CHECK" != "" -a "$FLAGDEL" != "TESTING" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "$username/$group $upped MB - #$num on quota $DURNAME - already delled thought."
      fi
    else
      if [ "$ADDTOGROUP" != "" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          echo "GROUP $ADDTOGROUP" >> $USERLOCATION/$username
          echo "$username/$group $upped MB - #$num on quota $DURNAME - Adding to group $ADDTOGROUP" >> $CLEANUPLOG
        else
          echo "$username/$group $upped MB - #$num on quota $DURNAME - Adding to group $ADDTOGROUP (test)"
        fi
      else
        echo "$username/$group $upped MB - #$num on quota $DURNAME. Failed being in the top $SAFE" >> $CLEANUPLOG
      fi
      if [ "$SETCREDS" != "" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          sed -e "s/^CREDITS.*/CREDITS $SETCREDS/" $USERSLOCATION/$username > $TMP/$USER.TMP2
          mv -f $TMP/$USER.TMP2 $USERSLOCATION/$username; chmod 777 $USERSLOCATION/$username
        else
          echo "$username/$group $upped MB. - #$num on quota $DURNAME - Setting credits to $SETCREDS" >> $CLEANUPLOG
        fi
      fi
    fi
  fi

  if [ "$QANNOUNCE" = "TRUE" ]; then
    if [ -z "$failedusers" ]; then
      failedusers="$num:$username/$upped"
    else
      failedusers="$failedusers -=- $num:$username/$upped"
    fi
  fi

}

## Set second argument as selection.
selection="$2"

## Is first argument 'single'? It always is if you use the tcl.
if [ "$1" = "single" ]; then
  proc_checksingle
  if [ -z "$data" ]; then

    ## If the user was not found as Safe in the 'tur-trial.sh dummy quota test' list !
    echo "QuotaCleanup: $selection is not affected by quota cleanup as $selection has not passed yet or is excluded."
    # echo "This does NOT mean that $selection is safe from being delled. Normal quota still applies."
  else
    echo "$data"
  fi
  exit 0
fi

## Delete the cached file if it exists. We'll do a new one instead.
if [ -e "/tmp/quotalist.tmp" ]; then
  rm -f "/tmp/quotalist.tmp"
fi

## Set possible debug mode.
case $1 in
  [tT][eE][sS][tT]) DEBUG="TRUE"; TEST="TRUE" ;;
esac

## If we got this far, it means we are supposed to check all users.
CHECKING="ALL"
proc_checkduration
proc_checkall
if [ -z "$username" ]; then
  if [ "$DEBUG" = "TRUE" ]; then
    echo "No users passed quota yet !?"
    echo "Check with 'tur-trial.sh dummy quota test' and watch for any 'Safe' users."
    exit 9
  else
    echo "Hm, seems no users passed quota this duration" >> $CLEANUPLOG
  fi
fi

if [ "$DEBUG" != "TRUE" ]; then
  if [ "$QANNOUNCE" = "TRUE" ]; then
    echo `date "+%a %b %e %T %Y"` TURTRIAL: \"Only top $SAFE quota users are safe.\" >> $GLLOG
    echo `date "+%a %b %e %T %Y"` TURTRIAL: \"Failed users: $failedusers\" >> $GLLOG
  fi
fi

exit 0

# Save this: 

