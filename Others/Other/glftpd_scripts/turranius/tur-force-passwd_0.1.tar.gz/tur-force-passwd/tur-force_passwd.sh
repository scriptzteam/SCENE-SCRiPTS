#!/bin/bash
VER=0.1

# Simple script to deny dirlisting if the user has not changed password.
#
# * Copy tur-force_passwd.sh to /glftpd/bin and chmod to 755.
#
# * Add to glftpd.conf:
#   cscript LIST PRE /bin/tur-force_passwd.sh
#   cscript STAT PRE /bin/tur-force_passwd.sh
#   (add more if you can think of them).
#
# * Copy /glftpd/etc/passwd to /glftpd/etc/passwd.tur
#   If the /glftpd/etc/passwd.tur does not exist, the script
#   will allow dirlisting. 
#
# * Set the 3 paths in the settings.
#
# * Set any user/group/flag excludes. Note for users and groups:
#   Specify them as ^groupname$ to ensure a proper match.
#   Seperate users/groups/flags with a |
#   For groups, only the users primary group will be checked. This
#   is the fastest way.
#   If you dont use, for example, flagexclude, put a # infront of it.
#
# Now, whenever you want to force everyone to change passwords, copy 
# the passwd to passwd.tur again.
# If the password hash is the same in the passwd as the passwd.tur
# file, the user can not list dirs.
#
# NOTE: Some clients do not display the message that you need to change
#       password. You might want to add something to your welcome.msg
#       and topic.
#       Since ultrafxp (amongst others I guess) do not send the message
#       AND also kicks the user if he uses stat -l, I've added the allow_view=
#       setting. Set this to "/site" to allow users to atleast list the root
#       of the site. Setting it to "" will deny even that, but then you might
#       run into problems with ultrafxp clients.

#--[ Settings ]-----------------------------#

# Path to passwd file.
passwd="/etc/passwd"

# Path to copy of passwd. If this is a mss slave, specify
# the file on the hub ( /etc.ext/passwd.tur ) if you want.
# Recomended is to make a copy on the slave too though (faster).
# They cant 'site passwd' on the slave, but it will block dirlisting
# until they change password on the hub.
old_passwd="/etc/passwd.tur"

# If this is set, this path is allowed to be viewed.
# Some users have to set this as the error message is
# not always displayed on some clients for some reason.
allow_view="/site"

## Remove the # infront of the setting you want to enable.
# usersexclude="^Turranius$|^glftpd$"
# groupexclude="^SiTEOPS$|^iND$"
# flagexclude="1|7"

# If this is set, only the user specified will use
# this script. For testing purposes.
# You MUST change this, unless you're me.
only_work_for="turranius"


#--[ Script Start ]-------------------------#

if [ "$only_work_for" ]; then
  if [ "$USER" != "$only_work_for" ]; then
    exit 0
  fi
fi

if [ ! -e "$old_passwd" ]; then
  # echo -e "200No $old_passwd found. Skipping tur-force_passwd.sh\r"
  exit 0
fi

if [ "`grep "^$USER:" $passwd | cut -d ':' -f2`" = "`grep "$USER:" $old_passwd | cut -d ':' -f2`" ]; then
  if [ "$usersexclude" ]; then
    if [ "`echo "$USER" | egrep "$usersexclude"`" ]; then
    # echo -e "200User exclude $USER\r"
      exit 0
    fi
  fi
  if [ "$flagexclude" ]; then
    if [ "`echo "$FLAGS" | egrep "$flagexclude"`" ]; then
    # echo -e "200Flag exclude $FLAGS\r"
      exit 0
    fi
  fi
  if [ "$groupexclude" ]; then
    if [ "`echo "$GROUP" | egrep "$groupexclude"`" ]; then
    # echo -e "200Group exclude $GROUP\r"
      exit 0
    fi
  fi
  if [ -z "`grep "$USER:" $old_passwd`" ]; then
    # echo -e "200New user. Not in $old_passwd.\r"
    exit 0
  fi

  echo -e "500-----------------------------------------------------------------\r"
  echo -e "500You must change password before you are allowed to list dirs.\r"
  echo -e "500Use 'site passwd <password>' to change.\r"
  echo -e "500-----------------------------------------------------------------\r"

  if [ "$allow_view" ]; then
    if [ "$PWD" != "$allow_view" ]; then
      exit 2
    fi
  fi
fi

