#!/bin/bash
VER=1.1

#------------------------------------------------#
#                                                #
# Tur-TotalTraffic. Short script for displaying  #
# total traffic per section.                     #
#                                                #
#--[ Setup ]-------------------------------------#
#                                                #
# Copy tur-totaltraffic.sh to /glftpd/bin.       #
#                                                #
# Chmod to 755.                                  #
#                                                #
# Copy tur-totaltraffic.tcl to your bots scripts #
# dir, load it in the config and .rehash the bot.#
#                                                #
# Setup the options below:                       #
#                                                #
#--[ Changelog ]---------------------------------#
#                                                #
# 1.1  Changed how it gets the first entry in    #
#      the database. Instead of the first post   #
#      for each section in the db, it now grabs  #
#      the entry with the earliest date instead. #
#                                                #
#--[ Configuration ]-----------------------------#

## These should be self explaining.
SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"
SQLDB="transfers"
SQLTB="transfers"

## Selectable sections. Should be the same as in xferlog-import.sh
## part from the ALL section.
SECTIONS="ALL DVDR XXX XBOX ISO-UTILS"

B=""  ## Dont touch
U=""  ## Dont touch

## This is echoed.
proc_output() {
  echo "Reporting ${DIR_WORD} traffic ${SECTION_NAME} since ${FIRST}: ${B}${SIZE} GB${B} ( ${B}${SIZE_TB} TB${B} )."
}


#--[ Script Start ]------------------------------#

SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $SQLDB -N -s -e"

section="$1"
direction="$2"

proc_help() {
  echo "<Section: $SECTIONS> <Direction: i/o>"
}

if [ "$section" ]; then
  for each in $SECTIONS; do
    if [ "`echo "$section" | grep -i "^$each$"`" ]; then
      VALID_SECTION="TRUE"
      break
    fi
  done
  if [ -z "$VALID_SECTION" ]; then
    proc_help
    exit 0
  fi
fi

if [ "$direction" ]; then
  case $direction in
    [iI]) dir_name="uploaded"; direction="i";;
    [oO]) dir_name="downloaded"; direction="o";;
    *) proc_help; exit 0;;
  esac
fi

if [ -z "$section" ]; then
  proc_help
  exit 0
fi

if [ "`echo "$section" | grep -i "all"`" ]; then
  SECTION_NAME="from all sections"
  NEXT_WORD="where"
  FIRST_QUERY="select datum from transfers where ID = '1' limit 1"
else
  SECTION_NAME="from the $section section"
  SECTION_QUERY="where section = '$section'"
  NEXT_WORD="and"
  #FIRST_QUERY="select datum from transfers where section = '$section' order by datum asc limit 1"
  FIRST_QUERY="select datum from transfers where section = '$section' order by datum asc limit 1"
fi

if [ "$direction" ]; then
  DIR_WORD="$dir_name"
  DIR_QUERY="$NEXT_WORD direction = '$direction'"
else
  DIR_WORD="total"
fi

FIRST=`$SQL "$FIRST_QUERY"`
SIZE="`$SQL "select sum(size/1024/1024/1024) from $SQLTB $SECTION_QUERY $DIR_QUERY"`"
GB_NUM="`echo "$SIZE" | cut -d '.' -f1`"
if [ -z "$GB_NUM" ]; then GB_NUM="0"; fi
DEC="`echo "$SIZE" | cut -d '.' -f2 | cut -c1-2`"
SIZE="$GB_NUM.$DEC"
SIZE_TB="`echo "$SIZE / 1024" | bc -l | tr -d ' '`"
TB_NUM="`echo "$SIZE_TB" | cut -d '.' -f1`"
if [ -z "$TB_NUM" ]; then TB_NUM="0"; fi
DEC_TB="`echo "$SIZE_TB" | cut -d '.' -f2 | cut -c1-2`"
SIZE_TB="$TB_NUM.$DEC_TB"

proc_output

exit 0