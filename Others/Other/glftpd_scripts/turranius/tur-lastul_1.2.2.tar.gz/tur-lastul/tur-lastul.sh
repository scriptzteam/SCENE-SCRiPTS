#!/bin/bash
VER=1.2.2
#-[ Intro ]---------------------------------------------------------------#
#                                                                         #
# Tur-LastUl. Display last uploaded releases from all or select sections. #
# Works in both glftpd as a custom command and from irc, using a tcl.     #
#                                                                         #
#-[ Installation ]--------------------------------------------------------#
#                                                                         #
# Well I guess you all know the drill by now.. Ah, what the heck...       #
# Copy tur-lastul.sh to /glftpd/bin. Make it executable.                  #
# Copy tur-lastul.tcl to your bots config dir. Load it and .rehash.       #
#                                                                         #
#-[ Settings ]------------------------------------------------------------#
#                                                                         #
# glroot   = Root of glftpd. Usually /glftpd                              #
#                                                                         #
# gllog    = Path to glftpd.log, relative to glroot above.                #
#                                                                         #
# predirs  = Predirs or dirs which should not be displayed. Do not        #
#            enter 'CD1' and those here. We'll handle those soon.         #
#            You'll notice by the example that we exclude /GROUPS/ and    #
#            /PRE/. Thats to make sure its the full foldername it skips   #
#            Usually predirs arent in glftpd.log, but anyway...           #
#            Use a | to seperate different excludes. Dont use spaces.     #
#                                                                         #
# sections = Which sections to display. Requires full name but is not     #
#            case sensitive. This one will add / automatically to the     #
#            start and end automatically, so do not use those here.       #
#            Once again, the /'s are to make sure it takes the whole      #
#            sectionname, so that SVCD dosnt show if you specify VCD.     #
#            Use a space to separate different sections.                  #
#                                                                         #
# noshow   = Which releases to not show. Usually CD1, CD2 etc are added   #
#            as NEWDIR: in glftpd.log as well, but those are not          #
#            interesting. Use . as *, so CD. will exclude every CD1 etc.  #
#            In the example, we use CD[1-9] though which works just a     #
#            well.                                                        #
#            This will add a / to the front of each word, so ONLY the     #
#            last dirname in the path will be excluded because of this.   #
#            Ie, /SVCD/Blabal.CD1_FIX-Somegroup will still be shown. It   #
#            wont show /SVCD/Blabal.CD1_FIX-SOMEGROUP/CD1 though.         #
#            Use a space to separate noshows.                             #
#                                                                         #
# defaulthits = If you dont define how many results you want in the query,#
#               how many should be shown?                                 #
#                                                                         #
# maxhits    = The maximum number of lastuls a user can view. It will     #
#              never go over 100 no matter what you set this to.          #
#                                                                         #
# countfiles = Which filetypes to count for the %FILES% cookie. If you do #
#              not want to use the %FILES% cookie, set this to "" or set  #
#              a # infront of it so it wont even check, to speed up.      #
#              If you do not understand the format, dont use or edit it.  #
#                                                                         #
# usedu      = How to run 'du' for the %SIZE% cookie. It currently greps  #
#              "total" so 'du' must produce a grand total (c). The h      #
#              means the output is in human readable format (ie, 5MB).    #
#              If you dont use the %SIZE% cookie, set this to "" or put a #
#              # infront of it to speed it up by not even checking.       #
#                                                                         #
# Below this are the different texts it will output. There are two        #
# different sections of 3 texts each. First one is when executed from irc #
# and the second one is when executed from glftpd.                        #
#                                                                         #
#-[ glftpd.conf Settings ]------------------------------------------------#
#                                                                         #
# If you want this as a custom command in glftpd, add the following to    #
# glftpd.conf:                                                            #
#--                                                                     --#
# site_cmd lastul         EXEC    /bin/tur-lastul.sh
# custom-lastul           *
#--                                                                     --#
#                                                                         #
#-[ From irc ]------------------------------------------------------------#
#                                                                         #
# Basically, once you load the tcl in the bot and rehash it, !lastul will #
# be enabled in all chans the bot is in.                                  #
#                                                                         #
#-[ Usage ]---------------------------------------------------------------#
#                                                                         #
# !lastul only will display the last uploads from all defined sections.   #
# Example: !lastul divx 5                                                 #
# Example: !lastul all 5                                                  #
#                                                                         #
# It works the same way from inside glftpd.                               #
#                                                                         #
# If you specify a section instead of showing all, the path will not be   #
# displayed, only release name. No point in /SVCD/REL when you only want  #
# to display SVCD releases anyway.                                        #
#                                                                         #
# It does not show preed release. Thats cause everyones PRE: lines look   #
# different. If you want that, add the function yourself =)               #
#                                                                         #
# The only "non standard" binaries it uses are tac and basename so make   #
# sure you copy those to /glftpd/bin to make it run from inside glftpd.   #
# Also grep, egrep, cut, tr                                               #
#                                                                         #
# When running it from shell, it will think its in irc. Thats normal.     #
#                                                                         #
#-[ Changelog ]-----------------------------------------------------------#
#                                                                         #
# 1.2.2 : Fixed a problem that happened if it reached a nuked dir and     #
#         tried to run 'du' on it. It would get a permission denied error #
#         in the partyline of the bot and not display the results.        #
#                                                                         #
# 1.2.1 : Fixed a problem if you had non-alpha chars in the section names #
#         Sections need to be specified first followed by the number of   #
#         hits. Specify 'all' as section if you need to specify hits.     #
#                                                                         #
# 1.2 : Added option defaulthits to specify amount of hits if none are    #
#       defined. maxhits are the maximum number of hits a user can        #
#       select. It will never go over 100 no matter what you set though.  #
#                                                                         #
#       Files were not counted correctly when multiple CD's. Fixed.       #
#                                                                         #
# 1.1 : Added cookies %SIZE% and %FILES%. 2 new settings for this too:    #
#       usedu & countfiles. See instructions above.                       #
#                                                                         #
# 1.0 : Initial release.                                                  #
#                                                                         #
#-[ Settings ]------------------------------------------------------------#

glroot=/glftpd
gllog=/ftp-data/logs/glftpd.log
predirs='/GROUPS/|/PRE/'
sections="divx xbox dvdr vcd 0day"
noshow="CD[1-9] Sample Vobsub Vobsubs subs Cover Covers Allowed"

defaulthits=10
maxhits=20

countfiles="\.[r0][a0-9][r0-9]|\.zip|\.nfo|.sfv"
usedu="du -ch"

#-[ Output from IRC ]-----------------------------------------------------#
# Usable cookies in iheader and ifooter.                                  #
# %SECTION% = Specified section or All (Search for NAME="All" to change). #
# %AMOUNT%  = Number of hits requested.                                   #
#                                                                         #
# Usable cookies in iprint:                                               #
# %REL%     = Release name.                                               #
# %TIME%    = When directory was created.                                 #
# %WHO%     = Who created the folder.                                     #
# %GROUP%   = %WHO%'s primary group.                                      #
# %TAGLINE% = %WHO%'s tagline.                                            #
# %SIZE%    = Size of release if it exists. See 'usedu' above.            #
# %FILES%   = Amount of files in release. See 'countfiles' above.         #
# %BOLD%    = Start and stop bold text.                                   #
# %ULINE%   = Start and stop underlined text.                             #

# Header of output. Only %BOLD% and %ULINE%. Leave empty for no header.
iheader="%BOLD%[LastUL]%BOLD% - Last %AMOUNT% %SECTION% uploads on xXx"

# Main output. All cookies enabled, part from tagline.
iprint="%BOLD%[LastUL]%BOLD% - %TIME% -> %REL% (%SIZE% in %FILES%F) by %WHO%/%GROUP%"

# Footer of output. Only %BOLD% and %ULINE%. Leave empty for no footer.
ifooter=""

#-[ Output from glftpd - No cookies here  ]-------------------------------#

# Header of output. Leave empty for no header.
gheader="Last uploads on xXx"

# Main output.
gprint="%TIME% -> %REL% (%SIZE% in %FILES%F) by %WHO%/%GROUP%"

# Footer of output. Leave empty for no footer.
gfooter=""


#-[ Script Start - No changes here ]--------------------------------------#

## Are we in glftpd or irc ?
if [ "$FLAGS" ]; then
  mode=gl
  header="$gheader"
  print="$gprint"
  footer="$gfooter"
  glroot=""
else
  mode=irc
  gllog="$glroot$gllog"
  header="$iheader"
  print="$iprint"
  footer="$ifooter"
fi

if [ -z "$1" ]; then
  amount="$defaulthits"
else
  if [ "$1" != "all" ]; then
    checkselection="$1"
  fi
  if [ -z "$2" ]; then
    amount="$defaulthits"
  else
    if [ "`echo "$2" | tr -d '[:digit:]'`" ]; then
      echo "Error. Only use numbers in amount of hits."
      exit 0
    fi
    if [ "`echo "$2" | grep "...."`" ]; then
      echo "Overflow detected. Quitting."
      exit 0
    fi
    if [ "$2" -gt "$maxhits" ]; then
      amount="$maxhits"
    else
      amount="$2"
    fi
  fi
fi

## Put wanted section in $selection
if [ "$checkselection" ]; then
  if [ -z "$( echo "$sections" | grep -wi "$checkselection" )" ]; then
    echo "Invalid section. Valid ones are: $sections"
    echo "Number of hits can also be specified after section (no more than $maxhits)."
    echo "Specify 'all' for all sections if you need to specify hits."
    exit 0
  fi
  selection="/$checkselection/"
  singlesection=true
  NAME="$checkselection"
else
  for section in $sections; do
    if [ "$selection" ]; then
      selection="/$section/|$selection"
    else
      selection="/$section/"
    fi
  done
  NAME="All"
fi

## Build the noshow list (cd1 etc etc).
if [ "$noshow" ]; then
  for each in $noshow; do
    if [ "$noshow2" ]; then
      noshow2="/$each~|$noshow2"
    else
      noshow2="/$each~"
    fi
  done
fi

## Amount cant be empty.
if [ -z "$amount" ]; then
  echo "Error. Amount is not set. What went wrong? Dont know."
  exit 0
fi

## Its not 0, is it ?
if [ "$amount" = "0" ]; then
  echo "Error. Cant return 0 hits, moron."
  exit 0
fi

## Can we read glftpd.log ?
if [ ! -r "$gllog" ]; then
  echo "Error. Cant read glftpd.log. Check path and perms."
  exit 0
fi

## Are you a moron?
if [ -z "$sections" ]; then
  echo "Error. No sections defined."
  exit 0
fi

## Make lame fix
if [ -z "$predirs" ]; then
  predirs="FLKfj3098j3dj"
fi

proc_cookies() {
  if [ "$time" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TIME%/$time/g" )"
  fi
  if [ "$rel" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%REL%/$rel/g" | tr -s '^' '/' )"
  fi
  if [ "$who" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WHO%/$who/g" )"
  fi
  if [ "$group" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%GROUP%/$group/g" )"
  fi
  if [ "$tagline" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TAGLINE%/$tagline/g" )"
  fi
  if [ "$NAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SECTION%/$NAME/g" )"
  fi
  if [ "$amount" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%AMOUNT%/$amount/g" )"
  fi
  if [ "$files" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%FILES%/$files/g" )"
  fi
  if [ "$size" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SIZE%/$size/g" )"
  fi
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

if [ "$header" ]; then
  OUTPUT="$header"
  proc_cookies
  echo "$OUTPUT"
fi

num=0
internal=0
for rawdata in `tac $gllog | grep " NEWDIR: " | egrep -i "$selection" | egrep -vi "$predirs" | tr -d '"' | tr -s ' ' '~' | egrep -vi "$noshow2"`; do

  ## Break once we reach the number of hits.
  if [ "$num" = "$amount" ]; then
    break
  fi
  
  ## Safety break after 100 hits just incase.
  internal="$( expr "$internal" \+ "1" )"
  if [ "$internal" -gt "100" ]; then
    echo "Forcing break after 100 hits."
    break
  fi

  ## Grab the data from the glftpd.log line.
  time="$( echo $rawdata | cut -d '~' -f2-4 | tr -s '~' ' ' )"
  rel="$( echo $rawdata | cut -d '~' -f7 | sed -e 's/\/site\///' )"
  who="$( echo $rawdata | cut -d '~' -f8 )"
  group="$( echo $rawdata | cut -d '~' -f9 )"
  tagline="$( echo $rawdata | cut -d '~' -f10- | tr -s '~' ' ' )"

  ## %FILES% and %SIZE% cookie data are created here.
  if [ ! -e "$glroot/site/$rel" ]; then
    files="NA"
    size="NA"
  else
    if [ "$usedu" ]; then
      size=`$usedu $glroot/site/$rel 2>/dev/null | grep -w total | awk '{print $1}'`
    else
      size="DISABLED"
    fi
    if [ "$countfiles" ]; then
      files=`ls -R1 $glroot/site/$rel | egrep "$countfiles" | wc -l | tr -s ' '`
    else
      files="DISABLED"
    fi
  fi

  ## If a single section is selected, only print relname, not full path.
  if [ "$singlesection" = "true" ]; then
    rel="$( basename $rel )"
  fi

  ## Since sed (proc_cookies) dosnt like '/', replace those with '^' for now.
  if [ "$rel" ]; then
    rel="$( echo "$rel" | tr -s '/' '^' )"
  fi

  ## Replace print line with cookie data.
  OUTPUT="$print"
  proc_cookies  

  ## If this is not the same as the last rel, output it and count up 1.
  if [ "$rel" != "$lastrel" ]; then
    echo "$OUTPUT"
    num=$[$num+1]
  fi

  ## Set what this rel was so we can check it next run.
  lastrel="$rel"
done

if [ -z "$lastrel" ]; then
  echo "Nothing found."
  exit 0
fi

if [ "$footer" ]; then
  OUTPUT="$footer"
  proc_cookies
  echo "$OUTPUT"
fi