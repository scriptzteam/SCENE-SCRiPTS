#!/bin/bash
VER=1.0

#-----------------------------------------------------------------------
# This script is used to automatically add new users to trial using
# tur-trial3. Its executed as a cscript to adduser and gadduser.
#
# If you add someone who should not be on trial, just do
# 'site trial wipe username' after the user is added.
#
# If you use MSS, make sure to check the also_run setting below.
#
# NOTE: You MUST have configured tur-trial3 to work from inside
# glftpd (getting the mysql client to work from within the chroot).
#
# * Copy to /glftpd/bin
# * Chmod to 755
# * Add to glftpd.conf:
#   cscript SITE[:space:]ADDUSER  POST /bin/tur-trial3_autoadd.sh
#   cscript SITE[:space:]GADDUSER POST /bin/tur-trial3_autoadd.sh
#-----------------------------------------------------------------------

## Path to tur-trial3.sh - Seen chrooted (no /glftpd)
turtrial3=/bin/tur-trial3.sh

## Path to log output from tur-trial3 from. Set to /dev/null to not log.
## If this is set to a path, you must create the log and chmod it to 666.
## Path is seen chrooted.
log="/dev/null"


## If you use MSS, you probably already have:
## cscript SITE[:space:]ADDUSER  POST /bin/mss-post.sh &
## cscript SITE[:space:]GADDUSER POST /bin/mss-post.sh
## in glftpd.conf. Remove those (or put a # infront of them)
## and remove the below # to enable this script to run
## mss-post.sh instead.
## NOTE: For this to work, you MUST have mss-post.sh version 1.2.
# also_run="/bin/mss-post.sh"

#--[ No changes should be needed below here ]--#

## How to grab the username to add to trial. Should not need to change this.
username="`echo "$@" | cut -d ' ' -f3`"

## Run the extra script, if set with also_run.
if [ "$also_run" ]; then 
  $also_run $@ >> $log 2>&1
fi

## Run the command: tur-trial3.sh tadd username
$turtrial3 tadd $username >> $log
