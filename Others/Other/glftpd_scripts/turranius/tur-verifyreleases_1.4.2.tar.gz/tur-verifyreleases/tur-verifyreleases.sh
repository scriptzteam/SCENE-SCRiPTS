#!/bin/bash
VER=1.4.2

# Script used to verify all rar releases. Uses 'unrar t' to look for crc errors
# and reports this both to screen and to a logfile.
#
# It also checks the .sfv files in a release, if found, that all the files are included.
#
# Using calc_crc32, it will also act as 'rescan' and verify that each file matches
# that of from the sfv.
# The source for calc_crc32 is included. Compile it: gcc calc_crc32.c -o /glftpd/bin/calc_crc32
# The binary included is compiled on RedHat9 if you'd rather use that.
# This function works fine on any section which has a .sfv in their releases (including mp3).
#
# It can also create a CLEANSH file, which, when executed, will remove all failed
# releases.
#
# You'll need unrar installed, from www.rarlabs.com if you want the rar test.
#
#
# v 1.4.2   * The rar test will now also detect missing files in the releases as opposed
#             to only letting the sfv detect this.
#
# v 1.4.1 : * sfv checking is no longer case sensitive between the .sfv and the filename.
#
#           * If for some reason, it does not manage to get the crc from the file, it will
#             try up to 10 more times.
#
#           * Output changed to be a bit less verbose. Looks better.
#
#           * It will now check if the dirs in SECTIONS exists FIRST. Annoying when it
#             tells you that when its been running all night.
#
# v 1.4 : * Can now use calc_crc32 to verify that each file in the releases matches
#           the ones in the .sfv.
#           This makes it a perfekt 'rescan' for multiple directories.
#
#         * Use 'debug' as first and only argument to see what it does.
#           Wont print anything to screen otherwise.
#           Also a new setting: DEBUG=TRUE/FALSE if you always want to show it.
#
#         * You can now use :DEEP in sections and it will go through each subdir as well.
#           Good for MP3 archives.
#           If you enable this option in any of the SECTIONS, you'll need to download
#           and install 'tuls' from www.grandis.nu/glftpd first.
#
#         * Fixed clean.sh.. It now adds "" to the releasename to delete. Should fix 
#           those releases with () in them, when trying to delete them.
#
# v 1.3 : Now supports entering disc1-9, disk1-9 and dvd1-9. Was only cd1-9 before.
#         Not case sensitive of course =)
#
#         Changed sfv check. Its no longer case sensitive.
#
#         This update dedicated to DaShizNit who reported both "errors".
#
# v 1.2.1 : Oops. The sfv check added each release to the CLEANSH file, missing
#           files or not.
#
# v 1.2 : Added check in sfv that all files exists (look for incomplete releases).
#         Option for this: ADD_MISSING_FILE=TRUE/FALSE. With TRUE, it will add those
#         incomplete releases to the CLEANSH file as well as CRC failed releases.
#         If FALSE, missing files will only be logged (log and on screen).
#
# v 1.1 : Fixed minor error when sorting CLEANSH file at the end of scan.
#         Now checks for existance of unrar. Made UNRAR setting.

# Path to unrar binary. Set to "" to disable unrar testing and just use the CHKSFV below.
UNRAR="/usr/bin/unrar"

# Path to calc_crc32. Set to "" to disable. Only use the UNRAR setting above if so.
CALCCRC32="/glftpd/bin/calc_crc32"

# Path to tuls. Download and install from www.grandis.nu/glftpd first.
# Only needed if you use :DEEP in any of the SECTIONS below.
TULS="/glftpd/bin/tuls"

# Rootsection. Just makes it easier to set SECTIONS
ROOTSECTIONS="/glftpd/site/"

# Sections inside ROOTSECTIONS. Space/newline seperated.
# Use :DEEP at the end to dive into each dir inside the one specified
# here. See example.
SECTIONS="
DIVX
SVCD
DVDR
MP3:DEEP
"

# Where to create the logfile of failed rels?
# A new log will be created on each run.
LOG="/tmp/logfile.log"

# Where to create the clean.sh file?
# Note, this is not executable by default when created. You'll
# need to open it and look that its ok, then chmod 700 or similar to
# be able to run it. A new file will be created on each run.
CLEANSH="/tmp/clean.sh"

# If a file is in the sfv but not on disk, should it be added to the
# CLEANSH file above? Otherwise, only failed CRC releases will be added
# and missing files will only be logged.
ADD_MISSING_FILE="TRUE"

# Always show whats happening?
DEBUG="TRUE"


#--[ Script Start ]--------------------------------------------------#

if [ "$1" = "debug" ]; then
  DEBUG="TRUE"
fi

for each in $SECTIONS; do
  section="`echo "$each" | cut -d ':' -f1`"
  if [ ! -d "$ROOTSECTIONS/$section" ]; then
    echo "Error. Section $section ( $ROOTSECTIONS/$section ) does not exist. Will not run."
    exit 0
  fi
done

if [ ! -e "$UNRAR" ]; then
  echo "Cant find $UNRAR. Need to install unrar from www.rarlabs.com"
  exit 1
fi

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$*"
  fi
}

proc_log() {
  if [ "$LOG" ]; then
    echo "$*" >> $LOG
  fi
}

proc_findfile() {
  unset firstfile

  firstfile="`ls -1 | grep "\.rar$" | head -n1`"
  if [ -z "$firstfile" ]; then
    firstfile="`ls -1 | grep "\.r.*.*$" | sort -n | head -n1`"
  fi
  if [ -z "$firstfile" ]; then
    firstfile="`ls -1 | grep "\.00[0.1]$" | sort -n | head -n1`"
  fi
}

proc_scan_sfv() {
  unset SKIP
  if [ "`ls -1 | grep "\.[sS][fF][vV]$" | head -n1`" ]; then
    sfv_file="`ls -1 | grep "\.[sS][fF][vV]$" | head -n1`"
    proc_debug "  Matching CRCs from $sfv_file"
    for rawdata in `cat $sfv_file | tr -s ' ' '~' | tr -d '\r' |grep -i "^[a-z0-9]" | grep ".~........$" | cut -d '~' -f1-2`; do
      file="`echo "$rawdata" | cut -d '~' -f1`"
      sfv_crc="`echo "$rawdata" | cut -d '~' -f2`"

      if [ -z "`ls -1 | grep "$file"`" ]; then
        ## Try and find the real name incase the case differs from the sfv.
        realfile="`$TULS | tr ' ' '^' | grep "^-" | egrep -iv ":\.\.:|:\.\:" | awk -F"::::" '{print $4'} | grep -i "^$file$"`"
      fi
      if [ "$realfile" ]; then
        file="$realfile"
        unset realfile
      fi

      if [ -z "`ls -1 | grep "$file"`" ]; then
        proc_debug "  $file found in $sfv_file but not on disk. Incomplete release."
        proc_log "$sfv_file has $file but file not in $CURPATHNOCD - Incomplete release."
        if [ "$ADD_MISSING_FILE" = "TRUE" ]; then
          if [ "$CLEANSH" ]; then
            echo "rm -rf \"$CURPATHNOCD\"" >> $CLEANSH
          fi      
        fi
      else
        if [ "$CALCCRC32" ]; then
          retry=0

          file_crc="`$CALCCRC32 $file`"
          while [ -z "$file_crc" ]; do
            if [ "$retry" -ge "10" ]; then
              proc_debug "  Got no CRC from $file - tried $retry times... Setting 0000000"
              proc_log "Got no CRC from $CURPATHNOCD/$file - tried $retry times... Setting 0000000"
              file_crc="00000000"
              break
            fi
            retry=$[$retry+1]        
            file_crc="`$CALCCRC32 $file`"
          done

          if [ -z "`echo "$file_crc" | grep -i "^$sfv_crc$"`" ]; then
            proc_debug "  CRC mismatch in $file - sfv: $sfv_crc / file: $file_crc"
            proc_log "CRC mismatch in $CURPATHNOCD/$file - sfv: $sfv_crc / file: $file_crc"
            SKIP="TRUE"
            if [ "$CLEANSH" ]; then
              echo "rm -rf \"$CURPATHNOCD\"" >> $CLEANSH
            fi
          fi
        fi
      fi
    done
  else
    proc_debug "  No .sfv found - skipping."
  fi
}

proc_scan() {
  if [ "$firstfile" ]; then
    proc_debug "  Doing a .rar test - Starting with $firstfile"

    $UNRAR t $firstfile > /tmp/reltest.tmp 2>&1

    for rawdata in `cat /tmp/reltest.tmp | grep -i "packed data CRC failed" | tr -s ' ' '^'`; do
      wholefile="`echo "$rawdata" | cut -d '^' -f1`"
      badfile="`echo "$rawdata" | cut -d '^' -f9`"
      proc_debug "  $badfile CRC error in $CURPATH"
      proc_log "$badfile CRC error in $CURPATH"
      if [ "$CLEANSH" ]; then
        echo "rm -rf \"$CURPATHNOCD\"" >> $CLEANSH
      fi
    done


    for rawdata in `cat /tmp/reltest.tmp | grep -i "^Cannot find " | tr -s ' ' '^'`; do
      badfile="`echo "$rawdata" | cut -d '^' -f4`"
      proc_debug "  $badfile MISSING in $CURPATH"
      proc_log "$badfile MISSING in $CURPATH"
      if [ "$CLEANSH" ]; then
        echo "rm -rf \"$CURPATHNOCD\"" >> $CLEANSH
      fi

    done

  else
    proc_debug "  Didnt find a rar file to start scanning on - skipping."
  fi
}

if [ "$CLEANSH" ]; then
  echo "#!/bin/bash" > $CLEANSH
fi
if [ "$LOG" ]; then
  rm -f "$LOG"
fi

for rawdata in $SECTIONS; do
  section="`echo "$rawdata" | cut -d ':' -f1`"
  deep="`echo "$rawdata" | cut -d ':' -f2`"

  cd $ROOTSECTIONS$section
  proc_debug ""
  proc_debug "Entering $section"

  for release in `ls -1 | egrep -v "GROUPS|lost\+found"`; do
    unset cds
    cd $release
    if [ "$deep" = "DEEP" ]; then
      for subdir in `$TULS | tr ' ' '^' | grep "^d" | egrep -iv ":\.\.:|:\.\:" | awk -F"::::" '{print $4'} | egrep -v "GROUPS|lost\+found"`; do
        echo "Entering subdir $subdir"
        cd $ROOTSECTIONS$section/$release/$subdir
        CURPATHNOCD="$ROOTSECTIONS$section/$release/$subdir"
        proc_scan_sfv
        if [ "$UNRAR" ] && [ "$SKIP" != "TRUE" ]; then
          proc_findfile
          proc_scan
        fi
      done

    elif [ "`ls -1 | egrep "^[cC][dD][1-9]$|^[dD][iI][sS][cCkK][1-9]$|^[dD][vV][dD][1-9]$"`" ]; then
      for cds in `ls -1 | egrep "^[cC][dD][1-9]$|^[dD][iI][sS][cCkK][1-9]$|^[dD][vV][dD][1-9]$"`; do
        cd $ROOTSECTIONS$section/$release/$cds
        CURPATH="$ROOTSECTIONS$section/$release/$cds"
        CURPATHNOCD="$ROOTSECTIONS$section/$release"
        proc_debug ""
        proc_debug " Entering $release/$cds"
        proc_scan_sfv
        if [ "$UNRAR" ] && [ "$SKIP" != "TRUE" ]; then
          proc_findfile
          proc_scan 
        fi
      done

    else
      cd $ROOTSECTIONS$section/$release
      CURPATH="$ROOTSECTIONS$section/$release"
      CURPATHNOCD="$ROOTSECTIONS$section/$release"
      proc_debug ""
      proc_debug " Entering $release"
      proc_scan_sfv
      if [ "$UNRAR" ] && [ "$SKIP" != "TRUE" ]; then
        proc_findfile
        proc_scan
      fi
    fi
    cd $ROOTSECTIONS$section
  done

done

if [ "$CLEANSH" ]; then
  if [ -e "$CLEANSH" ]; then
    cat $CLEANSH | sort -u > /tmp/cleantmp.tmp
    mv -f /tmp/cleantmp.tmp $CLEANSH
    proc_debug ""
    proc_debug "$CLEANSH created. Need to chmod 700 $CLEANSH before running it (verify it first!)"
    proc_log "$CLEANSH created. Need to chmod 700 $CLEANSH before running it (verify it first!)"
  fi
fi

exit 0
