#!/bin/bash
VER=0.1

## Small script to add numbers for another stat section to all users.
##
## Problem: When adding a new stat section, the numbers for it does
## not get added to the userfile until that user logs in for the first
## time. This script helps eliminate that problem by adding "0 0 0" at the
## end of each stat in the userfile.
##
## This will help those running MSS amongst others.
## Say you add a new stat section to the hub, for stats from a slave.
## Normally, those stats will not be moved to the hub if the user never logged
## in to the hub and thus, no numbers exists on that userfile for that section.
##
## Copy to /glftpd/bin and chmod it to 700 (root executable).
## Run it once for each time you want to add a stat section.
##
## It wont matter if it adds too many "0 0 0" since those will be removed
## when the user logs on. They dont hurt.
##
## Specify debug as first argument to make a test run (wont do much but echo).
##
## Specify a single user as first argument to only add the 0 0 0 to that user.
## If so, you can use debug as the 2nd argument for testing.


USERDIR=/glftpd/ftp-data/users
TMPDIR=/tmp


##---[Start]---##

ADDLIST="ALLUP ALLDN WKUP WKDN DAYUP DAYDN MONTHUP MONTHDN NUKE"

if [ -d "$USERDIR" ]; then
  cd $USERDIR
else
  echo "Error. Cant find userdir at $USERDIR - Check settings."
  exit 1
fi

if [ ! -d "$TMPDIR" ]; then
  echo "Error. TMPDIR dir $TMPDIR does not exist."
  exit 1
fi

until [ -n "$backedup" ]; do
  echo -n "Have you done a backup of you're users first ? [Y]es [N]o: "
  read backedup
  case $backedup in
    [Nn])
      echo "Do so first."
      exit 0
    ;;
    [Yy])
      backedup="y"
    ;;
    *)
      unset backedup
      continue
    ;;
  esac
done

proc_addstats() {
  echo "Adding stats for $user"
  for stat in $ADDLIST; do
    CUR_STAT="`grep "^$stat\ " $user`"
    if [ -z "$CUR_STAT" ]; then
      echo "ERROR: Cant read $stat for $user. Aborting. Restore backup."
      exit 0
    fi
    CUR_STAT="`echo $CUR_STAT`"
    if [ "$1" != "debug" -a "$2" != "debug" ]; then
      grep -v "^$stat\ " $user > $TMPDIR/$user.temp
      cp -f "$TMPDIR/$user.temp" "$user"
      rm -f "$TMPDIR/$user.temp"
    fi
    echo "$CUR_STAT 0 0 0" >> $user
    
  done
}

if [ "$1" -a "$1" != "debug" ]; then
  user="$1"
  if [ ! -e "$user" ]; then
    echo "User $user does not exist. Quitting."
    exit 1
  fi
  proc_addstats
  exit 0
fi

for user in `grep "^FLAGS\ " * | cut -d ':' -f1 | grep -v "default.user"`; do
  proc_addstats
done


