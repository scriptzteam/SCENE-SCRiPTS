#!/bin/sh
# Version 1.0 by eur0dance
#
# This is a pre_dir_check script, which is being runned by glftpd before the dir is created.
# The script doesn't allow dir creation if if it was uploaded before or was nuked/unnuked or
# if it is mp3 release it can check its year (from the dir layout) and deny dir creation unless
# it's the current year.
#
# Installation:
# ~~~~~~~~~~~~~
# (1)
# You should put "predircheck.sh" in your glftpd bin dir and add it to your glftpd.conf like this: 
# pre_dir_check   /bin/predircheck.sh
# (2)
# echo, grep, dirlogcheck binaries that should be in your glftpd bin directory.
# In order to compile dirlogcheck do: "make". If your glftpd bin path is a standard one do
# "make install" after that, if not - copy the "dirlogcheck" binary to your glftpd bin dir.
# (3)
# Change the values inside the CONFIG section (if needed) and edit things in CODE sections
# as descibed below inside the "Notes" section.
#
# Notes:
# ~~~~~~
#        (1) The first "case block":
#        You need to edit the "case block" in the CODE section. First of all, put the correct paths from
#        your configuration for PRE and REQUESTS and MP3 dirs. If you don't use centralized PRE/GROUPS dir
#        then put your multiple pre/group dirs in the same fasion inside the case instead of my /site/PRE.
#        If you don't have REQUESTS dir or don't have MP3 section, remove their blocks from the "case block".
#        If you do have MP3 section but don't have it limited to 2002+ only please remove the /site/MP3 block.
#        If the current year is not 2002, please replace all 2002 numbers with your year inside /site/MP3 block.
#        (2) The second "case block":
#        This one defines dirs that won't be denied for creating, since they can appear (as sub dirs for example) 
#        inside many releases. You can add the dirs I forgot or removed those you don't need.
#
# The script gets these parameters from glftpd:  
# $1 = Name of directory.
# $2 = Actual path the directory is stored in.
#
# The script gets these values from "dirlogcheck" binary:
# dirstatus:  0 - NEWDIR, 1 - NUKE, 2 - UNNUKE, 3 - DELETED, 4 - DOESN'T EXIST

### CONFIG ###

# Your datapath relative to glftpd dir
datapath=/ftp-data

# Current year
curyear=2002


### CODE ###

# Edit this block as descibed above (this is the first "case block")
case $2 in
  /site/PRE/*)
     exit 0
  ;;
  /site/REQUESTS*)
     exit 0
  ;;
  /site/MP3/*)
     case $1 in 
       [cC][dD]*)
          gresult=1
       ;;
       *)     
          gresult1=`echo $1 | grep -c -- -$curyear-`
          gresult2=`echo $1 | grep -c -- -\($curyear\)-`
          gresult3=`echo $1 | grep -c -- -CD$curyear-`
       ;;
     esac
     if [ $gresult1 -eq 0 -a $gresult2 -eq 0 -a $gresult3 -eq 0 ]; then
        echo "Cannot create $2/$1 - Year is missing, not allowed or non RIAA! ($curyear+ only)"
        exit 2
     fi     
  ;;
esac  

# List of the exempted dirs, like: sample*, extra*, cover*, approved, bonus*, ac3*, subs*, oggdec*
# You can add other dirs in here (this is the second "case block").
case $1 in
   [sS][aA][mM][pP][lL][eE]*)
      exit 0
   ;;
   [eE][xX][tT[rR][aA]*)
      exit 0
   ;;
   [cC][oO][vV][eE][rR]*)
      exit 0 
   ;;
   [aA][pP][pP][rR][oO][vV][eE][dD]*)
      exit 0
   ;;
   [bB][oO][nN][uU][sS]*)
      exit 0
   ;;
   [aA][cC]3*)
      exit 0
   ;;
   [sS][uU][bB][sS]*)
      exit 0
   ;;
   [vV][oO][bB][sS][uU][bB]*)
     exit 0
   ;;
   [oO][gG][gG][dD][eE][cC]*)
     exit 0
   ;; 
esac 

# Don't edit this block !!!    
dirstatus=`dirlogcheck $1 $2`
if [ $dirstatus -eq 3 -o $dirstatus -eq 4 ]; then
   exit 0
else
   echo "Cannot create $2/$1 - DUPE!"
   echo "It already exists or has been nuked/unnuked."
   exit 2
fi       
