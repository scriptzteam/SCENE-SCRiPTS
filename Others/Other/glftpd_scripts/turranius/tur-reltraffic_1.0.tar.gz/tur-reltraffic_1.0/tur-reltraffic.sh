#!/bin/bash
VER=1.0

#-------------------------------------------------------#
#                                                       #
# Tur-RelTraffic. A script to display how much traffic  #
# a release has caused. Partial hits are supported, to  #
# check traffic from groups, etc.                       #
#                                                       #
# REQUIRES: xferlog-import.sh and tur-relsizeupdate.sh  #
#                                                       #
#--[ Setup ]--------------------------------------------#
#                                                       #
# Copy tur-reltraffic.sh to /glftpd/bin. Chmod to 755.  #
#                                                       #
# Copy tur-reltraffic.tcl to your bots scripts dir, add #
# it to the config and .rehash the both.                #
#                                                       #
# Setup the options below.                              #
#                                                       #
# Try it from shell by running without any arguments.   #
#                                                       #
# NOTE: If you do not have tur-relsizeupdate.sh and     #
#       only xferlog-import.sh, this script still works #
#       but it will not produce the ${DIFF} cookie.     #
#       Same applies if a release is missing from the   #
#       relsize database.                               #
#                                                       #
#--[ Settings ]-----------------------------------------#

## These should be self explaining.
## I'm just gonna assume you have the same MySQL server
## for both xferlog-import.sh and tur-relsizeupdate.sh
SQLBIN="mysql"
SQLHOST="localhost"
SQLUSER="root"
SQLPASS="password"

## Database and table for xferlog-import.sh
TRANSFER_SQLDB="transfers"
TRANSFER_SQLTB="transfers"

## Database and table for tur-relsizeupdate.sh
RELSIZE_SQLDB="relsize"
RELSIZE_SQLTB="relsize"

## Sections. Should be the same as in xferlog-import.sh
SECTIONS="DVDR ISO-UTILS XBOX XXX"

B=""  ## Dont touch
U=""  ## Dont touch

## This is the output.
## ${RELNAME} = What the user searched for.
## ${DIRMES}  = Either the word downloaded or uploaded, depending on search.
## ${MB}      = Megabyte transfered.
## ${USERS}   = Number of users who leeched/upped it.
## ${GROUP}   = Number of groups who leeched/upped it.
## ${DIFF}    = (Downloaded x.xx times)"
## ${B}       = Start/Stop bold text.
## ${U}       = Start/Stop underlined text.

proc_output() {
  if [ -z "$DAYS" ]; then

    ## If number of days is not specified.
    echo "${RELNAME} stats so far: ${DIRMES} ${B}${MB} MB${B} - ${B}${USERS}${B} users from ${GROUP} groups ${DIRMES} it${DIFF}." 

  else 

    ## If number of days is specified.
    echo "${RELNAME} stats so far: ${DIRMES} ${B}${MB} MB${B} - ${B}${USERS}${B} users from ${GROUP} groups ${DIRMES} in the last ${DAYS} days${DIFF}." 

  fi
}

#--[ Script Start ]-----------------------------#

TRANSFER_SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $TRANSFER_SQLDB -N -s -e"
RELSIZE_SQL="$SQLBIN -u $SQLUSER -p"$SQLPASS" -h $SQLHOST -D $RELSIZE_SQLDB -N -s -e"

if [ "$1" = "*" -o "$1" = "%" ]; then
  echo "Be more specific"
  exit 0
fi

if [ -z "$1" ]; then
  echo "Usage: !reltraffic <releasename> <days> <section> <direction (i)n/(o)ut>. If only releasename is given, default is outgoing traffic for unlimitied days in all sections. Sections are $SECTIONS or ALL (case sensetive). Days can be ALL for alltime. Use % for partial hits, like %-Group"
  exit 0
fi

if [ "$2" = "" -o "$2" = "ALL" ]; then
  DAYS=""
else
  DAYS="$2"
  verify="$( echo $SECTIONS | grep -w $2 )"
  if [ "$verify" ]; then
    echo "Second argument is # of days"
    exit 0
  fi
fi

if [ "$3" != "" -a "$3" != "ALL" ]; then
  verify="$( echo $SECTIONS | grep -w $3 )"
  if [ -z "$verify" ]; then
    echo "No no. Sections are $SECTIONS"
    exit 0
  else
    SECTION="$3"
  fi
fi

if [ -z "$4" ] || [ "$4" = "o" ]; then
  DIRECTION="o"
  DIRMES="downloaded"
else
  DIRECTION="i"
  DIRMES="uploaded"
fi

if [ "$DAYS" ]; then
  DAYQUERY="and TO_DAYS(NOW()) - TO_DAYS(datum) <= $DAYS"
fi

DIRECTIONQUERY="and direction = 'o'"
DIRWORD="Downloaded"
if [ "$DIRECTION" = "i" -o "$DIRECTION" = "I" ]; then
  DIRECTIONQUERY="and direction = 'i'"
  DIRWORD="Uploaded"
fi

if [ "$SECTION" ] && [ "$SECTION" != "ALL" ]; then
  SECTIONQUERY="and section = '$SECTION'"
else
  SECTIONQUERY="and section != 'GROUPS'"
fi

RELNAME=`echo $1 | sed s/*/%/g`

## Check from transfers.
DLINFO=`$TRANSFER_SQL "select sum(size/1024/1024), count(distinct groupname), count(distinct username) from $TRANSFER_SQLTB where name like '$RELNAME' $DIRECTIONQUERY $DAYQUERY $SECTIONQUERY" | awk -F" " '{print $1":"$2":"$3}'`

MB=`echo $DLINFO | awk -F":" '{print $1}' | awk -F"." '{print $1}'`
GROUP=`echo $DLINFO | awk -F":" '{print $2}'`
USERS=`echo $DLINFO | awk -F":" '{print $3}'`

if [ "$MB" = "NULL" ]; then
  echo "Nothing found on $RELNAME, either spelling is wrong or nothing was $DIRMES."
  exit 0
fi

## Is size in relsize?
sizetest=`$RELSIZE_SQL "select size, name from $RELSIZE_SQLTB where name = '$RELNAME' limit 1" | awk '{print $1"^"$2}'`
if [ "$sizetest" ]; then
  ## Found it in DB
  size="$( echo $sizetest | awk -F"^" '{print $1}' )"
  readrel="$( echo $sizetest | awk -F"^" '{print $2}' )"
  if [ "$size" != "0" ]; then
    diff="$( echo $MB / $size | bc -l | cut -b1-4 )"
  else
    diff="0"
  fi
  difference="$( echo $diff | awk -F"." '{print $1}' )"
  if [ "$difference" != "" ]; then
    difference="$( echo $diff | cut -b1-4 )"
    DIFF=" ($DIRWORD $difference times)"
  else
    difference="$( echo $diff | awk -F"." '{print $2}' )"
    DIFF=" ($DIRWORD 0.$difference times)"
  fi
fi

  
proc_output

exit 0
