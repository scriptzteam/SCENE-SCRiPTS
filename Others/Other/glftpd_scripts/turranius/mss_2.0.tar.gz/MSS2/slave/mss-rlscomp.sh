#!/bin/sh
##################################################################
# SCRIPTNAME : MSSRLSCOMP
# AUTHOR     : void0 (void0@mail.com)
# VERSION    : 0.1
# DESCRPTION : This script creates a MSS .notdoen action-file on
#              the slave to syncronize userstats after a release
#              is complete.              
#              It is to be used with Dark0n3s zs-c bu can probably
#              be modified to work with any other aswell.
#
# INSTALLATION (added/changed in zsconfig.h)
#  #define enable_complete_script TRUE
#  #define complete_script         "/bin/mss-rlscomp.sh"
#
# Apart from the standard binaries, make sure 'tac' is in your
# /glftpd/bin dir
#
# HISTORY
#   0.1  - First release! :)
#
# THANKS
#   Turranius for listening and implementing my ideas in MSS and
#   for making useful scripts for the public. Keep up the good!
#
##################################################################
# CONFIGURATION
##################################################################

# Path to your glftpd root. Do not use chrooted path.
GLROOT="/glftpd"

## Ignore this one.
if [ ! -d "$GLROOT" ]; then
  GLROOT=""
fi

## Path to config file
MSSSLAVECONFIG=$GLROOT/bin/mss-slave.conf

##################################################################
# READ CONFIG
##################################################################

. $MSSSLAVECONFIG

##################################################################
# FUNCTIONS
##################################################################
putlog()
{
    if [ "$VERBOSE" == "TRUE" ]; then
	echo "$*"
    fi
    if [ ! -z "$RLSCOMPLOG" ]; then
	echo `date +'%a %b %e %T %Y'` "MSSRLSCOMP:" "$*" >> $RLSCOMPLOG
    fi
}

##################################################################
write_action()
{
    putlog "Writing '$*' to slave actionfile."
    echo "$*" >> "$GLETC/$DESTNAME.actions.notdone"
}

##################################################################
# CORE
##################################################################
SCRIPTNAME="MSSRLSCOMP"
AUTHOR="void0 (void0@mail.com)"
VERSION="0.1"

##################################################################
## Verify logfile
if [ -e "$RLSCOMPLOG" ]; then
    if [ ! -f "$RLSCOMPLOG" ]; then
	putlog "Logfile exists but is not a file."
    fi
fi

putlog "$SCRIPTNAME v$VERSION by $AUTHOR - Start"

## Verify DESTNAME
if [ -z "$DESTNAME" ]; then
    putlog "DESTNAME is not set!"
    exit
fi

## Verify actions-directory
if [ -e "$GLETC" ]; then
    if [ ! -d "$GLETC" ]; then
	putlog "Actions-directory exists but is not a directory."
	exit
    fi
fi
if [ ! -w "$GLETC" ]; then
    putlog "Actions-directory is not writeable."
    exit
fi

if [ ! -r "$GLETC/passwd" ]; then
    putlog "No permissions to read from $GLETC/passwd. Check both $GLETC perms and passwd perms."
    exit
fi

if [ "$1" ]; then
    FULLPATH="$( tac "$GLXFERLOG" | grep -i ".*/$1 [ab] _ i .*" | head -n1 | tr -s ' ' | cut -d' ' -f9 )"
    if [ -z "$FULLPATH" ]; then
	putlog "File '$1' not found in $GLXFERLOG"
	exit
    fi

    RLSPATH="$GLROOT$( dirname "$FULLPATH" )"
    if [ ! -d "$RLSPATH" ]; then
	putlog "Found '$RLSPATH' but is not a directory."
	exit
    fi

    if [ -z "$( echo "$RLSPATH" | egrep "$EXCLUDE" )" ]; then
	putlog "Processing '$RLSPATH'"
	PROCESSED=""
	for CURUID in $( ls -ln $RLSPATH | tr -s ' ' | cut -d' ' -f3 ); do
	    if [ -z "$( echo "$PROCESSED" | grep "$CURUID " )" ]; then
		USERS="$( grep ":$CURUID:" $GLETC/passwd | cut -d':' -f1 )"
		if [ "$USERS" ]; then
		    for CURUSER in $USERS; do
			USERUID="$( grep "^$CURUSER:" $GLETC/passwd | cut -d':' -f3 )"
			if [ "$USERUID" ] && [ $CURUID -eq $USERUID ]; then
	    		    write_action "SYNC STATS $CURUSER"
			    PROCESSED="$PROCESSED$CURUID "
			    break
                        fi
		    done
		fi
	    fi
	done    
    else
	putlog "Release '$RLSPATH' was excluded. Found in '$EXCLUDE'."
    fi
fi

##################################################################
# END OF SCRIPT
##################################################################
