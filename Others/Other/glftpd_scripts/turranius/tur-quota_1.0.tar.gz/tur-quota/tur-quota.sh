#!/bin/bash
VER=1.0
#-------------------------------------------------------#
# Tur-Quota by Turranius.                               #
# This is like megatrial but for quota users. It will   #
# display everyone that has passed or (so far) failed   #
# quota. Made on request from PushPull.                 #
#                                                       #
# It is an extension to Tur-Trial so that must be       #
# installed and used with quota.                        #
#                                                       #
#-[ Settings ]------------------------------------------#
#                                                       #
# Before we begin, do a test. From shell, type:         #
# /glftpd/bin/tur-trial.sh dummy quota test             #
# It should display everyones quota status.             #
# If it does not, you are running a too old version of  #
# tur-trial or I missed something.                      #
#                                                       #
# Anyway, copy tur-quota.sh to /glftpd.bin              #
# Make it executable (chmod 755 tur-quota.sh)           #
# Copy tur-quota.tcl to your bots scripts dir and load  #
# it in the bots config file.                           #
#                                                       #
# Edit the settings in tur-quota.sh:                    #
# BIN=           The location of tur-trial.sh           #
#                                                       #
# ONELINE=       Show output in one line? Otherwise its #
#                one line per user.                     #
#                When using ONELINE, it will output 2   #
#                or more lines if the output gets       #
#                longer than 400 lines. Otherwise irc   #
#                will cut it short.                     #
#                                                       #
# SUMFOOTER=     This is what to add after each users   #
#                MB level in the output.                #
#                                                       #
# SHOWTOTAL=     If TRUE, it will show the number of    #
#                users who passed or failed too.        #
#                                                       #
# SAFEHEADER=    If you are not using ONELINE=TRUE this #
#                is what is shown before each user is   #
#                displayed.                             #
# FAILHEADER=    Same, but for failed users.            #
#                                                       #
# SPLITTER=      If you ARE using ONELINE=TRUE, this is #
#                shown inbetween each user to split it. #
#                                                       #
# EXCLUDE=       These users, space seperated, will not #
#                be displayed. Note that it by default  #
#                only shows users who are on quota, so  #
#                no need to add affils etc here.        #
#                                                       #
# Ok, try running tur-quota.sh from shell. If it works, #
# it should work from irc as well. Note that the tcl    #
# locks it for ops only. You should edit that one too   #
# if you want to change the trigger from !quotacheck    #
#                                                       #
#-[ Requirements ]--------------------------------------#
#                                                       #
# Tur-Trial 1.3+ or something (forgot exact version..)  #
# Its the one where I merged MonthUpAll into Tur-Trial. #
# Binaries: cut, tr, grep & expr                        #
#                                                       #
#-[ Contact ]-------------------------------------------#
#                                                       #
# Turranius on Efnet/linknet                            #
# http://www.grandis.nu/glftpd - http://grandis.mine.nu #
#                                                       #
#-[ Settings ]------------------------------------------#

BIN=/glftpd/bin/tur-trial.sh
ONELINE=TRUE
SUMFOOTER=" MB"
SHOWTOTAL=TRUE

## If ONELINE=FALSE
SAFEHEADER="Safe:"
FAILHEADER="Fail:"

## If ONELINE=TRUE
SPLITTER="-"

EXCLUDE="user1 user2"


#########################################################
# No frollicking around below here now, ya here?        #
#########################################################

unset WORD

proc_check() {
  each="$( echo $each | tr -s '^' ' ' )"
  if [ "$EXCLUDE" ]; then
    user="$( echo $each | cut -d' ' -f1 )"
    for suka in $EXCLUDE; do
      if [ "$user" = "$suka" ]; then
        SKIPUSER="TRUE"
      fi
    done
  fi
  if [ "$SKIPUSER" != "TRUE" ]; then
    if [ "$ONELINE" = "TRUE" ]; then
      if [ "$OUTPUT" ]; then
        OUTPUT="$OUTPUT $SPLITTER $each$SUMFOOTER"
        if [ "$( echo "$OUTPUT" | wc -m | tr -d ' ' )" -gt "400" ]; then
          echo "$OUTPUT"
          unset OUTPUT
        fi
      else
        OUTPUT="$each$SUMFOOTER"
      fi
    else
      echo "$NICE $each$SUMFOOTER"
    fi
    if [ "$SHOWTOTAL" = "TRUE" ]; then
      num="$( expr "$num" \+ "1" )"
    fi
  fi
  unset SKIPUSER
}

num=0

case $1 in
  passed)
    NICE="$SAFEHEADER"
    for each in `$BIN dummy quota test | grep -w "Safe" | tr -d '-' | tr -s ' ' '^' | cut -d"^" -f1,2`; do
      proc_check
    done
    ;;
  failed)
    NICE="$FAILHEADER"
    for each in `$BIN dummy quota test | grep -v "Test mode on." | grep -v "this is a test" | grep -v "Limit is" | grep -v "DEBUG:" | grep -wv "Safe" | tr -d '-' | tr -s ' ' '^' | cut -d"^" -f1,2`; do
      proc_check
    done
    ;;
  *)
    echo "Quota check: Enter passed or failed to display list."
    exit 0
    ;;
esac


if [ "$OUTPUT" ]; then
  if [ "$SHOWTOTAL" = "TRUE" ]; then
    echo "$OUTPUT $SPLITTER Total: $num"
  else
    echo "$OUTPUT"
  fi
else
  if [ "$SHOWTOTAL" = "TRUE" ]; then
    echo "Total users: $num"
  fi
fi

exit 0
