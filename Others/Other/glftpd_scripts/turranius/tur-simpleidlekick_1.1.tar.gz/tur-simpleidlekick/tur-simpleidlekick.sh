#!/bin/bash
VER=1.1

#--[ Intro ]-------------------------------------------------------#
#                                                                  #
# Simple idle kicker that checks the idletimer. Sometimes users    #
# seems to be able to idle forever even with no antiidle commands. #
# This script will just kick those. Nothing more, nothing less.    #
# If you want something more advanced, I suggest you install KTMF. #
#                                                                  #
# No long instructions this time. Only this:                       #
# This script requires tur-ftpwho 3.0 which is a seperate package  #
# available at my webpage as well.                                 #
#                                                                  #
# Example crontab: */2 * * * *   /glftpd/bin/tur-simpleidlekick.sh #
#                                                                  #
# http://www.grandis.nu/glftpd <-> http://grandis.mine.nu/glftpd   #
#                                                                  #
# Specify 'test' when running it to just show what it would do.    #
#                                                                  #
# Changes:                                                         #
# 1.1                                                              #
# cat /path/to/usersdir/-NEW-: No such file or directory -- FIXED  #
#                                                                  #
#------------------------------------------------------------------#

## Location of tur-ftpwho version 3+
TURFTPWHO=/glftpd/bin/tur-ftpwho

## What to kick on. s=seconds, m=minutes, h=hours
INTERVAL=s

## And if the idle time on that interval is greater then this..
MAXIDLETIME=8

## Path to users dir.
USERSDIR=/glftpd/ftp-data/users

## Excluded users. Space separated.
EXCLUDEUSERS="ostnisse kalibro"

## Excluded groups. Space separated.
EXCLUDEGROUPS="Ostgroup pissgroup"

## Excluded paths, Space separated (can be a single word too).
EXCLUDEPATHS="/GROUPS/"


#--[ Script Start ]---------------------------------------------------#

if [ "$1" = "test" ]; then
  TEST="TRUE"
fi

if [ "$EXCLUDEUSERS" ]; then
  EXCLUDEUSERS=`echo "$EXCLUDEUSERS" | tr -s ' ' '|'`
  EXCLUDEUSERS="^$EXCLUDEUSERS\$"
  if [ "$TEST" = "TRUE" ]; then
    echo "Setting excluded users to: \"$EXCLUDEUSERS\""
  fi
fi

if [ "$EXCLUDEGROUPS" ]; then
  EXCLUDEGROUPS=`echo "$EXCLUDEGROUPS" | tr -s ' ' '|'`
#  EXCLUDEGROUPS="^GROUP $EXCLUDEGROUPS\$"
  if [ "$TEST" = "TRUE" ]; then
    echo "Setting excluded groups to: \"$EXCLUDEGROUPS\""
  fi
fi

if [ "$EXCLUDEPATHS" ]; then
  EXCLUDEPATHS=`echo "$EXCLUDEPATHS" | tr -s ' ' '|'`
  if [ "$TEST" = "TRUE" ]; then
    echo "Setting excluded paths to \"$EXCLUDEPATHS\""
  fi
fi

## Check that this is atleast version 3 of tur-ftpwho
if [ -z "`$TURFTPWHO -v | grep "^Version"`" ]; then
  echo "Error. This script requires atleast tur-ftpwho 3.0 which is a"
  echo "seperate package from http://www.grandis.nu/glftpd"
  exit 1
fi

for rawdata in `$TURFTPWHO | tr -d ' ' | grep "\^Idle:\^" | grep -v "\-NEW\-"`; do
  SKIP=FALSE
  username=`echo "$rawdata" | cut -d '^' -f1`
  group=`echo "$rawdata" | cut -d '^' -f5`
  if [ -z "$group" ]; then
    group="NoGroup"
  fi
  pid=`echo "$rawdata" | cut -d '^' -f2`
  pwd=`echo "$rawdata" | cut -d '^' -f4`
  idletime=`echo "$rawdata" | cut -d '^' -f6`
  if [ "$TEST" = "TRUE" ]; then
    echo "DEBUG: user:$username group:$group pid:$pid pwd:$pwd idletime:$idletime"
    echo ""
  fi

  ## Check excluded user
  if [ "$EXCLUDEUSERS" ]; then
    if [ "`echo "$username" | egrep "$EXCLUDEUSERS"`" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$username/$group is an excluded user. Skipping."
      fi
      SKIP="TRUE"
    fi
  fi

  ## Check excluded group
  if [ "$EXCLUDEGROUPS" -a "$SKIP" != "TRUE" ]; then
    if [ "`grep "^GROUP\ " $USERSDIR/$username | egrep "$EXCLUDEGROUPS"`" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$username/$group is in excluded group. Skipping."
      fi
      SKIP="TRUE"
    fi
  fi

  ## Check for flag I on this user.
  if [ "$SKIP" != "TRUE" ]; then
    if [ "`grep "^FLAGS " $USERSDIR/$username | grep "I"`" -a "$SKIP" != "TRUE" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$username/$group has flag I. Skipping."
      fi
      SKIP="TRUE"
    fi
  fi

  if [ "$EXCLUDEPATHS" -a "$SKIP" != "TRUE" ]; then
    if [ "`echo "$pwd" | egrep -i "$EXCLUDEPATHS"`" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$username/$group is in $pwd. Skipping."
      fi
      SKIP="TRUE"
    fi
  fi

  if [ "`echo "$idletime" | grep ":*:"`" -a "$SKIP" != "TRUE" ]; then
    case $INTERVAL in
      [hH]) idletime=`echo "$idletime" | cut -d ':' -f1` ;;
      [mM]) idletime=`echo "$idletime" | cut -d ':' -f2` ;;
      [sS]) idletime=`echo "$idletime" | cut -d ':' -f3` ;;
      *) echo "Error. INTERVAL must be either h, m or s"; exit 1;;
    esac

    if [ "$idletime" -ge "$MAXIDLETIME" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Would have kicked $username/$group with pid: $pid for being idle for $idletime$INTERVAL"
      else
        kill $pid >/dev/null 2>&1
        kill -9 $pid >/dev/null 2>&1
      fi
    fi
  fi  
done

if [ -z "$username" ]; then
  if [ "$TEST" = "TRUE" ]; then
    echo "No users idling it seems."
    exit 0
  fi
fi

exit 0
