#!/bin/bash
VER=1.0

#--[ Intro ]----------------------------------------------------
#
# This is a script for announcing the latest story from 
# http://www.grandis.nu/glftpd in your chan/staffchan.
#
# It will only announce the header for each new story, not the
# full information (too spammy).
#
#--[ Setup ]----------------------------------------------------
#
# Copy tur-newsannounce.sh to /glftpd/bin and chmod it to 700.
#
# Edit the settings:
#
# LINK=   The link to the file containing the latest news.
#         Should not need to change this.
#
# WGET=   Yepp, this script uses wget. This is how to get the
#         $LINK file.
#
# GLLOG=  Full path to glftpd.log for bot output.
#
# TMP=    A temporary dir to store 2 files in. 
#
#--[ Announce ]-------------------------------------------------
#
# If you use dark0n3s dZSbot.tcl or pzs-ng, add the following
# to either dZSbot.tcl or dZSbconf.tcl (depending on what you use):
#
# To 'set msgtypes(DEFAULT)' add: TURNEWS
#
# Add the following where you see fit:
# set chanlist(TURNEWS)  "#chan"
# set disable(TURNEWS)   0
# set variables(TURNEWS) "%sid %author %time %announce"
#
# Now, if you use dark0n3s dZSbot.tcl, add the following as well:
# set announce(TURNEWS)  "New Story on http://www.grandis.nu/glftpd at %time by %author: %announce"
#
# However, if you use pzs-ng, you'll want to edit your current theme file and add:
# announce.TURNEWS = "New Story on http://www.grandis.nu/glftpd at %time by %author: %announce"
#
# You may change the announce line to whatever you see fit.
# Dont forget to .rehash the bot.
#
#--[ Crontab ]--------------------------------------------------
#
# Now, before you crontab this script, run it from shell and 
# make sure it announces in your chan. Run it again and it 
# should not announce the same thing again.
#
# To make it announce the same thing again, remove the file
# $TMP/old_newsannounce and run the script.
#
# IMPORTANT: It does NOT read the info directory from my website.
# It downloads a file containing the latest news and reads that.
# This file is only updated every 2 hours, so there is NO use to
# crontab this script more then once or twice every 2 hours.
# I'll ban your ass if I see you grabbing this file too often.
#
# So, to crontab it to run every 2 hours:
# 5 */2 * * * /glftpd/bin/tur-newsannounce.sh
# This will run it 5 minutes past every 2 hours (the file is updated 
# every even hour at my end, so 5 minutes past should be good).
#
#--[ Settings ]-------------------------------------------------


LINK="http://www.grandis.nu/glftpd/newsannounce.tmp"

## Take away the -q to get debug output.
WGET="wget -q -T 5 --cookies=off $LINK"

GLLOG="/glftpd/ftp-data/logs/glftpd.log"

TMP=/tmp


#--[ Script Start ]---------------------------------------------

## How to announce.
proc_announce() {
  echo `date "+%a %b %e %T %Y"` TURNEWS: "$*" >> $GLLOG
}

## Delete old file if there.
if [ -e "$TMP/newsannounce.tmp" ]; then
  rm -f "$TMP/newsannounce.tmp"
fi

## Enter the TMP dir and run the WGET.
cd $TMP
$WGET

## If we got a file...
if [ -e "$TMP/newsannounce.tmp" ]; then

  ## Get the sid (ID) of the story.
  sid="`cat "$TMP/newsannounce.tmp" | awk -F"@@@@" '{print $1}'`"

  ## Announce? NO. Set this to TRUE later if so.
  ANNOUNCE="FALSE"

  ## Check that we actually got a sid from the downloaded file.
  if [ -z "$sid" ]; then
    echo "Tur-Newsannounce Error. Could not read sid from $TMP/newsannounce.tmp"
    exit 0
  fi

  ## Check if we should announce this or not.
  if [ -e "$TMP/old_newsannounce" ]; then
    if [ "`cat "$TMP/old_newsannounce"`" = "$sid" ]; then
      exit 0
    else
      ANNOUNCE="TRUE"
    fi
  else
    ANNOUNCE="TRUE"
  fi

  ## It should be announced. Grab all the values and 'proc_announce' it.
  if [ "$ANNOUNCE" = "TRUE" ]; then
    author="`cat "$TMP/newsannounce.tmp" | awk -F"@@@@" '{print $2}'`"
    time="`cat "$TMP/newsannounce.tmp" | awk -F"@@@@" '{print $3}'`"
    header="`cat "$TMP/newsannounce.tmp" | awk -F"@@@@" '{print $4}'`"
    proc_announce \"$sid\" \"$author\" \"$time\" \"$header\"
    echo "$sid" > "$TMP/old_newsannounce"
  fi

  ## Delete downloaded file.
  rm -f "$TMP/newsannounce.tmp"
fi


exit 0