#!/bin/bash
VER=1.2.1
## See README for instructions on the configuration.

#--[ Configuration ]------------------------------------#

USERSDIR=/glftpd/ftp-data/users
DATAFILE=/glftpd/etc/tur-goodboy.db
TMP=/glftpd/tmp
STATS=/glftpd/bin/stats
GLCONF=/etc/glftpd.conf
LOG=/glftpd/ftp-data/logs/tur-goodboy.log
MSGS=/glftpd/ftp-data/msgs

READSECTION=0
DURATION=t
EUROWEEK=FALSE
RANDOMUSERS="5"

IGNORELEECH=TRUE
USEREXCLUDE="turranius|ostnisse"
GROUPEXCLUDE="SiTEOPS|TRiAL|TRiAL-2"

GIVECREDS=""
GIVEFLAG=""
JUMPONFLAG=FALSE
LEECHFLAG=W
LEECHPATH="/Archive"
ONEDAYONLY=TRUE

## Announce settings:

GLLOG=/glftpd/ftp-data/logs/glftpd.log
MBLIMIT="1000"

WINNERANNOUNCE="%BOLD%-SiteName-%BOLD% [TOPUL] - From todays Top %ULINE%$RANDOMUSERS Uploaders%ULINE%, we select %BOLD%%WINNER%%BOLD% at position %BOLD%%POS%%BOLD% (%UPFILES% F/%UPMEG%) to get %BOLD%leech%BOLD% in the archive for 24 hours."

REMOVEANNOUNCE="%BOLD%-SiteName-%BOLD% [TOPUL] - %BOLD%%LOOSER%%BOLD%'s leech in the archive has %ULINE%expired%ULINE% !"


#--[ Script Start ]-------------------------------------#

## Check if USERSDIR is defined correctly.
if [ ! -d "$USERSDIR" ]; then
  echo "Error. $USERDIR, defined as USERDIR does not exist."
  exit 1
fi

## Check that datafile exists and can be read and written to.
if [ ! -e "$DATAFILE" ]; then
  echo "DATAFILE does not exist; touch $DATAFILE; chmod 777 $DATAFILE"
  exit 1
elif [ ! -r "$DATAFILE" ]; then
  echo "Error: Cant read $DATAFILE. Check permissions."
  exit 1
elif [ ! -w "$DATAFILE" ]; then
  echo "Error: Cant write to $DATAFILE. Check permissions."
  exit 1
fi

## Check that TMP is defined correctly.
if [ ! -d "$TMP" ]; then
  echo "Error. $TMP, defined as TMP does not exist; mkdir -m777 $TMP"
  exit 1
fi

## Build STATSLINE which we then execute.
if [ "$GLCONF" ]; then
  STATSLINE="$STATS -$DURATION -u -x 500 -s $READSECTION -r $GLCONF"
else
  STATSLINE="$STATS -$DURATION -u -x 500 -s $READSECTION"
fi

## Test if bc is working if we have GIVECREDS set.
if [ "$GIVECREDS" -o "$MBLIMIT" ]; then
  TEST=`echo "100 + 200" | bc -l`
  if [ -z "$TEST" ]; then
    echo "Error. GIVECREDS and MBLIMIT requires binary bc, which you do not seem to have in your path."
    exit 1
  fi
  unset TEST
fi

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number=0
    while [ "$number" -le $LOW ]; do
      number=$RANDOM
      if [ "$number" -gt "$HIGH" ]; then
        let "number %= $HIGH"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

proc_cookies() {
  if [ "$WINNER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WINNER%/$WINNER/g" )"
  fi
  if [ "$LOOSER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%LOOSER%/$LOOSER/g" )"
  fi
  if [ "$HEADER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%HEADER%/$HEADER/g" )"
  fi
  if [ "$DURNAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DURNAME%/$DURNAME/g" )"
  fi
  if [ "$upnum" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%POS%/$upnum/g" )"
  fi
  if [ "$numbermb" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%CREDS%/$numbermb/g" )"
  fi
  if [ "$USERMEG" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UPMEG%/$USERMEG/g" )"
  fi
  if [ "$USERFILES" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UPFILES%/$USERFILES/g" )"
  fi
  
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

proc_log() {
  if [ "$LOG" ]; then
    TEXT="$@"
    LOGHEADER=`date +%d" "%m" "%Y" - "%W" -"`
    echo "$LOGHEADER $TEXT" >> $LOG
  fi
}

proc_checkmonthend() {
  MONTHNOW="$( date +%b )"
  case $MONTHNOW in
    Jan) MONTHTOTAL="31" ;;
    Feb) MONTHTOTAL="28" ;;
    Mar) MONTHTOTAL="31" ;;
    Apr) MONTHTOTAL="30" ;;
    May) MONTHTOTAL="31" ;;
    Jun) MONTHTOTAL="30" ;;
    Jul) MONTHTOTAL="31" ;;
    Aug) MONTHTOTAL="31" ;;
    Sep) MONTHTOTAL="30" ;;
    Oct) MONTHTOTAL="31" ;;
    Nov) MONTHTOTAL="30" ;;
    Dec) MONTHTOTAL="31" ;;
    *) MONTHTOTAL="31" ;;
  esac

  DAYOFMONTH="$( date +%d )"

  if [ "$MONTHTOTAL" != "$DAYOFMONTH" ]; then
    if [ "$ONEDAYONLY" != "TRUE" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the month. Since this is a test I'm gonna run anyway."
        proc_removelastaward
        proc_reward
      else
        exit 0
      fi
    else
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the month. Running full anyway since were testing."
      fi
      proc_removelastaward
      if [ "$TEST" = "TRUE" ]; then
        proc_reward
      fi
    fi
  else
    if [ "$TEST" = "TRUE" ]; then
      echo "End of the month. Checking who wins and if anyone got leech last period."
    fi
    proc_removelastaward
    proc_reward
  fi
}

proc_checkweekend() {
  DAYNOW="$( date +%w )"

  case $EUROWEEK in
    [tT][rR][uU][eE]) WEEKENDS="0" ;;
    [fF][aA][lL][sS][eE]) WEEKENDS="6" ;;
    *) echo "Error: EUROWEEK must be TRUE or FALSE."; exit 1
  esac

  if [ "$DAYNOW" != "$WEEKENDS" ]; then
    if [ "$ONEDAYONLY" = "TRUE" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the week (on day $DAYNOW. Week ends on $WEEKENDS). Running anyway since were just testing."
        proc_reward
      fi
      proc_removelastaward
    fi
  else
    if [ "$TEST" = "TRUE" ]; then
      echo "End of the week. Checking who wins and if anyone got leech last period."
    fi
    proc_removelastaward
    proc_reward
  fi
}

proc_checkdayend() {
  if [ "$TEST" = "TRUE" ]; then
    echo "Test run for daily stats started"
  fi
  proc_removelastaward
  proc_reward
}

if [ "$RANDOMUSERS" ]; then
  LOW="0"
  HIGH=$[$RANDOMUSERS+1]
  proc_random
  WINNUM="$number"
  if [ "$TEST" = "TRUE" ]; then
    echo "Randoming top $RANDOMUSERS winners and decides it nr $WINNUM"
  fi
else
  WINNUM="0"
fi

proc_reward() {
  ## Make lame fixes.
  if [ -z "$USEREXCLUDE" ]; then
    USEREXCLUDE="RJ3klj3r30390"
  fi
  if [ -z "$GROUPEXCLUDE" ]; then
    GROUPEXCLUDE="Fkeljfklejfe897"
  fi

  unset NEWRATIO; unset ORGRATIO; unset OUTPUT
  ## Does the winner have leech? If so, try #2 in the list, and so on.
  upnum=0
  upwinnum=0
  unset WINNER
  for RAWDATA in `$STATSLINE | grep "^\[..\]" | tr -s ' ' '^'`; do
    CURUSER=`echo "$RAWDATA" | cut -d '^' -f2`
    unset GROUP; unset EXCLUDED
    upnum=$[$upnum+1]
    if [ -z "$( echo "$CURUSER" | egrep "$USEREXCLUDE" )" ]; then
      if [ "$IGNORELEECH" = "TRUE" ]; then
        if [ -z "$( grep "^RATIO " $USERSDIR/$CURUSER | cut -d ' ' -f2- | grep "0" )" ]; then
          WINNER="$CURUSER"
        else
          if [ "$TEST" = "TRUE" ]; then
            echo "$upnum: $CURUSER won? NO, he has leech."
          fi
        fi
      else
        WINNER="$CURUSER"
      fi

      if [ "$WINNER" ]; then
        for GROUP in `grep "^GROUP " $USERSDIR/$CURUSER | cut -d ' ' -f2`; do
          if [ "$( echo "$GROUP" | egrep "$GROUPEXCLUDE" )" ]; then
            EXCLUDED=TRUE
            if [ "$TEST" = "TRUE" ]; then
              echo "$upnum: $CURUSER won? NO. Hes in an excluded group."
            fi
          fi
          if [ "$EXCLUDED" ]; then
            unset WINNER
            break
          fi
        done
      fi

      if [ "$WINNER" ]; then
        if [ "$JUMPONFLAG" = "TRUE" -a "$GIVEFLAG" != "" ]; then
          if [ "$( grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2 | grep "$GIVEFLAG" )" ]; then
            if [ "$TEST" = "TRUE" ]; then
              echo "$upnum: $CURUSER won? NO. JUMPONFLAG is TRUE and $GIVEFLAG already on him."
            fi
            unset WINNER
          fi
        fi
      fi

    else
      if [ "$TEST" = "TRUE" ]; then
        echo "$upnum: $CURUSER won? NO, he is an excluded user."
      fi
    fi

    if [ "$RANDOMUSERS" ]; then
      if [ "$upnum" = "$WINNUM" ]; then
        if [ -z "$WINNER" ]; then
          WINNUM=$[$WINNUM+1]
          if [ "$TEST" = "TRUE" ]; then
            echo "Would have found the random winner, but hes excluded. Grabbing next one."
          fi
        fi
      else
        if [ "$WINNER" ]; then
          if [ "$TEST" = "TRUE" ]; then
            echo "$upnum: $CURUSER won? NO. number $WINNUM did."
          fi
        fi
        unset WINNER
      fi
    fi
 
    if [ "$WINNER" ]; then

      ## Get how many files and MB were uploaded.
      RAWDATA=`echo "$RAWDATA" | tr '^' ' '`
      for each in $RAWDATA; do
        USERFILES=$USERMEG
        USERMEG=$last
        last=$each
      done
      unset each; unset last
      USERFILES="$( echo "$USERFILES" | tr -d '[:alpha:]' )"

      ## If MBLIMIT is reached, convert MB to GB
      if [ "$MBLIMIT" ]; then
        USERMEG="$( echo "$USERMEG" | tr -d '[:alpha:]' )"
        if [ "$USERMEG" -gt "$MBLIMIT" ]; then
          USERMEG=`echo "$USERMEG / 1024" | bc -l | tr -d ' '`
          USERMEG1=`echo "$USERMEG" | cut -d '.' -f1`
          if [ -z "$USERMEG1" ]; then
            USERMEG1="0"
          fi
          USERMEG2=`echo "$USERMEG" | cut -d '.' -f2 | cut -c1`
          if [ -z "$USERMEG2" ]; then
            USERMEG2="0"
          fi
          USERMEG="$USERMEG1.$USERMEG2"

          unset USERMEG1; unset USERMEG2

          USERMEG="$USERMEG GB"
        else
          USERMEG="$USERMEG MB"
        fi
      fi

      ## Break out of loop. We got a winner.
      break
    fi

  done

  if [ -z "$WINNER" ]; then
    echo "Error. Could not get a winner. Most likely there is no winners yet for this period."
    exit 1
  fi

  if [ "$LEECHFLAG" ]; then
    ORGFLAGS=`grep "^FLAGS " $USERSDIR/$WINNER | cut -d ' ' -f2`
    if [ "$( echo "$ORGFLAGS" | grep "$LEECHFLAG" )" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Was going to give flag $LEECHFLAG to $WINNER but he already have it."
      fi
    else
      NEWLFLAGS="$LEECHFLAG$ORGFLAGS"
      if [ "$TEST" != "TRUE" ]; then
        sed -e "s/^FLAGS .*/FLAGS $NEWLFLAGS/" $USERSDIR/$WINNER > $TMP/tur-goodboy.leech.tmp
        cp -f $TMP/tur-goodboy.leech.tmp $USERSDIR/$WINNER
        rm -f $TMP/tur-goodboy.leech.tmp

        echo "$WINNER^GotLeech^$LEECHFLAG" >> $DATAFILE

        ## Anything else you want to run when it rewards the user?
         /glftpd/bin/mss-customhub.sh dummy $WINNER

        proc_log "$WINNER - $upnum this $DURNAME - Got Flag $LEECHFLAG for leech."
      else
        echo "Would have given $WINNER flag $LEECHFLAG and written $WINNER^GotLeech^$LEECHFLAG to DATAFILE"
      fi
    fi
  fi ## END GIVE LEECH.

  if [ "$GIVEFLAG" ]; then
    ORGFLAGS=`grep "^FLAGS " $USERSDIR/$WINNER | cut -d ' ' -f2`
    if [ -z "$ORGFLAGS" ]; then
      echo "Error. Could not read current FLAGS on $WINNER"
      exit 1
    fi

    if [ "$( echo "$ORGFLAGS" | grep "$GIVEFLAG" )" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$WINNER would have gotten flag $GIVEFLAG, but he already have it."
      fi
    else
      if [ "$TEST" != "TRUE" ]; then
        sed -e "s/^FLAGS .*/FLAGS $GIVEFLAG$ORGFLAGS/" $USERSDIR/$WINNER > $TMP/tur-goodboy.flag.tmp
        cp -f $TMP/tur-goodboy.flag.tmp $USERSDIR/$WINNER
        rm -f $TMP/tur-goodboy.flag.tmp      

        echo "$WINNER^GotFlag^$GIVEFLAG" >> $DATAFILE

        proc_log "$WINNER - $upnum this $DURNAME - Got Flag $GIVEFLAG"
      else
        echo "Would have given $WINNER flag $GIVEFLAG and written $WINNER^GotFlag^$GIVEFLAG to DATAFILE"
      fi
    fi

  fi ## END GIVE FLAG

  if [ "$GIVECREDS" ]; then
    ORGCREDS=`grep "^CREDITS " $USERSDIR/$WINNER | cut -d ' ' -f2`
    if [ -z "$ORGCREDS" ]; then
      echo "Error: Could not read current CREDITS from $WINNER"
      exit 1
    fi

    LOW=`echo "$GIVECREDS" | cut -d ':' -f1`
    HIGH=`echo "$GIVECREDS" | cut -d ':' -f2`
    if [ -z "$LOW" ]; then
      echo "Error: Couldnt get the low number. GIVECREDS should be num:num. Check instructions."
      exit 1
    fi
    if [ -z "$HIGH" ]; then
      echo "Error: Couldnt get the high number. GIVECREDS should be num:num. Check instructions."
      exit 1
    fi
    proc_random
    if [ -z "$number" ]; then
      echo "Error: Could not random numbers between $LOW and $HIGH."
      exit 1
    fi

    numbermb="$number"
    number="`echo "$number * 1024" | bc -l | cut -d '.' -f1`"

    NEWCREDS=`echo "$ORGCREDS + $number" | bc -l | cut -d '.' -f1`
    if [ -z "$NEWCREDS" ]; then
      echo "Error. Could not count new credits for $WINNER"
      echo "Did random on $LOW and $HIGH and got $number"
      echo "Tried to add $number to his current creds: $ORGCREDS"
      exit 1
    else
      if [ "$TEST" != "TRUE" ]; then
        if [ "$NEWCREDS" != "$ORGCREDS" ]; then
          sed -e "s/^CREDITS .*/CREDITS $NEWCREDS/" $USERSDIR/$WINNER > $TMP/tur-goodboy.creds.tmp
          cp -f $TMP/tur-goodboy.creds.tmp $USERSDIR/$WINNER
          rm -f $TMP/tur-goodboy.creds.tmp
        fi

        proc_log "$WINNER - $upnum this $DURNAME - Got creds $numbermb ($ORGCREDS before, $NEWCREDS after)"
      else
        echo "Would have given $WINNER $numbermb MB creds."
      fi
    fi
  fi  ## END GIVE CREDS
    
  ## Build announce line.
  if [ "$WINNERANNOUNCE" -a "$GLLOG" ]; then
    OUTPUT="$WINNERANNOUNCE"
    proc_cookies
  fi

  if [ "$TEST" = "TRUE" ]; then
    echo "Winner this $DURNAME is $upnum : $WINNER"
    if [ "$OUTPUT" ]; then
      echo "Would have announced: $OUTPUT"    
    fi
  else
    if [ "$OUTPUT" ]; then
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
    fi
  fi

  ## Send message to winner.
  if [ "$MSGS" ]; then
    HDATE=`date +%a" "%b" "%d" "%T" "%y`
    HEADER="!HFROM: !CTur-GoodBoy !H(!C$HDATE!H)!0"
    if [ "$LEECHFLAG" ]; then
      if [ "$ONEDAYONLY" = "TRUE" ]; then
        MSG="!HCongratulation on Top-Upload this $DURNAME. You got leech in $LEECHPATH for 24 hours."
      else
        MSG="!HCongratulation on Top-Upload this $DURNAME. You got leech in $LEECHPATH this whole $DURNAME."
      fi
    fi
    if [ "$GIVEFLAG" ]; then
      if [ -z "$MSG" ]; then
        if [ "$ONEDAYONLY" = "TRUE" ]; then
          MSG="!HCongratulation on Top-Upload this $DURNAME. You got flag $GIVEFLAG for 24 hours.!0"
        else
          MSG="!HCongratulation on Top-Upload this $DURNAME. You got flag $GIVEFLAG this whole $DURNAME.!0"
        fi
      else
        MSG="$MSG You also got flag $GIVEFLAG for the same duration."
      fi
    fi
    if [ "$MSG" ]; then
      if [ "$TEST" != "TRUE" ]; then
        MSG="$MSG!0"
        echo "$HEADER" >> $MSGS/$WINNER
        echo "--------------------------------------------------------------------------" >> $MSGS/$WINNER
        echo "$MSG" >> $MSGS/$WINNER
        echo "!HThis message was generated by Tur-GoodBoy $VER by Turranius - 2003!0" >> $MSGS/$WINNER
        echo " " >> $MSGS/$WINNER
      else
        echo " "
        echo "Would have sent the following message to $MSGS/$WINNER:"
        echo "$HEADER"
        echo "--------------------------------------------------------------------------"
        echo "$MSG"
        echo "!HThis message was generated by Tur-GoodBoy $VER by Turranius - 2003!0"
      fi

    fi
  fi
}

## Procedure for removing leech they were given previously."
proc_removelastaward() {
  unset CURUSER; unset ORGRATIO; unset POS; unset OUTPUT

  for rawdata in `cat $DATAFILE`; do
    unset CURUSER; unset ORGRATIO; unset POS; unset GOTFLAG
    if [ "$rawdata" ]; then
      CURUSER=`echo "$rawdata" | cut -d '^' -f1`
      ACTION=`echo "$rawdata" | cut -d '^' -f2`
      GOTFLAG=`echo "$rawdata" | cut -d '^' -f3`

      case $ACTION in
        GotLeech) proc_restoreleech ;;
        GotFlag) proc_restoreflag ;;
        *) echo "Error. Got unknown action: $ACTION"; exit 1 ;;
      esac
      LOOSER="$CURUSER"

      ## Anything else you wanna run when it removes reward?
       /glftpd/bin/mss-customhub.sh dummy $LOOSER

    fi
  done

  if [ -z "$CURUSER" ]; then
    if [ "$TEST" = "TRUE" ]; then
      echo "No previous award found. This is NOT an error."
    fi
  else
    if [ "$REMOVEANNOUNCE" -a "$GLLOG" ]; then
      OUTPUT="$REMOVEANNOUNCE"
      proc_cookies
      if [ "$TEST" = "TRUE" ]; then
        echo "Would have announced: $OUTPUT"
      else
        echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
      fi
    fi
  fi
}

proc_restoreflag() {
  CURFLAGS=`grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2`
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Was going to restore flags on $WINNER but cant read his current FLAGS."
  else
    NEWFLAGS=`echo "$CURFLAGS" | tr -d "$GOTFLAG"`

    if [ "$TEST" != "TRUE" ]; then
      sed -e "s/^FLAGS .*/FLAGS $NEWFLAGS/" $USERSDIR/$CURUSER > $TMP/tur-goodboy.flag.tmp
      cp -f $TMP/tur-goodboy.flag.tmp $USERSDIR/$CURUSER
      rm -f $TMP/tur-goodboy.flag.tmp    

      proc_removefromdata
    else
      echo "Last periods winner: $CURUSER - changing flags from $CURFLAGS to $NEWFLAGS"
      if [ "$LEECHFLAG" ]; then
        echo "NOTE: Since its a test, I never really removed the GIVEFLAG. Hence the weird flagchange."
      fi
    fi
  fi
}

proc_restoreleech() {
  CURFLAGS=`grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2`
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Was going to restore leech flag on $WINNER but cant read his current FLAGS."
  else
    NEWFLAGS=`echo "$CURFLAGS" | tr -d "$GOTFLAG"`

    if [ "$TEST" != "TRUE" ]; then
      sed -e "s/^FLAGS .*/FLAGS $NEWFLAGS/" $USERSDIR/$CURUSER > $TMP/tur-goodboy.leech.tmp
      cp -f $TMP/tur-goodboy.leech.tmp $USERSDIR/$CURUSER
      rm -f $TMP/tur-goodboy.leech.tmp    

      proc_removefromdata
    else
      echo "Last periods winner: $CURUSER - changing leechflags from $CURFLAGS to $NEWFLAGS"
    fi
  fi
}

proc_removefromdata() {
  grep -vi "$rawdata" $DATAFILE > $TMP/tur-goodboydata.tmp
  cp -f $TMP/tur-goodboydata.tmp $DATAFILE
  rm -f $TMP/tur-goodboydata.tmp
}  

A1=`echo "$1" | tr '[:upper:]' '[:lower:]'`
A2=`echo "$2" | tr '[:upper:]' '[:lower:]'`

if [ "$A1" = "test" -o "$2" = "test" ]; then
  TEST="TRUE"
  echo "TEST mode on. Nothing will actually be written or changed."
fi

case $DURATION in
  t) DURNAME="day"; proc_checkdayend ;;
  w) DURNAME="week"; proc_checkweekend ;;
  m) DURNAME="month"; proc_checkmonthend ;;
  *) echo "Error: Duration must be set to t, w or m"; exit 1 ;;
esac
  
