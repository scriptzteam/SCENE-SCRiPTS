#!/bin/bash
VER=0.7
#--[ Intro ]--------------------------------------#
#                                                 #
# Running (for example) a large 0DAY archive and  #
# want to clear out the older versions of stuff   #
# when theres a later version already on site?    #
# This script is for you.                         #
#                                                 #
#-                                               -#
#                                                 #
# Note: This script uses dirloglist to find       #
# the older versions, so make sure your           #
# 'site search' is up to date first. I recomend   #
# tur-dirlogclean to keep it in shape.            #
#                                                 #
#-                                               -#
#                                                 #
# Note: This script does NOT automatically delete #
# anything, so its safe to play around with. What #
# it does is create a deldupes.sh file with a lot #
# of: rm -f "/path/to/release"                    #
# Once the execution is complete, you can go      #
# through this file and then run it, should you   #
# so please.                                      #
#                                                 #
#-                                               -#
#                                                 #
# How much will it save?                          #
#                                                 #
# On a test machine, having *cought*0days*cought* #
# from 2002-2005 (faked of course), taking up     #
# 1.2 TB, the saved amount of space, had the      #
# deldupes.sh file been executed, would have been #
# an astounding 612 GB.                           #
# Yes, thats half your archive only consisting of #
# older versions. Amazing.                        #
#                                                 #
#--[ Installation ]-------------------------------#
#                                                 #
# dirloglist = Full path to your dirloglist       #
#              binary. MAKE SURE it works by      #
#              running it. It should output every #
#              release on your site.              #
#                                                 #
#              If it spits out weird chars, you   #
#              probably upgraded to glftpd 2+     #
#              without replacing your binaries.   #
#                                                 #
# glroot=    Path to the root of glftpd. Usually  #
#            just /glftpd.                        #
#                                                 #
# final_file=  When running, it will NOT          #
#              automatically remove any releases. #
#              Instead, it will create this file  #
#              that you can chmod to 700 and run. #
#              However, its IMPORTANT that you    #
#              look over this file before running #
#              it. Any mistake can del your whole #
#              site.                              #
#                                                 #
# sections=  Specify each section on your site    #
#            that you want to search for releases #
#            in.                                  #
#            Add :DEEP to the end to dive one     #
#            dir into that (for dated dirs).      #
#                                                 #
#            Add :2xDEEP to the end to dive two   #
#            dirs down.                           #
#                                                 #
#            Finally, :3xDEEP is also accepted to #
#            jump 3 levels down the dir structure.#
#                                                 #
#            Example: Say you have the following  #
#            path:                                #
#     $glroot/site/Archive/0DAYS/0DAYS1/2004/0102 #
#            Now, instead of adding 0101 / 0102,  #
#            etc, you can do:                     #
#     $glroot/site/Archive/0DAYS/0DAYS1/2004:DEEP #
#            Or:                                  #
#     $glroot/site/Archive/0DAYS/0DAYS1:2xDEEP    #
#            Or:                                  #
#     $glroot/site/Archive/0DAYS:3xDEEP           #
#                                                 #
#            If you have a space in your sections #
#            then use [:space:]                   #
#                                                 #
# look_for=  If you want to search for specific   #
#            releases only, you can set this one. #
#            Its a standard egrep -i line.        #
#                                                 #
#            Ex: "\-LND$|^Understand[\.|-|_]"     #
#            That would look for dupes from group #
#            LND and anything starting with       #
#            Understand. / Understand- or         #
#            Understand_                          #
#                                                 #
#            Setting it to "" will enable full    #
#            dupefind mode. Its also the default. #
#                                                 #
#            It is NoT case sensetive.            #
#                                                 #
# path_must_include=                              #
#            When it finds a release and looks    #
#            for similar ones in the dirlog, if   #
#            you have both 0DAY and APPS sections #
#            then it might find an older rel in   #
#            the other section.                   #
#            So, if you only want to find 0DAY    #
#            dupes and not APPS, set this to 0DAY #
#            and the path to the release must     #
#            include "0DAY".                      #
#                                                 #
#            You can specify more then one word   #
#            here. For example "DOCS|0DAY"        #
#                                                 #
#            Set to "" to disable (default).      #
#                                                 #
#            It IS case sensitive.                #
#                                                 #
# no_match_versions= This is a tricky one.        #
#                                                 #
#            Any word specified here must exist   #
#            in both the version it found and the #
#            ones it finds in dirlog for them to  #
#            be considered "same version type".   #
#                                                 #
#            For example. You have the word       #
#            "Professional" in here.              #
#            If it finds a release called         #
#            Some.cool.thing.Professinal.v1.1-bla #
#            and in the dupelog we find           #
#            Some.cool.thing.v1.0-bla then it     #
#            will skip this version check and     #
#            Some.cool.thing.v1.0-bla will not be #
#            deleted.                             #
#                                                 #
#            This also works the other way around.#
#                                                 #
#            You can also specify more then one   #
#            word, seperated with a | to mean OR. #
#            So: Keygen\.Only|Keymaker\.Only      #
#            Both releases need to include either #
#            Keygen.only OR keymaker.only to be   #
#            considered a match.                  #
#                                                 #
#            If you allow languages other then    #
#            English, its best to add those       #
#            languages here to to make sure it    
#            does not delete a Swedish rel just   #
#            because there is a newer Polish one, #
#            for example.                         #
#                                                 #
#            It is NoT case sensitive.            #
#                                                 #
# exclude=   Any dirs you do not want it to check.#
#            As you can see, ebook is in there.   #
#            Thats because ebooks rarely have a   #
#            version number, so pointless to try  #
#            to find older versions for them.     #
#                                                 #
#            Note, this is a simple egrep -vi     #
#            line, so if you specify, for example #
#            PRE, it will skip any dir containing #
#            that word. To specify only the dir   #
#            use ^PRE$ and it will only match on  #
#            the dir thats actually named PRE.    #
#                                                 #
#            If you have something called [OST]   #
#            that you want to exclude, specify    #
#            \[OST\] or you'll exclude anything   #
#            contains O, o, S, s, T or t          #
#                                                 #
# dirlog_exclude=                                 #
#            When looking for dupes in the dirlog #
#            it will exclude anything specied in  #
#            this setting.                        #
#            So, the default:                     #
#            "\/CD[1-9]$|\/DVD[1-9]$|\/DISK[1-9]$"#
#            is good for apps dirs, where we dont #
#            want it to find /CD1-9, /DVD1-9 or   #
#            /DISK1-9                             #
#                                                 #
#            It is NoT case sensitive.            #
#                                                 #
# count_mb=  TRUE/FALSE. If this is set to true,  #
#            it will check the space of every rel #
#            that it thinks it can delete. It     #
#            will give you periodic output when   #
#            running in debug mode on how much is #
#            saved so far. It will also, at the   #
#            end of the execution, show you how   #
#            much would be saved in total, if you #
#            run the created deldupes.sh file.    #
#                                                 #
#--[ Running it ]---------------------------------#
#                                                 #
# As we said, it wont actually delete anything by #
# itself, so its quite safe to play with.         #
# Run it as ./tur-dupefind.sh <debug>             #
#                                                 #
# While its running, you can open a second shell  #
# and run a tail -f /tmp/deldupes.sh              #
# or where ever you specified final_file to.      #
# Pretty fun to look at in realtime.              #
#                                                 #
#-[ More indepth info ]---------------------------#
#                                                 #
# How does it work?                               #
#                                                 #
# It goes into each dir defined in sections.      #
# In here, it lists each release. For each rel it #
# finds, it will check the final_file to make     #
# sure it is not already marked for deletion.     #
#                                                 #
# Then it will try to find out what the relname   #
# is. It does this by taking everything infront   #
# of "[\.|\_][Vv][0-9]" - For example for:        #
# Some.Release.v1.1-somegroup the releasename is: #
# Some Release                                    #
#                                                 #
# It now grabs the version from it. It finds that #
# in a similar way. The version will be 1.1       #
#                                                 #
# NOTE: If the release lacks a v/V infront of the #
# version, it will not be detected. 99% of all    #
# releases follows the v standard though.         #
# "v.0.9" works and so does "v0.9"                #
#                                                 #
# Now, it runs dirloglist and greps for           #
# "Some.Release".                                 #
# (In grep, a . is the same as "anything", so it  #
#  will find _ as well, etc.)                     #
#                                                 #
# For every line returned, it will check the      #
# no_match_versions to make sure the are a match  #
# in version type (proffessional/home etc etc).   #
#                                                 #
# If its a match, it will check the version of    #
# the release from the dirlog.                    #
# Lets say it found Some.Release.v1.0-somegroup.  #
#                                                 #
# It checks the versions. If 1.0 is lower then    #
# 1.1, the release is older and will be added as  #
# rm -rf "/full/path/Some.Release.v1.0-somegroup" #
# to the final_file.                              #
#                                                 #
# If count_MB is set to TRUE, it will run "du" on #
# the older release and add it to amount saved.   #
#                                                 #
#-[ Contact ]-------------------------------------#
#                                                 #
# WEB: http://www.grandis.nu                      #  
#                                                 #
#-[ Changelog ]-----------------------------------#
#                                                 #
# 0.7   : * First public test version.            #
#                                                 #
#-[ Settings ]------------------------------------#

dirloglist="/glftpd/bin/dirloglist"

glroot="/glftpd"

final_file="/tmp/deldupes.sh"

sections="
$glroot/site/0DAYS:DEEP
$glroot/site/Archive/0DAYS:2xDEEP
"

look_for=""

path_must_include="0DAYS"

no_match_versions="
Professional
Home
Enterprise
Corporate
Platinum
Crack
Linux
Keygen[_|\.]Only|Keymaker[_|\.]Only
Incl[_|\.]Keygen|Incl[_|\.]Keymaker
"

exclude="^GROUPS$|^!Today$|^!Yesterday$|^lost\+found$|^All$|ebook"

dirlog_exclude="\/CD[1-9]$|\/DVD[1-9]$|\/DISK[1-9]$|\/Allowed$"

count_mb="TRUE"


#-[ Script Start ]--------------------------------#

if [ "$1" = "debug" ]; then
  echo "Verifying existance of required bins.."
  DEBUG="TRUE"
fi

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$@"
  fi
}

if [ ! -x "$dirloglist" ]; then
  echo "Error. Cant execute $dirloglist. Check existance and perms."
  exit 1
fi

if [ -e "/tmp/tur-dupefind.db" ]; then
  rm -f "/tmp/tur-dupefind.db"
fi
touch "/tmp/tur-dupefind.db"
if [ -e "/tmp/tur-dupefind.tmp" ]; then
  rm -f "/tmp/tur-dupefind.tmp"
fi

if [ "$final_file" ]; then
  echo "#!/bin/bash" > "$final_file"
  echo "" >> $final_file
fi

if [ -z "$look_for" ]; then
  look_for="."
fi
if [ -z "$path_must_include" ]; then
  path_must_include="."
fi
if [ -z "$exclude" ]; then
  exclude="r43jrkjl4"
fi
if [ -z "$dirlog_exclude" ]; then
  dirlog_exclude="fkjfklejljfe"
fi

proc_debug "Exclude          : \"${exclude}\""
proc_debug "Dirlog_exclude   : \"${dirlog_exclude}\""
proc_debug "Look_for         : \"${look_for}\""
proc_debug "Path_must_include: \"${path_must_include}\""
proc_debug ""

mb_saved="0"

proc_findit() {
  for release in `ls -1 "$SCAN_LOCATION" | egrep -i "$look_for" | egrep -iv ${exclude}`; do
    echo ""
    unset release_program
    unset release_in_dirlog
    proc_debug "Processing $release"

    if [ "`grep "/${release}" $final_file`" ]; then
      proc_debug "Skipping $release - Already exists in $final_file"
      unset full_path
    else
      release_split="`echo "$release" | tr -s '.' ' ' | tr -s '_' ' ' | tr -s '-' ' '`"
      # proc_debug "Splitting it gives $release_split"
      for release_part in $release_split; do

        if [ "`echo "$release_part" | grep -i "^v[0-9]"`" ]; then
          break
        else
          if [ "$release_program" ]; then
            release_program="$release_program $release_part"
          else
            release_program="$release_part"
          fi
        fi

      done
      if [ -z "$release_program" ]; then
        proc_debug "Failed to get release from $release"
      else
        proc_debug "I think its $release_program"

        release_version="$dirlog_version"; unset dirlog_version; unset release_in_dirlog

        if [ "$dirlog_version" != "9999999999999" ]; then

          release_program_dot="`echo "$release_program" | tr -s ' ' '.'`"
          unset announced_rel
          echo "$SCAN_LOCATION/$release" > "/tmp/tur-dupefind.tmp"
          unset full_path; unset added_one_dir
          for full_path in `$dirloglist | cut -d ':' -f3 | cut -c2- | egrep "$path_must_include" | grep -i "\/$release_program_dot[-|\.|_]v[\.|0-9]" | egrep -iv "$dirlog_exclude" | grep -v "\/$release$"`; do

            release_in_dirlog="`basename "$full_path"`"
            unset SKIP

            if [ ! -d "$glroot$full_path" ]; then
              proc_debug "Skipping. No longer exists: $glroot$full_path"
              SKIP="TRUE"
            fi

            if [ "$no_match_versions" ] && [ "$SKIP" != "TRUE" ]; then
              for no_match_word in $no_match_versions; do
                if [ "`echo "$release" | egrep -i "$no_match_word"`" ]; then
                  if [ -z "`echo "$release_in_dirlog" | egrep -i "$no_match_word"`" ]; then
                    #proc_debug "$release has $no_match_word in it, but $release_in_dirlog does not."
                    SKIP="TRUE"
                  fi
                fi
            
                if [ -z "`echo "$release" | egrep -i "$no_match_word"`" ]; then
                  if [ "`echo "$release_in_dirlog" | egrep -i "$no_match_word"`" ]; then
                    #proc_debug "$release does NOT have $no_match_word in it, but $release_in_dirlog DOES."
                    SKIP="TRUE"
                  fi
                fi
  
                if [ "$SKIP" = "TRUE" ]; then
                  echo "Different versions ($no_match_word): $release_in_dirlog"
                  unset release_in_dirlog
                  if [ -z "$added_one_dir" ]; then
                    unset full_path
                  fi
                  break
                fi
              done
            fi

            if [ "$release_in_dirlog" ]; then
              echo "$glroot$full_path" >> "/tmp/tur-dupefind.tmp"
              added_one_dir="true"
            fi
          done
        fi
      fi
    fi

    if [ -z "$full_path" ]; then
      proc_debug "No other versions found."
    else
      proc_get_oldest_rel
    fi

    proc_debug ""
  done
}

proc_get_oldest_rel() {
  unset newest_version; unset newest_release
  unset skipped; unset gotone
  for release_in_dirlog in `cat /tmp/tur-dupefind.tmp`; do

    proc_get_ver

    if [ "`grep "${release_in_dirlog}" $final_file`" ]; then
      proc_debug "Skipping $release_in_dirlog - Already exists in $final_file"
      dirlog_version="9999999999999"
    fi

    if [ "$dirlog_version" != "9999999999999" ]; then
      if [ -z "$newest_version" ]; then
        newest_version="$dirlog_version"
        newest_release="$release_in_dirlog"
        release_version="$dirlog_version"
      else

        proc_is_version_older
        if [ "$RELEASE_OLDER" = "TRUE" ]; then
          newest_version="$dirlog_version"
          newest_release="$release_in_dirlog"
          release_version="$dirlog_version"
          proc_debug "Newer: $dirlog_version - $release_in_dirlog"
          gotone="true"
        elif [ "$RELEASE_OLDER" = "SAME" ]; then
          proc_debug "Skipping $release_in_dirlog - Same version."
          if [ -z "$skipped" ]; then
            skipped="^${release_in_dirlog}$"
          else
            skipped="$skipped|^${release_in_dirlog}$"
          fi
        else
          proc_debug "Older: $dirlog_version - $release_in_dirlog"
          gotone="true"
        fi
      fi
    else
      if [ -z "$skipped" ]; then
        skipped="^${release_in_dirlog}$"
      else
        skipped="$skipped|^${release_in_dirlog}$"
      fi
    fi
  done
  if [ -z "$skipped" ]; then
    skipped="r3r3iojr3j"
  fi
  
  if [ "$gotone" ]; then
    echo "" >> "$final_file"
    echo "# Keep: $newest_release" >> "$final_file"

    for rawdata in `cat /tmp/tur-dupefind.tmp | grep -v "^${newest_release}$" | egrep -v "$skipped"`; do
      echo "rm -rf \"$rawdata\"" >> "$final_file"

      if [ "$count_mb" = "TRUE" ]; then
        size_on_del="`du -s -m "$rawdata" | cut -f1`"
        if [ -z "$size_on_del" ]; then
          size_on_del="0"
        fi
        mb_saved=$[$mb_saved+$size_on_del]
      fi
    done

    proc_debug "Newest version seems to be: $newest_version - $newest_release"
    proc_debug "Saved so far: ${mb_saved}MB"
    proc_debug ""
  fi
}


proc_is_version_older() {
  unset RELEASE_OLDER

  if [ -z "$release_version" ]; then
    proc_debug "proc_is_version_older did not get a release_version"
    RELEASE_OLDER="TRUE"    
  else
    if [ -z "`echo "$release_version" | grep "\."`" ]; then
      release_version="${release_version}."
    fi
  fi

  if [ -z "$dirlog_version" ]; then
    proc_debug "proc_is_version_older did not get a dirlog_version"
    RELEASE_OLDER="TRUE"
  else
    if [ -z "`echo "$dirlog_version" | grep "\."`" ]; then
      dirlog_version="${dirlog_version}."
    fi
  fi
  unset same

  if [ -z "$RELEASE_OLDER" ]; then
    release_first="`echo "$release_version" | cut -d '.' -f1`"
    dirlog_first="`echo "$dirlog_version" | cut -d '.' -f1`"
 
    if [ "$release_first" ] && [ "$dirlog_first" ]; then
#proc_debug "Checking if $release_first is greated then $dirlog_first"
      if [ "$release_first" -gt "$dirlog_first" ]; then
        RELEASE_OLDER="FALSE"; unset same
      elif [ "$release_first" -lt "$dirlog_first" ]; then
        RELEASE_OLDER="TRUE"; unset same
      elif [ "$release_first" = "$dirlog_first" ]; then
        same=true
      fi

      if [ "$same" = "true" ]; then
        release_second="`echo "$release_version" | cut -d '.' -f2`"
        dirlog_second="`echo "$dirlog_version" | cut -d '.' -f2`"         
#echo "$release_version = $release_second -- $dirlog_version = $dirlog_second"
        if [ "$release_second" ] && [ "$dirlog_second" ]; then
#proc_debug "Checking if $release_second is greated then $dirlog_second"
          if [ "$release_second" -gt "$dirlog_second" ]; then
            RELEASE_OLDER="FALSE"; unset same
          elif [ "$release_second" -lt "$dirlog_second" ]; then
            RELEASE_OLDER="TRUE"; unset same
          elif [ "$release_second" = "$dirlog_second" ]; then
            same=true
          fi

          if [ "$same" = "true" ]; then
            release_third="`echo "$release_version" | cut -d '.' -f3`"
            dirlog_third="`echo "$dirlog_version" | cut -d '.' -f3`"         
            if [ "$release_third" ] && [ "$dirlog_third" ]; then
#proc_debug "Checking if $release_third is greated then $dirlog_third"
              if [ "$release_third" -gt "$dirlog_third" ]; then
                RELEASE_OLDER="FALSE"; unset same
              elif [ "$release_third" -lt "$dirlog_third" ]; then
                RELEASE_OLDER="TRUE"; unset same
              elif [ "$release_third" = "$dirlog_third" ]; then
                same=true
              fi

              if [ "$same" = "true" ]; then
                release_fourth="`echo "$release_version" | cut -d '.' -f4`"
                dirlog_fourth="`echo "$dirlog_version" | cut -d '.' -f4`"         
                if [ "$release_fourth" ] && [ "$dirlog_fourth" ]; then
#proc_debug "Checking if $release_fourth is greated then $dirlog_fourth"
                  if [ "$release_fourth" -gt "$dirlog_fourth" ]; then
                    RELEASE_OLDER="FALSE"; unset same
                  elif [ "$release_fourth" -lt "$dirlog_fourth" ]; then
                    RELEASE_OLDER="TRUE"; unset same
                  elif [ "$release_fourth" = "$dirlog_fourth" ]; then
                    same=true
                  fi

                else
                  if [ -z "$release_fourth" ] && [ "$dirlog_fourth" ]; then
                    RELEASE_OLDER="TRUE"; unset same
                  fi
                  if [ "$release_fourth" ] && [ -z "$dirlog_fourth" ]; then                  
                    RELEASE_OLDER="FALSE"; unset same
                  fi
                fi                    
              fi

            else
              if [ -z "$release_third" ] && [ "$dirlog_third" ]; then
                RELEASE_OLDER="TRUE"; unset same
              fi
              if [ "$release_third" ] && [ -z "$dirlog_third" ]; then                  
                RELEASE_OLDER="FALSE"; unset same
              fi
            fi
          fi
        else
          if [ -z "$release_second" ] && [ "$dirlog_second" ]; then
            RELEASE_OLDER="TRUE"; unset same
          fi
          if [ "$release_second" ] && [ -z "$dirlog_second" ]; then                  
            RELEASE_OLDER="FALSE"; unset same
          fi
        fi
      fi
    else
      if [ -z "$release_first" ] && [ "$dirlog_first" ]; then
        RELEASE_OLDER="TRUE"; unset same
      fi
      if [ "$release_first" ] && [ -z "$dirlog_first" ]; then                  
        RELEASE_OLDER="FALSE"; unset same
      fi
    fi
  fi
  if [ -z "$RELEASE_OLDER" ]; then
    if [ "$same" = "true" ]; then
      RELEASE_OLDER="SAME"
    else
      RELEASE_OLDER="TRUE"
    fi
  fi
}

proc_get_ver() {
  if [ -z "$release_in_dirlog" ]; then
    proc_debug "proc_get_ver did not get a release_in_dirlog to work with.. skipping."
    dirlog_version="9999999999999"
  else
    release_in_dirlog_nodot="`echo "$release_in_dirlog" | tr -s '.' ' ' | tr -s '_' ' ' | tr -s '-' ' '`"
    unset dirlog_version
    unset got_version
    for each in $release_in_dirlog_nodot; do
      if [ "$got_version" ]; then
        if [ -z "`echo "$each" | tr -d '[:digit:]'`" ]; then
          if [ "$dirlog_version" ]; then
            dirlog_version="$dirlog_version $each"
          else
            dirlog_version="$each"
          fi
        else
          test="`echo "$each" | tr -d '[:digit:]'`"
          if [ "`echo "$test" | grep -i "^[a-z]$"`" ]; then
            each="`echo "$each" | tr -d '[:alpha:]'`"
            if [ "$dirlog_version" ]; then
              dirlog_version="$dirlog_version $each"
            else
              dirlog_version="$each"
            fi
          else
            break
          fi
          unset test
        fi
      fi

      if [ "`echo "$each" | egrep -i "^v[0-9]|^v$"`" ]; then
        dirlog_version="`echo "$each" | tr -d '[:alpha:]'`"
        got_version="true"
      fi
    done

    if [ -z "$dirlog_version" ]; then
      proc_debug "Failed to get version for $release_in_dirlog"
      dirlog_version="9999999999999"
    else
      dirlog_version="`echo "$dirlog_version" | tr ' ' '.'`"
    fi
  fi
}

for section in $sections; do
  section="`echo "$section" | sed -e 's/\[\:space\:\]/ /g'`"
  dated="$( echo $section | cut -d ':' -f2 )"

  if [ "$dated" != "DEEP" ] && [ "$dated" != "2xDEEP" ] && [ "$dated" != "3xDEEP" ]; then
    proc_debug "Entering \"$section\""

    SCAN_LOCATION="$section"    
    proc_findit
  else
    section="$( echo $section | cut -d ':' -f1 )"
    if [ ! -d "$section" ]; then
      echo "Error. \"$section\" does not exist. Skipping."
    else
      cd "$section"
      LIST="$( ls -1 | egrep -vi "$exclude" )"
      for folder in $LIST; do

        if [ "$dated" = "2xDEEP" ]; then
          LIST2="$( ls -1 $folder | egrep -vi "$exclude" )"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
              echo "Not a dir: $section/$folder/$folder2 - Skipping."
            else
              proc_debug "Entering (2xDEEP) \"$section/$folder/$folder2\""
              SCAN_LOCATION="$section/$folder/$folder2"
              proc_findit
            fi
          done

        elif [ "$dated" = "3xDEEP" ]; then
          LIST2="$( ls -1 $folder | egrep -vi "$exclude" )"
          for folder2 in $LIST2; do
            if [ ! -d "$section/$folder/$folder2" ]; then
              echo "Not a dir: $section/$folder/$folder2 - Skipping."
            else
              LIST3="$( ls -1 $folder/$folder2 | egrep -vi "$exclude" )"
              for folder3 in $LIST3; do
                if [ ! -d "$section/$folder/$folder2/$folder3" ]; then
                   echo "Not a dir: $section/$folder/$folder2/$folder3 - Skipping."
                else
                  proc_debug "Entering (3xDEEP) \"$section/$folder/$folder2/$folder3\""
                  SCAN_LOCATION="$section/$folder/$folder2/$folder3"
                  proc_findit
                fi
              done
            fi
          done

        else
          if [ ! -d "$section/$folder" ]; then
            echo "Not a dir: $section/$folder - Skipping."
          else
            proc_debug "Entering (DEEP) \"$section/$folder\""
            SCAN_LOCATION="$section/$folder"
            proc_findit
          fi
        fi

      done
    fi
  fi
done

echo ""
echo "All done. Removal file created as $final_file"
echo "Make SURE you go over this file manually before"
echo "finally running a: chmod 755 $final_file; $final_file"
echo "Total saved by running this file: ${mb_saved}MB"
echo ""
exit 0
