#!/bin/bash
VER=1.0
#---------------------------------------------------------------#
#                                                               #
# Tur-Requests. My own little version of it..                   #
# Supposed to replace 'site request','site reqfilled' on site   #
# and add !request, !reqfilled & !requests functions to irc.    #
# Bot parts ment for Dark0n3's zipscript-c.                     #
#                                                               #
# Will create a .requests file (definable) and optionally the   #
# directories (REQ-Release and FILLED-Release).                 #
#                                                               #
#-[ Installation ]----------------------------------------------#
#                                                               #
# Copy tur-request.sh to /glftpd/bin. Make it executable.       #
# Copy tur-request.tcl to your bots config folder and load it.  #
# Edit tur-request.tcl and change any triggers if you dont like #
# the default settings. Take note of my mad tcl skillz =)       #
#                                                               #
# Edit tur-request.sh and change the settings as follows:       #
#                                                               #
# glroot     = The root of glftpd. Since this script works from #
#              both inside glftpd and shell, we need this here. #
#                                                               #
# requests   = Where to create the requested folders. This is   #
#              your request folder on site, seen chrooted.      #
#              ( meaning, dont add /glftpd ).                   #
#                                                               #
# gllog      = Path to glftpd.log for bot announcing, chrooted. #
#                                                               #
# reqfile    = File to store requests in. You can put this in   #
#              your request dir if you like. If you want it     #
#              to be displayed every time someone enters the    #
#              request directory, add it to 'show_diz' in       #
#              glftpd.conf                                      #
#              Make sure this file exists and has perms so      #
#              anyone can write to it.                          #
#                                                               #
# tmp        = Temporary folder to store some litte stuff.      #
#              Seen chrooted ( /glftpd/tmp ).                   #
#                                                               #
# allowspace = TRUE/FALSE. Allow spaces in requests? Note that  #
#              from irc, requests have to be encapsulated in "" #
#              if you want to use spaces (it will say so too).  #
#                                                               #
# requesthead= What to add to the start of requested folders.   #
#              If someone requests ost.release, it will make    #
#              the dir 'REQ-ost.release' in the requests dir.   #
#                                                               #
#              IMPORTANT: If you do not want Tur-Request to     #
#              create the directories and instead just use the  #
#              reqfile, set this one "" or put a # infront of   #
#              the line. No dirs will be created or renamed     #
#              when filled then.                                # 
#                                                               #
# filledhead = Same as above, but when someone fills it.        #
#              This has no use if requesthead is empty since    #
#              there wont be any folder to rename.              #
#                                                               #
# sitename   = Name of your site.                               #
#                                                               #
# Below all this are the basic outputs. More info there.        #
#                                                               #
#-[ glftpd.conf settings ]--------------------------------------#
#                                                               #
# Add this to glftpd.conf to replace the request and reqfilled  #
# commands.                                                     #
#--                                                           --#
# site_cmd request       EXEC    /bin/tur-request.sh request
# site_cmd reqfilled     EXEC    /bin/tur-request.sh reqfilled
# site_cmd requests      EXEC    /bin/tur-request.sh status
#
# custom-request         1
# custom-requests        *
# custom-reqfilled       *
#--                                                           --#
#                                                               #
# Heres something for silicon^: If you add the variable '-hide' #
# after either request/reqfilled or status, it will not         #
# announce to irc. This works from irc too and it will not say  #
# stuff in the channel it was executed in, instead of the main  #
# one.                So if you want a command in glftpd, where #
# you can reqfill without it announcing in your chan, either do:#
# 'site reqfilled -hide <release>' or set up extra commands.    #
# Something like:                                               #
#--                                                           --#
# site_cmd delrequest    EXEC  /bin/tur-request.sh reqfilled -hide 
# custom-delrequest      1
#--                                                           --#
#                                                               #
#-[ zipscript-c settings ]--------------------------------------#
#                                                               #
# To make this mofo announce, add the following to dZSbot.tcl:  #
#                                                               #
# To: 'set msgtypes(DEFAULT)', add REQUEST REQFILLED REQSTATUS  #
#                                                               #
# Add the following in the appropriate places:                  #
#--                                                           --#
# set chanlist(REQUEST)   "#YourChan"
# set chanlist(REQFILLED) "#YourChan"
# set chanlist(REQSTATUS) "#YourChan"
#
# set disable(REQUEST)   0
# set disable(REQFILLED) 0
# set disable(REQSTATUS) 0
#
# set variables(REQUEST)   "%request %user"
# set variables(REQFILLED) "%request %user"
# set variables(REQSTATUS) "%msg"
#
# set announce(REQUEST)     "%bold-\[Request\]-%bold %user adds a request for %bold%request%bold. Please fill ASAP."
# set announce(REQFILLED)   "%bold-\[Request\]-%bold %user reqfilled %bold%request%bold. Good work."
# set announce(REQSTATUS)   "%bold-\[Request\]-%bold %msg"      
#--                                                           --#
# Change the announce text anyway you like.                     #
#                                                               #
#-[ Other ]-----------------------------------------------------#
#                                                               #
# If you run 'tur-request.sh status auto' it will check if      #
# there are any requests and if so, announce it to the channel. #
# If there are no requests, it will just quit. This is if you   #
# want a reminder in irc on all the requests from time to time. #
# You can just crontab it to do 'status auto' whenever you like.#
# If you leave out the 'auto', it will announce even if there   #
# are no releases requests.                                     #
#                                                               #
# When filling a request, you can enter either the release      #
# both with the requestheader and well as without. It will      #
# check both.                                                   #
#                                                               #
# When running it from shell, it will think its running in irc. #
# Thats normal.                                                 #
#                                                               #
# If you want to request or reqfill something from shell, the   #
# syntax is:                                                    #
# tur-request.sh request/reqfilled user request                 #
# ie, tur-request.sh request Turranius More.Money               #
# User does not have to be an existing user. Anything will do.  #
#                                                               #
# !request is by default locked to ops only. !reqfilled and     #
# !requests are not. If you enable !request for the public, you #
# dont need !requests really as !request shows the list if you  #
# give it no arguments. ( This is done in tur-request.tcl ).    #
#                                                               #
# I was going to make a complete script for zipscript-c that    #
# would automatically fill the request when it was completed    #
# but it wouldnt work very well. First of all, zipscript-c does #
# not return the full path, only filename. I can get around it  #
# by checking xferlog for where that file is. But what if a req #
# has 2 CD's ? When first was filled, it would reqfill the dir. #
# So, wont add that right now. You're free to make a working    #
# complete script as an addon for this and I'l gladly add it.   #
#                                                               #
# Using numbers instead of names is prefered. Will probably add #
# that feature in the future (site reqfilled 1).                #
#                                                               #
#-[ Contact ]---------------------------------------------------#
#                                                               #
# Turranius on efnet/linknet. Usually in #glftpd.               #
# http://www.grandis.nu/glftpd and http://grandis.mine.nu       #
#                                                               #
#-[ Settings ]--------------------------------------------------#

glroot=/glftpd
requests=/site/REQUESTS
gllog=/ftp-data/logs/glftpd.log
reqfile=/site/REQUESTS/.requests
tmp=/tmp
allowspace=TRUE

requesthead="REQ-"
filledhead="FILLED-"
sitename=xXx

#-[ Custom Text ]-----------------------------------------------#
#                                                               #
# Custom text explanation with 'cookies'. Note that not all     #
# cookies are available in every output.                        #
# You do not have to change these if you dont want to.          #
#                                                               #
# Cookies are:                                                  #
# %WHO%         = Who made the request. Either nick on irc or   #
#                 the username on site (depending on how).      #
# %WHAT%        = What was requested/reqfilled.                 #
# %NAME%        = Will either be 'request' or 'fill'            #
# %REQUESTHEAD% = Speaks for itself. Whatever you set it to     #
#                 above.                                        #
# %FILLEDHEAD%  = See above.                                    #
# %MODE%        = Will either be 'irc' or 'gl' depending on how #
#                 script was executed.                          #
# %HOWTOFILL%   = How to fill a request. Will either be         #
#                 'site reqfilled <name>' or '!reqfilled <name>'#
# %ADDDATE%     = Date right now. Like '10:25:47 PM 04-18-2003' #
#                 You can change this with 'adddate' below, but #
#                 do not use any output with / in them.         #
#                                                               #
# %SITENAME%    = What you defined in sitename=                 #
#                                                               #
# %BOLD%        = Start and stop bold text. This will only show #
#                 in irc output, not in glftpd.                 #
# %ULINE%       = Start and stop underline text. Same as %BOLD% #
#---------------------------------------------------------------#

# What to say if you try to request something thats already requested.                   
ALREADYREQUESTED="%BOLD%%WHAT%%BOLD% has already been requested."

# What to say when someone tries to request something already filled?
ALREADYFILLED="%BOLD%%WHAT%%BOLD% has already been filled, thanks."

# If no argument is given to request or reqfilled.
NOARGUMENT="Please specify %ULINE%something%ULINE% to %NAME%"

# What to add to the requestfile for each request.
REQINFILE="%WHAT% - by %WHO% (%MODE%) at %ADDDATE%"

# What to say incase of valid request from glftpd?
# If you do it from irc, the 'set announce' handles that.
GLOK="Ok, %WHAT% added to requests."

# If you try to fill something that is not requested.
NOTREQUESTED="%BOLD%%WHAT%%BOLD% is %ULINE%not%ULINE% requested."

# If a request is in the file but no directory exists..
FORCEFILL="Forcing automatic fill of %BOLD%%WHAT%%BOLD% as the directory is not there."

# If there are no requests when someone checks them.
NOREQUESTS="Looks empty..."

# How to fill a request. Added at the end of various places.
TOFILL="If you fill a request, please do %BOLD%%HOWTOFILL%%BOLD%"

# What to say at the top of request list.
STATUSHEAD="Current Requests on %BOLD%%SITENAME%%BOLD%:"

# If allowspace is FALSE, what to say?
NOSPACES="Spaces are not allowed!"

# If trying to use spaces in irc without "" 
# Note the format 'text "blabla" text'
SPACEHELP='When using spaces, please use "release name" from irc.'



#-[ Script Start ]----------------------------------------------#
#                                                               #
# No changes below here unless you want to change some text.    #
# Might want to look at adddate right below here if needed...   #
#                                                               #
#---------------------------------------------------------------#

adddate="$( date +%r" "%x | tr -s '/' '-' )"

## Check if we're in glftpd or shell (irc)..
if [ "$FLAGS" -a "$GROUP" ]; then
  mode=gl
else
  mode=irc
  requests=$glroot$requests
  reqfile=$glroot$reqfile

  if [ "$gllog" ]; then
    gllog=$glroot$gllog
  fi
fi

proc_mainerror() {
  echo "Got neither request, reqfilled nor status... quitting."
  exit 1
}

if [ -z "$1" ]; then
  proc_mainerror
fi

proc_cookies() {
  if [ "$WHO" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WHO%/$WHO/g" )"
  fi
  if [ "$WHAT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WHAT%/$WHAT/g" )"
  fi
  if [ "$mode" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MODE%/$mode/g" )"
  fi
  if [ "$name" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%NAME%/$name/g" )"
  fi
  if [ "$adddate" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ADDDATE%/$adddate/g" )"
  fi
  if [ "$requesthead" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%REQUESTHEAD%/"$requesthead"/g" )"
  fi
  if [ "$filledhead" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%FILLEDHEAD%/$filledhead/g" )"
  fi
  if [ "$HOWTOFILL" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%HOWTOFILL%/$HOWTOFILL/g" )"
  fi
  if [ "$sitename" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SITENAME%/$sitename/g" )"
  fi
  if [ "$mode" = "irc" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  else
    OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  fi
}

if [ "$1" = "request" ]; then
  request=true
  name=request
elif [ "$1" = "reqfilled" ]; then
  reqfilled=true
  name=fill
elif [ "$1" = "status" ]; then
  status=true
  name=status
else
  proc_mainerror
fi

if [ "$mode" = "gl" ]; then
  WHO=$USER
  if [ "$2" = "-hide" ]; then
    HIDE=TRUE
    echo "Hidden mode on. Nothing will be written to glftpd.log."
    WHAT="$* "
    WHAT="$( echo "$WHAT" | cut -d' ' -f3- | tr -s ' ' )"
  else
    HIDE=FALSE
    WHAT="$* "
    WHAT="$( echo "$WHAT" | cut -d' ' -f2- | tr -s ' ' )"
  fi
  HOWTOFILL='site reqfilled <name>'

else
  if [ "$3" = "-hide" -o "$2" = "-hide" ]; then
    echo "Quiet mode on. Shhh."
    HIDE=TRUE
    WHO="$2"
    WHAT="$4"
    CRAP="$5"
  else
    HIDE=FALSE
    WHO="$2"
    WHAT="$3"
    CRAP="$4"
  fi
  HOWTOFILL='!reqfilled <name>'
fi

if [ "$status" = "true" ]; then 
  WHAT=somecrap
fi

if [ "$allowspace" != "TRUE" ]; then
  if [ "$( echo "$WHAT" | grep ' ' )" ]; then
    OUTPUT="$NOSPACES"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  fi
fi

if [ "$CRAP" ]; then
  OUTPUT="$SPACEHELP"
  proc_cookies
  echo "$OUTPUT"
  exit 0
else
  unset CRAP
fi

if [ ! -w "$requests" ]; then
  echo "Request error. Cant write to requests directory. Check path and perms."
  exit 0
fi

if [ "$WHAT" = "" ]; then
  OUTPUT="$NOARGUMENT"
  proc_cookies
  echo "$OUTPUT"
  unset request
  unset reqfilled
  status=true
fi

## REQUEST MODE

if [ "$request" = "true" ]; then

  if [ "$requesthead" ]; then
    ## Check if folder is created..  
    if [ -d "$requests/$filledhead$WHAT" ]; then
      OUTPUT="$ALREADYFILLED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    elif [ -d "$requests/$requesthead$WHAT" ]; then
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  else
    ## Check if request is in file..
    if [ "$( grep -w -- "$WHAT" "$reqfile" )" ]; then
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi

  if [ "$reqfile" ]; then
    if [ ! -e "$reqfile" ]; then
      touch "$reqfile"
    fi
    if [ -w "$reqfile" ]; then
      OUTPUT="$REQINFILE"
      proc_cookies
      echo "$OUTPUT" >> $reqfile
    else
      error="$( basename $reqfile )"
      echo "Error: Cant write to $error. Check paths and perms."
      exit 0
    fi
  fi
 
  if [ "$gllog" ]; then
    if [ -w "$gllog" ]; then
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQUEST: \"$WHAT\" \"$WHO\" >> $gllog
      fi
    else
      echo "Error. Cant write to $gllog. Check paths and perms."
      exit 0
    fi
  fi

  if [ "$mode" = "gl" ]; then
    OUTPUT="$GLOK"
    proc_cookies
    echo "$OUTPUT"
  fi

  if [ "$requesthead" ]; then
    mkdir -m777 "$requests/$requesthead$WHAT"
  fi

fi

## REQFILL MODE

if [ "$reqfilled" = "true" ]; then
  if [ "$requesthead" ]; then
    if [ ! -d "$requests/$WHAT" ] && [ ! -d "$requests/$requesthead$WHAT" ]; then
      OUTPUT="$NOTREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  else
    WHATCHECK="$( echo "$WHAT" | tr -s ' ' '~' )"
    for line in `cat $reqfile | tr -s ' ' '~'`; do
      if [ "$( echo "$line" | grep -- "^$WHATCHECK" )" ]; then
        FOUND="YEAH"
      fi
    done
    if [ "$FOUND" != "YEAH" ]; then
      OUTPUT="$NOTREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    else
      unset FOUND
      unset WHATCHECK
    fi
  fi

  WHAT="$( echo "$WHAT" | sed -e "s/^$requesthead//" )"
  if [ "$reqfile" ]; then
    if [ ! -w "$reqfile" ]; then
      error="$( basename $reqfile )"
      echo "Error. Cant write to $error file. Check paths and perms."
      exit 0
    else
      grep -vi -- "$WHAT" "$reqfile" > $tmp/reqfile.tmp
      cp -f $tmp/reqfile.tmp $reqfile
      rm -f $tmp/reqfile.tmp
    fi
  fi
    
  if [ "$gllog" ]; then
    if [ -w "$gllog" ]; then
      if [ "$mode" = "gl" ]; then
        echo "Ok, < $WHAT> has been marked filled."
      fi
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQFILLED: \"$WHAT\" \"$WHO\" >> $gllog
      fi
    else
      echo "Error. Cant write to $gllog. Check paths and perms."
      exit 0
    fi
  fi

  if [ "$requesthead" ]; then
    mv -f "$requests/$requesthead$WHAT" "$requests/$filledhead$WHAT"
  fi
fi

if [ "$status" = "true" ]; then
  if [ -z "$reqfile" ]; then
    echo "To use status, you must have a reqfile defined."
    exit 0
  fi

  if [ "$2" = "auto" ]; then
    if [ ! -e $reqfile ]; then
      exit 0
    fi
    if [ -z "$( cat $reqfile )" ]; then
      exit 0
    fi      
  fi

  if [ ! -r "$reqfile" ]; then
    echo "Cant read $reqfile. Check paths and perms."
    exit 0
  fi

  OUTPUT="$STATUSHEAD"
  proc_cookies
  if [ "$mode" = "gl" ]; then
    echo "$OUTPUT"
  else
    if [ "$HIDE" = "FALSE" ]; then
      echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
    fi
  fi

  for line in `cat $reqfile | tr -s ' ' '^'`; do
    WHAT="$( echo $line | cut -d'^' -f1 )"
    gotone=yeah
    if [ ! -r "$reqfile" ]; then
      if [ ! -d "$requests/$requesthead$WHAT" ]; then
        grep -vi -- "$WHAT" "$reqfile" > $tmp/reqfile.tmp
        cp -f $tmp/reqfile.tmp $reqfile
        rm -f $tmp/reqfile.tmp
 
        OUTPUT="$FORCEFILL"
        proc_cookies
      fi

      if [ "$mode" = "gl" ]; then
        echo "$OUTPUT"
      fi
      if [ "$gllog" ]; then
        if [ "$HIDE" = "FALSE" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
        fi
      fi
    else
      gotone=yeah
      line="$( echo $line | tr -s '^' ' ' )"
      if [ "$mode" = "gl" ]; then
        echo "$line"
      else
        if [ "$HIDE" = "FALSE" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$line\" >> $gllog
        fi
      fi
    fi
  done
  if [ -z "$gotone" ]; then
    OUTPUT="$NOREQUESTS"
    proc_cookies
    if [ "$mode" = "gl" -o "$mode" = "irc" -a "$HIDE" = "TRUE" ]; then
      echo "$OUTPUT"
    else
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
      fi
    fi
  else
    OUTPUT="$TOFILL"
    proc_cookies
    if [ "$mode" = "gl" ]; then
      echo "$OUTPUT"
    else
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
      fi
    fi
  fi
fi

exit 0
