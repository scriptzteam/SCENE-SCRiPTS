#!/bin/bash
VER=1.0
#--[ Intro ]-----------------------------------------------#
#                                                          #
# Tur-Bw. A script to show total bandwidth usage on the    #
# site.                                                    #
# I started making a tur-who for listing everyone but it   #
# got sooo slow in bash, trying to line everything up that #
# I skipped that project. So heres tur-bw instead.         #
#                                                          #
#--[ Installation ]----------------------------------------#
#                                                          #
# Copy tur-bw.sh to /glftpd/bin. chmod 755 tur-bw.sh       #
#                                                          #
# Copy tur-bw.tcl to your bots config dir. Change command  #
# it triggers on if you wish. Dont forget to rehash bot.   #
# Load it after the script your previously used for !bw if #
# you are too lazy to remove the old functionality.        #
#                                                          #
#--[ Settings ]--------------------------------------------#
#                                                          #
# WHOBIN  = This script uses tur-ftpwho (3.0+). This is    #
#           the full path to it. tur-ftpwho is a seperate  #
#           package available at my site. Running          #
#           tur-ftpwho -v should display atleast v 3.0.    #
#           If it shows no info, its not 3.0 =)            #
#                                                          #
# DIREXCLUDES = Dirs or part of dirs where it will not add #
#               the bandwidth from. If you dont want it to #
#               report bw from predirs, you can add those  #
#               here. Set to "" to show all bandwidth.     #
#                                                          #
# SHOWTOTAL = This is just how many users you allow at the #
#             same time on the site. Im too lazy to read   #
#             it from glftpd.conf.                         #
#                                                          #
# FAKESPEED = "1.0" means it shows real speed. 2.0 would   #
#             fake the speed to be double of what it       #
#             actually is.                                 #
#             Can also set this one to "" for 1.0          #
#             Depending on regional settings, you might    #
#             have to set it to 1,0                        #
#                                                          #
# OUTPUT    = This is what it will say. See above it for   #
#             available cookies.                           #
#             There are 3 OUTPUT fields but two are        #
#             disabled with a #. Its just different ways   #
#             of doing it for examples.                    #
#                                                          #
#--[ Contact ]---------------------------------------------#
#                                                          #
#    http://www.grandis.nu <-> http://grandis.mine.nu      #
#                                                          #
#--[ Configuration ]---------------------------------------#

WHOBIN=/glftpd/bin/tur-ftpwho

DIREXCLUDES="
/GROUPS
/site/DIVX/GROUPS
"

SHOWTOTAL=20

FAKESPEED="1.0"

#--[ Cookies for OUTPUT ]----------------------------------#
#                                                          #
# %UPTOT%     = Total number of uploaders.                 #
# %UP%        = Speed of all uploaders.                    #
# %DNTOT%     = Total number of downloaders.               #
# %DN%        = Speed of all downloaders.                  #
# %TOTTRAN%   = Total number of up/downloaders.            #
# %TOTSPEED%  = Combined speed of up/downloads.            #
#                                                          #
# %IDLERS%    = All pure idlers.                           #
# %OTHER%     = Users doing other stuff (not really idle). #
# %ALLIDLERS% = %IDLERS% + %OTHER% combined.               #
# %TOTAL%     = Total number of users online.              #
# %SHOWTOTAL% = What you specified in SHOWTOTAL.           #
#                                                          #
# %BOLD%      = Start/Stop bold output.                    #
# %ULINE%     = Start/Stop underlined text.                #
# %COL%       = Color. Must be followed by a number.       #
#               For example %COL%1 would be black.         #
#               3 green, 4 red, 8 yellow etc.              #
#               Press ctrl-k in mirc to get a list (0-15)  #
#                                                          #
#               NOTE: Color number will show when running  #
#               from shell but it will look ok from irc.   #
#----------------------------------------------------------#

## Clean output.
OUTPUT="-xXX- [BW] - [ UP: %UPTOT%/%UP%Kb/Sec ]-[ DN: %DNTOT%/%DN%Kb/Sec ]-[ Total: %TOTTRAN%/%TOTSPEED%Kb/Sec ]-[ Idle: %IDLERS% Other: %OTHER% (%ALLIDLERS%) ]-[ Online: %TOTAL%/%SHOWTOTAL% ]"

## Bold usage.
# OUTPUT="-xXX- [BW] - [ UP: %BOLD%%UPTOT%/%UP%%BOLD%Kb/Sec ]-[ DN: %BOLD%%DNTOT%/%DN%%BOLD%Kb/sec ]-[ Total: %BOLD%%TOTTRAN%/%TOTSPEED%%BOLD%Kb/Sec ]-[ Idle: %BOLD%%IDLERS%%BOLD% Other: %BOLD%%OTHER%%BOLD% (%ALLIDLERS%) ]-[ Online: %BOLD%%TOTAL%%BOLD%/%SHOWTOTAL% ]"

## Color usage.
# OUTPUT="%COL%4-xXX-%COL%1 [BW] - [ UP: %COL%12%UPTOT%/%UP%Kb/Sec%COL%1 ]-[ DN: %COL%12%DNTOT%/%DN%Kb/sec%COL%1 ]-[ Total: %COL%12%TOTTRAN%/%TOTSPEED%%COL%1Kb/Sec ]-[ Idle: %COL%12%IDLERS% %COL%1Other: %COL%12%OTHER%%COL%1 (%ALLIDLERS%) ]-[ Online: %COL%12%TOTAL%/%SHOWTOTAL%%COL%1 ]"


#--[ Script Start ]----------------------------------------#

if [ ! -x "$WHOBIN" ]; then
  echo "Error. Cant execute $WHOBIN. Check perms and paths."
  exit 0
elif [ -z "$OUTPUT" ]; then
  echo "Error. No OUTPUT defined."
  exit 0
elif [ "`echo "100 + 100" | bc -l`" != "200" ]; then
  echo "Error. bc not installed? You'll need it."
  exit 0
fi

if [ "$DIREXCLUDES" ]; then
  DIREXCLUDES="`echo $DIREXCLUDES | tr -s ' ' '|'`"
else
  DIREXCLUDES="No0Dirs0At0All"
fi

proc_cookies() {
  if [ "$SHOWTOTAL" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SHOWTOTAL%/$SHOWTOTAL/g" )"
  fi
  if [ "$total" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTAL%/$total/g" )"
  fi
  if [ "$UP" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UP%/$UP/g" )"
  fi
  if [ "$UPTOT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%UPTOT%/$UPTOT/g" )"
  fi
  if [ "$DN" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DN%/$DN/g" )"
  fi
  if [ "$DNTOT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DNTOT%/$DNTOT/g" )"
  fi
  if [ "$TOTSPEED" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTSPEED%/$TOTSPEED/g" )"
  fi
  if [ "$TOTTRAN" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%TOTTRAN%/$TOTTRAN/g" )"
  fi
  if [ "$IDLERS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%IDLERS%/$IDLERS/g" )"
  fi
  if [ "$OTHER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%OTHER%/$OTHER/g" )"
  fi
  if [ "$ALLIDLERS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ALLIDLERS%/$ALLIDLERS/g" )"
  fi

  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%COL%//g" )"
}

total="0"; UP="0"; UPTOT="0"; DN="0"; DNTOT="0"; IDLERS="0"; OTHER="0"

for rawdata in `$WHOBIN | tr -d ' ' | egrep -v "$DIREXCLUDES"`; do
  unset speed; unset action
  total=$[$total+1]

  action="`echo "$rawdata" | cut -d '^' -f3`"

  if [ "$action" = "Dn:" -o "$action" = "Up:" ]; then
    speed="`echo "$rawdata" | cut -d '^' -f4`"

    if [ "$action" = "Dn:" ]; then
      DN="`echo "$DN + $speed" | bc -l`"
      DNTOT=$[$DNTOT+1]
    else
      UP="`echo "$UP + $speed" | bc -l`"
      UPTOT=$[$UPTOT+1]
    fi

  elif [ "$action" = "Idle:" ]; then
    IDLERS=$[$IDLERS+1]
  else
    OTHER=$[$OTHER+1]

  fi
done

if [ "$FAKESPEED" ]; then
  DN="`echo "$DN * $FAKESPEED" | bc -l`"
  UP="`echo "$UP * $FAKESPEED" | bc -l`"
fi
TOTSPEED="`echo "$UP + $DN" | bc -l`"
TOTTRAN="`echo "$UPTOT + $DNTOT" | bc -l`"

ALLIDLERS=$[$IDLERS+$OTHER]

proc_cookies
echo "$OUTPUT"

exit 0
