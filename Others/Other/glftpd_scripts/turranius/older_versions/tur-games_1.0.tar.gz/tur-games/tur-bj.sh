#!/bin/bash
VER=1.0

USERPATH=/ftp-data/users
BACKUPPATH=/ftp-data/users/backup
LOCKFILE=/tmp/bj.lock
GLLOGFILE=/ftp-data/logs/games.log
LOGFILE=/ftp-data/logs/bj.log
LOGFILETMP=/ftp-data/logs/bjtmp.log
USERFILETMP=/tmp/$USER.BJTMP
BINPATH=/bin
PLAYFILE=/tmp/bj_$USER
NODELAYPASS=onlycoolppl
RANDOMUSERRAID="TRUE"
COPSRAIDWINNINGS="FALSE"
COPSRAIDBETWINNINGS="FALSE"

MINBET="50"
MAXBET="1000"


#--[ Script Start ]--#

proc_output() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $GLLOGFILE
}

BOLD=""
ULINE=""

currenttime=0
lasttime=0
delayedtime=0

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

## If the user does not type anything after 'site play', this is displayed.
if [ -z $1 ]; then
  echo "----------------------[ BlackJack ]---------------------------"
  echo "Usage: site bj <MB Credits>   - To play.                      "
  echo "Usage: site bj hit            - Get another card.             "
  echo "Usage: site bj stay           - No more cards.                "
  echo "Usage: site bj double         - Double your bet.              "
  echo "Usage: site bj status         - To see your status.           "
  echo "Usage: site bj highscores     - To see the highscores.        "
  echo "Usage: site myscore           - Your score in all games.      "
  echo "--------------------------------------------------------------"
  echo "Rules are:                                                    "
  echo "You can only play once every 15 minutes.                      "
  echo "You can bet ${MINBET}-${MAXBET} dollah's (MB credits).        "
  echo "Special BlackJack rules are:                                  " 
  echo ""
  echo "> Aces only counts as 1's if you manage to get two of them in "
  echo "> the initial deal, otherwise, they are always 11 !           "
  echo ""
  echo "The Bank has to hit on 16 or less, and stay on 17 or more.    "
  echo "The Bank can only hit three times. You can hit infinite times."
  echo "BlackJack gives 2x the bet.                                   "
  echo "If you get 9-11 on the inital give, you can double the bet.   "
  echo "Should you double, you must hit and can only hit once.        "
  echo "----------------------------------------[ Turranius 2002 ]----"
  exit 0
fi

## Create or update filedate on logfile.
  touch $LOGFILE

## Check that the user does not have leech
  RATIO=$(grep RATIO $USERPATH/$USER | awk -F" " '{print $2}')
  if [ $RATIO = "0" ]; then
    echo "Sorry, you are banned from the casino cause your credits arent worth anything."
    exit 0
  fi

## Check that another game isnt running.
if [ -e $LOCKFILE ]; then
  echo "Another game is in progress. Try again in a few seconds."
  exit 0
fi

## If the user gives the nodelaypass, delete his timer file.
if [ "$1" = "$NODELAYPASS" ]; then
  ## If a second variable is set, check if that is a user, and if so, reset that users timer.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      echo "Admin password detected. Clearing timer for $2"
      proc_output "${BOLD}-(BJ)- $USER${BOLD} grants ${BOLD}$2${BOLD} another go at BlackJack."
      rm -f /tmp/bjtime_$2
      exit 0
    else
      echo "Cant clear timer for $2. No such user."
      exit 0
    fi
  else
    echo "Admin password detected. Clearing your timer."
    rm -f /tmp/bjtime_$USER
    exit 0
  fi
fi

## User requested his status.
if [ "$1" = "status" ]; then
  ## If a second variable is set, check if that is a user, and if so, show his stats.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      USER="$2"
    else
      echo "User not found."
      exit 0
    fi
  fi
  echo "Status for $USER in the BJ Casino."
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"
  echo "You have $USERCREDSMB dollah's to play with."

  currenttime=`date +%s`
  if [ -e /tmp/bjtime_$USER ]; then
    lasttime=`cat /tmp/bjtime_$USER`
    lasttime=`expr $lasttime / 60`
    currenttime=`expr $currenttime / 60`
    delayedtime=`expr $currenttime - $lasttime`
    if [ `expr $delayedtime "<=" 14` = 1 ] ; then
      x=15
      delayedtime=$[x - $delayedtime ]
      echo "Your slot will open in $delayedtime minutes."
    else
      echo "Your slot to play is open now."
    fi
  else
    echo "Your slot to play is open now."
  fi

  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "You have never played before."
    exit 0
  else
    echo "Your total standing vs the bj casino is $LOG dollah's (mb credits)."
    exit 0
  fi
fi

## User selected to see highscores.
if [ "$1" = "highscores" ]; then
  echo "-------[ Highscore for the BlackJack casino ]--------"
  cat $LOGFILE | sort -k 2,2 -n -r
  echo "----[ BlackJack casino was created by Turranius ]----"
  exit 0
fi

## Double section.
if [ "$1" = "double" ]; then

  if [ -e $PLAYFILE ]; then
    CORE="yes"
  else
    echo "You dont have any current games going on..."
    rm -f $LOCKFILE
    exit 0
  fi

  touch $LOCKFILE

  TOTAL="$(cat $PLAYFILE | grep PLAYER | awk -F":" '{print $2}')"
  BANKTOTAL="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $2}')"
  BANKNUM1NAME="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $3}')"
  BET="$(cat $PLAYFILE | grep BET | awk -F":" '{print $2}')"
  DOUBLE="$(cat $PLAYFILE | grep DOUBLE | awk -F":" '{print $2}')"

  if [ "$DOUBLE" = "USED" ]; then
    echo "You can only double once!"
    sleep 1
    rm -f $LOCKFILE
    exit 0
  fi

  if [ "$DOUBLE" != "ACTIVE" ]; then
    echo "You can only double if you get 9, 10 or 11"
    sleep 1
    rm -f $LOCKFILE
    exit 0
  else
    BET="$(expr $BET \* 2)"
    echo "You double the bet to $BET"
    echo "Now do 'site bj hit'"
    proc_output "${BOLD}-(BJ)- $USER${BOLD} doubles the bet to ${BOLD}$BET${BOLD} Dollah's!"
    echo "PLAYER:$TOTAL" > $PLAYFILE
    echo "BANK:$BANKTOTAL:$BANKNUM1NAME" >> $PLAYFILE
    echo "BET:$BET" >> $PLAYFILE
    echo "DOUBLE:USED" >> $PLAYFILE
    sleep 1
    rm -f $LOCKFILE
    exit 0
  fi 
fi

## Hit section
if [ "$1" = "hit" ]; then

  if [ -e $PLAYFILE ]; then
    CORE="yes"
  else
    echo "You dont have any current games going on..."
    rm -f $LOCKFILE
    exit 0
  fi

  touch $LOCKFILE

  HIT="$(cat $PLAYFILE | grep HIT | awk -F":" '{print $2}')"
  TOTAL="$(cat $PLAYFILE | grep PLAYER | awk -F":" '{print $2}')"
  BANKTOTAL="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $2}')"
  BANKNUM1NAME="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $3}')"
  BET="$(cat $PLAYFILE | grep BET | awk -F":" '{print $2}')"
  DOUBLE="$(cat $PLAYFILE | grep DOUBLE | awk -F":" '{print $2}')"
 
  if [ "$DOUBLE" = "YES" ]; then
    echo "You can only hit once after you doubled. You have to Stay"
    sleep 1
    rm -f $LOCKFILE
    exit 0
  fi

  echo "Your total is $TOTAL"
  echo "You take another card"
  #NUM3="$($BINPATH/randomit 2 14)"

  LOW=2
  HIGH=14
  proc_random
  NUM3="$number"

  NUM3NAME=$NUM3
  if [ "$NUM3" = "11" ]; then
    NUM3NAME="Jack"
    NUM3=10 
  fi
  if [ "$NUM3" = "12" ]; then
    NUM3NAME="Queen"
    NUM3=10
  fi
  if [ "$NUM3" = "13" ]; then
    NUM3NAME="King"
    NUM3=10
  fi
  if [ "$NUM3" = "14" ]; then
    NUM3NAME="Ace"
    NUM3=11
  fi
  echo "You get a $NUM3NAME"
  TOTAL="$(expr $TOTAL \+ $NUM3)"
  proc_output "${BOLD}-(BJ)- $USER${BOLD} hits and gets a ${BOLD}$NUM3NAME${BOLD} (${BOLD}$TOTAL${BOLD} Total)"
  echo "Your total: $TOTAL"

  if [ "$TOTAL" -gt "21" ]; then
    echo "You are busted. You loose"
    proc_output "${BOLD}-(BJ)- $USER${BOLD} is busted!"

    USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
    BETKB="$(expr $BET \* 1024)"
    NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
    sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
    mv -f $USERFILETMP $USERPATH/$USER

    LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
    if [ "$LOG" = "" ]; then
      echo "$USER -$BET" >> $LOGFILE
    else
      STANDING="$(expr $LOG \- $BET)"
      echo "Your total standing with the BJ casino is $STANDING dollah's"
      proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
      sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
      mv -f $LOGFILETMP $LOGFILE
    fi

    rm -f $LOCKFILE
    rm -f $PLAYFILE
    exit 0
  else
    echo "PLAYER:$TOTAL" > $PLAYFILE
    echo "BANK:$BANKTOTAL:$BANKNUM1NAME" >> $PLAYFILE
    echo "BET:$BET" >> $PLAYFILE
    if [ "$DOUBLE" = "USED" ]; then
      echo "DOUBLE:YES" >> $PLAYFILE
    fi
    echo "---------------------------------"
    echo "You have $TOTAL"
    echo "Do you wish to Hit or Stay?"
    echo "('site bj hit' or 'site bj stay')"
    rm -f $LOCKFILE
    exit 0
  fi
fi

## Stay section
if [ "$1" = "stay" ]; then

  if [ -e $PLAYFILE ]; then
    CORE="yes"
  else
    echo "You dont have any current games going on..."
    rm -f $LOCKFILE
    exit 0
  fi

  touch $LOCKFILE

  TOTAL="$(cat $PLAYFILE | grep PLAYER | awk -F":" '{print $2}')"
  BANKTOTAL="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $2}')"
  BANKNUM1NAME="$(cat $PLAYFILE | grep BANK | awk -F":" '{print $3}')"
  BET="$(cat $PLAYFILE | grep BET | awk -F":" '{print $2}')"
  echo "Bank flips the card and its a $BANKNUM1NAME."

  echo "Your total: $TOTAL. Bank total: $BANKTOTAL"
  proc_output "${BOLD}-(BJ)- Bank${BOLD} flips it's card and it's a ${BOLD}$BANKNUM1NAME${BOLD} (${BOLD}$BANKTOTAL${BOLD} Total)"

  if [ "$BANKTOTAL" = "21" ]; then
    echo "Bank has BlackJack. You loose $BET Dollah's!"
    echo "$(date +'%a %b %d %T %Y') SLOWDL: ${BOLD}-(BJ)- Bank${BOLD} has BlackJack. ${BOLD}$USER${BOLD} loose $BET Dollah's." >> $GLLOGFILE

    USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
    BETKB="$(expr $BET \* 1024)"
    NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
    sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
    mv -f $USERFILETMP $USERPATH/$USER

    LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
    if [ "$LOG" = "" ]; then
      echo "$USER -$BET" >> $LOGFILE
    else
      STANDING="$(expr $LOG \- $BET)"
      echo "Your total standing with the BJ casino is $STANDING dollah's"
      proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
      sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
      mv -f $LOGFILETMP $LOGFILE
    fi

    rm -f $PLAYFILE
    sleep 1
    rm -f $LOCKFILE
    exit 0
  fi

  if [ "$BANKTOTAL" -gt "16" ]; then
    if [ "$TOTAL" = "$BANKTOTAL" ]; then
      echo "Its a draw!"
      proc_output "${BOLD}-(BJ)- Draw! No Winners."
      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    fi
    if [ "$BANKTOTAL" -gt "$TOTAL" ]; then
      echo "Bank wins your $BET dollah's with $BANKTOTAL vs $TOTAL."
      proc_output "${BOLD}-(BJ)- Bank${BOLD} wins with $BANKTOTAL vs ${BOLD}$USER${BOLD}'s $TOTAL."

#      COPS="$($BINPATH/randomit 0 100)"

      LOW=0
      HIGH=100
      proc_random
      COPS="$number"


      if [ "$COPS" -lt "10" ]; then
        echo "Cops raid and claim the banks winnings!"
        proc_output "${BOLD}-(BJ)-${BOLD} Cops raid and claims the winnings from the bank! ${BOLD}$USER${BOLD} gets his money back."
        rm -f $LOCKFILE
        rm -f $PLAYFILE
        exit 0
      fi

      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER

      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER -$BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \- $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi
      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    else
      echo "You win $BET dollah's with $TOTAL vs $BANKTOTAL."
      proc_output "${BOLD}-(BJ)- $USER${BOLD} wins with $TOTAL vs Bank's $BANKTOTAL."

      #COPS="$($BINPATH/randomit 0 100)"

      LOW=0
      HIGH=100
      proc_random
      COPS="$number"

      
      if [ "$COPSRAIDBETWINNINGS" = "TRUE" ]; then
        if [ "$COPS" -lt "10" ]; then
          echo "Cops raid and claim your bet & winnings!"
          proc_output "${BOLD}-(BJ)-${BOLD} Cops raid and claims the bet & winnings from ${BOLD}$USER${BOLD}"
          USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
          BETKB="$(expr $BET \* 1024)"
          NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
          sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
          mv -f $USERFILETMP $USERPATH/$USER

          LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
          if [ "$LOG" = "" ]; then
            echo "$USER -$BET" >> $LOGFILE
          else
            STANDING="$(expr $LOG \- $BET)"
            echo "Your total standing with the BJ casino is $STANDING dollah's"
            proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
            sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
            mv -f $LOGFILETMP $LOGFILE
            rm -f $LOCKFILE
            rm -f $PLAYFILE
            exit 0
          fi
        fi
      fi

      if [ "$COPSRAIDWINNINGS" = "TRUE" ]; then
        if [ "$COPS" -lt "20" ]; then
  	  echo "Cops raid and claim your winnings!"
          proc_output "${BOLD}-(BJ)-${BOLD} Cops raid and claims the winnings from ${BOLD}$USER${BOLD}"
          rm -f $LOCKFILE
          rm -f $PLAYFILE
          exit 0
        fi
      fi     

      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \+ $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER

      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER $BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \+ $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi
      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    fi
  fi  
 
  if [ "$BANKTOTAL" -lt "17" ]; then
    echo "Bank takes another card"
    #BANKNUM3="$($BINPATH/randomit 2 14)"

    LOW=2
    HIGH=14
    proc_random
    BANKNUM3="$number"

    BANKNUM3NAME=$BANKNUM3
    if [ "$BANKNUM3" = "11" ]; then
      BANKNUM3NAME="Jack"
      BANKNUM3=10 
    fi
    if [ "$BANKNUM3" = "12" ]; then
      BANKNUM3NAME="Queen"
      BANKNUM3=10
    fi
    if [ "$BANKNUM3" = "13" ]; then
      BANKNUM3NAME="King"
      BANKNUM3=10
    fi
    if [ "$BANKNUM3" = "14" ]; then
      BANKNUM3NAME="Ace"
      BANKNUM3=11
    fi
    echo "Bank gets a $BANKNUM3NAME"
    BANKTOTAL="$(expr $BANKTOTAL \+ $BANKNUM3)"
    proc_output "${BOLD}-(BJ)- Bank${BOLD} hits and gets a ${BOLD}$BANKNUM3NAME${BOLD} (${BOLD}$BANKTOTAL${BOLD} Total)"
    echo "Banks total: $BANKTOTAL"
    sleep 2
    if [ "$BANKTOTAL" -lt "17" ]; then
      echo "Bank takes another card"
      #BANKNUM4="$($BINPATH/randomit 2 14)"

      #NUM="$(/bin/randomit 0 100)"
      LOW=2
      HIGH=14
      proc_random
      BANKNUM4="$number"

      BANKNUM4NAME=$BANKNUM4
      if [ "$BANKNUM4" = "11" ]; then
        BANKNUM4NAME="Jack"
        BANKNUM4=10 
      fi
      if [ "$BANKNUM4" = "12" ]; then
        BANKNUM4NAME="Queen"
        BANKNUM4=10
      fi
      if [ "$BANKNUM4" = "13" ]; then
        BANKNUM4NAME="King"
        BANKNUM4=10
      fi
      if [ "$BANKNUM4" = "14" ]; then
        BANKNUM4NAME="Ace"
        BANKNUM4=11
      fi
      echo "Bank gets a $BANKNUM4NAME"
      BANKTOTAL="$(expr $BANKTOTAL \+ $BANKNUM4)"
      proc_output "${BOLD}-(BJ)- Bank${BOLD} hits and gets a ${BOLD}$BANKNUM4NAME${BOLD} (${BOLD}$BANKTOTAL${BOLD} Total)"
      echo "Banks total: $BANKTOTAL"
      sleep 2
      if [ "$BANKTOTAL" -lt "17" ]; then
        echo "Bank takes another card"
        #BANKNUM5="$($BINPATH/randomit 2 14)"

        LOW=2
        HIGH=14
        proc_random
        NUM="$number"

        BANKNUM5NAME=$BANKNUM5
        if [ "$BANKNUM5" = "11" ]; then
          BANKNUM5NAME="Jack"
          BANKNUM5=10 
        fi
        if [ "$BANKNUM5" = "12" ]; then
          BANKNUM5NAME="Queen"
          BANKNUM5=10
        fi
        if [ "$BANKNUM5" = "13" ]; then
          BANKNUM5NAME="King"
          BANKNUM5=10
        fi
        if [ "$BANKNUM5" = "14" ]; then
          BANKNUM5NAME="Ace"
          BANKNUM5=11
        fi
        echo "Bank gets a $BANKNUM5NAME"
        BANKTOTAL="$(expr $BANKTOTAL \+ $BANKNUM5)"
        proc_output "${BOLD}-(BJ)- Bank${BOLD} hits and gets a ${BOLD}$BANKNUM5NAME${BOLD} (${BOLD}$BANKTOTAL${BOLD} Total)"
        echo "Banks total: $BANKTOTAL"
      fi
    fi
    if [ "$BANKTOTAL" -gt "21" ]; then
      echo "Bank is busted. You win $BET dollah's !"
      proc_output "${BOLD}-(BJ)- Bank${BOLD} is busted. ${BOLD}$USER${BOLD} wins $BET Dollah's."

      if [ "$COPSRAIDBETWINNINGS" = "TRUE" ]; then
        #COPS="$($BINPATH/randomit 0 100)"

        LOW=0
        HIGH=100
        proc_random
        COPS="$number"

        if [ "$COPS" -lt "15" ]; then
          echo "Cops raid and claim your bet & winnings!"
          proc_output "${BOLD}-(BJ)-${BOLD} Cops raid and claims the bet & winnings from ${BOLD}$USER${BOLD}"
          USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
          BETKB="$(expr $BET \* 1024)"
          NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
          sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
          mv -f $USERFILETMP $USERPATH/$USER

          LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
          if [ "$LOG" = "" ]; then
            echo "$USER -$BET" >> $LOGFILE
          else
            STANDING="$(expr $LOG \- $BET)"
            echo "Your total standing with the BJ casino is $STANDING dollah's"
            proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
            sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
            mv -f $LOGFILETMP $LOGFILE
            rm -f $LOCKFILE
            rm -f $PLAYFILE
            echo "DEBUG: 80"
            exit 0
          fi
        fi
      fi

      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \+ $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER

      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER $BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \+ $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi

      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    fi

    if [ "$TOTAL" = "$BANKTOTAL" ]; then
      echo "Its a draw!"
      echo "$(date +'%a %b %d %T %Y') SLOWDL: ${BOLD}-(BJ)- Draw! No Winners." >> $GLLOGFILE
      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    fi

    if [ "$BANKTOTAL" -gt "$TOTAL" ]; then
      echo "Bank wins your $BET dollah's with $BANKTOTAL vs your $TOTAL"
      proc_output "${BOLD}-(BJ)- Bank${BOLD} wins $BET Dollah's with $BANKTOTAL vs ${BOLD}$USER${BOLD}'s $TOTAL"

      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \- $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER

      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER -$BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \- $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi

      rm -f $LOCKFILE
      rm -f $PLAYFILE
      exit 0
    else
      echo "You win $BET dollah's with $TOTAL vs the banks $BANKTOTAL"
      proc_output "${BOLD}-(BJ)- $USER${BOLD} wins $BET Dollah's with $TOTAL vs Bank's $BANKTOTAL"
      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \+ $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER
      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER $BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \+ $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi
      rm -f $PLAYFILE
      rm -f $LOCKFILE
      exit 0
    fi
    rm -f $LOCKFILE
    rm -f $PLAYFILE
    exit 0
  fi
  rm -f $LOCKFILE
  rm -f $PLAYFILE
  exit 0
fi

if [ -e $PLAYFILE ]; then
  echo "You have a current game going on. You must chose to either Hit or Stay."
  rm -f $LOCKFILE
  exit 0
fi

## If another game isnt running, create the lockfile so noone else can play.
touch $LOCKFILE

## Make the bet x 1024 cause the userfiles contains kilobytes, not megabytes
BETCREDS="$(expr $1 \* 1024)"

## If the above calculation crapped out, the $BETCREDS is empty. User typed something other than numbers.
if [ "$BETCREDS" = "" ]; then
  echo "Bad amount of credits. Only use numbers!"
  rm -f $LOCKFILE
  exit 0
fi

## Minumum amount of credits to gamble.
if [ "$1" -lt "$MINBET" ]; then
  echo "Sorry, minumum amount to gamble with is ${MINBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

## Maximum amount of credits to gamble.
if [ "$1" -gt "$MAXBET" ]; then
  echo "Sorry, maximum amount to gamble with is ${MINBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

## Make a backup of the userfile before doing anything.
cp -f $USERPATH/$USER $BACKUPPATH/$USER.bj

## Check that the user really has that much credits
USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"

## Translate it to megabytes.
USERCREDSMB="$(expr $USERCREDS \/ 1024)"

## If the user does not have enough credits...
if [ "$USERCREDS" -lt "$BETCREDS" ]; then
  echo "The guards grab you and toss you out! They toss your $USERCREDSMB credits after you!"
  proc_output "${BOLD}-(BJ)-${BOLD} The guards throws out ${BOLD}$USER${BOLD} from the casino cause he tryed to gamble with more then he had!"
  rm -f $LOCKFILE
  exit 0
fi

## Check the time since it was last run.
currenttime=`date +%s`
if [ -e /tmp/bjtime_$USER ]; then
     lasttime=`cat /tmp/bjtime_$USER`
     lasttime=`expr $lasttime / 60`
     currenttime=`expr $currenttime / 60`
     delayedtime=`expr $currenttime - $lasttime`
  if [ `expr $delayedtime "<=" 14` = 1 ] ; then
     x=15
     delayedtime=$[x - $delayedtime ]
     echo "You can only play once every 15 minutes. Your slot will open in $delayedtime minutes."
     echo "Use 'site bj status' to keep updated."
     rm -f $LOCKFILE
     exit 0
  fi
fi

## Make sure the current credits can be read.
if [ "$USERCREDS" = "" ]; then
  echo "Hm, cant seem to read your userfile, or you are piss poor."
  rm -f $LOCKFILE
  exit 0
else
  echo "You toss $1 dollah's on the BlackJack Table."
  proc_output "${BOLD}-(BJ)- $USER${BOLD} toss ${BOLD}$1${BOLD} Dollah's on the BlackJack table."
  sleep 2
fi

## Update the time when play was last run. Comment out this line for no delay.
echo `date +%s` > /tmp/bjtime_$USER

## Make the actual random number for player
#NUM1="$($BINPATH/randomit 2 14)"

LOW=2
HIGH=14
proc_random
NUM1="$number"


NUM1NAME=$NUM1
if [ "$NUM1" = "11" ]; then
  NUM1NAME="Jack"
  NUM1=10
fi
if [ "$NUM1" = "12" ]; then
  NUM1NAME="Queen"
  NUM1=10
fi
if [ "$NUM1" = "13" ]; then
  NUM1NAME="King"
  NUM1=10
fi
if [ "$NUM1" = "14" ]; then
  NUM1NAME="Ace"
  NUM1=11
fi

echo You got a: $NUM1NAME
proc_output "${BOLD}-(BJ)- $USER${BOLD} gets a ${BOLD}$NUM1NAME${BOLD}."
sleep 2
#NUM2="$($BINPATH/randomit 2 14)"

LOW=2
HIGH=14
proc_random
NUM2="$number"


NUM2NAME=$NUM2
if [ "$NUM2" = "11" ]; then
  NUM2NAME="Jack"
  NUM2=10
fi
if [ "$NUM2" = "12" ]; then
  NUM2NAME="Queen"
  NUM2=10
fi
if [ "$NUM2" = "13" ]; then
  NUM2NAME="King"
  NUM2=10
fi
if [ "$NUM2" = "14" ]; then
  NUM2NAME="Ace"
  NUM2=11
fi

echo You got a: $NUM2NAME
TOTAL="$( expr $NUM1 \+ $NUM2 )"
if [ "$TOTAL" = "22" ]; then
  TOTAL=12
fi

proc_output "${BOLD}-(BJ)- $USER${BOLD} gets a ${BOLD}$NUM2NAME${BOLD} (${BOLD}$TOTAL${BOLD} Total)"
sleep 2

## Make the actual random number for bank.
#BANKNUM1="$($BINPATH/randomit 2 14)"

LOW=2
HIGH=14
proc_random
BANKNUM1="$number"


BANKNUM1NAME=$BANKNUM1
if [ "$BANKNUM1" = "11" ]; then
  BANKNUM1NAME="Jack"
  BANKNUM1=10
fi
if [ "$BANKNUM1" = "12" ]; then
  BANKNUM1NAME="Queen"
  BANKNUM1=10
fi
if [ "$BANKNUM1" = "13" ]; then
  BANKNUM1NAME="King"
  BANKNUM1=10
fi
if [ "$BANKNUM1" = "14" ]; then
  BANKNUM1NAME="Ace"
  BANKNUM1=11
fi

echo "Bank got a: *Hidden*"
proc_output "${BOLD}-(BJ)- Bank${BOLD} gets a ${BOLD}*Hidden*${BOLD}."
#echo "Debug: ($BANKNUM1 - $BANKNUM1NAME)"
sleep 2
#BANKNUM2="$($BINPATH/randomit 2 14)"

LOW=2
HIGH=14
proc_random
BANKNUM2="$number"


BANKNUM2NAME=$BANKNUM2
if [ "$BANKNUM2" = "11" ]; then
  BANKNUM2NAME="Jack"
  BANKNUM2=10
fi
if [ "$BANKNUM2" = "12" ]; then
  BANKNUM2NAME="Queen"
  BANKNUM2=10
fi
if [ "$BANKNUM2" = "13" ]; then
  BANKNUM2NAME="King"
  BANKNUM2=10
fi
if [ "$BANKNUM2" = "14" ]; then
  BANKNUM2NAME="Ace"
  BANKNUM2=11
fi

echo Bank got a: $BANKNUM2NAME
proc_output "${BOLD}-(BJ)- Bank${BOLD} gets a $BANKNUM2NAME."
BANKTOTAL="$( expr $BANKNUM1 \+ $BANKNUM2 )"
if [ "$BANKTOTAL" = "22" ]; then
  BANKTOTAL=12
fi

BET=$1
if [ "$TOTAL" = "21" ]; then
  if [ "$BANKNUM2" -gt "9" ]; then 
    if [ "$BANKTOTAL" != "21" ]; then
      echo "Bank flips his closed card and..."
      sleep 1
      echo "Its a $BANKNUM1NAME. You win a Blackjack!"
      BET="$(expr $BET \* 2)"
      proc_output "${BOLD}-(BJ)- Bank${BOLD} flips the closed card and it's a $BANKNUM1NAME. ${BOLD}$USER${BOLD} win a BlackJack!"

      USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
      BETKB="$(expr $BET \* 1024)"
      NEWCREDSKB="$(expr $USERCREDSKB \+ $BETKB)"
      sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
      mv -f $USERFILETMP $USERPATH/$USER

      LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
      if [ "$LOG" = "" ]; then
        echo "$USER $BET" >> $LOGFILE
      else
        STANDING="$(expr $LOG \+ $BET)"
        echo "Your total standing with the BJ casino is $STANDING dollah's"
        proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
        sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
        mv -f $LOGFILETMP $LOGFILE
      fi

    else
      echo "Bank flips his closed card and..."
      sleep 1
      echo "Its a $BANKNUM1NAME. Both BlackJack. Its a draw!"
      proc_output "${BOLD}-(BJ)- Bank${BOLD} flips the closed card and it's a $BANKNUM1NAME. It's a draw!"
      rm -f $LOCKFILE
      exit 0
    fi
  else
    echo "You win a BlackJack!"
    proc_output "${BOLD}-(BJ)- $USER${BOLD} wins a ${BOLD}BlackJack!${BOLD}"
    BET="$(expr $BET \* 2)"

    USERCREDSKB="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
    BETKB="$(expr $BET \* 1024)"
    NEWCREDSKB="$(expr $USERCREDSKB \+ $BETKB)"
    sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
    mv -f $USERFILETMP $USERPATH/$USER
        
    LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
    if [ "$LOG" = "" ]; then
      echo "$USER $BET" >> $LOGFILE
    else
      STANDING="$(expr $LOG \+ $BET)"
      echo "Your total standing with the BJ casino is $STANDING dollah's"
      proc_output "${BOLD}-(BJ)- $USER${BOLD}'s total standing vs the BJ casino is $STANDING dollah's"
      sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
      mv -f $LOGFILETMP $LOGFILE
    fi

  fi
else
   DOUBLE=NO
   if [ "$TOTAL" = "9" ]; then
     DOUBLE=ACTIVE
   fi
   if [ "$TOTAL" = "10" ]; then
     DOUBLE=ACTIVE
   fi   
   if [ "$TOTAL" = "11" ]; then
     DOUBLE=ACTIVE
   fi
   echo "PLAYER:$TOTAL" > $PLAYFILE
   echo "BANK:$BANKTOTAL:$BANKNUM1NAME" >> $PLAYFILE
   echo "BET:$1" >> $PLAYFILE

   if [ "$DOUBLE" = "ACTIVE" ]; then
     echo "---------------------------------------------------"
     echo "You have $TOTAL"
     echo "Do you wish to Hit, Stay or Double?"
     echo "('site bj hit', 'site bj stay' or 'site bj double')"
     echo "DOUBLE:ACTIVE" >> $PLAYFILE
     rm -f $LOCKFILE
     exit 0
   else
     echo "---------------------------------"
     echo "You have $TOTAL"
     echo "Do you wish to Hit or Stay?"
     echo "('site bj hit' or 'site bj stay')"
     echo "DOUBLE:NO" >> $PLAYFILE
     rm -f $LOCKFILE
     exit 0
   fi
fi

rm -f $LOCKFILE
exit 0