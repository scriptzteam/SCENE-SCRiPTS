#!/bin/bash
VER=2.9.1

#-[ Script Start ]----------------------------------------------#
#                                                               #
# No changes below here unless you want to change some text.    #
#                                                               #
#---------------------------------------------------------------#

## Read config
if [ -z $config ]; then
  config="`dirname $0`/tur-request.conf"
fi
if [ ! -r $config ]; then
  echo "Error. Can not read $config"
  exit 0
else
  . $config
fi

if [ -z "$datebin" ]; then
  datebin="date"
fi

## Check if we're in glftpd or shell (irc)..
if [ "$FLAGS" ]; then
  mode=gl
  BY="$USER"
  HOWTOFILL='site reqfilled <number or name>'
else
  mode=irc
  requests=$glroot$requests
  reqfile=$glroot$reqfile
  tmp=$glroot$tmp
  if [ "$msgsdir" ]; then
    msgsdir=$glroot$msgsdir
  fi
  if [ "$usersdir" ]; then
    usersdir="$glroot$usersdir"
  fi
  if [ "$gllog" ]; then
    gllog=$glroot$gllog
  fi
  if [ "$log" ]; then
    log="$glroot$log"
  fi
  HOWTOFILL='!reqfilled <number or name>'
fi

proc_mainerror() {
  echo "Got neither request, reqfilled, reqwipe, status, fix or checkold... quitting."
  exit 0
}

if [ -z "$1" ]; then
  proc_mainerror
fi

## Procedure for logging
proc_log() {
  if [ "$log" ]; then
    if [ -w "$log" ]; then
      echo `$datebin "+%a %b %e %T %Y"` "$@" >> $log
    else
      if [ "$USER" = "root" ]; then
        touch $log
        if [ -x "chmod" ]; then
          chmod 777 $log
        fi
      else
        logname=`basename $log`
        echo "Error: Can not write to $logname. Create and set 777."
      fi
    fi
  fi
}

## Heres where we change those %blabla% into real text.
proc_cookies() {
  if [ "$BY" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%WHO%/$BY/g"`
  fi
  if [ "$WHAT" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%WHAT%/$WHAT/g"`
  fi
  if [ "$ACTION" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%ACTION%/$ACTION/g"`
  fi
  if [ "$RELEASE" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%RELEASE%/$RELEASE/g"`
  fi
  if [ "$mode" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%MODE%/$mode/g"`
  fi
  if [ "$name" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%NAME%/$name/g"`
  fi
  if [ "$adddate" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%ADDDATE%/$adddate/g"`
  fi
  if [ "$requesthead" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%REQUESTHEAD%/"$requesthead"/g"`
  fi
  if [ "$filledhead" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%FILLEDHEAD%/$filledhead/g"`
  fi
  if [ "$HOWTOFILL" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%HOWTOFILL%/$HOWTOFILL/g"`
  fi
  if [ "$sitename" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%SITENAME%/$sitename/g"`
  fi
  if [ "$FOR" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%FOR%/$FOR/g"`
  fi
  if [ "$num" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%NUM%/$num/g"`
  fi
  if [ "$IRCOUTPUT" = "TRUE" -o "$AUTO" = "TRUE" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%BOLD%//g"`
    OUTPUT=`echo $OUTPUT | sed -e "s/%ULINE%//g"`
  else
    OUTPUT=`echo $OUTPUT | sed -e "s/%BOLD%//g"`
    OUTPUT=`echo $OUTPUT | sed -e "s/%ULINE%//g"`
  fi

}

## Get all arguments into RAWSTRING.
RAWSTRING="`echo "$@" | tr -d '\]' | tr -d '\[' | tr -d '\|'`"

## Make initial check. Cant include a /
if [ "$( echo "$RAWSTRING" | grep "\/" )" ]; then
  if [ "$mode" = "irc" ]; then
    IRCOUTPUT="TRUE"
  fi

  OUTPUT="$NONSTANDARDCHAR"
  proc_cookies
  echo "$OUTPUT"
  exit 0
fi

if [ "$mode" = "irc" -a "$1" != "checkold" ]; then
  ## If from irc, cut out second word to BY. This is who its from.
  BY=`echo "$RAWSTRING" | cut -d ' ' -f2`
  ## Remove that one when done.

  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/$BY//" | tr -s ' '`
fi

## Check first word. This is the action to take (request, reqfilled etc).
RUN=`echo "$RAWSTRING" | cut -d' ' -f1`
## Remove run command from RAWSTRING.
RAWSTRING=`echo "$RAWSTRING" | sed -e "s/^$RUN//"`
## Clear up RAWSTRING from leftover spaces.
RAWSTRING=`echo $RAWSTRING`

if [ "$RAWSTRING" = "$RUN" -a "$RUN" = "request" -o "$RAWSTRING" = "" -a "$RUN" = "request" ]; then
  if [ "$mode" = "irc" ]; then
    echo "Usage: !request <username> <request> (-hide) (-for:<username>)"
    echo "-hide is used to not announce to chan."
    echo "-for:<username> is used to specify who the request is for."
  else
    echo "Usage: site request <request> (-hide) (-for:<username>)"
    echo "-hide is used to not announce to chan."
    echo "-for:<username> is used to specify who the request is for."
  fi
  exit 0
fi

## Check if -hide is in RAWSTRING. If so, remove it and set HIDE=TRUE
if [ "$( echo "$RAWSTRING" | grep -w "\-hide" )" ]; then
  HIDE=TRUE
  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/\-hide//"`
else
  HIDE=FALSE
fi

## Clear up RAWSTRING from start and ending spaces.
RAWSTRING=`echo $RAWSTRING`

## Check if -for: is in RAWSTRING. If so, cut it out and check who its for.
unset FOR; unset FORLAST
if [ "$( echo "$RAWSTRING" | grep '\-for\:' )" ]; then
  for crap in $RAWSTRING; do
    if [ "$( echo "$crap" | grep '\-for\:' )" ]; then
      FOR=`echo $crap | cut -d ':' -f2`
      break
    fi
  done

  ## Check that FOR isnt empty.
  if [ -z "$FOR" ]; then
    echo "When using '-for:' then specify a user who its for too."
    exit 0
  fi

  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/\-for:$FOR//"`

  unset FORLAST
fi

## Clear up RAWSTRING again
RAWSTRING=`echo $RAWSTRING`

## DEBUG VALUES. Remove below #'s to only get debug output.
# echo "full  : <$@>"
# echo "by    : <$BY>"
# echo "action: <$RUN>"
# echo "hide  : <$HIDE>"
# echo "for   : <$FOR>"
# echo "rel   : <$RAWSTRING>"
# exit 0

## Set request to $WHAT from $RAWSTRING and clear RAWSTRING
WHAT="$RAWSTRING"; unset RAWSTRING

## Check if allowspace is FALSE.
if [ "$allowspace" = "FALSE" ]; then
  ## If it was, check if theres a space in $WHAT
  if [ "$( echo "$WHAT" | grep ' ' )" ]; then
    ## If there was a space, check if replacewith is set.
    if [ "$replacewith" ]; then
      ## If it was, replace all spaces with it.
      WHAT=`echo "$WHAT" | tr ' ' "$replacewith"`
    else
      ## If replacewith is empty, say the NOSPACES error.
      if [ "$mode" = "irc" ]; then
        IRCOUTPUT="TRUE"
      fi

      OUTPUT="$NOSPACES"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi
fi  

## Verify that $WHAT is set etc. If no argument is given...
proc_verify() {

  ## Check that $WHAT does not include bad chars..."
  if [ "$( echo "$WHAT" | egrep "$badchars" )" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$NONSTANDARDCHAR"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  fi

  if [ -z "$WHAT" -o "$ERROR" = "TRUE" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$NOARGUMENT"
    proc_cookies
    echo "$OUTPUT"
    AUTO="TRUE"
    exit 0
  fi

  if [ ! -d "$tmp" ]; then
    if [ "$mode" = "irc" ]; then
      echo "Error. Cant find $tmp. Create it and set 777 in it."
    else
      echo "Error. Cant find $glroot$tmp. Create it and set 777 in it."
    fi
    exit 0
  fi
  touch "$tmp/testtouch.tmp"
  if [ ! -e "$tmp/testtouch.tmp" ]; then
    if [ "$mode" = "irc" ]; then
      echo "Error. Cant write to $tmp. Check perms."
    else
      echo "Error. Cant write to $glroot$tmp. Check perms."
    fi
    exit 0
  fi
  rm -f $tmp/testtouch.tmp

}

## Does the reqfile exist and can we read it?
proc_checkfile() {
  if [ ! -e "$reqfile" ]; then
    echo "Can not find $reqfile. Create it and set proper perms on it (777)"
    exit 0
  fi
  if [ ! -w "$reqfile" ]; then
    echo "Found requestfile, but can not write to it. Set proper perms on it."
    exit 0
  fi
}

## Reorder reqfile so numbers are in order.
proc_reorder() {
  ## Can the reqfile be written to?
  if [ ! -w "$reqfile" ]; then
    echo "Cant read $reqfile for fix. Create it and/or set perms."
    exit 0
  fi

  ## Remove previous file just incase.
  if [ -e "$tmp/reorder.tmp" ]; then
    rm -f "$tmp/reorder.tmp"
  fi

  ## Count each line in the reqfile to see which number we should put on it.
  num=0
  for line in `cat $reqfile | tr -s ' ' '^' | tr -d ']' | tr -d '[' | cut -d':' -f2-`; do
    num=$[$num+1]
    if [ -z "$( echo "$num" | grep ".." )" ]; then
      newnum="[ $num:]"
    else
      newnum="[$num:]"
    fi

    ## Add requests to new reqfile.
    echo "$newnum $line" | tr -s '^' ' ' >> $tmp/reorder.tmp
  done

  ## Was any file created? Copy it if so. If not, no requests were found.
  if [ -e "$tmp/reorder.tmp" ]; then
    cp -f "$tmp/reorder.tmp" "$reqfile"
    rm -f "tmp/reorder.tmp"
  else
    ## Only say this if fix was run manually. Not when reqfilling etc.
    if [ "$name" = "fix" ]; then
      echo "No requests to fix was found."
    fi
  fi
}  

## Check for old requests.
proc_checkold() {
  if [ "$removedays" ]; then
    for line in `cat $reqfile | tr -s ' ' '^'`; do
      unset FIRST; unset SECOND; unset THIRD; unset GOTNAME; unset RELEASE
      unset SECONDSOLD; unset OLD; unset RELNUMBER
      if [ "$line" ]; then
        for each in `echo "$line" | tr -s '^' ' '`; do
          if [ "$GOTNAME" != "TRUE" ]; then
            if [ "$each" = "~" ]; then
              GOTNAME=TRUE
            else
              RELEASE="$each"
            fi
          fi
          FIRST="$SECOND"
          SECOND="$THIRD"
          THIRD="$each"
        done
        THIRD="$( echo "$THIRD" | tr -s '-' '/' )"
        SECONDSOLD="$( $datebin --date="$FIRST $SECOND $THIRD" +%s )"
        SECONDSMAX="$( $datebin --date "-$removedays day" +%s )"

        if [ "$SECONDSOLD" -lt "$SECONDSMAX" ]; then
          REAL_POSITION="$( echo "$line" | cut -d ']' -f1 )]"
          RELNUMBER="$( echo "$line" | cut -d ':' -f1 | tr -d '[' | tr -d ']' | tr -d ' ' | tr -d '^' )"
          OLD=TRUE
        fi
      fi

      ## This release is too old. Delete it.

      if [ "$OLD" = "TRUE" ]; then
        GOT_OLD_RELEASE="TRUE"
        if [ "$gllog" ]; then
          mode="gl"
          OUTPUT="$STATUSANNOUNCE"
          IRCOUTPUT="TRUE"
          proc_cookies
          proc_output "$OUTPUT $REAL_POSITION $RELEASE has been deleted because its older then $removedays days."
        fi
        if [ -d "$requests/$requesthead$RELEASE" ]; then
          rmdir "$requests/$requesthead$RELEASE" >/dev/null 2>&1
        fi

        proc_log "REQDELAUTO: \"crontab deleted $RELEASE - Older then $removedays days.\""
 
        DEL_NUMBERS="$DEL_NUMBERS $REAL_POSITION"

      fi

    done

    ## Announce the remaining requests.
    if [ "$GOT_OLD_RELEASE" = "TRUE" ]; then

      ## Make a new file without the reqfilled ones and copy it over the old one.
      for REAL_POSITION in $DEL_NUMBERS; do
        REAL_POSITION="`echo "$REAL_POSITION" | tr '^' ' '`"
        grep -vF "$REAL_POSITION" "$reqfile" > $tmp/newreqfile.tmp
        cp -f "$tmp/newreqfile.tmp" "$reqfile"
        rm -f "$tmp/newreqfile.tmp"
      done
      ## Reorder new one so numbers are linear.
      proc_reorder

      if [ "$showonauto" = "TRUE" ]; then
        auto="auto"
        proc_status
      fi
    fi

  fi      

  if [ "$removefdays" ]; then
    if [ -d "$requests" ]; then

      if [ -z "$mustinclude" ]; then
        mustinclude="."
      fi
      if [ -z "$exclude" ]; then
        exclude="fejfklJ252452delj"
      fi
      if [ ! -x "$file_date" ]; then
        echo "Was going to check for old requests, but file_date ($file_date) is not executable."
        exit 0
      fi

      cd $requests
      for dir in `ls | grep "$mustinclude" | egrep -v "$exclude"`; do
        # echo="checking $dir because its from $reldate"
        timestamp=`$file_date $dir`
        secsold=`$datebin -d "$timestamp" +%s`
        seclimit=`$datebin -d "-$removefdays day" +%s`
        if [ "$secsold" -lt "$seclimit" ]; then
          reldate=`$datebin -d "$timestamp" +%m%d`
          rm -rf "$dir"
          IRCOUTPUT="TRUE"
          if [ ! -e "$dir" ]; then
            if [ "$gllog" ]; then
              OUTPUT="$STATUSANNOUNCE"
              proc_cookies
              LINETOSAY="$OUTPUT Deleting $dir because its from $reldate"
              echo `$datebin "+%a %b %e %T %Y"` TURGEN: \"$LINETOSAY\" >> $gllog
              unset LINETOSAY
            fi
          else
            if [ "$gllog" ]; then
              OUTPUT="$STATUSANNOUNCE"
              proc_cookies
              LINETOSAY="$OUTPUT Was going to delete $dir because its from $reldate, but seems I couldnt."
              echo `$datebin "+%a %b %e %T %Y"` TURGEN: \"$LINETOSAY\" >> $gllog
              unset LINETOSAY
            fi
          fi
        fi
      done
    else
      echo "Should have checked for old requests, but $requests wasnt found or not a dir."
    fi
  fi
}

## Make a request.
proc_request() {

  proc_checkfile

  ## Dont mess with these ones.
  adddate="$( $datebin +%r" "%x | tr -s '/' '-' )"
  REQINFILE="%NUM% %WHAT% ~ by %WHO% (%MODE%) at %ADDDATE%"
  REQINFILE2="%NUM% %WHAT% ~ by %WHO% (%MODE%) for %FOR% at %ADDDATE%"

  ## If requesthead is set, is there already a dir with this name ?
  if [ "$requesthead" ]; then
    if [ -d "$requests/$requesthead$WHAT" ]; then
      if [ "$mode" = "irc" ]; then
        IRCOUTPUT="TRUE"
      fi
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi

  ## Is it already requested in file ? This one needs work to recognize . as a char.
  if [ "$( cat $reqfile | cut -c5- | grep -w -- "$WHAT " )" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$ALREADYREQUESTED"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  else
    ## Figure out which number its gonna get.
    num=1
    for each in `cat $reqfile | tr -s ' ' '^'`; do
      num=$[$num+1]
    done

    if [ "$max_requests" ]; then
      if [ "`cat $reqfile | wc -l | tr -d ' '`" -ge "$max_requests" ]; then
        OUTPUT="$TOOMANYREQUESTS"
        proc_cookies
        echo "$OUTPUT"
        exit 0
      fi
    fi

    if [ -z "$( echo "$num" | grep ".." )" ]; then
      num="\[ $num:\]"
    else
      num="\[$num:\]"
    fi

    ## Announce it unless gllog is empty ( not set ).
    if [ "$gllog" ]; then
      if [ -w "$gllog" ]; then
        if [ "$HIDE" != "TRUE" ]; then
          RELEASE="$num $WHAT"

          if [ "$FOR" ]; then
            OUTPUT="$REQANNOUNCE2"
          else
            OUTPUT="$REQANNOUNCE"
          fi
          IRCOUTPUT="TRUE"
          proc_cookies
          proc_output "$OUTPUT"
          IRCOUTPUT="FALSE"
        fi
      else
        echo "Error. Cant write to $gllog. Check paths and perms."
        exit 0
      fi
    fi

    ## Say "request added". Take output from GLOK. Only from glftpd. irc is handled in botscript.
    if [ "$mode" = "gl" ]; then
      if [ "$mode" = "irc" ]; then
        IRCOUTPUT="TRUE"
      fi
      OUTPUT="$GLOK"
      proc_cookies
      echo "$OUTPUT"
    fi

    ## Create the dir.
    if [ "$requesthead" ]; then
      mkdir -m777 "$requests/$requesthead$WHAT"
    fi

    ## Log it.
    proc_log "REQUEST: \"$BY requested $WHAT\""

    IRCOUTPUT="TRUE"
    if [ "$FOR" ]; then
      OUTPUT="$REQINFILE2"
    else
      OUTPUT="$REQINFILE"
    fi
    proc_cookies
    echo "$OUTPUT" >> $reqfile

    if [ "$showonrequest" = "TRUE" ]; then
      proc_status
    fi

    exit 0

  fi
} ## End of proc_request.


proc_reqfilled() {
  proc_checkfile

   if [ -z "$WHAT" ]; then
     echo "Specify the number when reqfilling."
     exit 0
   ## Changed to allow filling from name as well.
   #elif [ "`echo "$WHAT" | tr -d '[:digit:]'`" ]; then
   #  echo "Specify the number when reqfilling."
   #  exit 0
   fi

  ## Is it requested? (check by number)
  if [ -z "`echo "$WHAT" | tr -d '[:digit:]'`" ]; then
    if [ -z "$( echo "$WHAT" | grep ".." )" ]; then
      WHATNEW="\[ $WHAT:\]"
    else
      WHATNEW="\[$WHAT:\]"
    fi
  fi
  
  ## By default we pretend it was found in the request list. Will be set to FALSE if its actually not, below.
  REQUEST_FOUND="TRUE"

  if [ -z "`echo "$WHAT" | tr -d '[:digit:]'`" ]; then
    ## Check if requested by number
    if [ -z "$( cat $reqfile | cut -d ':' -f1 | cut -d '~' -f1 | tr -d '[' | tr -d ']' | grep -w -- "$WHAT" )" ]; then
      REQUEST_FOUND="FALSE"
    fi
  else
    ## Check if requested by name
    if [ -z "$( cat $reqfile | cut -d ']' -f2 | cut -d '~' -f1 | cut -c2- | grep -w -- "$WHAT" )" ]; then
      REQUEST_FOUND="FALSE"
    else

      ## It WAS requested by name. Extract the number of the release.
      WHATNEW="$( cat $reqfile | grep "\[[\ |0-9][0-9]:\] $WHAT \~" | cut -d ']' -f1 | head -n1 )"

      if [ -z "$WHATNEW" ]; then
        echo "Error. Found the $WHAT request in the list but failed to extract its number.."
        echo "Use the number instead."
        exit 0
      fi

      ## Add a ] at the end of it.
      WHATNEW="${WHATNEW}]"
      if [ "$mode" = "gl" ]; then
        echo "Request number for $WHAT seems to be: $WHATNEW"
      fi
    fi
  fi

  if [ "$REQUEST_FOUND" = "FALSE" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$NOTREQUESTED"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  else

    LINETODEL="$( cat "$reqfile" | grep -w "${WHATNEW}" | head -n1 )"

    ## If it should send messages, grab who made the request and who its for (if it was).
    if [ "$msgsdir" ]; then
      if [ "$( echo "$LINETODEL" | grep " for " )" ]; then
        REQUESTFOR=`echo "$LINETODEL" | cut -d ')' -f2 | cut -d ' ' -f3`
      fi
      REQUESTBY=`echo "$LINETODEL" | cut -d '~' -f2- | cut -d ' ' -f3`
    fi 

    ## Get release name.
    RELEASE=`echo "$LINETODEL" | cut -d ':' -f2 | cut -d '~' -f1 | cut -c2-`
    RELEASE=`echo $RELEASE` ## Clean it up from initial and ending spaces.

    case $name in
      reqfill)

        ## Check that its not empty.
        if [ -z "`ls -1 "$requests/$requesthead$RELEASE"`" ]; then
          if [ "$mode" = "gl" ]; then
            echo "$REQFILLEDEMPTY"
          else
            IRCOUTPUT="TRUE"
            OUTPUT="$REQFILLEDEMPTYIRC"
            proc_cookies
            echo "$OUTPUT"
          fi
          exit 0
        fi

        ## Fix the dir..
        if [ "$requesthead" ]; then
          if [ -d "$requests/$requesthead$RELEASE" ]; then

            ## If the filled dir already exists, add a number to the end of it.
            if [ -e "$requests/$filledhead$RELEASE" ]; then
              num=0; unset NUMBER; unset NOMOVE
              while [ -e "$requests/$filledhead$RELEASE$NUMBER" ]; do
                num=$[$num+1]
                NUMBER=$num
                if [ "$NUMBER" -gt "20" ]; then
                  NOMOVE=TRUE
                  break
                fi
              done
              if [ "$NOMOVE" != "TRUE" ]; then
                mv -f "$requests/$requesthead$RELEASE" "$requests/$filledhead$RELEASE$NUMBER"
              fi
            else
              ## All ok, just move the dir.
              mv -f "$requests/$requesthead$RELEASE" "$requests/$filledhead$RELEASE"
            fi

          else
            if [ "$mode" = "gl" ]; then
              requestname=`basename $requests`
              echo "$requesthead$RELEASE was not found in $requestname. Skipping rename or dir!"
              unset requestname
            fi
          fi
        fi

        if [ "$mode" = "gl" ]; then
          echo "$WHAT : $RELEASE has been filled. Thank you."
        fi

        proc_sendmsg "reqfilled" "Go fetch!"
        ACTION="reqfilled" ## Action for irc announce
        proc_log "REQFILL: \"$BY filled $RELEASE\""
        ;;

      reqdel)
        if [ "`echo "$BY" | grep -i "^$REQUESTBY$"`" ]; then
          ## Say this to glftpd in either case.
          if [ "$mode" = "gl" ]; then
            echo "$WHAT : $RELEASE has been deleted."
          fi

          if [ -d "$requests/$requesthead$RELEASE" ]; then
            rmdir "$requests/$requesthead$RELEASE" >/dev/null 2>&1
          fi

          proc_sendmsg "deleted" "Sorry!"
          ACTION="reqdelled" ## Action for irc announce
          proc_log "REQFILL: \"$BY deleted -reqdel- $RELEASE\""
        else
          echo "Permission denied. $RELEASE requested by $REQUESTBY, not $BY"
          exit 0
        fi
        ;;

      reqwipe) 
        if [ -d "$requests/$requesthead$RELEASE" ]; then
          rm -rf "$requests/$requesthead$RELEASE"
          if [ "$mode" = "gl" ]; then
            echo "Wiped out $requests/$requesthead$RELEASE"
          fi
        else
          echo "Gee, I would love to wipe out $RELEASE, but there is no such dir."
        fi

        proc_sendmsg "wiped" "Sorry!"
        ACTION="reqwiped" ## Action for irc announce
        proc_log "REQFILL: \"$BY wiped -reqwipe- $RELEASE\""
        ;;

    esac

    ## Make a new file without the reqfilled one and copy it over the old one.

    grep -wv "$WHATNEW" "$reqfile" > $tmp/newreqfile.tmp
    if [ -e "$tmp/newreqfile.tmp" ]; then
      cp -f "$tmp/newreqfile.tmp" "$reqfile"
      rm -f "$tmp/newreqfile.tmp"
    else
      echo "Error: $tmp/newreqfile.tmp was not created."
      exit 0
    fi
    ## Reorder new one so numbers are linear.
    proc_reorder

    if [ "$gllog" ]; then
      if [ -w "$gllog" ]; then
        if [ "$HIDE" != "TRUE" ]; then
          IRCOUTPUT="TRUE"
          OUTPUT="$FILLANNOUNCE"
          proc_cookies
          proc_output "$OUTPUT"
          IRCOUTPUT="FALSE"
        fi
      else
        echo "Error. Cant write to $gllog. Check paths and perms."
        exit 0
      fi
    fi

    if [ "$showonfill" = "TRUE" ]; then
      proc_status
    fi
  fi
}

proc_status() {
  if [ "$auto" = "auto" ]; then
    AUTO=TRUE
    mode="gl"
  fi

  if [ "$mode" = "irc" ]; then
    IRCOUTPUT="TRUE"
    ## Make HEADER ##
    OUTPUT="$STATUSANNOUNCE"
    proc_cookies
    HEADER="$OUTPUT"
  else
    IRCOUTPUT="FALSE"
  fi

  for each in `cat $reqfile | tr -s ' ' '^'`; do
    FOUNDONE="TRUE"

    ## Header stuff.
    if [ "$SAIDIT" != "TRUE" -a "$STATUSHEAD" != "" -a "$NOHEADFOOT" != "TRUE" -a "$HIDE" != "TRUE" ]; then
      OUTPUT="$STATUSHEAD"
      proc_cookies
      ## If its running 'status auto', always go to irc.
      if [ "$AUTO" = "TRUE" ]; then
        proc_output "$HEADER $OUTPUT"
      else
        echo "$HEADER $OUTPUT"
      fi
      SAIDIT="TRUE"

    fi

    ## Request. One per line in file.

    LINETOSAY=`echo "$each" | tr -s '^' ' '`
    OUTPUT="$LINETOSAY"
    proc_cookies
    if [ "$AUTO" = "TRUE" ]; then
      proc_output "$HEADER $OUTPUT"
    else
      echo "$HEADER $OUTPUT"
    fi

    unset LINETOSAY
  done
  unset SAIDIT

  ## Footer stuff.
  if [ "$FOUNDONE" != "TRUE" -a "$AUTO" != "TRUE" -a "$HIDE" != "TRUE" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$NOREQUESTS"
    proc_cookies
    if [ "$AUTO" = "TRUE" ]; then
      proc_output "$HEADER $OUTPUT"
    else
      echo "$HEADER $OUTPUT"
    fi
  fi

  if [ "$FOUNDONE" = "TRUE" -a "$TOFILL" != "" -a "$NOHEADFOOT" != "TRUE" -a "$HIDE" != "TRUE" ]; then
    if [ "$mode" = "irc" ]; then
      IRCOUTPUT="TRUE"
    fi
    OUTPUT="$TOFILL"
    proc_cookies
    if [ "$AUTO" = "TRUE" ]; then
      proc_output "$HEADER $OUTPUT"
    else
      echo "$HEADER $OUTPUT"
    fi
  fi
}

proc_sendmsg() {
  if [ "$msgsdir" ]; then
    if [ "$REQUESTFOR" ]; then

      if [ -e "$usersdir/$REQUESTFOR" ]; then
        ## -for: was specified. Sending message to that user.
        echo "--------------------------------------------------------------------------" >> $msgsdir/$REQUESTFOR
        echo "$RELEASE was requested by $REQUESTBY for you. $BY just $1 it. $2." >> $msgsdir/$REQUESTFOR
        echo "!HThis message was generated by Tur-Request $VER!0" >> $msgsdir/$REQUESTFOR
        echo " " >> $msgsdir/$REQUESTFOR
        chmod 666 $msgsdir/$REQUESTFOR >/dev/null 2>&1
      fi

      ## cc is TRUE. Sending a carbon copy to the requester.
      if [ "$cc" = "TRUE" -a "$REQUESTBY" ]; then
        if [ -e "$usersdir/$REQUESTBY" ]; then
          if [ "$BY" != "$REQUESTBY" ]; then
            echo "--------------------------------------------------------------------------" >> $msgsdir/$REQUESTBY
            echo "You requested $RELEASE for $REQUESTFOR. This has been $1 by $BY." >> $msgsdir/$REQUESTBY
            echo "!HThis message was generated by Tur-Request $VER!0" >> $msgsdir/$REQUESTBY
            echo " " >> $msgsdir/$REQUESTBY
            chmod 666 $msgsdir/$REQUESTBY >/dev/null 2>&1
          fi
        fi
      fi

    else
      ## No -for: was specified. Its for himself.
      if [ "$REQUESTBY" ]; then
        if [ -e "$usersdir/$REQUESTBY" ]; then
          if [ "$REQUESTBY" != "$BY" ]; then
            echo "--------------------------------------------------------------------------" >> $msgsdir/$REQUESTBY
            echo "Your request for $RELEASE has been $1 by $BY. $2!" >> $msgsdir/$REQUESTBY
            echo "!HThis message was generated by Tur-Request $VER!0" >> $msgsdir/$REQUESTBY
            echo " " >> $msgsdir/$REQUESTBY
            chmod 666 $msgsdir/$REQUESTBY >/dev/null 2>&1
          fi
        fi
      fi
    fi

  fi
}

## Here there be main menu, yar.
## By the way; http://happytreefriends.com
## What the fuck are you doing down here anyway?

case $RUN in
  request) name="request"; proc_verify; proc_request ;;
  reqfilled) name="reqfill"; proc_verify; proc_reqfilled ;;
  reqdel) name="reqdel"; reqdel=TRUE; proc_verify; proc_reqfilled ;;
  reqwipe) name="reqwipe"; reqwipe=TRUE; proc_verify; proc_reqfilled ;;
  status) name="status"; auto="$2"; proc_status ;;
  fix) name="fix"; proc_reorder ;;
  checkold) name="checkold"; proc_checkfile; proc_checkold ;;
  *) echo "Hm, didnt get any reasonable action. Dont run this from shell." ;;
esac

exit 0
