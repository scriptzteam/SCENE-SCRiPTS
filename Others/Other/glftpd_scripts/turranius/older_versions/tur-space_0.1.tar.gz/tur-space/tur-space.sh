#!/bin/bash
VER=0.1

## Remove # below to hardset config location
## If not, it will be read from the same dir as tur-space.sh is in.
# config=/glftpd/bin/tur-space.conf

###############################################################################
# No changes should be needed under here.                                     #
###############################################################################

## Load config file
if [ -z "$config" ]; then
  config="`dirname $0`/tur-space.conf"
fi

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$*"
  fi
}

proc_log() {
  if [ "$LOGFILE" ]; then
    echo `date "+%a %b %e %T %Y"` SPACE: \"$*\" >> $LOGFILE
  fi
}

proc_get_free_space() {
  trigger_device_check="$1"
  unset free_space
  free_space="`df -Pm | grep "$trigger_device_check" | tr -s ' ' | cut -d ' ' -f4`"
}

proc_get_release_size() {
  check_release_size="`du -csm "$source_release_path/$source_release" | tail -n1 | cut -f1`"
}

proc_find_oldest_dir() {

  source_dir="$1"
  source_name="$2"
  source_device="$3"

  cd $source_dir

  unset oldest_dir_raw

  if [ "$source_dated" != "DATED" ]; then
    unset DATED_
    oldest_dir_raw="`$TULS | grep "^d" | egrep -v "$IGNORES" | tr '^' ' ' | sort -k6 -n -r | tail -n1`"
    oldest_dir="`echo "$oldest_dir_raw" | awk -F"::::" '{print $4}'`"
    oldest_date="`echo "$oldest_dir_raw" | awk -F"::::" '{print $5}' | cut -d ' ' -f6`"
  else
    oldest_dir_raw="`$TULS | grep "^d" | egrep -v "$IGNORES" | tr -s ':' ' ' | sort -k4 -n -r | tail -n1`"
    oldest_dir="`echo "$oldest_dir_raw" | cut -d ' ' -f4`"
    oldest_date="`echo "$oldest_dir_raw" | cut -d ' ' -f7 | cut -d '^' -f3`"
    DATED_="(dated dir)"
  fi

  if [ -z "$oldest_dir_raw" ]; then
    proc_debug "Error: Did not find any dir to delete in $source_dir ($source_name). Quitting."
    proc_log "Error: Did not find any dir to delete in $source_dir ($source_name). Quitting."
    exit 1
  fi

  if [ "$DEBUG" = "TRUE" ]; then
    DEBUG_TIME="`date -d "1970-01-01 $oldest_date sec" +%F" "%T`"
  fi

  source_release_path="$source_dir"
  source_release="$oldest_dir"
  proc_get_release_size

  proc_debug "Oldest dir in $source_dir ($source_name) seems to be $oldest_dir ($check_release_size MB) <- $DEBUG_TIME"
  echo "$source_dir $source_name $oldest_dir $oldest_date $check_release_size" >> "$TMP/oldest_dir.tmp"
}

proc_find_destination_old() {
  destinations="$*"

  if [ -e "$TMP/oldest_dir.tmp" ]; then
    rm -f "$TMP/oldest_dir.tmp"
  fi

  for destination in $destinations; do
    dest_device="`echo "$destination" | cut -d ':' -f1`"
    dest_path="`echo "$destination" | cut -d ':' -f2`"
    if [ -z "`echo "$mount_errors" | grep " $dest_device "`" ]; then
      unset source_dated
      proc_find_oldest_dir $dest_path $source_name $dest_device
    fi
  done

  if [ ! -e "$TMP/oldest_dir.tmp" ]; then
    proc_debug "Error. Could not find oldest dir to remove from $destinations."
    proc_log "Error. Could not find oldest dir to remove from $destinations."
  else
    source_release_raw="`cat "$TMP/oldest_dir.tmp" | sort -k4 -n -r | tail -n1`"
    source_release_path="`echo "$source_release_raw" | cut -d ' ' -f1`"
    source_name="`echo "$source_release_raw" | cut -d ' ' -f2`"
    source_release="`echo "$source_release_raw" | cut -d ' ' -f3`"
    source_time="`echo "$source_release_raw" | cut -d ' ' -f4`"
    release_size="`echo "$source_release_raw" | cut -d ' ' -f5`"

#    source_device="`echo "$source_release_raw" | cut -d ' ' -f6`"
#    echo "$source_dir $source_name $oldest_dir $source_date $source_device" >> "$TMP/oldest_dir.tmp"
#    echo "proc_delete $source_release_path $source_release $source_size"

    proc_delete $source_release_path $source_release $source_size

    if [ -z "$looping_to_find_space" ]; then
      looping_to_find_space="true"
      ## Check free space on device now..
      proc_get_free_space $source_device

      destinations="$source_device:$source_release_path"

      while [ "$release_size" -ge "$free_space" ]; do
        proc_debug "Space on $source_device: $free_space MB. Need $release_size !!"

        if [ "$DEBUG" = "TRUE" ]; then IGNORES="$IGNORES|::$source_release::"; fi

        proc_find_oldest_dir $source_release_path $source_name $source_device

        if [ -z "$oldest_dir_raw" ]; then
          proc_debug "Error. Nothing to delete in $source_release_path on $source_device."
          proc_log "Error. Nothing to delete in $source_release_path on $source_device."
          break
        else

          source_release="`echo "$oldest_dir_raw" | cut -d ' ' -f3`"
          proc_get_release_size $source_release_path $source_release
          proc_delete $source_release_path $source_release $check_release_size
          if [ "$DEBUG" = "TRUE" ]; then
            free_space="`echo "$free_space + $check_release_size" | bc -l | cut -d '.' -f1 | tr -d ' '`"
          else
            proc_get_free_space $source_device
          fi

        fi
      done

      if [ "$DEBUG" = "TRUE" ]; then
        proc_debug "Space needed ($release_size) fixed. Would have moved the original release now."
        proc_log "Space needed ($release_size) fixed. Would have moved the original release now."
      fi

    fi
  fi
}

proc_delete() {

  source_release_path="$1"
  source_release="$2"
  source_size="$3"

  if [ "$mount_error" = "true" ]; then
    no_delete=true
    proc_log "WARNING. Will not delete $source_release_path/$source_release since we seem to have mount errors."
  else

    if [ ! -d "$source_release_path/$source_release" ]; then
      proc_debug "Error. Could not find $source_release_path/$source_release to delete !"
      proc_log "Error. Could not find $source_release_path/$source_release to delete !"
    else

      proc_get_release_size

      proc_log "Freeing $check_release_size MB from $source_release_path by deleting $source_release"

      if [ "$DEBUG" = "TRUE" ]; then
        proc_debug "would have executed rm -rf \"$source_release_path/$source_release\""
      else
        rm -rf "$source_release_path/$source_release"
        if [ -d "$source_release_path/$source_release" ]; then
          proc_log "Error. Deleted $source_release_path/$source_release but its still there! Quitting."
          exit 1
        fi
      fi
    fi

  fi
  if [ "$DEBUG" = "TRUE" ]; then IGNORES="$IGNORES|::$source_release::"; fi
}

proc_move() {
  if [ "`echo "$last_moved_release" | cut -d ':' -f1`" = "$source_release" ]; then
    last_moved_path="`echo "$last_moved_release" | cut -d ':' -f2`"
    last_moved_release="`echo "$last_moved_release" | cut -d ':' -f1`"
    proc_debug "Error: $last_moved_path/$last_moved_release was moved just before. Quitting."
    proc_log "Error: $last_moved_path/$last_moved_release was moved just before. Quitting."

    proc_exit
  fi

  source_release_path="$1"
  source_release="$2"
  dest_release_path="$3"
  source_size="$4"

  proc_log "$trigger_device at $trigger_device_free MB. Freeing $source_size MB by moving $source_release_path/$source_release -> $dest_release_path"

  if [ "$DEBUG" = "TRUE" ]; then
    proc_debug "Would have moved $source_release_path/$source_release ($source_size MB) to $dest_release_path"
  else

    cp -rf --preserve=timestamps "$source_release_path/$source_release" "$dest_release_path"

    num_files_source="`ls -1 "$source_release_path/$source_release" | wc -l | tr -d ' '`"
    num_files_dest="`ls -1 "$dest_release_path/$source_release" | wc -l | tr -d ' '`"
    if [ "$num_files_source" != "$num_files_dest" ]; then
      sleep 5
      num_files_source="`ls -1 "$source_release_path/$source_release" | wc -l | tr -d ' '`"
      num_files_dest="`ls -1 "$dest_release_path/$source_release" | wc -l | tr -d ' '`"
      if [ "$num_files_source" != "$num_files_dest" ]; then
        proc_log "Error: After copying $source_release from $source_release_path into $dest_release_path, the number of files does not match up. Source:$num_files_source Dest:$num_files_dest"
        proc_debug "Error. After copying $source_release from $source_release_path into $dest_release_path, the number of files does not match up. Source:$num_files_source Dest:$num_files_dest"
        proc_debug "Quitting and you should check why this happened on a simple copy."
        proc_exit
      fi
    else
      rm -rf "$source_release_path/$source_release"
    fi
  fi

  if [ "$DEBUG" = "TRUE" ]; then IGNORES="$IGNORES|::$source_release::"; fi

  last_moved_release="$source_release:$source_release_path"
}

proc_find_most_space_free() {
  destinations="$*"

  most_size=0
  for destination in `echo $destinations`; do
    dest_device="`echo "$destination" | cut -d ':' -f1`"
    dest_path="`echo "$destination" | cut -d ':' -f2`"

    proc_get_free_space $dest_device
    if [ -z "$free_space" ]; then
      proc_debug "Error. $dest_device dosnt seem mounted.. skipping that as destination."
      mount_error=true
      mount_errors=" $mount_errors $dest_device "
    elif [ "$free_space" -gt "$most_size" ]; then
      most_size="$free_space"
      most_size_device="$dest_device"
      most_size_path="$dest_path"
    fi
  done
  if [ -z "$most_size_device" ]; then
    proc_debug "Error. Seems I could not get a destination for $dest_device - Skipping."
  else
## FAKE
#most_size="500"

    proc_debug "Most free space seems to be in $most_size_path on $most_size_device ($most_size MB free)."
    ## Check if the release will fit there.
    release_size="`du -csm "$source_release_path/$source_release" | tail -n1 | cut -f1`"
    if [ -z "$release_size" ]; then
      proc_debug "Error. Couldnt get the size for $source_release - Skipping."
    else
      if [ "$release_size" -ge "$most_size" ]; then
        proc_debug "Seems $source_release ($release_size MB) would not fit in $most_size_path ($most_size MB free)"
        proc_log "$source_release ($release_size MB) would not fit in $most_size_path ($most_size MB)."

        if [ "$DEBUG" = "TRUE" ]; then IGNORES="$IGNORES|::$source_release::"; fi

        unset looping_to_find_space
        proc_find_destination_old $destinations
      else
        proc_move $source_release_path $source_release $most_size_path $release_size
      fi
    fi

  fi
}

proc_exit() {
  rm -f "$TMP/tur-space.lock"
  exit 0
}

proc_find_destination() {
  unset destination_found; unset destinations
  source_release_path="$1"
  source_release="$2"
  source_name="$3"

  proc_debug "Checking destinations for $source_release from $source_name in $source_release_path"

  for destination_dirs in `grep "^ARC$source_name=" $config`; do
    destination_found=TRUE
    dest_device="`echo "$destination_dirs" | cut -d '=' -f2 | cut -d ':' -f1`"
    dest_path="`echo "$destination_dirs" | cut -d ':' -f2`"
    proc_debug "Found destination: $dest_path on device $dest_device"
    destinations="$destinations $dest_device:$dest_path"
  done

  if [ -z "$destination_found" ]; then
    proc_debug "NO destination dir found. Deleting $source_release_path/$source_release."
    proc_delete $source_release_path $source_release
  else
    proc_find_most_space_free $destinations
  fi
}
  
proc_find_sourcedirs() {
  trigger_device_check="$1"

  if [ -e "$TMP/oldest_dir.tmp" ]; then
    rm -f "$TMP/oldest_dir.tmp"
  fi
  for incoming_sections in `grep "^INC" $config | grep "=$trigger_device_check:"`; do
    source_name="`echo "$incoming_sections" | cut -d '=' -f1 | cut -c4-`"
    source_dir="`echo "$incoming_sections" | cut -d ':' -f2`"
    source_dated="`echo "$incoming_sections" | cut -d ':' -f3`"
    proc_debug "Found source dir for section $source_name on $trigger_device_check - $source_dir - $source_dated"

    proc_find_oldest_dir $source_dir $source_name $source_dated
  done

  if [ ! -e "$TMP/oldest_dir.tmp" ]; then
    proc_debug "Error. No dir found to delete. Skipping."
  else

    source_release_raw="`cat "$TMP/oldest_dir.tmp" | sort -k4 -n -r | tail -n1`"
    source_release_path="`echo "$source_release_raw" | cut -d ' ' -f1`"
    source_name="`echo "$source_release_raw" | cut -d ' ' -f2`"
    source_release="`echo "$source_release_raw" | cut -d ' ' -f3`"
    proc_debug "Oldest dir on $trigger_device_check is $source_name -> $source_release_path/$source_release."

    proc_find_destination $source_release_path $source_release $source_name
  fi    
}


## Get dirs settings.
IGNORE_DIRS="`grep "^IGNORE=" $config | cut -d '=' -f2 | tr -d '"'`"
for ignore in $IGNORE_DIRS; do
  if [ -z "$IGNORES" ]; then
    IGNORES="::$ignore::"
  else
    IGNORES="::$ignore::|$IGNORES"
  fi
done
IGNORES="$IGNORES|^Listing\ |::\.::|::\.\.::"

TMP="`grep "^TMP=" $config | cut -d '=' -f2 | tr -d '"'`"
if [ -z "$TMP" ]; then
  TMP="/tmp"
fi
TULS="`grep "^TULS=" $config | cut -d '=' -f2 | tr -d '"'`"
if [ -z "$TULS" ]; then
  TULS="tuls"
fi

LOGFILE="`grep "^LOGFILE=" $config | cut -d '=' -f2 | tr -d '"'`"

if [ ! -x "$TULS" ]; then
  echo "Error. Can not execute tuls ( $TULS )."
  proc_log "Error. Can not execute tuls ( $TULS )."
  exit 1
fi

proc_verify_triggers() {
  if [ -z "$trigger_device" ]; then
    proc_debug "Error: In $triggers, I fail to find the device name. Check your config."
    proc_log "Error: In $triggers, I fail to find the device name. Check your config."
    exit 2
  elif [ -z "$trigger_free" ]; then
    proc_debug "Error: In $triggers, I fail to find the amount free to trigger on. Check your config."
    proc_log "Error: In $triggers, I fail to find the amount free to trigger on. Check your config."
    exit 2
  elif [ -z "$trigger_clean" ]; then
    proc_debug "Error: In $triggers, I fail to find the amount to make free. Check your config."
    proc_log "Error: In $triggers, I fail to find the amount to make free. Check your config."
    exit 2
  elif [ "`echo "$trigger_free" | tr -d '[:digit:]'`" ]; then
    proc_debug "Error: In $triggers, it seems that the amount of free space to trigger on is not a number. Check config."
    proc_log "Error: In $triggers, it seems that the amount of free space to trigger on is not a number. Check config."
    exit 2
  elif [ "`echo "$trigger_clean" | tr -d '[:digit:]'`" ]; then
    proc_debug "Error: In $triggers, it seems that the amount of free space to clean is not a number. Check config."
    proc_log "Error: In $triggers, it seems that the amount of free space to clean is not a number. Check config."
    exit 2
  fi
}

proc_sanity_check() {
  echo "Sanity check for Tur-Space $VER"
  echo "---------------------------------"

  for triggers in `grep "^TRIGGER=" $config`; do
    trigger_device="`echo "$triggers" | cut -d '=' -f2 | cut -d ':' -f1`"
    trigger_free="`echo "$triggers" | cut -d ':' -f2`"
    trigger_clean="`echo "$triggers" | cut -d ':' -f3`"

    proc_verify_triggers

    echo "Ignores set to: $IGNORES"
    echo ""
    echo "On device $trigger_device, we will check if theres less then $trigger_free MB free."
    echo "If there is, we will delete stuff until theres $trigger_clean MB free space."

    if [ -e "$TMP/oldest_dir.tmp" ]; then
      rm -f "$TMP/oldest_dir.tmp"
    fi

    echo "Source dirs for device $trigger_device are:"
    for incoming_sections in `grep "^INC" $config | grep "=$trigger_device:"`; do
      source_name="`echo "$incoming_sections" | cut -d '=' -f1 | cut -c4-`"
      source_dir="`echo "$incoming_sections" | cut -d ':' -f2`"
      source_dated="`echo "$incoming_sections" | cut -d ':' -f3`"
      echo " $source_dir"

      cd $source_dir

      if [ "$source_dated" != "DATED" ]; then
        unset DATED_
        oldest_dir_raw="`$TULS | grep "^d" | egrep -v "$IGNORES" | tr '^' ' ' | sort -k6 -n -r | tail -n1`"
        oldest_dir="`echo "$oldest_dir_raw" | awk -F"::::" '{print $4}'`"
        oldest_date="`echo "$oldest_dir_raw" | awk -F"::::" '{print $5}' | cut -d ' ' -f1-4`"
      else
        oldest_dir_raw="`$TULS | grep "^d" | egrep -v "$IGNORES" | tr -s ':' ' ' | sort -k4 -n -r | tail -n1`"
        oldest_dir="`echo "$oldest_dir_raw" | cut -d ' ' -f4`"
        oldest_date="`echo "$oldest_dir_raw" | cut -d ' ' -f5 | cut -d '^' -f1-3 | tr '^' ' '`"
        DATED_="(dated dir)"
      fi

      echo " - Oldest release seems to be $oldest_dir <- $oldest_date $DATED_"

      unset destination_found
      for destination_dirs in `grep "^ARC$source_name=" $config`; do
        destination_found=TRUE
        dest_device="`echo "$destination_dirs" | cut -d '=' -f2 | cut -d ':' -f1`"
        dest_path="`echo "$destination_dirs" | cut -d ':' -f2`"
        echo " -- Destination is $dest_path on $dest_device"
        df_verify="`df -PhT | grep "$dest_device" | tr -s ' '`"
        if [ -z "$df_verify" ]; then
          echo " --- ERROR! Device: $dest_device not found in df list. Sure its mounted?"
          echo " -----------------------------------------------------------------------"
          echo ""
        else
          device="`echo "$df_verify" | cut -d ' ' -f1`"
          file_system="`echo "$df_verify" | cut -d ' ' -f2`"
          total="`echo "$df_verify" | cut -d ' ' -f3`"
          used="`echo "$df_verify" | cut -d ' ' -f4`"
          free="`echo "$df_verify" | cut -d ' ' -f5`"
          percent_used="`echo "$df_verify" | cut -d ' ' -f6`"
          mounted_on="`echo "$df_verify" | cut -d ' ' -f7`"
          if [ -z "`echo "$dest_path" | grep "^$mounted_on"`" ]; then
            echo " --- WARNING! Device $device is mounted on $mounted_on but destination dir is set for $dest_path."
            echo " --- This might not be an error, but it looks like it."
            echo " --- df reports: Device:$device FS:$file_system Tot:$total Used:$used Free:$free %Use:$percent_used"
            echo " --- Mountpoint:$mounted_on"
            echo ""
          else
            echo " --- Looks good! df reports: Device:$device FS:$file_system Tot:$total Used:$used Free:$free %Use:$percent_used"
            echo " --- Mountpoint:$mounted_on"
            echo ""
          fi
        fi
      done
      if [ -z "$destination_found" ]; then
        echo " -- NO destination dir. Releases will be deleted."
      fi
      echo ""
    done

    echo ""
  done

  for rawdata in `grep "^ARC" $config`; do
    sec_name="`echo "$rawdata" | cut -d '=' -f1 | cut -c4-`"
    if [ -z "`grep "^INC$sec_name=" $config`" ]; then
      echo "Warning: Section $sec_name's archive defined as $rawdata - No source (INC$sec_name) found for that section."
      echo "It will be ignored."
    fi
  done

  proc_exit
} 

proc_help() {
  echo ""
  echo "Tur-Space $VER by Turranius."
  echo ""
  echo "Commands:"
  echo "sanity = Verify configuration in tur-space.conf"
  echo "go     = Proceed and move stuff."
  echo "         Specify 'debug' as second arg to enable debug output"
  echo "         Nothing is actually done in debug mode."
  echo ""
  proc_exit
}

proc_go() {
  for triggers in `grep "^TRIGGER=" $config`; do
    unset mount_error; unset no_delete; unset mount_errors; unset did_something

    trigger_device="`echo "$triggers" | cut -d '=' -f2 | cut -d ':' -f1`"
    trigger_free="`echo "$triggers" | cut -d ':' -f2`"
    trigger_clean="`echo "$triggers" | cut -d ':' -f3`"

    proc_verify_triggers

    proc_debug "Found trigger: $trigger_device - $trigger_free - $trigger_clean"
    proc_get_free_space $trigger_device

    trigger_device_free="$free_space"

    if [ -z "$free_space" ]; then
      proc_debug "Error. Could not get free space from device $trigger_device defined in $triggers - skipping"
      proc_log "Error: Could not get free space from device $trigger_device defined in $triggers - skipping"
    else
      proc_debug ""
      counter="0"
      unset said_header

      if [ "$free_space" -lt "$trigger_free" ]; then
        while [ "$free_space" -lt "$trigger_clean" ]; do

          did_something=true

          if [ -z "$said_header" ]; then
            proc_log "Device $trigger_device has $free_space MB free. Needs $trigger_clean MB so processing it."
            said_header="true"
          fi

          proc_debug ""
          proc_find_sourcedirs $trigger_device
          proc_get_free_space $trigger_device

          trigger_device_free="$free_space"

          if [ "$no_delete" = "true" ]; then
            proc_debug "Skipping $trigger_device since we have mount errors and its time to delete."
            unset no_delete
            break
          fi

          if [ "$DEBUG" = "TRUE" ]; then
            counter=$[$counter+1]
            if [ "$counter" -ge "20" ]; then
              proc_debug "Debug: Forcing Quit after 20 loops. Normally it wouldnt stop until its finished"
              proc_debug "or if there are errors."
              break
            fi
          fi

        done

        proc_log "Done. $free_space MB free on $trigger device"
      fi

      if [ -z "$did_something" ]; then
        proc_debug "$trigger_device got enough space already. Skipping."
      fi
    fi
  done

  proc_exit
}

case $2 in
  [dD][eE][bB][uU][gG]) DEBUG="TRUE" ;;
esac

if [ -e "$TMP/tur-space.lock" ]; then
  if [ "$1" = "sanity" ]; then  
    DEBUG="TRUE"
  fi
  proc_debug "Lockfile exists. Remove $TMP/tur-space.lock if you are sure its not running."
  if [ "$DEBUG" = "TRUE" ]; then
    LAST_ERROR="`grep "Error" $LOGFILE | tail -n1`"
    if [ "$LAST_ERROR" ]; then
      proc_debug "Last error was:"
      proc_debug "$LAST_ERROR"
    fi
  fi
  proc_log "Lockfile exists. Remove $TMP/tur-space.lock if you are sure its not running."
  exit 0
else
  touch "$TMP/tur-space.lock"
fi

case $1 in
  [sS][aA][nN][iI][tT][yY]) DEBUG="TRUE"; proc_sanity_check ;;
  [gG][oO]) proc_go ;;
  *) proc_help ;;
esac

proc_exit
