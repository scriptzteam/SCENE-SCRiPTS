#!/bin/bash
VER=1.0
#--[ Intro ]---------------------------------------------------#
#                                                              #
# Tur-ListIdle. A script to show when users last logged in.    #
# Speciality includes letting defined users also check their   #
# groups and/or let gadmins check their own users only.        #
#                                                              #
#--[ Installation ]--------------------------------------------#
#                                                              #
# Copy tur-listidle.sh to /glftpd/bin and chmod it to 755.     #
#                                                              #
# Edit your glftpd.conf and add two lines:                     #
# site_cmd listidle EXEC /bin/tur-listidle.sh                  #
# custom-listidle *                                            #
#                                                              #
# Make sure you have the following binaries in /glftpd/bin:    #
# egrep, grep, date & cut                                      #
#                                                              #
#--[ Configuration ]-------------------------------------------#
#                                                              #
# GLROOT    = Path to your glftpd directory.                   #
#                                                              #
# USER_DIR  = Path to your users dir, seen from GLROOT above.  #
#                                                              #
# SEE_ALL   = Here you set which flags are allowed to see all  #
#             users without restriction. Seperate them with a  #
#             | sign. Example: "1|7" would let users with flag #
#             1 or 7 to see all users.                         #
#             Set to "" to not let anyone do that.             #
#                                                              #
# SEE_OWN   = Here you set which flags are allowed to see idle #
#             time for users in their own group(s).            #
#                                                              #
# SEE_OWN_PRIMARY_ONLY =                                       #
#             TRUE/FALSE. With TRUE, users in glftpd versions  #
#             1.+ can only see other status of users in their  #
#             primary group.                                   #
#             On glftpd 2.+ versions, they can see everyone    #
#             in the groups in which they currently are gadmin.#
#                                                              #
# LIMIT_DAYS= If you only wish to show people that have been   #
#             idle a number of days minumum, set the number of #
#             days here. "" to show everyone.                  #
#                                                              #
# SHOW_FULL_TIME =                                             #
#             TRUE/FALSE. With TRUE, it will split up the time #
#             in years, weeks, days, hours, minutes, seconds.  #
#             With FALSE, it will only show the number of days.#
#                                                              #
# GLVERSION = 1/2. Set which version of glftpd you are running.#
#                                                              #
# Now, try 'site listidle' from your site.                     #
#                                                              #
# If running it from shell, it will automatically grant you    #
# access to see all users.                                     #
#                                                              #
#--[ Contact ]-------------------------------------------------#
#                                                              #
# http://www.grandis.nu or http://grandis.mine.nu              #
#                                                              #
#--[ Settings ]------------------------------------------------#

GLROOT=/glftpd
USER_DIR=/ftp-data/users
SEE_ALL="1|7"
SEE_OWN="3"
SEE_OWN_PRIMARY_ONLY="TRUE"
LIMIT_DAYS="7"
SHOW_FULL_TIME="TRUE"
GLVERSION=1


#--[ Script Start ]--------------------------------------------#

if [ "$FLAGS" ]; then
  mode="gl"
else
  mode="shell"
  USER_DIR="$GLROOT$USER_DIR"
fi

if [ ! -e "$USER_DIR" ]; then
  echo "Can not find $USER_DIR - Check paths and perms"
  exit 1
fi

if [ -x "date" ]; then
  echo "Error. You need the date binary in glftpd's bin dir."
  exit 1
fi

if [ -z "$SEE_ALL" ]; then
  SEE_ALL="~"
fi
if [ -z "$SEE_OWN" ]; then
  SEE_OWN="~"
fi

if [ "$mode" = "shell" ]; then
  permission="full"
else
  if [ "`grep "^FLAGS\ " $USER_DIR/$USER | cut -d ' ' -f2 | egrep "$SEE_ALL"`" ]; then
    permission="full"
  elif [ "`grep "^FLAGS\ " $USER_DIR/$USER | cut -d ' ' -f2 | egrep "$SEE_OWN"`" ]; then
    permission="own"
  else
    permission="denied"
  fi
fi

if [ "$permission" = "denied" ]; then
  echo "You do not have access to this command."
  exit 1
fi

proc_calctime() {
  unset ago
  YEARDIFF=0
  WEEKDIFF=0
  DAYDIFF=0
  MINDIFF=0
  SECDIFF=0

  let DIFF=$timenow-$laston;

  if [ $DIFF -lt 0 ]; then
    let DIFF=DIFF*-1
  fi

  let PERC=$DIFF/60;
  let ORA=$PERC/60;
  let DAYDIFF=$ORA/24;

  DAYSAGO="$DAYDIFF"

  if [ "$SHOW_FULL_TIME" = "FALSE" ]; then
    ago="$DAYSAGO days"
    return
  fi

  let HOURDIFF=$ORA-24*$DAYDIFF;
  let MINDIFF=$PERC-60*$ORA
  let SECDIFF=$DIFF-60*$PERC

  ## Years old ?
  if [ "$DAYDIFF" -gt "730" ]; then
    DAYDIFF=$[$DAYDIFF-730]
    ago="2 Years"
    YEARDIFF="2"
  elif [ "$DAYDIFF" -gt "365" ]; then
    DAYDIFF=$[$DAYDIFF-365]
    ago="1 Year"
    YEARDIFF="1"
  fi

  ## Weeks.
  if [ "$DAYDIFF" -gt "7" ]; then
    WEEKDIFF=0
    while [ "$DAYDIFF" -gt "7" ]; do
      WEEKDIFF=$[$WEEKDIFF+1]
      DAYDIFF=$[$DAYDIFF-7]
    done
    if [ "$WEEKDIFF" -gt "1" ]; then
      if [ "$ago" ]; then
        ago="$ago, $WEEKDIFF Weeks, $DAYDIFF Days"
      else
        ago="$WEEKDIFF Weeks, $DAYDIFF Days"
      fi
    else
      if [ "$ago" ]; then
        ago="$ago, $WEEKDIFF Week, $DAYDIFF Days"
      else
        ago="$WEEKDIFF Week, $DAYDIFF Days"
      fi
    fi

  ## Days
  else
    WEEKDIFF=0
    if [ "$DAYDIFF" != "0" ]; then
      if [ "$DAYDIFF" -gt "1" ]; then
        if [ "$ago" ]; then
          ago="$ago, $DAYDIFF Days"
        else
          ago="$DAYDIFF Days"
        fi
      else
        if [ "$ago" ]; then
          ago="$ago, $DAYDIFF Day"
        else
          ago="$DAYDIFF Day"
        fi
      fi
    fi
  fi

  ## Hours
  if [ "$HOURDIFF" != "0" ]; then
    if [ "$ago" ]; then
      if [ "$HOURDIFF" -gt "1" ]; then
        ago="$ago, $HOURDIFF Hours"
      else
        ago="$ago, $HOURDIFF Hour"
      fi
    else
      if [ "$HOURDIFF" -gt "1" ]; then
        ago="$HOURDIFF Hours"
      else
        ago="$HOURDIFF Hour"
      fi
    fi
  fi

  ## Minutes
  if [ "$MINDIFF" != "0" ]; then
    if [ "$ago" ]; then
      if [ "$MINDIFF" -gt "1" ]; then
        ago="$ago, $MINDIFF Mins"
      else
        ago="$ago, $MINDIFF Min"
      fi
    else
      if [ "$MINDIFF" -gt "1" ]; then
        ago="$MINDIFF Minutes"
      else
        ago="$MINDIFF Minute"
      fi
    fi
  fi

  ## Seconds
  if [ "$SECDIFF" != "0" ]; then

    if [ "$SECDIFF" -lt "0" ]; then
      proc_log "$SECDIFF seconds. Aborting."
      exit 0
    fi

    if [ "$ago" ]; then
      if [ "$SECDIFF" -gt "1" ]; then
        ago="$ago, $SECDIFF Secs"
      else
        ago="$ago, $SECDIFF Sec"
      fi
    else
      if [ "$SECDIFF" -gt "1" ]; then
        ago="$SECDIFF Seconds"
      else
        ago="$SECDIFF Second"
      fi
    fi
  fi

  if [ "$DAYSAGO" -gt "1000" ]; then
    ago="several years"
  fi

  if [ -z "$ago" ]; then
    ago="0 seconds"
  fi
}

proc_counttime() {
  laston="`grep "^TIME\ " $username | cut -d ' ' -f3`"
  if [ -z "$laston" ]; then
    echo "Error. Cant read TIME on $username - Skipping."
  else
    proc_calctime

    while [ -z "`echo "$username" | grep ".........."`" ]; do
      username="$username "
    done

    if [ "$LIMIT_DAYS" ]; then
      if [ "$LIMIT_DAYS" -le "$DAYSAGO" ]; then
        echo "$username last online: $ago ago"
        FOUND_ONE="TRUE"
      fi
    else
      echo "$username last online: $ago ago"
      FOUND_ONE="TRUE"
    fi
  fi
}    
  
cd "$USER_DIR"

echo "#--[ Tur-ListIdle $VER - Showing when users were last logged on. ]--#"

timenow="`date +%s`"
if [ "$permission" = "full" ]; then
  for username in `grep "^TIME\ " * | cut -d ':' -f1 | grep -v "default.user"`; do
    proc_counttime
  done
elif [ "$permission" = "own" ]; then
  if [ "$SEE_OWN_PRIMARY_ONLY" != "TRUE" ]; then
    for own_group in `grep "^GROUP\ " $USER | cut -d ' ' -f2`; do
      if [ "$GLVERSION" = "1" ]; then
        echo "In group: $own_group"
        for username in `grep "^GROUP $own_group$" * | cut -d ':' -f1 | grep -v "default.user"`; do
          if [ "$username" != "$USER" ]; then
            proc_counttime
          fi
        done
      else
        echo "In group: $own_group"
        for username in `grep "^GROUP $own_group\ [0-1]$" * | cut -d ':' -f1 | grep -v "default.user"`; do
          if [ "$username" != "$USER" ]; then
            proc_counttime
          fi
        done
      fi
    done
  else
    if [ "$GLVERSION" = "1" ]; then
      echo "In group: $GROUP"
      for username in `grep "^GROUP $GROUP$" * | cut -d ':' -f1 | egrep -v "default.user|$USER$"`; do
        if [ "$username" != "$USER" ]; then
          proc_counttime
        fi
      done
    else
      for own_group in `grep "^GROUP\ .*\ 1$" $USER | cut -d ' ' -f2`; do
        echo "In group: $own_group"
        for username in `grep "^GROUP $own_group [0-1]$" * | cut -d ':' -f1`; do
          if [ "$username" != "$USER" ]; then
            proc_counttime
          fi
        done
      done
    fi
  fi
fi

if [ -z "$FOUND_ONE" ]; then
  if [ "$LIMIT_DAYS" ]; then
    echo "No users found to be idle more then $LIMIT_DAYS days."
  else
    echo "No users found.."
  fi
fi

echo ""

exit 0
