#!/usr/bin/perl
## This is a small script made by avizion to emulate 
## the 'ls -m' function in FreeBSD so that tur-autonuke
## works in that distro too. Too use this one, make it executable
## and specify its full path in the LSM variable in tur-autonuke.conf
##
## Oh yeah, perl must be installed. Do a 'which perl' and set the first
## line in this script to that file. Try and run fbsd_ls.sh from shell
## and it should return every file in one line with a , inbetween.

my $oldpwd = $ENV{PWD};
if ( @ARGV[0] ne "" ) { chdir @ARGV[0]; }
print join(', ', split(/\n/, `ls -1`) )."\n";
chdir $oldpwd;