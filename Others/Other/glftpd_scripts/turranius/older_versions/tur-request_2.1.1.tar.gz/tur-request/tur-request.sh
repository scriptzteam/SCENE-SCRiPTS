#!/bin/bash
VER=2.1.1
#-[ Settings ]--------------------------------------------------#

## Leave this marked out and it will read the config from the
## same directory as tur-request.sh is located. Otherwise you may
## specify where it is.
# config=/glftpd/bin/tur-request.conf


#-[ Script Start ]----------------------------------------------#
#                                                               #
# No changes below here unless you want to change some text.    #
#                                                               #
#---------------------------------------------------------------#

## Read config
if [ -z $config ]; then
  config="`dirname $0`/tur-request.conf"
fi
if [ ! -r $config ]; then
  echo "Error. Cant not read $config"
  exit 0
else
  . $config
fi

## Check if we're in glftpd or shell (irc)..
if [ "$FLAGS" ]; then
  mode=gl
  BY="$USER"
else
  mode=irc
  requests=$glroot$requests
  reqfile=$glroot$reqfile
  tmp=$glroot$tmp
  if [ "$gllog" ]; then
    gllog=$glroot$gllog
  fi
  if [ "$log" ]; then
    log="$glroot$log"
  fi
fi

proc_mainerror() {
  echo "Got neither request, reqfilled, reqwipe, status, fix or checkold... quitting."
  exit 1
}

if [ -z "$1" ]; then
  proc_mainerror
fi

## Procedure for logging
proc_log() {
  if [ "$log" ]; then
    if [ -w "$log" ]; then
      echo `date "+%a %b %e %T %Y"` "$@" >> $log
    else
      if [ "$USER" = "root" ]; then
        touch $log
        if [ -x "chmod" ]; then
          chmod 777 $log
        fi
      else
        logname=`basename $log`
        echo "Error: Can not write to $logname. Create and set 777."
      fi
    fi
  fi
}

## Heres where we change those %blabla% into real text.
proc_cookies() {
  if [ "$BY" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%WHO%/$BY/g"`
  fi
  if [ "$WHAT" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%WHAT%/$WHAT/g"`
  fi
  if [ "$mode" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%MODE%/$mode/g"`
  fi
  if [ "$name" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%NAME%/$name/g"`
  fi
  if [ "$adddate" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%ADDDATE%/$adddate/g"`
  fi
  if [ "$requesthead" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%REQUESTHEAD%/"$requesthead"/g"`
  fi
  if [ "$filledhead" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%FILLEDHEAD%/$filledhead/g"`
  fi
  if [ "$HOWTOFILL" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%HOWTOFILL%/$HOWTOFILL/g"`
  fi
  if [ "$sitename" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%SITENAME%/$sitename/g"`
  fi
  if [ "$FOR" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%FOR%/$FOR/g"`
  fi
  if [ "$num" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%NUM%/$num/g"`
  fi
  if [ "$mode" = "irc" ]; then
    OUTPUT=`echo $OUTPUT | sed -e "s/%BOLD%//g"`
    OUTPUT=`echo $OUTPUT | sed -e "s/%ULINE%//g"`
  else
    OUTPUT=`echo $OUTPUT | sed -e "s/%BOLD%//g"`
    OUTPUT=`echo $OUTPUT | sed -e "s/%ULINE%//g"`
  fi
}

## Get all arguments into RAWSTRING.
RAWSTRING="$@"

unset ERROR
if [ "$mode" = "gl" ]; then
  if [ -z "$( echo "$RAWSTRING" | cut -d ' ' -f2 )" ]; then
    ERROR=TRUE
  fi
  HOWTOFILL='site reqfilled <number>'
else
  if [ -z "$( echo "$RAWSTRING" | cut -d ' ' -f3 )" ]; then
    ERROR=TRUE
  fi
  HOWTOFILL='!reqfilled <number>'
fi

if [ "$mode" != "gl" ]; then
  ## If from irc, cut out second word to BY. This is who its from.
  BY=`echo "$RAWSTRING" | cut -d ' ' -f2`
  ## Remove that one when done.
  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/$BY //"`
fi

## Check first word. This is the action to take (request, reqfilled etc).
RUN=`echo "$RAWSTRING" | cut -d' ' -f1`
## Remove run command from RAWSTRING.
RAWSTRING=`echo "$RAWSTRING" | sed -e "s/^$RUN //"`

## Check if -hide is in RAWSTRING. If so, remove it and set HIDE=TRUE
if [ "$( echo "$RAWSTRING" | grep -w "\-hide" )" ]; then
  HIDE=TRUE
  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/\-hide//"`
else
  HIDE=FALSE
fi

## Clear up RAWSTRING from stand and ending spaces.
RAWSTRING=`echo $RAWSTRING`

## Check if -for: is in RAWSTRING. If so, cut it out and check who its for.
unset FOR; unset FORLAST
if [ "$( echo "$RAWSTRING" | grep '\-for\:' )" ]; then
  for crap in $RAWSTRING; do
    if [ "$( echo "$crap" | grep '\-for\:' )" ]; then
      FOR=`echo $crap | cut -d ':' -f2`
      break
    fi
  done

  ## Check that FOR isnt empty.
  if [ -z "$FOR" ]; then
    echo "When using '-for:' then specify a user who its for too."
    exit 0
  fi

  RAWSTRING=`echo "$RAWSTRING" | sed -e "s/\-for:$FOR//"`

  unset FORLAST
fi

## Clear up RAWSTRING
RAWSTRING=`echo $RAWSTRING`

## Whats left of RAWSTRING should be the release I hope. Remove any excess spaces.
WHAT=`echo "$RAWSTRING" | tr -s ' '`

## DEBUG VALUES. Remove below #'s to only get debug output.
# echo "full  : <$@>"
# echo "by    : <$BY>"
# echo "action: <$RUN>"
# echo "hide  : <$HIDE>"
# echo "for   : <$FOR>"
# echo "rel   : <$RAWSTRING>"
# exit 0

## Check if allowspace is FALSE.
if [ "$allowspace" = "FALSE" ]; then
  ## If it was, check if theres a space in $WHAT
  if [ "$( echo "$WHAT" | grep ' ' )" ]; then
    ## If there was a space, check if replacewith is set.
    if [ "$replacewith" ]; then
      ## If it was, replace all spaces with it.
      WHAT=`echo "$WHAT" | tr ' ' "$replacewith"`
    else
      ## If replacewith is empty, say the NOSPACES error.
      OUTPUT=$NOSPACES
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi
fi  

## Verify that $WHAT is set etc. If no argument is given...
proc_verify() {

  ## Check that $WHAT does not include bad chars..."
  if [ "$( echo "$WHAT" | egrep "\*|\[|\]|\{|\]|\^|\~" )" ]; then
    OUTPUT="$NONSTANDARDCHAR"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  fi

  if [ -z "$WHAT" -o "$ERROR" = "TRUE" ]; then
    OUTPUT="$NOARGUMENT"
    proc_cookies
    echo "$OUTPUT"
    AUTO="TRUE"
    proc_status
    exit 0
  fi

  if [ ! -d "$tmp" ]; then
    if [ "$mode" = "irc" ]; then
      echo "Error. Cant find $tmp. Create it and set 777 in it."
    else
      echo "Error. Cant find $glroot$tmp. Create it and set 777 in it."
    fi
    exit 0
  fi
  touch "$tmp/testtouch.tmp"
  if [ ! -e "$tmp/testtouch.tmp" ]; then
    if [ "$mode" = "irc" ]; then
      echo "Error. Cant write to $tmp. Check perms."
    else
      echo "Error. Cant write to $glroot$tmp. Check perms."
    fi
    exit 0
  fi
  rm -f $tmp/testtouch.tmp

}

## Does the reqfile exist and can we read it?
proc_checkfile() {
  if [ ! -e "$reqfile" ]; then
    echo "Can not find $reqfile. Create it and set proper perms on it (777)"
    exit 0
  fi
  if [ ! -w "$reqfile" ]; then
    echo "Found requestfile, but can not write to it. Set proper perms on it."
    exit 0
  fi
}

## Reorder reqfile so numbers are in order.
proc_reorder() {
  ## Can the reqfile be written to?
  if [ ! -w "$reqfile" ]; then
    echo "Cant read $reqfile for fix. Create it and/or set perms."
    exit 0
  fi

  ## Remove previous file just incase.
  if [ -e "$tmp/reorder.tmp" ]; then
    rm -f "$tmp/reorder.tmp"
  fi

  ## Count each line in the reqfile to see which number we should put on it.
  num=0
  for line in `cat $reqfile | tr -s ' ' '^' | tr -d ']' | tr -d '[' | cut -d':' -f2-`; do
    num=$[$num+1]
    if [ `echo "$num" | wc -L | tr -d ' '` = '1' ]; then
      newnum="[ $num:]"
    else
      newnum="[$num:]"
    fi

    ## Add requests to new reqfile.
    echo "$newnum $line" | tr -s '^' ' ' >> $tmp/reorder.tmp
  done

  ## Was any file created? Copy it if so. If not, no requests were found.
  if [ -e "$tmp/reorder.tmp" ]; then
    cp -f "$tmp/reorder.tmp" "$reqfile"
    rm -f "tmp/reorder.tmp"
  else
    ## Only say this if fix was run manually. Not when reqfilling etc.
    if [ "$name" = "fix" ]; then
      echo "No requests to fix was found."
    fi
  fi
}  

## Check for old requests.
proc_checkold() {
  if [ "$removedays" ]; then
    for line in `cat $reqfile | tr -s ' ' '^'`; do
      unset FIRST; unset SECOND; unset THIRD; unset GOTNAME; unset RELEASE
      unset SECONDSOLD; unset OLD; unset RELNUMBER
      if [ "$line" ]; then
        for each in `echo "$line" | tr -s '^' ' '`; do
          if [ "$GOTNAME" != "TRUE" ]; then
            if [ "$each" = "~" ]; then
              GOTNAME=TRUE
            else
              RELEASE="$each"
            fi
          fi
          FIRST="$SECOND"
          SECOND="$THIRD"
          THIRD="$each"
        done
        THIRD="$( echo "$THIRD" | tr -s '-' '/' )"
        SECONDSOLD="$( date --date="$FIRST $SECOND $THIRD" +%s )"
        SECONDSMAX="$( date --date "-$removedays day" +%s )"

        if [ "$SECONDSOLD" -lt "$SECONDSMAX" ]; then
          RELNUMBER="$( echo "$line" | cut -d ':' -f1 | tr -d '[' | tr -d ']' | tr -d ' ' | tr -d '^' )"
          OLD=TRUE
        fi
      fi

      ## This release is too old. Delete it by running tur-request.sh again with reqdelauto.
      if [ "$OLD" = "TRUE" ]; then
        SCRIPTNAME="$0"
        $SCRIPTNAME reqdelauto AUTO $RELNUMBER
      fi
    done
  fi

  if [ "$removefdays" ]; then
    if [ -d "$requests" ]; then

      if [ -z "$mustinclude" ]; then
        mustinclude="."
      fi
      if [ -z "$exclude" ]; then
        exclude="fejfklJ252452delj"
      fi
      if [ ! -x "$file_date" ]; then
        echo "Was going to check for old requests, but file_date ($file_date) is not executable."
        exit 0
      fi

      cd $requests
      for dir in `ls | grep "$mustinclude" | egrep -v "$exclude"`; do
        echo="checking $dir because its from $reldate"
        timestamp=`$file_date $dir`
        secsold=`date -d "$timestamp" +%s`
        seclimit=`date -d "-$removefdays day" +%s`
        if [ "$secsold" -lt "$seclimit" ]; then
          reldate=`date -d "$timestamp" +%m%d`
          echo "Deleteting $dir because its from $reldate"
          rm -rf "$dir"
          if [ ! -e "$dir" ]; then
            if [ "$gllog" ]; then
              LINETOSAY="Deleteting $dir because its from $reldate"
              echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$LINETOSAY\" >> $gllog
              unset LINETOSAY
            fi
          else
            if [ "$gllog" ]; then
              LINETOSAY="Was going to delete $dir because its from $reldate, but seems I couldnt."
              echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$LINETOSAY\" >> $gllog
              unset LINETOSAY
            fi
          fi
        fi
      done
    else
      echo "Should have checked for old requests, but $requests wasnt found or not a dir."
    fi
  fi
}

## Make a request.
proc_request() {

  proc_checkfile

  ## Dont mess with these ones.
  adddate="$( date +%r" "%x | tr -s '/' '-' )"
  REQINFILE="%NUM% %WHAT% ~ by %WHO% (%MODE%) at %ADDDATE%"
  REQINFILE2="%NUM% %WHAT% ~ by %WHO% (%MODE%) for %FOR% at %ADDDATE%"

  ## If requesthead is set, is there already a dir with this name ?
  if [ "$requesthead" ]; then
    if [ -d "$requests/$requesthead$WHAT" ]; then
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi

  ## Is it already requested in file ? This one needs work to reqognize . as a char.
  if [ "$( cat $reqfile | cut -c5- | grep -w -- "$WHAT " )" ]; then
    OUTPUT="$ALREADYREQUESTED"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  else
    ## Figure out which number its gonna get.
    num=1
    for each in `cat $reqfile | tr -s ' ' '^'`; do
      num=$[$num+1]
    done
    if [ `echo "$num" | wc -L | tr -d ' '` = '1' ]; then
      num="\[ $num:\]"
    else
      num="\[$num:\]"
    fi

    ## Announce it unless gllog is empty ( not set ).
    if [ "$gllog" ]; then
      if [ -w "$gllog" ]; then
        if [ "$HIDE" != "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` REQUEST: \"$WHAT\" \"$BY\" >> $gllog
        fi
      else
        echo "Error. Cant write to $gllog. Check paths and perms."
        exit 0
      fi
    fi

    ## Say "request added". Take output from GLOK. Only from glftpd. irc is handled in botscript.
    if [ "$mode" = "gl" ]; then
      OUTPUT="$GLOK"
      proc_cookies
      echo "$OUTPUT"
    fi

    ## Create the dir.
    if [ "$requesthead" ]; then
      mkdir -m777 "$requests/$requesthead$WHAT"
    fi

    ## Log it.
    proc_log "REQUEST: \"$BY requested $WHAT\""

    if [ "$FOR" ]; then
      OUTPUT="$REQINFILE2"
    else
      OUTPUT="$REQINFILE"
    fi
    proc_cookies
    echo "$OUTPUT" >> $reqfile
    exit 0

  fi

  ## End of proc_request.
}

proc_reqfilled() {
  proc_checkfile

  if [ "$( echo "$WHAT" | tr -d [0123456789*REPEAT] )" ]; then
    echo "Specify the number when reqfilling."
    exit 0
  fi

  ## Is it requested?
  if [ `echo "$WHAT" | wc -L | tr -d ' '` = '1' ]; then
    WHATNEW="\[ $WHAT:\]"
  else
    WHATNEW="\[$WHAT:\]"
  fi
  if [ -z "$( cat $reqfile | cut -d ':' -f1 | cut -d '~' -f1 | tr -d '[' | tr -d ']' | grep -w -- "$WHAT" )" ]; then
    OUTPUT="$NOTREQUESTED"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  else

    LINETODEL="$( cat "$reqfile" | grep "^$WHATNEW " | head -n1 )"

    ## Get release name. Kinda ugly but what the heck..
    RELEASE=`echo "$LINETODEL" | cut -d ':' -f2 | cut -d '~' -f1 | cut -c2-`
    for each in $RELEASE; do
      if [ "$RELEASENEW" ]; then
        RELEASENEW="$RELEASENEW $each"
      else
        RELEASENEW="$each"
      fi
    done
    RELEASE="$RELEASENEW"; unset RELEASENEW

    ## Make a new file without the reqfilled one and copy it over the old one.
    grep -v "^$WHATNEW" "$reqfile" > $tmp/newreqfile.tmp
    if [ -e "$tmp/newreqfile.tmp" ]; then
      cp -f "$tmp/newreqfile.tmp" "$reqfile"
      rm -f "$tmp/newreqfile.tmp"
    else
      echo "Error: $tmp/newreqfile.tmp was not created."
      exit 0
    fi
    ## Reorder new one so numbers are linear.
    proc_reorder

    ## IF WIPE COMMAND, DEL THE REQUEST. IF NOT, FILL IT.
    if [ "$name" = "reqwipe" ]; then
      if [ -d "$requests/$requesthead$RELEASE" ]; then
        rm -rf "$requests/$requesthead$RELEASE"
        if [ "$mode" = "gl" ]; then
          echo "Wiped out $requests/$requesthead$RELEASE"
        fi
        if [ "$HIDE" != "TRUE" ]; then
          if [ "$gllog" ]; then
            echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$RELEASE was wiped by $BY\" >> $gllog
          fi
          HIDE=TRUE
        fi
      else
        echo "Gee, I would love to wipe out $RELEASE, but there is no such dir."
      fi
    else
      ## It will end here if reqdel or reqdelauto was issued. That will be delled further down.
      if [ "$requesthead" != "" -a "$name" != "reqdel" -a "$name" != "reqdelauto" ]; then
        if [ -d "$requests/$requesthead$RELEASE" ]; then

          ## If the filled dir already exists, add a number to the end of it.
          if [ -e "$requests/$filledhead$RELEASE" ]; then
            num=0; unset NUMBER; unset NOMOVE
            while [ -e "$requests/$filledhead$RELEASE$NUMBER" ]; do
              num=$[$num+1]
              NUMBER=$num
              if [ "$NUMBER" -gt "20" ]; then
                NOMOVE=TRUE
                break
              fi
            done
            if [ "$NOMOVE" != "TRUE" ]; then
              mv -f "$requests/$requesthead$RELEASE" "$requests/$filledhead$RELEASE$NUMBER"
            fi
          else
            ## All ok, just move the dir.
            mv -f "$requests/$requesthead$RELEASE" "$requests/$filledhead$RELEASE"
          fi
        else
          if [ "$mode" = "gl" ]; then
            requestname=`basename $requests`
            echo "$requesthead$RELEASE was not found in $requestname. Skipping rename!"
            unset requestname
          fi
        fi
      fi
    fi

    ## Say this if running from glftpd.
    if [ "$mode" = "gl" -a "$name" != "reqdel" ]; then
      if [ "$HIDE" != "TRUE" ]; then
        echo "$WHAT : $RELEASE has been filled. Thank you."
        AUTO=TRUE; NOHEADFOOT="TRUE"; proc_status; unset NOHEADFOOT
      fi
    fi

    if [ "$name" = "reqdel" ]; then
      ## Say this to glftpd in either case.
      if [ "$mode" = "gl" ]; then
        echo "$WHAT : $RELEASE has been deleted."
      fi
      ## If -hide wasnt used, also announce it to chan, if gllog is set too.
      if [ "$HIDE" != "TRUE" ]; then
        if [ "$gllog" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$RELEASE was deleted by $BY\" >> $gllog
        fi
        AUTO=TRUE; NOHEADFOOT="TRUE"; proc_status; unset NOHEADFOOT
        HIDE=TRUE
      fi
      if [ -d "$requests/$requesthead$RELEASE" ]; then
        rmdir "$requests/$requesthead$RELEASE" >/dev/null 2>&1
      fi
    fi

    if [ "$name" = "reqdelauto" ]; then
      if [ "$gllog" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$RELEASE has been deleted because its older then $removedays days.\" >> $gllog
      fi
      if [ "$showonauto" = "TRUE" ]; then
        AUTO=TRUE; NOHEADFOOT="TRUE"; proc_status; HIDE=TRUE; unset NOHEADFOOT
      else
        HIDE=TRUE
      fi
      if [ -d "$requests/$requesthead$RELEASE" ]; then
        rmdir "$requests/$requesthead$RELEASE" >/dev/null 2>&1
      fi
    fi

    ## Logging.
    case $name in
      reqfill) proc_log "REQFILLED: \"$BY filled $RELEASE\"" ;;
      reqdel) proc_log "REQFILLED: \"$BY deleted -reqdel- $RELEASE\"" ;;
      reqwipe) proc_log "REQFILLED: \"$BY wiped -reqwipe- $RELEASE\"" ;;
    esac

    if [ "$gllog" ]; then
      if [ -w "$gllog" ]; then
        if [ "$HIDE" != "TRUE" ]; then
          echo `date "+%a %b %e %T %Y"` REQFILLED: \"$RELEASE\" \"$BY\" >> $gllog
        fi
      else
        echo "Error. Cant write to $gllog. Check paths and perms."
        exit 0
      fi
    fi

  fi
}

proc_status() {
  if [ "$auto" = "auto" ]; then
    AUTO=TRUE
  fi

  for each in `cat $reqfile | tr -s ' ' '^'`; do
    if [ "$SAIDIT" != "TRUE" -a "$STATUSHEAD" != "" -a "$NOHEADFOOT" != "TRUE" -a "$HIDE" != "TRUE" ]; then
      OUTPUT="$STATUSHEAD"
      proc_cookies
      if [ "$mode" = "gl" ]; then
        echo "$OUTPUT"
      else
        if [ "$gllog" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
        fi
      fi
      SAIDIT="TRUE"
    fi

    FOUNDONE="TRUE"
    LINETOSAY=`echo "$each" | tr -s '^' ' '`
    if [ "$mode" = "gl" ]; then
      echo "$LINETOSAY"
    else
      if [ "$HIDE" != "TRUE" ]; then
        if [ "$gllog" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$LINETOSAY\" >> $gllog
        fi
      fi
    fi
    unset LINETOSAY
  done
  unset SAIDIT

  if [ "$FOUNDONE" != "TRUE" -a "$AUTO" != "TRUE" -a "$HIDE" != "TRUE" ]; then
    OUTPUT="$NOREQUESTS"
    proc_cookies
    if [ "$mode" = "gl" ]; then
      echo "$OUTPUT"
    else
      if [ "$gllog" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
      fi
    fi
  fi
  if [ "$FOUNDONE" = "TRUE" -a "$TOFILL" != "" -a "$NOHEADFOOT" != "TRUE" -a "$HIDE" != "TRUE" ]; then
    OUTPUT="$TOFILL"
    proc_cookies
    if [ "$mode" = "gl" ]; then
      echo "$OUTPUT"
    else
      if [ "$HIDE" != "TRUE" ]; then
        if [ "$gllog" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
        fi
      fi
    fi
  fi
}

case $RUN in
  request) name="request"; proc_verify; proc_request ;;
  reqfilled) name="reqfill"; proc_verify; proc_reqfilled ;;
  reqdel) name="reqdel"; reqdel=TRUE; proc_verify; proc_reqfilled ;;
  reqdelauto) name="reqdelauto"; reqdel=TRUE; proc_verify; proc_reqfilled ;;
  reqwipe) name="reqwipe"; reqwipe=TRUE; proc_verify; proc_reqfilled ;;
  status) name="status"; auto="$2"; proc_status ;;
  fix) name="fix"; proc_reorder ;;
  checkold) name="checkold"; proc_checkfile; proc_checkold ;;
  *) echo "Hm, didnt get any reasonable action" ;;
esac

exit 0
