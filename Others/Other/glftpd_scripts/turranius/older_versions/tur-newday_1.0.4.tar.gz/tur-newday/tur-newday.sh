#!/bin/bash
VER=1.0.4
#-[ Intro ]--------------------------------------------------------#
#                                                                  #
# Tur-NewDay. A script to make a daily/weekly/monthly dir.         #
# Created by Turranius, for Turranius. Shared cause I'm nice :)    #
#                                                                  #
#-[ Setup ]--------------------------------------------------------#
#                                                                  #
# Copy this script to /glftpd/bin, or anywhere you want. Make it   #
# executable (chmod 755 or something).                             #
# Edit the settings below.                                         #
#                                                                  #
# After everything is set up, crontab it to run once a day. Dont   #
# worry if you run weekly or monthly. It wont actually run unless  #
# its the last day of the week or month, so crontabbing once a day #
# is ok anyway.                                                    #
# 0 0 * * * /glftpd/bin/tur-newday.sh                              #
# 0 1 * * * /glftpd/bin/tur-newday.sh close                        #
#                                                                  #
# Read more on 'close' further down.                               #
#                                                                  #
#-[ Options ]------------------------------------------------------#
#                                                                  #
# gllog     = Full path to your glftpd.log file if you want it to  #
#             announce. Set this to "" for it to keep quiet or put #
#             a # infront of the line.                             #
#                                                                  #
# glroot    = Full path to glftpd.                                 #
#                                                                  #
# section   = Where to make the dirs. One section only.            #
#             This is relative to glroot above.                    #
#                                                                  #
# duration  = How often should we make the new dir? Options are:   #
#             day, week and month.                                 #
#                                                                  #
# euroweek  = If duration is set to week, do you use euroweeks?    #
#             euroweak = new week starts on mondays. Otherwise its #
#             on sunday. Must be TRUE or FALSE.                    #
#                                                                  #
# chmod     = What to chmod the new dir to. Set to "" to disable.  #
#             Default is 777 which is what it should be.           #
#                                                                  #
# old       = What to chmod the old dated dir to when executed     #
#             with argument 'close'. Default is 755.               #
#                                                                  #
# symlinks  = This is to create symlinks that points to the        #
#             the current dir. You can use as many as you like.    #
#             Example1: /site/0DAYS-Today                          #
#             That will simply make one called 0DAYS-Today in      #
#             /site.                                               #
#             Example2: /site/0DAYS/Today:/site/0DAYS/Yesterday    #
#             Like above, this will make the same symlink, but     #
#             move the previous symlink to 'Yesterday' first.      #
#                                                                  #
#             Of course, depending on which duration you set, you  #
#             might want to change the names of the symlinks =)    #
#                                                                  #
#             Leave empty ("") and it wont bother with symlinks.   #
#                                                                  #
#             Try not to use ! or anything in the name unless you  #
#             know what you are doing.                             #
#                                                                  #
# day       = The date format if you use duration=day.             #
#             Default is %m%d which translates to MMDD (0315).     #
#             Normally, you shouldnt need to change any of these.  #
#                                                                  #
# week      = The date format if you use duration=week.            #
#             Default is %V-%Y which translates to WW-YYYY         #
#             Note that %V is week number of year with Monday as   #
#             first day of week (01..53).                          #
#             %U = week number of year with Sunday as first day of #
#             week (00..53)                                        #
#                                                                  #
# month     = The date format if you use duration=month.           #
#             Default is %B-%Y which translates to MM-YYYY         #
#                                                                  #
# lastday   = Should be set to the same as 'day', but with         #
#             --date "-1 day". This is to specify yesterdays dir.  #
#             We use these when executed with the 'close' arg to   #
#             set a different chmod on that directory.             #
#             Used if duration=day                                 #
#                                                                  #
# lastweek  = Same as above, but with --date "-1 week".            #
#             Used if duration=week                                #
#                                                                  #
# lastmonth = Same as above, but with --date "-1 month".           #
#             Used if duration=month                               #
#                                                                  #
#-[ Announce ]-----------------------------------------------------#
#                                                                  #
# Of course we have bot announce support. Wouldnt be Tur- approved #
# if it didnt =) Heres how to do it with zipscript-c by Dark0n3:   #
# Add to 'set msgtypes(DEFAULT)': TURDAY TURDAYC                   #
# Add the following to the relevant positions:                     #
#--                                                              --#
#
# set chanlist(TURDAY)    "#YourChan"
# set chanlist(TURDAYC)   "#YourChan"
#
# set disable(TURDAY)    0
# set disable(TURDAYC)   0
#
# set variables(TURDAY)      "%dir"
# set variables(TURDAYC)     "%dir"
#
# set announce(TURDAY)  "%bold-\[NEWDAY\]-%bold New dated dir %bold%dir%bold created."
# set announce(TURDAYC) "%bold-\[NEWDAY\]-%bold Previous dated dir, %bold%dir%bold, is now closed for uploads."
#
#--                                                              --#
#                                                                  #
# Change the announce lines as you wish.                           #
# If you do not want announces when say, you close last periods    #
# dated dir, set 'set disable(TURDAYC)' to 1.                      #
# If you dont want annoucing at all, set gllog to ""               #
#                                                                  #
# If you run multiple instances of this script and you want        #
# different announce lines on them, you need to search for         #
# TURDAY and TURDAYC in the script. Change those to something else #
# (TURDAY2 ?). Then add the lines above again with that trigger.   #
# If you dont care if they announce the same, leave it be.         #
#                                                                  #
#-[ Other ]--------------------------------------------------------#
#                                                                  #
# As you might have noticed, we only handle one section. If you    #
# have 2 daily dirs, just make a copy of this script to another    #
# name and set that up for the other section. Then crontab both.   #
#                                                                  #
# This script can take 3 arguments. debug, close and force.        #
# 'tur-newday.sh debug' will only display what it would have done. #
# It wont actually do anything. Use this for first time test.      #
#                                                                  #
# 'tur-newday.sh close <debug>' will close the last periods dated  #
# dir by chmodding it to the 'old' value. This means that if you   #
# want to prevent uploads to the old dir, but keep it open for an  #
# hour or so, you can crontab it with argument 'close', one hour   #
# after midnight, each day.                                        #
#                                                                  #
# 'tur-newday.sh force'. Normally, in week or month mode           #
# it will not run unless its the first day of the week/month. But  #
# with 'force' it will anyway. You might want to use this the      #
# first time you run it or if the site has been down and it hasnt  #
# created the new weekly or monthly dir.                           #
#                                                                  #
#-[ Changelog ]----------------------------------------------------#
#                                                                  #
# 1.0.4  Fix: For weekly dir creations, I used date %U. Thats 0-53 #
#             Changed to use %V instead (1-53).                    #
#             Just change 'week=' and 'lastweek=' if you need.     #
#                                                                  #
# 1.0.3  Fix: 'force' argument wasnt working very well on weekly   #
#             and monthly dir creation. Thanks LPC for the report. #
#                                                                  #
#-[ Settings ]-----------------------------------------------------#

gllog=/glftpd/ftp-data/logs/glftpd.log
glroot=/glftpd
section=/site/0DAYS
duration=day
euroweek=TRUE
chmod=777
old=755

symlinks="
/site/Today
/site/0DAYS/Today:/site/0DAYS/Yesterday
"

day="$( date +%m%d )"
week="$( date +%V-%Y )"
month="$( date +%B-%Y )"

lastday="$( date --date "-1 day" +%m%d )"
lastweek="$( date --date "-1 week" +%V-%Y )"
lastmonth="$( date --date "-1 month" +%B-%Y )"


#-[ Script Start. No changes should be needed below here ]---------#

## Has to run AFTER midnight, so..
sleep 1

## Check if first or second argument is 'debug'
if [ "$1" = "debug" -o "$2" = "debug" -o "$1" = "DEBUG" -o "$2" = "DEBUG" ]; then
  DEBUG=TRUE
fi

## Check if first argument is 'force'.
if [ "$1" = "force" -o "$1" = "FORCE" ]; then
  if [ "$duration" = "day" ]; then
    echo "Force is only needed when running in week or month mode."
    exit 0
  else
    FORCE="TRUE"
  fi
fi

## Check if first argument is 'close'.
if [ "$1" = "close" -o "$1" = "CLOSE" ]; then
  CLOSE=TRUE
fi

## Generic path check.
if [ ! -d "$glroot$section" ]; then
  echo "Tur-NewDay error: $glroot$section does not exist."
  exit 0
fi

## Procedure to check if its the last day of the month.
proc_monthly() {
  if [ "$FORCE" != "TRUE" ]; then
    DAYOFMONTH="$( date +%d )"
    if [ "$DAYOFMONTH" != "01" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Not the first day of the month. Daynow is $DAYOFMONTH, not 01. Debug, so continuing."
      else
        exit 0
      fi
    fi
  fi
}

## Procedure to check if its the last day of the week.
proc_weekly() {
 if [ "$FORCE" != "TRUE" ]; then
   DAYNOW="$( date +%w )"
    if [ "$euroweek" = "FALSE" ]; then
      CHECKDAY="0"
    else
      CHECKDAY="1"
    fi
    if [ "$CHECKDAY" != "$DAYNOW" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Not the first day of the week. Daynow is $DAYNOW, not $CHECKDAY. Debug, so continuing."
      else
        exit 0
      fi
    fi
  fi
}

## Print this if its in debug mode.
if [ "$DEBUG" = "TRUE" ]; then
  echo "Debug on. Not actually doing anything. Duration is set to '$duration'"
fi

## Procedure for creating a new dated dir.
proc_createnew() {
  ## Check that it dosnt already exist, and quit if so, unless its in debug mode.
  if [ -d "$glroot$section/$TARGET" ]; then
    echo "Tur-NewDay error. $glroot$section/$TARGET already exists."
    if [ "$DEBUG" = "TRUE" ]; then
      echo "Since this is just a test, we'll continue anyway.."
    else
      if [ "$FORCE" != "TRUE" ]; then
        exit 0
      fi
    fi
  fi

  ## Make the actual dir
  if [ "$DEBUG" = "TRUE" ]; then
    echo "Create dir: $glroot$section/$TARGET"
  else
    mkdir "$glroot$section/$TARGET"

    ## Announce stuff.
    ## Remove /site/ from output. Dont want to show that.
    if [ "$gllog" ]; then
      nicename="$( echo "$section" | sed -e 's/\/site\///' )"
      echo `date "+%a %b %e %T %Y"` TURDAY: \"$nicename/$TARGET\" >> $gllog
    fi
  fi

  ## Chmod new dir ?
  if [ "$chmod" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "chmod $chmod $glroot$section/$TARGET"
    else
      chmod $chmod "$glroot$section/$TARGET"
    fi
  fi

  ## Make symlink(s)
  for symlink in $symlinks; do
    unset today
    unset yesterday

    ## Check if theres a : in the symlink, meaning it should use 'yesterday' as well.
    if [ -z "$( echo "$symlink" | grep ':' )" ]; then
      today="$symlink"
    else
      today="$( echo $symlink | cut -d ':' -f1 )"
      yesterday="$( echo $symlink | cut -d ':' -f2 )"
    fi

    ## Move today to yesterday or del it.
    if [ "$yesterday" ]; then
      if [ -L "$glroot$today" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Moving $glroot$today to $glroot$yesterday"
        else
          mv -f "$glroot$today" "$glroot$yesterday"
        fi
      fi
    fi

    ## Make the new symlink
    if [ "$DEBUG" = "TRUE" ]; then
      echo "Making symlink $glroot$today pointing to $section/$TARGET"
    else
      ln -f -s "$section/$TARGET" "$glroot$today"
    fi
  done
}

## Go go. If CLOSE is TRUE, then it was started with argument 'close'
if [ "$CLOSE" != "TRUE" ]; then
  ## Close wasnt specified so creating new dir.

  case $duration in
    [dD][aA][yY]) TARGET="$day";;
    [wW][eE][eE][kK]) TARGET="$week"; proc_weekly;;
    [mM][oO][nN][tT][hH]) TARGET="$month"; proc_monthly;;
    *) echo "Tur-NewDay error. duration not set right (day/week/month)."; exit 0;;
  esac
  proc_createnew
  exit 0
  
else
  ## Close was specified. Closing last periods dir.

  case $duration in
    [dD][aA][yY]) TARGET="$lastday";;
    [wW][eE][eE][kK]) TARGET="$lastweek";;
    [mM][oO][nN][tT][hH]) TARGET="$lastmonth";;
    *) echo "Tur-NewDay error. duration not set right (day/week/month)."; exit 0;;
  esac

  ## Check if 'old' is set.
  if [ -z "$old" ]; then
    echo "Tur-NewDay error. Set to close last dir, but 'old' is not set."
    exit 0
  else
    if [ ! -d "$glroot$section/$TARGET" ]; then
      echo "Tur-NewDay error. Was going to chmod $old $glroot$section/$TARGET, but dir not found."
      exit 0
    fi
    if [ "$DEBUG" = "TRUE" ]; then
      echo "Setting chmod $old on $glroot$section/$TARGET"
    else
      chmod $old "$glroot$section/$TARGET"

      ## Announce stuffs.
      ## Remove /site/ from output. Dont want to show that.
      if [ "$gllog" ]; then
        nicename="$( echo "$section" | sed -e 's/\/site\///' )"
        echo `date "+%a %b %e %T %Y"` TURDAYC: \"$nicename/$TARGET\" >> $gllog
      fi
    fi
  fi

  exit 0

fi