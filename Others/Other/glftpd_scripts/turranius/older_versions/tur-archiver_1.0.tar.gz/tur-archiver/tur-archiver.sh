#!/bin/bash
############################################################################
# Tur-Archiver 1.0 by Turranius  ( http://www.grandis.nu/glftpd/ )         #
####                                                                    ####
# This script has the ability to go through todays dated dir, looking at   #
# the contents and based on what you set, move or copy files that match to #
# a different folder.                                                      #
# Like the default setup, you want to save all folders that contains the   #
# words "Keymaker.Only" or "KeyGen.Only" and copy then to an archive       #
# called KeyMakers.                                                        #
# This Keymakers folder contains a number of subfolders, namely;           #
# ABC DEF GHI JKL MNO PQR STU VWX YZ 0-9                                   #
# The script will check which folder it should go into, based on the first #
# letter in the release name, and move or copy it there.                   #
####                                                                    ####
# Installation:                                                            #
# Put this script in /glftpd/bin, or wherever you like really.             #
# Make it executable.                                                      #
# Edit the settings below:                                                 #
# LOG=       Where you want it to log to.                                  #
# FROM=      The parent folder of the dated dirs (that contains dated dirs)#
#            You can put more parent folders here, just separate them with #
#            a space.                                                      #
# TO=        The parent folder of where they should go to.                 #
#                                                                          #
# TOSTRUCTURE= Important one. How does the folders insite TO= look like?   #
#              You decide how the folders are set up. The example is only  #
#              that, an example. You could might as well use               #
#              A B C D, etc.                                               #
#              If you want something that starts with A to be archived,    #
#              make sure there is one folder defined here containing A.    #
#              It is NOT case sensitive, so do NOT add A and a.  A=a too.  #
#              Just make sure you have a folder for every letter and number#
#              if you want those letters and numbers moved.                #
#              Note: The 0-9 folder will automatically take 0123456789     #
#              I just thought it looked stupid with a folder called that :)#
#              That is the ONLY folder you can do something like that on.  #
#              Note2: If it cant find any destination for the folder, it   #
#              will not touch it at all (starts with a - or something).    #
#                                                                          #
# MOVE=        What to you want moved to these folders? Space separated.   #
#              Standard is Keymaker.Only, Keygen.Only & Keygenerator.Only. #
#              If a folder contains any of those, it will be moved/copied. #
#              This is not case sensitive. KeyGen is the same as keygen.   #
#              HINT: If you want to use this script to save stuff from a   #
#                    single group or something, only set, for instance,    #
#                    -CORE here and only releases by CORE will be archived #
#                                                                          #
# EXCLUDE=     What to exclude? | separated.                               #
#              As you can see, the default will exclude [incomplete].      #
#              [incomplete], in my case, are symlinks created by           #
#              zipscript-c. The copying will probably crap out if there is #
#              a folder containing wierd chars, so make sure you exclude   #
#              em if you have em.                                          #
#              It wont break anything if you miss it. Just annoying with   #
#              errors on the screen.                                       #
#              Any special chars must be escaped (with \ first).           #
#              HINT: If, for instance, you do NOT want anything made by    #
#                    CORE archived, add -CORE here.                        #
#                                                                          #
# MOVEFOLDER=  TRUE/FALSE. If set to TRUE, it will MOVE the folder.        #
#              If set to FALSE, it will just copy them.                    #
#                                                                          #
# today=       This is how your dated folders look like. The default is    #
#              %m%d, which translates to 0527 for the 27th of May.         #
#              Do a date --help from shell to find out how it works.       #
#                                                                          #
# Once you have it set up, try and run it from shell with the argument     #
# test ( tur-archiver.sh test ). That will show you what it was supposed   #
# to have done. If there is no output, it did not find anything to archive.#
#                                                                          #
# Finally, add it to crontab. Run it a few minutes before midnight each    #
# day so it can grab all the stuff.                                        #
#                                                                          #
# Another hint. If you want to force it to check a certain date, run it    #
# with the date as an extra variable.                                      #
# Example: 'tur-archiver.sh test 0503' or 'tur-archiver.sh 0503'.          #
# The first time, when you probably want it to go through all your dated   #
# folders, do this, once its all setup:                                    #
# Go to your folder containing all the dated dirs, and type:               #
# for each in `ls -a -L | tr -d /`;do /glftpd/bin/tur-archiver.sh test $each; done
#                                                                          #
# Its gonna start spamming. If it looks good, break it and run it without  #
# the 'test' near the end.                                                 #
####                                                                    ####
# Changelog:                                                               #
# 1.0 : Initial release.                                                   #
############################################################################
# Contact Turranius on efnet (turranius/turran/turr|away/turr|work).       #
############################################################################

LOG="/glftpd/ftp-data/logs/tur-archiver.log"              # What to log to.
FROM="/glftpd/site/0DAYS"      # Parents of dated folders. Space Separated.
TO="/glftpd/site/Archive/KeyMakers"                       # Parent folder of setting below.
TOSTRUCTURE="ABC DEF GHI JKL MNO PQR STU VWX YZ 0-9"      # Read about this one above.
MOVE="Keygen_Only Keymaker.Only Keygen.Only Keygenerator.Only"        # What to look for in the folders. Space Separated.
EXCLUDE='\[incomplete\]|GROUPS|!Today|!Yesterday'         # Any folders to ignore?
MOVEFOLDERS="FALSE"                                       # TRUE = Move them. FALSE = Copy them.

today="$(date +%m%d)"                                     # Dated dir structure.

############################################################
## No changes below needed                                 #
############################################################

DATENOW="$(date +%D" - "%T)"

if [ "$1" != "test" ]; then
  if [ "$1" != "" ]; then
    today="$1"
  fi
else
  if [ "$2" != "" ]; then
    today="$2"
  fi
fi

if [ -e $TO ]; then
  if [ "$MOVEFOLDERS" = "TRUE" ]; then
    CMD="mv"
  else
    CMD="cp -Rf"
  fi
else
  echo "Can not find $TO. Nowhere to move to".
  exit 1
fi

ERROR=""
for toexists in $TOSTRUCTURE; do
  if [ -e "$TO/$toexists" ]; then
    found="yes"
  else
    echo "Can not find path $TO/$toexists."
    echo "You must create those folders yourself and make sure we have permission to move stuff there."
    ERROR="TRUE"
  fi
done

if [ "$ERROR" = "TRUE" ]; then
  exit 0
fi

for dir in $FROM; do
  if [ -e "$dir/$today" ]; then
    cd $dir/$today
    for i in `ls -f -A | egrep -v $EXCLUDE`; do
      VERIFY=""
      for search in $MOVE; do
        VERIFY="$( echo $i | grep -i $search )"
        if [ "$VERIFY" != "" ]; then
          LETTER="$( echo $i | cut -b -1 )"
          for DEST in `echo $TOSTRUCTURE`; do
            if [ "$DEST" = "0-9" ]; then
              DEST="0123456789"
            fi
            DESTF="$( echo $DEST | grep -i $LETTER )"
            if [ "$DESTF" != "" ]; then
              if [ "$DESTF" = "0123456789" ]; then
                DESTF="0-9"
              fi
              if [ "$1" = "test" ]; then
                echo "$DATENOW From: $dir/$today/$i -> $TO/$DESTF/"
              else
                echo "$DATENOW From: $dir/$today/$i -> $TO/$DESTF/" >> $LOG
                $CMD $dir/$today/$i $TO/$DESTF
              fi
            fi
          done
        fi
      done
    done
  else
    if [ "$1" = "test" ]; then
      echo "Can not find $dir/$today to check in. If you have multiple FROM sections, dont worry."     
    else
      echo "$DATENOW : Could not find $dir/$today to check in. Not a bad thing if you have multiple FROM sections." >> $LOG
    fi
  fi
done

exit 0
