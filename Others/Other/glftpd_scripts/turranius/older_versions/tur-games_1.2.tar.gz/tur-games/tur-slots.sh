#!/bin/bash
VER=1.1

USERPATH=/ftp-data/users
BACKUPPATH=/ftp-data/users/backup
LOCKFILE=/tmp/slots.lock
LOGFILE=/ftp-data/logs/slots.log
LOGFILETMP=/tmp/logfile.slotstmp
USERFILETMP=/tmp/$USER.slotstmp
GLLOGFILE=/ftp-data/logs/games.log
NODELAYPASS=onlycoolppl

MINBET="50"
MAXBET="1000"

##--[ Script Start ]--#

proc_output() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $GLLOGFILE
}

BOLD=""
ULINE=""

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

## Show welcome message
if [ -z $1 ]; then
  echo "Welcome to the slots machines!" 
  echo "Usage: site slots <mb to bet> - to gamble."
  echo "Usage: site slots rules       - to read rules. Make sure you do!"
  echo "Usage: site slots highscores  - to see the highscores list."
  echo "Usage: site slots status      - to see your current status."
  echo "Usage: site myscore           - Your score in all games."
  exit 0
fi

if [ "$1" = "rules" ]; then
  echo "----------------[ Welcome to the Slot machine ]---------------"
  echo "This is a game of 5 slots - 4 fruits and one dollar sign."
  echo "Minimum bet is $MINBET dollah's (MB creds). Max is $MAXBET Dollah's."
  echo "Winnings are as follows:"
  echo "One of each...............................= 4x your bet TAKEN"
  echo "3 Melons, Bananas, Apples or Oranges......= 3x your bet back"
  echo "3 Dollar signs............................= 4x your bet back"
  echo "4 Melons..................................= 20x your bet back"
  echo "4 Bananas.................................= 25x your bet back"
  echo "4 Apples..................................= 30x your bet back"
  echo "4 Oranges.................................= 35x your bet back"
  echo "4 Dollar signs............................= 40x your bet back"
  echo "5 Melons..................................= 80x your bet back"
  echo "5 Bananas.................................= 85x your bet back"
  echo "5 Apples..................................= 90x your bet back"
  echo "5 Oranges.................................= 95x your bet back"
  echo "5 Dollar signs............................= 100x your bet back"
  echo "-----------------[ Created by Turranius in 2002 ]-------v1.1--"
  echo ""
  exit 0
fi

## User selected to see highscores.
if [ "$1" = "highscores" ]; then
  echo "--------[ Highscore for Slots ]-----------"
  cat $LOGFILE | sort -k 2,2 -n -r
  echo "----[ Slots was created by Turranius ]----"
  exit 0
fi

## User requested his status.
if [ "$1" = "status" ]; then
  ## If a second variable is set, check if that is a user, and if so, show his stats.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      USER="$2"
    else
      echo "User not found."
      exit 0
    fi
  fi
  echo "Status for $USER in Slots."
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"
  echo "You have $USERCREDSMB dollah's to play with."

  currenttime=`date +%s`
  if [ -e /tmp/slots_$USER ]; then
    lasttime=`cat /tmp/slots_$USER`
    lasttime=`expr $lasttime / 60`
    currenttime=`expr $currenttime / 60`
    delayedtime=`expr $currenttime - $lasttime`
    if [ `expr $delayedtime "<=" 14` = 1 ] ; then
      x=15
      delayedtime=$[x - $delayedtime ]
      echo "Your slot will open in $delayedtime minutes."
    else
      echo "Your slot to play is open now."
    fi
  else
    echo "Your slot to play is open now."
  fi

  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "You have never played before."
    exit 0
  else
    echo "Your total standing vs the casino is $LOG dollah's (mb credits)."
    exit 0
  fi
fi

## If the user gives the nodelaypass, delete his timer file.
if [ "$1" = "$NODELAYPASS" ]; then
  ## If a second variable is set, check if that is a user, and if so, reset that users timer.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      echo "Admin password detected. Clearing timer for $2"
      proc_output "${BOLD}-(SLOTS)- $USER's${BOLD} grants ${BOLD}$2${BOLD} another slot!"
      rm -f /tmp/slots_$2
      exit 0
    else
      echo "Cant clear timer for $2. No such user."
      exit 0
    fi
  else
    echo "Admin password detected. Clearing your timer."
    rm -f /tmp/slots_$USER
    exit 0
  fi
fi

## Create or update time on logfile
touch $LOGFILE

## Check that the user does not have leech
  RATIO=$(grep RATIO $USERPATH/$USER | awk -F" " '{print $2}')
  if [ $RATIO = "0" ]; then
    echo "Sorry, you are banned from the casino cause your credits arent worth anything."
    exit 0
  fi

## Check that another game isnt currently running.
if [ -e $LOCKFILE ]; then
  echo "Another game is in progress. Try again later."
  exit 0
fi

## Create lockfile, cause here we go.
touch $LOCKFILE

## Make the bet x 1024 cause the userfiles contains kilobytes, not megabytes
BETCREDSMB="$1"
BETCREDS="$(expr $1 \* 1024)"

## If the above calculation crapped out, the $BETCREDS is empty. User typed something other than numbers.
if [ "$BETCREDS" = "" ]; then
  echo "Bad amount of credits. Only use numbers!"
  rm -f $LOCKFILE
  exit 0
fi

## Validate that the bet can be manupulated. If this isnt here, and the user
## has a dot in his bet, all calculations will fail and the user ends up with
## 0.0 credits. Not that good, eh?
VALIDATE="$(expr $1 \* 2)"
if [ "$VALIDATE" = "" ]; then
  echo "Seems to be a problem with your bet. Did you use dots?"
  exit 0
fi

## Minumum amount of credits to gamble.
if [ "$1" -lt "$MINBET" ]; then
  echo "Sorry, minumum amount to gamble with is ${MINBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

# Maximum amount of credits to gamble.
if [ "$1" -gt "$MAXBET" ]; then
  echo "Sorry, maximum amount to gamble with is ${MAXBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

## Make a backup of the userfile before doing anything.
if [ "$BACKUPPATH" ]; then
  cp -f $USERPATH/$USER $BACKUPPATH/$USER.slots
fi

## Check that the user really has that much credits
USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"

## Translate it to megabytes.
USERCREDSMB="$(expr $USERCREDS \/ 1024)"

## If the user does not have enough credits...
if [ "$USERCREDS" -lt "$BETCREDS" ]; then
  echo "The guards grab you and toss you out! They toss your $USERCREDSMB credits after you!"
  proc_output "${BOLD}-(SLOTS)- The guards toss out $USER${BOLD} for trying to gamble with more than he had!"
  rm -f $LOCKFILE
  exit 0
fi

## Check the time since it was last run.
currenttime=`date +%s`
if [ -e /tmp/slots_$USER ]; then
     lasttime=`cat /tmp/slots_$USER`
     lasttime=`expr $lasttime / 60`
     currenttime=`expr $currenttime / 60`
     delayedtime=`expr $currenttime - $lasttime`
  if [ `expr $delayedtime "<=" 14` = 1 ] ; then
     x=15
     delayedtime=$[x - $delayedtime ]
     echo "You can only play once every 15 minutes. Your slot will open in $delayedtime minutes."
     echo "Use 'site play status' to keep updated."
     rm -f $LOCKFILE
     exit 0
  fi
fi

## Make sure the current credits can be read.
if [ "$USERCREDS" = "" ]; then
  echo "Hm, cant seem to read your userfile, or you are piss poor."
  rm -f $LOCKFILE
  exit 0
else
  echo "You put in $1 dollah's in the slot machine and pull the lever."
  proc_output "${BOLD}-(SLOTS)- $USER${BOLD} puts${BOLD} $1 ${BOLD}dollah's in the slot machine."
  if [ "$USER" = "kriptiq" -o "$USER" = "RallyOter" ]; then
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} automatically LOOSES!! -5000 GIG!"
    sleep 2
    proc_output "${BOLD}-(SLOTS)- Naaaah, just kidding."
  else
    sleep 2
  fi
  echo "The tension is high while the numbers are rolling."
  sleep 2
fi

## Update the time when play was last run. Comment out this line for no delay.
echo `date +%s` > /tmp/slots_$USER

## Clear up slots
MELON="0"
BANANA="0"
APPLE="0"
ORANGE="0"
DOLLAR="0"

## First slot
#NUM1="$(/bin/randomit 0 100)"

LOW=0
HIGH=100
proc_random
NUM1="$number"

# echo "Debug: first random number: $NUM1"
ONEDONE="0"
sleep 2

## Roll the first one
if [ "$NUM1" -lt "20" ]; then
  ONEDONE="1"
  FIRSTNAME="Melon"
  MELON="1"
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM1" -lt "40" ]; then
    ONEDONE="1"
    FIRSTNAME="Banana"
    BANANA="1"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM1" -lt "60" ]; then
    ONEDONE="1"
    FIRSTNAME="Apple"
    APPLE="1"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM1" -lt "80" ]; then
    ONEDONE="1"
    FIRSTNAME="Orange"
    ORANGE="1"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
 if [ "$NUM1" -gt "79" ]; then
   FIRSTNAME="Dollarsign"
   DOLLAR="1"
 fi
fi

echo "1st Slot: $FIRSTNAME"
proc_output "${BOLD}-(SLOTS)- 1st${BOLD} Slot is a: $FIRSTNAME."

## Second slot
#NUM2="$(/bin/randomit 0 100)"

LOW=0
HIGH=100
proc_random
NUM2="$number"


# echo "Debug: second random number: $NUM2"
ONEDONE="0"
sleep 2

## Roll the second one
if [ "$NUM2" -lt "20" ]; then
  ONEDONE="1"
  SECONDNAME="Melon"
  MELON="$(expr $MELON \+ 1)"
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM2" -lt "40" ]; then
    ONEDONE="1"
    SECONDNAME="Banana"
    BANANA="$(expr $BANANA \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM2" -lt "60" ]; then
    ONEDONE="1"
    SECONDNAME="Apple"
    APPLE="$(expr $APPLE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM2" -lt "80" ]; then
    ONEDONE="1"
    SECONDNAME="Orange"
    ORANGE="$(expr $ORANGE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
 if [ "$NUM2" -gt "79" ]; then
   SECONDNAME="Dollarsign"
   DOLLAR="$(expr $DOLLAR \+ 1)"
 fi
fi

echo "2nd Slot: $SECONDNAME"
proc_output "${BOLD}-(SLOTS)- 2nd${BOLD} Slot is a: $SECONDNAME."

## Third slot
#NUM3="$(/bin/randomit 0 100)"
LOW=0
HIGH=100
proc_random
NUM3="$number"

# echo "Debug: third random number: $NUM3"
ONEDONE="0"
sleep 2

## Roll the third one
if [ "$NUM3" -lt "20" ]; then
  ONEDONE="1"
  THIRD="1"
  THIRDNAME="Melon"
  MELON="$(expr $MELON \+ 1)"
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM3" -lt "40" ]; then
    ONEDONE="1"
    THIRD="2"
    THIRDNAME="Banana"
    BANANA="$(expr $BANANA \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM3" -lt "60" ]; then
    ONEDONE="1"
    THIRD="3"
    THIRDNAME="Apple"
    APPLE="$(expr $APPLE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM3" -lt "80" ]; then
    ONEDONE="1"
    THIRD="4"
    THIRDNAME="Orange"
    ORANGE="$(expr $ORANGE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
 if [ "$NUM3" -gt "79" ]; then
   THIRD="5"
   THIRDNAME="Dollarsign"
   DOLLAR="$(expr $DOLLAR \+ 1)"
 fi
fi

echo "3rd Slot: $THIRDNAME"
proc_output "${BOLD}-(SLOTS)- 3rd${BOLD} Slot is a: $THIRDNAME."

## Fourth slot
#NUM4="$(/bin/randomit 0 100)"
LOW=0
HIGH=100
proc_random
NUM4="$number"

# echo "Debug: fourt random number: $NUM4"
ONEDONE="0"
sleep 2

## Roll the fourth one
if [ "$NUM4" -lt "20" ]; then
  ONEDONE="1"
  FOURTH="1"
  FOURTHNAME="Melon"
  MELON="$(expr $MELON \+ 1)"
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM4" -lt "40" ]; then
    ONEDONE="1"
    FOURTH="2"
    FOURTHNAME="Banana"
    BANANA="$(expr $BANANA \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM4" -lt "60" ]; then
    ONEDONE="1"
    FOURTH="3"
    FOURTHNAME="Apple"
    APPLE="$(expr $APPLE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM4" -lt "80" ]; then
    ONEDONE="1"
    FOURTH="4"
    FOURTHNAME="Orange"
    ORANGE="$(expr $ORANGE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
 if [ "$NUM4" -gt "79" ]; then
   FOURTH="5"
   FOURTHNAME="Dollarsign"
   DOLLAR="$(expr $DOLLAR \+ 1)"
 fi
fi

echo "4th Slot: $FOURTHNAME"
proc_output "${BOLD}-(SLOTS)- 4th${BOLD} Slot is a: $FOURTHNAME."

## Fifth slot
#NUM5="$(/bin/randomit 0 100)"
LOW=0
HIGH=100
proc_random
NUM5="$number"


# echo "Debug: fifth random number: $NUM5"
ONEDONE="0"
sleep 2

## Roll the fifth one
if [ "$NUM5" -lt "20" ]; then
  ONEDONE="1"
  FIFTH="1"
  FIFTHNAME="Melon"
  MELON="$(expr $MELON \+ 1)"
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM5" -lt "40" ]; then
    ONEDONE="1"
    FIFTH="2"
    FIFTHNAME="Banana"
    BANANA="$(expr $BANANA \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM5" -lt "60" ]; then
    ONEDONE="1"
    FIFTH="3"
    FIFTHNAME="Apple"
    APPLE="$(expr $APPLE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
  if [ "$NUM5" -lt "80" ]; then
    ONEDONE="1"
    FIFTH="4"
    FIFTHNAME="Orange"
    ORANGE="$(expr $ORANGE \+ 1)"
  fi
fi

if [ "$ONEDONE" != "1" ]; then
 if [ "$NUM5" -gt "79" ]; then
   FIFTH="5"
   FIFTHNAME="Dollarsign"
   DOLLAR="$(expr $DOLLAR \+ 1)"
 fi
fi
 
echo "5th Slot: $FIFTHNAME"
proc_output "${BOLD}-(SLOTS)- 5th${BOLD} Slot is a: $FIFTHNAME."

#echo "----------------------------------"
#echo "Melons : $MELON"
#echo "Bananas: $BANANA"
#echo "Apples : $APPLE"
#echo "Oranges: $ORANGE"
#echo "Dollahs: $DOLLAR"
#echo "----------"

RATIO=""

## Ops, bad luck.
if [ "$MELON" = "1" ]; then
  if [ "$BANANA" = "1" ]; then
    if [ "$APPLE" = "1" ]; then
      if [ "$ORANGE" = "1" ]; then
        if [ "$DOLLAR" = "1" ]; then
          echo "Youre bad luck sets of the alarm. Cops claim your bet and make you pay a fine!"
          proc_output "${BOLD}-(SLOTS)- $USER's${BOLD} bad luck sets of the nerd alarm. Cops claim $USER's bet and make him pay a fine!"
          RATIO="-2"
        fi
      fi
    fi
  fi
fi

## 5 in a row
if [ "$RATIO" = "" ]; then
  if [ "$MELON" = "5" ]; then
    echo "SUPER MELON PRICE."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES THE MEGA PRICE!!!"
    RATIO="80"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$BANANA" = "5" ]; then
    echo "SUPER BANANA PRICE."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES THE MEGA PRICE!!!"
    RATIO="85"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$APPLE" = "5" ]; then
    echo "SUPER APPLE PRICE."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES THE MEGA PRICE!!!"
    RATIO="90"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$ORANGE" = "5" ]; then
    echo "SUPER ORANGE PRICE."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES THE MEGA PRICE!!!"
    RATIO="95"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$DOLLAR" = "5" ]; then
    echo "SUPER DOLLAR PRICE."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES THE MEGA MEGA PRICE!!!"
    RATIO="100"
  fi
fi


## 4 in a row
if [ "$RATIO" = "" ]; then
  if [ "$MELON" = "4" ]; then
    echo "4 MELONS IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES 4 MELONS!!"
    RATIO="20"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$BANANA" = "4" ]; then
    echo "4 BANANAS IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES 4 BANANAS!!"
    RATIO="25"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$APPLE" = "4" ]; then
    echo "4 APPLES IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES 4 APPLES!!"
    RATIO="30"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$ORANGE" = "4" ]; then
    echo "4 ORANGES IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES 4 ORANGES!!"
    RATIO="35"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$DOLLAR" = "4" ]; then
    echo "4 DOLLAR IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} SCORES 4 DOLLAR SIGNS!!"
    RATIO="40"
  fi
fi

## 3 in a row.
if [ "$RATIO" = "" ]; then
  if [ "$DOLLAR" = "3" ]; then
    echo "3 DOLLAR IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} scores with 3 Dollar signs."
    RATIO="4"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$MELON" = "3" ]; then
    echo "3 MELONS IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} scores with 3 Melons."
    RATIO="3"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$BANANA" = "3" ]; then
    echo "3 BANANAS IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} scores with 3 Bananas."
    RATIO="3"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$APPLE" = "3" ]; then
    echo "3 APPLES IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} scores with 3 Apples."
    RATIO="3"
  fi
fi

if [ "$RATIO" = "" ]; then
  if [ "$ORANGE" = "3" ]; then
    echo "3 ORANGES IN A ROW."
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} scores with 3 Oranges."
    RATIO="3"
  fi
fi


## Random winnings.

#if [ "$RATIO" = "" ]; then
#  if [ "$DOLLAR" = "2" ]; then
#    echo "You get to keep your credits."
#    RATIO="0"
#    rm -f $LOCKFILE
#  fi
#fi
 
#echo "Current creds: $USERCREDSMB"
#echo "Bet: $BETCREDSMB"

if [ "$RATIO" != "" ]; then
  # echo "Ratio: $RATIO"
  WINMB="$(expr $BETCREDSMB \* $RATIO)"
  WINKB="$(expr $BETCREDS \* $RATIO)"
  if [ "$RATIO" -gt "0" ]; then
    echo "Congratulations. You won $WINMB dollah's"
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} won $WINMB dollah's."
  else
    echo "Pissed, you go home with $WINMB dollah's"
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD} goes home pissed with $WINMB dollah's"
  fi
  NEWCREDSMB="$(expr $USERCREDSMB \+ $WINMB)"
  NEWCREDSKB="$(expr $NEWCREDSMB \* 1024)"
else
  NEWCREDSMB="$(expr $USERCREDSMB \- $BETCREDSMB)"
  NEWCREDSKB="$(expr $NEWCREDSMB \* 1024)"
  echo "Sorry, you lost $BETCREDSMB dollah's"
  proc_output "${BOLD}-(SLOTS)- $USER${BOLD} lost $BETCREDSMB dollah's"
#  echo "New creds: $NEWCREDSKB"
fi

#echo "New creds: $NEWCREDSMB"
#echo "Old creds: $USERCREDS"
#echo "New creds: $NEWCREDSKB"

sed -e "s/^CREDITS [0-9]* /CREDITS $NEWCREDSKB /1" $USERPATH/$USER > $USERFILETMP
cp -f $USERFILETMP $USERPATH/$USER
rm -f $USERFILETMP

if [ "$RATIO" = "" ]; then
  ## echo "Add NEG results to logfile."
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER -$BETCREDSMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG - $BETCREDSMB)"
    echo "Your total standing with the casino is $STANDING dollah's"
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD}'s total standing vs the casino is $STANDING dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    cp -f $LOGFILETMP $LOGFILE
    rm -f $LOGFILETMP
  fi
else
  ## echo "Add PLUS results to logfile."
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER $WINMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG \+ $WINMB)"
    echo "Your total standing with the casino is $STANDING dollah's"
    proc_output "${BOLD}-(SLOTS)- $USER${BOLD}'s total standing vs the casino is $STANDING dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    cp -f $LOGFILETMP $LOGFILE
    rm -f $LOGFILETMP
  fi
fi

rm -f $LOCKFILE

exit 0