#!/bin/bash
VER=1.6.1
#############################################################
# Tur-Vacation. A simple way to go on vacation.             #
# Tired of people telling you they are going on vacation?   #
# Tired of having to add users to excuded list in the trial #
# script? Well, NO MORE. heh. Heres how it works:           #
#                                                           #
# Users issue a command from site. 'site vacation on yes'   #
# What it mainly does is add that user to a group. That     #
# group is already (by you) excluded in your trialscript so #
# they will not be automatically delled or something.       #
#                                                           #
# But this script can do two more things to the user.       #
# 1: It can prevent him from downloading while on vacation. #
# 2: it can prevent him from uploading while on vacation.   #
# It does this by setting max_sim_down and/or max_sim_up to #
# 0.                                                        #
# Thus they can log in and look around, but not much else.  #
#                                                           #
# It also has a minimum time that must have passed since    #
# they went on vacation, until they can turn vacation off   #
# again. This is so they cant go on vacation at the end of  #
# each month.                                               #
#                                                           #
# As with v1.4, it can work together with Tur-Trial 2.1+    #
# so that if a user was on vacation for half the month, he  #
# should only need to upload half the quota limit to pass.  #
#                                                           #
# You can also issue the command 'site vacation status' to  #
# get a status report of everyone on vacation.              #
#                                                           #
#-[ Setup ]------------------------------------------------##
#                                                           #
# Copy this script to /glftpd/bin. Make it executable.      #
# ( chmod 755 /glftpd/bin/tur-vacation.sh )                 #
#                                                           #
# Add it to glftpd.conf as a custom command:                #
# site_cmd vacation       EXEC    /bin/tur-vacation.sh      #
# custom-vacation         !=TRiAL !=TRiAL-2 *               #
# ( just an example above to deny trial users to run it. )  #
#                                                           #
# Edit the settings below:                                  #
#                                                           #
# USERS=     Location of users folder, chrooted /glftpd.    #
#                                                           #
# LOG=       Log location for vacation on and off.          #
#            Set to "" to disable logging.                  #
#            If you plan to use bot output, set this to     #
#            glftpd.log (default).                          #
#                                                           #
# MINDUR=    Minimum duration in days before they can turn  #
#            off vacation.                                  #
#            Set this one to "" to turn the function off.   #
#                                                           #
# VACATIONGROUP= Group they will be added to. Add this in   #
#                glftpd first ( site grpadd VACATION ).     #
#                Exclude this group from quota/whatever.    #
#                                                           #
# DB=        This script will keep data about people on     #
#            vacation in this file. Create it and make sure #
#            its writable.                                  #
#            ( touch /glftpd/tmp/vacation.index )           #
#            ( chmod 777 /glftpd/tmp/vacation.index )       #
#                                                           #
# TMP=       Temporary storage for modifying user files.    #
#            Make sure users have full perms in here.       #
#                                                           #
# BLOCKUP=   Set max_sim_up to 0 when they go on vacation?  #
#            With this on TRUE, they cant upload.           #
#                                                           #
# BLOCKDN=   Set max_sim_down to 0 when they go on vacation?#
#            With this one TRUE, they cant download.        #
#                                                           #
# STATUS=    What do you want to trigger the status report  #
#            with? If you dont like your user to do this    #
#            then change it something only you know.        #
#                                                           #
# BINDATE=   This is the location of the binary 'date'.     #
#                                                           #
# TRIALDATA= If you are using Tur-Trial 2.1+ for monthly    #
#            quota, set this file to point to the same file #
#            as VACATIONDATA in Tur-Trial.conf. It will     #
#            use this seperate file to check how long the   #
#            user was on vacation and deduct those number   #
#            days from the users quota limit.               #
#            Set a # infront of this one to disable it.     #
#            Its disabled by default.                       #
#                                                           #
#            If you set this file, users can only go on     #
#            vacation ONCE in each month to prevent abuse.  #
#                                                           #
# NOTE: If someone issues the command by mistake and you    #
#       wish to fix it, edit the DB file. At the end is a   #
#       long number. Set that to 1 and they can enable      #
#       themselfs again.                                    #
#       If TRIALDATA is set, edit that file as well and     #
#       remove the line with the users name on it.          #
#                                                           #
#############################################################
# If you want irc output to go with this, set LOG to your   
# glftpd.log and, if you run zipscript-c, add this to       
# dZSbot.h:                                               
# To 'set msgtypes(DEFAULT)', add VACATION and VACATIONOFF    
#
# below the other 'set chanlist', add:                        
# set chanlist(VACATION)    "#YourChan"                     
# set chanlist(VACATIONOFF) "#YourChan"                     
#
# to the other 'set disable', add:                            
# set disable(VACATION)    0                                
# set disable(VACATIONOFF) 0                                
#
# to the other 'set variables', add:
# set variables(VACATION)    "%user %prelogin %postlogin"
# set variables(VACATIONOFF) "%user %duration %prelogin %postlogin"
#
# to the other 'set announce', add:
# set announce(VACATION)     "%user goes on vacation. Have fun!"
# set announce(VACATIONOFF)  "%user is back from vacation after %duration days. Welcome back!"
# 
# %prelogin and %postlogin are just how the LOGIN field in the user
# file looked before and after. Not much to have in irc, but 
# good that its logged.
#
# Dont forget to rehash the bot.
#
##-[ Contact ]---------------------------------------------##
# http://www.grandis.nu/glftpd/ or http://grandis.mine.nu   #
# I usually hang in #glftpd on efnet as Turran.             #
#############################################################
# Changelog:
#
# 1.6.1 : When coming back from vacation, it didnt always
#         recognize that the user are currently on vacation and
#         would tell him/her "not found in the DB and need
#         a siteop to restore you". Thats now fixed.
#
# 1.6   : Added an option when checking status: clean
#         This will clean out purged users ( not deleted ) from
#         the vacation db.
#         To set who can do this, a setting was added below:
#         ADMINFLAG='1|7'
#         Meaning that users with flag 1 and 7 can do this.
#         Encapsule in '' and seperate flags with |
#
#         When checking status, it will show if a user is deleted
#         ( flag 6 ) and those deleted & purged ( no userfile ).
#
#         Changed it into proc's instead of just going from top
#         to bottom. Helps upgrades etc.
#
#         Changed all awk's to cut. Changed all grep -w FLAGS
#         to grep "^FLAGS "
#
# 1.5   : Some changes in regards to TRIALDATA, added in 1.4.
#
#         A user can only go on vacation once every month.
#
#         If a user is already in the TRIALDATA file when
#         going on vacation, it will remove previous instances
#         and just add this new one.
#
#         Some distros does not have a GNU compliant date bin
#         which was required for the TRIALDATA part. It made it
#         impossible to use date to get the number of seconds
#         sometimes. I now make those calculations manually
#         instead, just using 'date +%s' so it should work
#         on, for instance, freebsd too.
#
#         Also added the setting DATEBIN so you can specify
#         its location.
#
#         For reasons unknown, I removed the userdata from
#         the TRIALDATA file when you went OFF vacation.
#         That should ofcourse no be done.
#
# 1.4   : Added TRIALDATA. A seperate DB file used by 
#         Tur-Trial 2.1+ to deduct credits from quotalimit
#         if the user was on vacation this month.
#         Its disabled with a # by default. If you enable it,
#         create the file and chmod 777 on it.
#
#         NOTE: If you are just upgrading, current vacation
#         users will NOT be effected by this. They need to
#         get out of vacation and back in again for this to
#         work.
#
# 1.3   : It switched the upload and download slots when a 
#         user came back from vacation.. oops.
#
# 1.2   : Counted 12 hours instead of 24 per day, giving the
#         wrong days count in status check.
#
# 1.1   : When doing a status check, it kept going down the
#         script instead of exiting. Not a big deal as nothing
#         happened *usually*.
#############################################################

USERS=/ftp-data/users            ## Users location
LOG=/ftp-data/logs/glftpd.log    ## Log location
MINDUR=7                         ## Min days to be on vaca..
VACATIONGROUP=VACATION           ## Group to add to.
DB=/tmp/vacation.index           ## Database file, seen chrooted.
TMP=/tmp                         ## Temporary location.
BLOCKUP=TRUE                     ## No uploading?
BLOCKDN=TRUE                     ## No downloading?
STATUS=status                    ## Check status with 'site ?'
ADMINFLAG='1|7'                  ## Used that can run 'clean'

DATEBIN='/bin/date'              ## Location of date executable.

# TRIALDATA="/etc/quota_vacation.db"
## Remove above # to enable Tur-Trial 2.1+ interaction.


##############################################################
# No changes below here, unless you want to change something #
# In which case, this text is useless and.. hmm. bah.        #
##############################################################

## Check if we can write to userfile.
if [ ! -w $USERS/$USER ]; then
  echo "Error. Your userfile can not be edited. Bug siteops to fix perms."
  exit 1
fi

if [ "$TRIALDATA" ]; then
  if [ ! -e "$TRIALDATA" ]; then
    echo "Please create the TRIALDATA file and set 777 on it."
    exit 1
  elif [ ! -w "$TRIALDATA" ]; then
    echo "Can not write to the TRIALDATA file. Set 777 on it."
    exit 1
  fi
fi

## Test the DATEBIN
if [ ! -x "$DATEBIN" ]; then
  echo "Error. Cant execute $DATEBIN. Make sure it exists and is executable."
  exit 1
fi

## No argument? Show help.
proc_help() {
  echo "############################################################"
  echo "# Vacation System $VER by Turranius."
  echo "# This script allows you to set yourself in vacation mode."
  echo "# During that time, you will be excluded from any quotas"
  if [ "$BLOCKUP" = "TRUE" -a "$BLOCKDN" = "TRUE" ]; then
    echo "# and you can not upload or download."
    SAIDIT="YES"
  fi
  if [ "$SAIDIT" != "YES" ]; then
    if [ "$BLOCKUP" = "TRUE" ]; then
      echo "# and you will not be able to upload while on vacation."
    fi
    if [ "$BLOCKDN" = "TRUE" ]; then
      echo "# and you will not be able to download while on vacation"
    fi
  fi
  if [ "$MINDUR" ]; then
    echo "# If you set yourself on vacation, $MINDUR days must pass"
    echo "# before you are allowed to change back."
  fi
  echo "#"
  echo "# To enable vacation, issue 'site vacation on'"
  echo "# To disable it, issue 'site vacation off'"
  exit 0
} ## End proc_help


## Show status for everyone on vacation.
proc_status() {
  if [ ! -r "$DB" ]; then
    echo "Can not read from $DB. Check perms or if the file even exists.."
    exit 1
  fi

  if [ -z "$( grep ^ $DB )" ]; then
    echo "No users on vacation..."
    exit 0
  fi
 
  if [ -z "$ADMINFLAG" ]; then
    ADMINFLAG="none"
  fi

  for each in `cat $DB`; do
    if [ "$each" ]; then
      user="$( echo $each | cut -d '^' -f1 )"
      otime="$( echo $each | cut -d '^' -f4 )"
      ominutes=$[$otime/60]
      ohours=$[$ominutes/60]
      odays=$[$ohours/24]
      
      time="$( $DATEBIN +%s )"
      minutes=$[$time/60]
      hours=$[$minutes/60]
      days=$[$hours/24]

      nhours=$[$hours-$ohours]
      ndays=$[$days-$odays]
      unset DELMSG
      if [ ! -e "$USERS/$user" ]; then
        FOUNDPURGED=TRUE
        DELMSG=" - Deleted and Purged?!"
        if [ "clean" = "$A2" ]; then
          if [ "$( grep "^FLAGS " "$USERS/$USER" | egrep "$ADMINFLAG" )" ]; then
            if [ ! -w "$DB" ]; then
              echo "Error. No write permissions on DB file $DB"
            else
              echo " "
              echo "Removing $user from vacation db."
              grep -v "^$user\^" "$DB" > "$TMP/vacationdata.tmp"
              cp -f "$TMP/vacationdata.tmp" "$DB"
              rm -f "$TMP/vacationdata.tmp"
            fi
          else
            if [ -z "$SAIDERR" ]; then
              echo "You do not have access to cleaning up the vacation DB."
              SAIDERR=TRUE
            fi
          fi
        fi
      elif [ "$( grep "^FLAGS " "$USERS/$USER" | grep "6" )" ]; then
        DELMSG=" - Deleted (Flag 6)"
      fi
      echo "$user has been gone for $ndays days ( $nhours hours )$DELMSG"
    fi
  done

  if [ -z "$user" ]; then
    echo "No users on vacation? DB empty."
  fi

  if [ "$A2" != "clean" -a "$FOUNDPURGED" = "TRUE" ]; then
    if [ "$( grep "^FLAGS " "$USERS/$USER" | egrep "$ADMINFLAG" )" ]; then
      echo "Issue 'status clean' to clean out purged users."
    fi
  fi

  exit 0
} ## End proc_status


## Going on vacation
proc_on() {
  if [ "$A2" != "yes" ]; then
    echo "Are you sure?"
    if [ "$MINDUR" != "" ]; then
      echo "You will not be able to change back for $MINDUR days."
    fi
    if [ "$BLOCKUP" = "TRUE" ]; then
      echo "You will not be able to upload while on vacation."
    fi
    if [ "$BLOCKDN" = "TRUE" ]; then
      echo "You will not be able to download while on vacation."
    fi
    if [ "$TRIALDATA" ]; then
      echo "The time you are away will be deducted from your quota on the month you are back."
    fi
    echo "To verify and agree to those terms; issue 'site vacation on yes'"
    exit 0
  fi
  
  if [ ! -w "$DB" ]; then
    echo "Error. No permissons to edit vacation database. Bug siteops to fix perms"
    exit 1
  fi

  if [ "$LOG" ]; then
    if [ ! -w "$LOG" ]; then
      echo "Error. Can not write to logfile. Ask siteops to fix perms on it."
      exit 1
    fi
  fi

  if [ "$TRIALDATA" ]; then
    if [ ! -w "$TRIALDATA" ]; then
      echo "Error. Can not write to TRIALDATA file. Ask a siteop to fix perms on it."
      exit 1
    fi
  fi

  if [ "$( grep "^$USER\^" $DB )" ]; then
    echo "You are already on vacation.. turn that off first"
    exit 1
  fi
 
  if [ "$TRIALDATA" ]; then
    unset TRIALINFO
    TRIALINFO="$( grep "^$USER^" $TRIALDATA | cut -d '^' -f2 )"
    if [ "$TRIALINFO" ]; then

      SECONDSNOW="$( $DATEBIN +%s )"
      DAYOFMONTH="$( $DATEBIN +%d )"
      SECONDSSOFAR=$[$DAYOFMONTH*86400]
      MONTHSTARTSEC=$[$SECONDSNOW-$SECONDSSOFAR]

      if [ "$TRIALINFO" -gt "$MONTHSTARTSEC" ]; then
        echo "You can only go on vacation once a month!"
        exit 1
      fi
    fi      
  fi

  FIRST="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f2 )"
  SECOND="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f3 )"
  DNSLOTS="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f4 )"
  UPSLOTS="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f5 )"
  
  TIMENOW="$( $DATEBIN +%s )"

  echo $USER"^"$UPSLOTS"^"$DNSLOTS"^"$TIMENOW >> $DB

  ## Add to TRIALDATA file. Remove previous ones if hes in there already.
  if [ "$TRIALDATA" ]; then
    TRIALINFO="$( grep "^$USER^" $TRIALDATA | cut -d '^' -f2 )"
    if [ "$TRIALINFO" ]; then
      grep -vw "^$USER" $TRIALDATA > $TMP/trialdata.tmp
      cp -f $TMP/trialdata.tmp $TRIALDATA
      rm -f $TMP/trialdata.tmp
    fi
    echo $USER"^"$TIMENOW >> $TRIALDATA
  fi

  if [ -z "$( grep "^$USER\^" $DB )" ]; then
    echo "Could not verify saved data. Contact siteops."
    echo "Write to $DB with your info must have failed."
    exit 1
  fi

  if [ "$TRIALDATA" ]; then
    if [ -z "$( grep "^$USER\^" $TRIALDATA )" ]; then
      echo "Could not verify saved data. Contact siteops."
      echo "Write to $TRIALDATA with your info must have failed."

      grep -vw "^$USER" $DB > $TMP/db.tmp
      cp -f $TMP/db.tmp $DB
      rm -f $TMP/db.tmp

      exit 1
    fi
  fi

  BEFORELOGINS="$FIRST $SECOND $DNSLOTS $UPSLOTS"

  if [ "$BLOCKDN" = "TRUE" ]; then
    DNSLOTS="0"
  fi

  if [ "$BLOCKUP" = "TRUE" ]; then
    UPSLOTS="0"
  fi 

  AFTERLOGINS="$FIRST $SECOND $DNSLOTS $UPSLOTS"

  if [ "$LOG" ]; then
    echo `$DATEBIN "+%a %b %e %T %Y"` VACATION: \"$USER\" \"$BEFORELOGINS\" \"$AFTERLOGINS\"  >> $LOG
  fi

  sed -e "s/^LOGINS $BEFORELOGINS/LOGINS $AFTERLOGINS/" $USERS/$USER > $TMP/$USER.tmp
  cp -f $TMP/$USER.tmp $USERS/$USER
  rm -f $TMP/$USER.tmp
  echo "GROUP $VACATIONGROUP" >> $USERS/$USER


  echo "All done. Issue 'site vacation off' when back."
  exit 0
} ## End proc_on

proc_off() {
  if [ ! -w "$DB" ]; then
    echo "Can not write to vacation db. Ask siteops to fix perms."
    exit 1
  fi 

  if [ "$TRIALDATA" ]; then
    if [ ! -w "$TRIALDATA" ]; then
      echo "Can not write to TRIALDATA file. Ask siteops to fix perms."
      exit 1
    fi
  fi

  if [ -z "$( grep "^$USER^" $DB )" ]; then
    if [ -z "$( grep "GROUP $VACATIONGROUP" $USERS/$USER )" ]; then
      echo "You are not marked for vacation..."
      exit 1
    else
      echo "Can not find you in vacation database. You need a siteop to restore you."
      exit 1
    fi
  fi

  USERRAWDATA="$( grep "^$USER\^" $DB )"

  if [ -z "$USERRAWDATA" ]; then
    echo "Couldnt grab your previous info from vacation db. Ask a siteop to fix perms or fix you manually."
    exit 1
  fi

  FIRST="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f2 )"
  SECOND="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f3 )"
  ODNSLOTS="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f4 )"
  OUPSLOTS="$( grep "^LOGINS " $USERS/$USER | cut -d ' ' -f5 )"

  DNSLOTS="$( echo $USERRAWDATA | cut -d '^' -f2 )"
  UPSLOTS="$( echo $USERRAWDATA | cut -d '^' -f3 )"
  TIMETHEN="$( echo $USERRAWDATA | cut -d '^' -f4 )"
  TIMENOW="$( $DATEBIN +%s )"
  
  if [ "$TIMETHEN" = "" -o "$TIMENOW" = "" ]; then
    echo "Error. Can not see when you went on vacation, or cant check what time it is now."
    exit 1
  fi

  if [ "$MINDUR" ]; then
    TIMETHEN=$[$TIMETHEN/60]
    TIMETHEN=$[$TIMETHEN/60]
    TIMETHEN=$[$TIMETHEN/24]
    TIMENOW=$[$TIMENOW/60]
    TIMENOW=$[$TIMENOW/60]
    TIMENOW=$[$TIMENOW/24]

    DIFFERENCE=$[$TIMENOW-$TIMETHEN]
 
    if [ "$DIFFERENCE" -lt "$MINDUR" ]; then
      echo "Minimum duration not yet reached."
      echo "You went on vacation $DIFFERENCE days ago and minimum is $MINDUR days"
      echo "If you feel this is in error, contact your favorite siteop."
      exit 1
    fi
  fi
 
  if [ "$ODNSLOTS" != "$DNSLOTS" -a "$OUPSLOTS" != "$UPSLOTS" ]; then
    BEFORELOGINS="$FIRST $SECOND $ODNSLOTS $OUPSLOTS"
    AFTERLOGINS="$FIRST $SECOND $UPSLOTS $DNSLOTS"

    sed -e "s/^LOGINS $BEFORELOGINS/LOGINS $AFTERLOGINS/" $USERS/$USER > $TMP/$USER.tmp
    cp -f $TMP/$USER.tmp $USERS/$USER
    rm -f $TMP/$USER.tmp
  fi

  if [ "$( grep "^GROUP $VACATIONGROUP" $USERS/$USER )" ]; then
    grep -vw "^GROUP $VACATIONGROUP" $USERS/$USER > $TMP/$USER.2.tmp
    cp -f $TMP/$USER.2.tmp $USERS/$USER
    rm -f $TMP/$USER.2.tmp
  fi

  grep -vw "^$USER" $DB > $TMP/db.tmp
  cp -f $TMP/db.tmp $DB
  rm -f $TMP/db.tmp

## Removed for now.. Shouldnt delete it from the TRIALDATA file.
#  if [ "$TRIALDATA" ]; then
#    grep -vw "^$USER" $TRIALDATA > $TMP/trialdata.tmp
#    cp -f $TMP/trialdata.tmp $TRIALDATA
#    rm -f $TMP/trialdata.tmp
#  fi

  if [ "$LOG" ]; then
    echo `$DATEBIN "+%a %b %e %T %Y"` VACATIONOFF: \"$USER\" \"$DIFFERENCE\" \"$BEFORELOGINS\" \"$AFTERLOGINS\"  >> $LOG
  fi
 
  echo "Welcome back!"
  exit 0
} ## End proc_on


## Set args into A1 and A2, removing all control chars for safety.
A1=`echo "$1" | tr -d '[:cntrl:]'`
A2=`echo "$2" | tr -d '[:cntrl:]'`

## Run process depending on A1 arg.
case $A1 in
  [oO][nN]) proc_on; exit 0 ;;
  [oO][fF][fF]) proc_off; exit 0 ;;
  [sS][tT][aA][tT][uU][sS]) proc_status; exit 0 ;;
  *) proc_help; exit 0
esac

exit 0