#!/bin/bash
VER=1.4

## Remove # below to hardset config location
## If not, it will be read from the same dir as tur-daystats.sh is in.
# config=/glftpd/bin/tur-daystats.conf

#--[ Script Start ]------------------------------#

## Load config file
if [ -z "$config" ]; then
  config="$( dirname $0 )/tur-daystats.conf"
fi

. $config

## Write to temp file.
proc_tempout() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $tmp/daystats.output.tmp
}

if [ "$1" = "test" ]; then
  test="yes"
fi

day1=`date +%e | tr -d ' '`
if [ "$( echo "$day1" | grep "^.$" )" ]; then
  day="[ 0]$day1"
fi

case `date +%m` in
  01) month="Jan";;
  02) month="Feb";;
  03) month="Mar";;
  04) month="Apr";;
  05) month="May";;
  06) month="Jun";;
  07) month="Jul";;
  08) month="Aug";;
  09) month="Sep";;
  10) month="Oct";;
  11) month="Nov";;
  12) month="Dec";;
esac

today="$( date +"... $month $day ..:..:.. "%Y )"
today2="$( date +"... $month $day1 ..:..:.. "%Y )"

egrep -i "^$today|^$today2" $gllog > $tmp/daystats.tmp
egrep -i "^$today|^$today2" $login >> $tmp/daystats.tmp

for slave in $MSS_SLAVES; do
  if [ -e "$MSS_DAYSTATS_DIR/$slave.daystats.log" ]; then
    if [ "$1" = "test" ]; then
      echo "Adding $MSS_DAYSTATS_DIR/$slave.daystats.log to todays stats."
    fi
    cat "$MSS_DAYSTATS_DIR/$slave.daystats.log" >> $tmp/daystats.tmp
    rm -f "$MSS_DAYSTATS_DIR/$slave.daystats.log"
  fi
done

logins="$( grep " LOGIN: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "logins" ]; then
  logins="0"
fi
logout="$( grep " LOGOUT: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "logout" ]; then
  logout="0"
fi
timeout="$( grep " TIMEOUT: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "timeout" ]; then
  timeout="0"
fi

nukes="$( grep " NUKE: " $tmp/daystats.tmp | grep -v "UNKNOWN" | wc -l | tr -d ' ' )"
if [ -z "$nukes" ]; then
  nukes="0"
fi
pres="$( grep "$pregrepline" $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "$pres" ]; then
  pres="0"
fi
newdir="$( grep " NEWDIR: " $tmp/daystats.tmp | egrep -vi $exclude | wc -l | tr -d ' ' )"
if [ -z "$newdir" ]; then
  newdir="0"
fi
deldir="$( grep " DELDIR: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "$deldir" ]; then
  deldir="0"
fi

for section in $sections; do

  ## Translator
  if [ "`echo "$section" | grep "\:"`" ]; then
    secname="`echo "$section" | cut -d ':' -f2`"
    section="`echo "$section" | cut -d ':' -f1`"
  else
    secname="$section"
  fi

  if [ "$FULLINFO" ]; then
    FULLINFO="$FULLINFO $separator"
  fi
  if [ "$FULLINFO" ]; then
    FULLINFO="$FULLINFO $secname: `grep " NEWDIR: " $tmp/daystats.tmp | grep -F -- "/$section/" | egrep -vi $exclude | wc -l | tr -d ' '`"
  else
    FULLINFO="$secname: `grep " NEWDIR: " $tmp/daystats.tmp | grep -F -- "/$section/" | egrep -vi $exclude | wc -l | tr -d ' '`"
  fi
done

for section in $sectionspre; do

  ## Translator
  if [ "`echo "$section" | grep "\:"`" ]; then
    secname="`echo "$section" | cut -d ':' -f2`"
    section="`echo "$section" | cut -d ':' -f1`"
  else
    secname="$section"
  fi

  if [ "$FULLPRE" ]; then
    FULLPRE="$FULLPRE $separator"
  fi
  if [ "$FULLPRE" ]; then
    FULLPRE="$FULLPRE $secname: `grep "$pregrepline" $tmp/daystats.tmp | grep "$section" | wc -l | tr -d ' ' | tr -d '"'`"
  else
    FULLPRE="$secname: `grep "$pregrepline" $tmp/daystats.tmp | grep "$section" | wc -l | tr -d ' ' | tr -d '"'`"
  fi
done

if [ "$groupnameinpreline" ]; then
  new="1"
  highest="0"
  for pre in `grep "$pregrepline" $tmp/daystats.tmp | cut -d ' ' -f$groupnameinpreline | tr -d "$removefromgroup" | tr -d '"' | sort`; do
    if [ "$pre" ]; then
      if [ "$last" != "$pre" ]; then
        new="1"
      fi
      if [ "first" = "" -o "$last" = "$pre" ]; then
        new="$( expr $new + 1 )"
      fi

      if [ "$new" = "$highest" ]; then
        top="$top & $pre"
        highest="$new"
      else
        if [ "$new" -gt "$highest" ]; then
          top="$pre"
          highest="$new"
        fi
      fi
      last="$pre"
      first="no"
    fi
  done
  if [ "$top" ]; then
    top="$( echo "$top" | tr -d '[:cntrl:]' )"
  fi
fi

nukenr="0"
highestnuke="0"
for nuke in `grep " NUKE: " $tmp/daystats.tmp | cut -d ' ' -f$usernameinnuke | grep -v "UNKNOWN" | tr -d '"' | sort`; do
  if [ "$nuke" ]; then
    if [ "$lastnuke" != "$nuke" ]; then
      nukenr="1"
    fi
    if [ "$firstnuke" = "" -o "$lastnuke" = "$nuke" ]; then
      nukenr=$[$nukenr+1]
    fi

    if [ "$nukenr" -gt "$highestnuke" ]; then
      topnuke="$nuke"
      topnukenr="$nukenr"
      highestnuke="$nukenr"
    fi
    lastnuke="$nuke"
    firstnuke="no"
  fi
done

proc_split() {
  unset topuser; unset pos; unset meg; unset files; unset speed
  raw=`echo "$each" | tr -s '^' ' ' | tr -d '[' | tr -d ']'`
  for eachsection in $raw; do
    if [ -z "$pos" ]; then
      pos=`echo "$eachsection"` # | tr -d '[' | tr -d ']'`
    else
      if [ -z "$topuser" ]; then
        topuser="$eachsection"
      else
        if [ "$( echo "$eachsection" | grep "MB$" )" -a "$meg" = "" ]; then
          files=$last"F"
          meg="$eachsection"
        else
          if [ "$( echo "$eachsection" | grep "KBs$" )" ]; then
            speed="$eachsection"
          fi
        fi
      fi
    fi
    last=$eachsection    
  done

  S=' '
  while [ -z "$( echo "$pos" | grep "$poslenght" )" ]; do
    pos="$pos$S"
  done
  while [ -z "$( echo "$topuser" | grep "$userlenght" )" ]; do
    topuser="$topuser$S"
  done
  while [ -z "$( echo "$meg" | grep "$meglenght" )" ]; do
    meg="$meg$S"
  done
  while [ -z "$( echo "$files" | grep "$filelenght" )" ]; do
    files="$files$S"
  done
  while [ -z "$( echo "$speed" | grep "$speedlenght" )" ]; do
    speed="$speed$S"
  done
}

UPLIST=`$statbin -u -t -x 5 -s $statsection | grep "\[..\]" | tr -s ' ' '^'`
for each in $UPLIST; do
  if [ "$( echo "$each" | grep '\[01\]' )" ]; then
    proc_split
    firstuppos="$pos"
    firstupuser="$topuser"
    firstupfiles="$files"
    firstupmeg="$meg"
    firstupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[02\]' )" ]; then
    proc_split
    seconduppos="$pos"
    secondupuser="$topuser"
    secondupfiles="$files"
    secondupmeg="$meg"
    secondupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[03\]' )" ]; then
    proc_split
    thirduppos="$pos"
    thirdupuser="$topuser"
    thirdupfiles="$files"
    thirdupmeg="$meg"
    thirdupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[04\]' )" ]; then
    proc_split
    fourthuppos="$pos"
    fourthupuser="$topuser"
    fourthupfiles="$files"
    fourthupmeg="$meg"
    fourthupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[05\]' )" ]; then
    proc_split
    fifthuppos="$pos"
    fifthupuser="$topuser"
    fifthupfiles="$files"
    fifthupmeg="$meg"
    fifthupspeed="$speed"
  fi
done

UPLIST=`$statbin -d -t -x 5 -s $statsection | grep "\[..\]" | tr -s ' ' '^'`
for each in $UPLIST; do
  if [ "$( echo "$each" | grep '\[01\]' )" ]; then
    proc_split
    firstdnpos="$pos"
    firstdnuser="$topuser"
    firstdnfiles="$files"
    firstdnmeg="$meg"
    firstdnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[02\]' )" ]; then
    proc_split
    seconddnpos="$pos"
    seconddnuser="$topuser"
    seconddnfiles="$files"
    seconddnmeg="$meg"
    seconddnspeed="$speed"    
  fi

  if [ "$( echo "$each" | grep '\[03\]' )" ]; then
    proc_split
    thirddnpos="$pos"
    thirddnuser="$topuser"
    thirddnfiles="$files"
    thirddnmeg="$meg"
    thirddnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[04\]' )" ]; then
    proc_split
    fourthdnpos="$pos"
    fourthdnuser="$topuser"
    fourthdnfiles="$files"
    fourthdnmeg="$meg"
    fourthdnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[05\]' )" ]; then
    proc_split
    fifthdnpos="$pos"
    fifthdnuser="$topuser"
    fifthdnfiles="$files"
    fifthdnmeg="$meg"
    fifthdnspeed="$speed"
  fi
done

gup="$( $statbin -u -T -x 1 -s $statsection | cut -b 1-16,48-80 | grep '\[01\]' | head -n1 )"
gupcheck="$( echo $gup | cut -d ' ' -f4 )"
gup="$( echo $gup | cut -d ' ' -f2 )"

gdn="$( $statbin -d -T -x 1 -s $statsection | cut -b 1-16,48-80 | grep '\[01\]' | head -n1 )"
gdncheck="$( echo $gdn | cut -d ' ' -f4 )"
gdn="$( echo $gdn | cut -d ' ' -f2 )"

weekname="$( date +%A )"

if [ -e "$tmp/daystats.output.tmp" ]; then
  rm -f "$tmp/daystats.output.tmp"
fi

proc_output

if [ "$test" = "yes" ]; then
  cat $tmp/daystats.output.tmp
else
  cat $tmp/daystats.output.tmp >> $gllog
fi

exit 0
