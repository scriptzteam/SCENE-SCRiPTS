#!/bin/bash
VER=1.2

COMMAND="transfer"

SOURCENAME="NiA"
USERSOURCEROOT=/glftpd
USERSOURCE=/ftp-data/users.ext

DESTNAME="NiAxXx"
USERDESTROOT=/glftpd
USERDEST=/ftp-data/users

LOG=/ftp-data/logs/transfers.log
TMP=/tmp
BIN=/bin
MINAMOUNT="10"
MAXAMOUNT="10000"


###########################
# GO                      #
###########################

## Shell or glftpd?
if [ "$FLAGS" = "" ]; then
  MODE="SHELL"
  USERSOURCE="$USERSOURCEROOT$USERSOURCE"
  USERDEST="$USERDESTROOT$USERDEST"
  LOG="$USERDESTROOT$LOG"
  TMP="$USERDESTROOT$TMP"
  BIN="$USERDESTROOT$BIN"
  TAKE="$1"
  USER="$2"
  CREDS="$3"
else
  MODE="GL"
  TAKE="$1"
  CREDS="$2"
fi

if [ "$MODE" = "SHELL" ]; then
  echo "Sorry, shell support is no longer possible."
  exit 0
fi

proc_log() {
  if [ "$LOG" != "" ]; then
    echo `date "+%a %b %e %T %Y"` TRANS: \"$*\" >> $LOG
  fi
}

if [ "$LOG" != "" ]; then
  if [ ! -w "$LOG" ]; then
    echo "Error. No write permissions to logfile. Ask siteops to fix that."
    exit 0
  fi
fi

if [ ! -w "$TMP" ]; then
  echo "Error. No write permissions to TMP folder. Ask siteops to fix that."
  exit 0
fi

if [ ! -w "$USERSOURCE" ]; then
  echo "Error. No write permissions to users folder on $SOURCENAME."
  exit 0
fi

if [ ! -w "$USERDEST" ]; then
  echo "Error. No write permissions to users folder on $DESTNAME."
  exit 0
fi

## Some aliases
if [ "$TAKE" = "put" -o "$TAKE" = "throw" ]; then
  TAKE="give"
fi
if [ "$TAKE" = "get" -o "$TAKE" = "fetch" ]; then
  TAKE="take"
fi
if [ "$TAKE" = "TAKE" ]; then
  TAKE="take"
fi
if [ "$TAKE" = "GIVE" ]; then
  TAKE="give"
fi

## Procedute for locking on source
proc_lock_src() {
  if [ -e $USERSOURCE/$USER.lock ]; then
    sleep 1
    if [ -e $USERSOURCE/$USER.lock ]; then
      echo "$USER seems locked at $USERSOURCE. Aborting."
      proc_log "$USER seems locked at $USERSOURCE. Aborting."
      SKIP="YES"
    else
      touch $USERSOURCE/$USER.lock
    fi
  else
    touch $USERSOURCE/$USER.lock
  fi
}

## Procedute for unlocking on source
proc_unlock_src() {
  if [ -e "$USERSOURCE/$USER.lock" ]; then
    rm -f $USERSOURCE/$USER.lock
  fi
}

## Procedute for locking on destination
proc_lock_dst() {
  if [ -e $USERDEST/$USER.lock ]; then
    sleep 1
    if [ -e $USERDEST/$USER.lock ]; then
      echo "$USER seems locked at $USERDEST. Aborting."
      proc_log "$USER seems locked at $USERDEST. Aborting."
      SKIP="YES"
    else
      touch $USERDEST/$USER.lock
    fi
  else
    touch $USERDEST/$USER.lock
  fi
}

## Procedute for unlocking on destination
proc_unlock_dst() {
  if [ -e "$USERDEST/$USER.lock" ]; then
    rm -f $USERDEST/$USER.lock
  fi
}

## Procedure for verifying userfile.
proc_userver() {
  unset VERERR
  if [ ! -e "$CHECKPATH/$USER" ]; then
    VERERR="User_Does_Not_Exist"
  else
    if [ -z "$( grep "^USER " $CHECKPATH/$USER )" ]; then VERERR="$VERERR USER"; fi
    if [ -z "$( grep "^GENERAL " $CHECKPATH/$USER )" ]; then VERERR="$VERERR GENERAL"; fi
    if [ -z "$( grep "^LOGINS " $CHECKPATH/$USER )" ]; then VERERR="$VERERR LOGINS"; fi
    if [ -z "$( grep "^TIMEFRAME " $CHECKPATH/$USER )" ]; then VERERR="$VERERR TIMEFRAME"; fi
    if [ -z "$( grep "^FLAGS " $CHECKPATH/$USER )" ]; then VERERR="$VERERR FLAGS"; fi
    if [ -z "$( grep "^TAGLINE " $CHECKPATH/$USER )" ]; then VERERR="$VERERR TAGLINE"; fi
    if [ -z "$( grep "^DIR " $CHECKPATH/$USER )" ]; then VERERR="$VERERR DIR"; fi
    if [ -z "$( grep "^CREDITS " $CHECKPATH/$USER )" ]; then VERERR="$VERERR CREDITS"; fi
    if [ -z "$( grep "^RATIO " $CHECKPATH/$USER )" ]; then VERERR="$VERERR RATIO"; fi
    if [ -z "$( grep "^ALLUP " $CHECKPATH/$USER )" ]; then VERERR="$VERERR ALLUP"; fi
    if [ -z "$( grep "^ALLDN " $CHECKPATH/$USER )" ]; then VERERR="$VERERR ALLDN"; fi
    if [ -z "$( grep "^WKUP " $CHECKPATH/$USER )" ]; then VERERR="$VERERR WKUP"; fi
    if [ -z "$( grep "^WKDN " $CHECKPATH/$USER )" ]; then VERERR="$VERERR WKDN"; fi
    if [ -z "$( grep "^DAYUP " $CHECKPATH/$USER )" ]; then VERERR="$VERERR DAYUP"; fi
    if [ -z "$( grep "^DAYDN " $CHECKPATH/$USER )" ]; then VERERR="$VERERR DAYDN"; fi
    if [ -z "$( grep "^MONTHUP " $CHECKPATH/$USER )" ]; then VERERR="$VERERR MONTHUP"; fi
    if [ -z "$( grep "^MONTHDN " $CHECKPATH/$USER )" ]; then VERERR="$VERERR MONTHDN"; fi
    if [ -z "$( grep "^NUKE " $CHECKPATH/$USER )" ]; then VERERR="$VERERR NUKE"; fi
    if [ -z "$( grep "^TIME " $CHECKPATH/$USER )" ]; then VERERR="$VERERR TIME"; fi
    if [ -z "$( grep "^SLOTS " $CHECKPATH/$USER )" ]; then VERERR="$VERERR SLOTS"; fi
    if [ "$VERERR" != "" ]; then
      VERERR="$( echo $VERERR | tr -s ' ' )"
    fi
  fi
}

echo "Please wait. Verifying network. - Mode = $MODE"
  
if [ -e "$USERDEST/$USER" ]; then
  ok=yes
else
  echo "User $USER does not exist on $DESTNAME or permissions are wrong."
  proc_log "User $USER does not exist on $DESTNAME or permissions are wrong. Command was: $*"
  exit 0
fi

if [ -e "$USERSOURCE/$USER" ]; then
  ok=yes
else
  echo "User $USER does not exist on $SOURCENAME or link is down."
  proc_log "$USER tried to transfer creds but does not exist on $SOURCENAME or link is down. Command was: $*"
  exit 0 
fi

## Verify network link
if [ -w "$USERSOURCE/$USER" ]; then
  LINK="UP"
else
  echo "Transfer failed. Link to $SOURCENAME failed or the userfile is not writable."
  proc_log "Transfer failed for $USERSOURCE/$USER. Link to $SOURCENAME failed or the userfile is not writable. Command was: $*"
  exit 0
fi
if [ -w "$USERDEST/$USER" ]; then
  LINK="UP"
else
  echo "Transfer failed. Cant write to current userfile on $DESTNAME."
  proc_log "Transfer failed. Cant write to $USER on $DESTNAME. Command was: $*"
  exit 0
fi

## Verify userfile integrity on hub
CHECKPATH="$USERSOURCE"
if [ "$CREDS" != "" ]; then
  proc_userver
  if [ ! -z "$VERERR" ]; then
    echo "Warning. Userfile $USER on $SOURCENAME have problems with the following fields: $VERERR"
    proc_log "Warning. Userfile $USERSOURCE/$USER on $SOURCENAME have problems with the following fields: $VERERR"
    exit 0
  fi
  unset CHECKPATH

  ## Verify userfile integrity on slave
  CHECKPATH="$USERDEST"
  if [ ! -z "$VERERR" ]; then
    echo "Warning. Userfile $USER on $DESTNAME have problems with the following fields: $VERERR"
    proc_log "Warning. Userfile $USERDEST/$USER on $DESTNAME have problems with the following fields: $VERERR"
   exit 0
   fi
   unset CHECKPATH
fi

## Show status
if [ "$MODE" = "GL" -a "$1" = "status" ]; then
  if [ "$2" != "" ]; then
    USER="$2"
  fi
  SOURCECREDSKB="$( grep "^CREDITS " $USERSOURCE/$USER | awk '{print $2}' )"
  if [ "$SOURCECREDSKB" = "" ]; then
    echo "Can not read $SOURCENAME credits for $USER"
    proc_log "Can not read $SOURCENAME credits for $USER. Command was: $*"
    exit 0
  else
    SOURCECREDSMB="$( echo "$SOURCECREDSKB / 1024" | bc -l | awk -F"." '{print $1}' )"  
  fi
  DESTCREDSKB="$( grep "^CREDITS " $USERDEST/$USER | awk '{print $2}' )"
  if [ "$DESTCREDSKB" = "" ]; then
    echo "Can not read $DESTNAME credits for $USER"
    proc_log "Can not read $DESTNAME credits for $USER. Command was: $*"
    exit 0
  else
    DESTCREDSMB="$( echo "$DESTCREDSKB / 1024" | bc -l | awk -F"." '{print $1}' )"
  fi
  echo "-----------------------------------------"
  echo "Current credits:                         "
  echo "$SOURCENAME : $SOURCECREDSMB Mb"
  echo "$DESTNAME : $DESTCREDSMB Mb"
  echo "-----------------------------------------"
  exit 0
fi

if [ "$CREDS" = "" ]; then
  echo "-------------------------------------------------"
  echo "Welcome to the Credits Transfer System $VER      "
  echo "Current link is between $SOURCENAME/$DESTNAME"
  echo "-------------------------------------------------"
  echo "Usage :                                          "
  if [ "$MODE" = "GL" ]; then
    echo "site $COMMAND status                             "
    echo "site $COMMAND take/give Mb_Amount                "
   else
    echo "transfercredits.sh take/give username Mb_Amount  "
  fi
  echo "take = $SOURCENAME -> $DESTNAME"
  echo "give = $DESTNAME -> $SOURCENAME"
  echo "                                                 "
  echo "Min amount to move is $MINAMOUNT Mb.             "
  echo "Max amount to move is $MAXAMOUNT Mb.             "
  echo "Specifying 'all' instead of amount will move all "
  echo "your credits between sites, but not over max     "
  echo "amount though.                                   "
  echo ""
  echo "Example:"
  if [ "$MODE" = "GL" ]; then
    echo "site $COMMAND take 500"
    echo "would move 500 meg creds from $SOURCENAME to $DESTNAME"
  else
    echo "transfercreds.sh take turranius 500"
    echo "would move 500 meg of turranius's creds from $SOURCENAME to $DESTNAME"
  fi
  echo "---------------------------[ Turranius 2002 ]----"
  exit 0
fi

## Make sure TAGLINE does not contain any of the words in the below egrep.
unset VERIFY
VERIFY="$( grep "^TAGLINE " $USERSOURCE/$USER | egrep -w 'ALLUP|ALLDN|WKUP|WKDN|DAYUP|DAYDN|MONTHUP|MONTHDN|NUKE|TIME|CREDITS' )"
if [ "$VERIFY" != "" ]; then
  echo "Your tagline on $SOURCENAME contains a bad word. Please change it and wait for it to be replicated."
  echo "Bad words are: ALLUP, ALLDN, WKUP, WKDN, DAYUP, DAYDN, MONTHUP, MONTHDN, NUKE, TIME & CREDITS"
  proc_log "$USER was denied transfer cause his tagline on $USERSOURCE has bad words. Command was: $*"
  exit 0
fi
unset VERIFY
VERIFY="$( grep "^TAGLINE " $USERDEST/$USER | egrep -w 'ALLUP|ALLDN|WKUP|WKDN|DAYUP|DAYDN|MONTHUP|MONTHDN|NUKE|TIME|CREDITS' )"
if [ "$VERIFY" != "" ]; then
  echo "Your tagline on $DESTNAME contains a bad word. Please change it and wait for it to be replicated."
  echo "Bad words are: ALLUP, ALLDN, WKUP, WKDN, DAYUP, DAYDN, MONTHUP, MONTHDN, NUKE, TIME & CREDITS"
  proc_log "$USER was denied transfer cause his tagline on $USERSOURCE has bad words. Command was: $*"
  exit 0
fi

if [ "$CREDS" = "all" -o "$CREDS" = "ALL" ]; then
  CREDS="666"
  ALL="TRUE" 
fi

## Make sure bet is not over 6 chars long
MAX="$( echo "$CREDS" | wc -c | tr -d ' ' )"
if [ "$MAX" -gt "6" ]; then
  echo "Nice try to overflow, but max in $MAXAMOUNT Mb, sucka."
  proc_log "$USER tried to fuck something up! Command was: $*"
  exit 0
fi

## Make a test calculation on it to make sure there are no crap in it.
TESTING="$( expr $CREDS \+ 2 )"
if [ "$TESTING" = "" ]; then
  echo "Only use numbers in credits. No dots or other chars."
  proc_log "$USER tried to fuck something up! Command was: $*"
  exit 0
fi

## Check for -
VERIFY="$( echo $CREDS | grep -F -i -- "-" )"
if [ "$VERIFY" != "" ]; then
  echo "No can do buddy! Done use -"
  proc_log "$USER tried to fuck something up! Command was: $*"
  exit 0
fi

## User tried to transfer minus credits.
if [ "$CREDS" -lt "0" ]; then
  echo "Nice try, jackass"
  proc_log "$USER tried to fuck something up! Command was: $*"
  exit 0
fi

## User tried to transfer below minumum limit.
if [ "$CREDS" -lt "$MINAMOUNT" ]; then
  echo "Minimum amount to transfer is $MINAMOUNT Mb"
  proc_log "$USER tried to transfer less then $MINAMOUNT MB. Command was: $*"
  exit 0
fi 

## User tried to transfer above max limit.
if [ "$CREDS" -gt "$MAXAMOUNT" ]; then
  echo "Maximum amount to transfer is $MAXAMOUNT Mb"
  proc_log "$USER tried to transfer more then $MAXAMOUNT MB. Command was: $*"
  exit 0
fi 

if [ "$LINK" = "UP" ]; then
  
  if [ "$TAKE" != "give" ]; then
    if [ "$TAKE" != "take" ]; then
      echo "Use either give or take."
      if [ "$MODE" = "GL" ]; then
        echo "site $COMMAND, for help"
      fi
      exit 0
    fi
  fi
 
  ## Put amount in variable $CREDSMB and make a KiloByte calculation on it.
  CREDSMB="$CREDS"
  CREDSKB="$( echo "$CREDSMB * 1024" | bc -l | awk -F"." '{print $1}' )"

  ## Try and read credits from source site.
  SOURCECREDSKB="$( grep "^CREDITS " $USERSOURCE/$USER | awk '{print $2}' )"
  if [ "$SOURCECREDSKB" = "" ]; then
    echo "Can not read source sites credits."
    proc_log "Can not read CREDITS field on $SOURCENAME. Command was: $*"
    exit 0
  fi
  SOURCECREDSMB="$( echo "$SOURCECREDSKB / 1024" | bc -l | awk -F"." '{print $1}' )"
  
  ## Try and read credits from destination site.
  DESTCREDSKB="$( grep "^CREDITS " $USERDEST/$USER | awk '{print $2}' )"
  if [ "$DESTCREDSKB" = "" ]; then
    echo "Can not read destination sites credits."
    proc_log "Can not read CREDITS field on $DESTNAME. Command was: $*"
    exit 0
  fi
  DESTCREDSMB="$( echo "$DESTCREDSKB / 1024" | bc -l | awk -F"." '{print $1}' )"
  
  ## --> Take <-- credits from source
  if [ "$TAKE" = "take" ]; then
    if [ "$ALL" = "TRUE" -a "$CREDS" = "666" ]; then
      CREDSMB="$SOURCECREDSMB"
      CREDSKB="$( echo "$CREDSMB * 1024" | bc -l | awk -F"." '{print $1}' )"
      if [ "$CREDSMB" -lt "$MINAMOUNT" ]; then
        echo "You must have atleast $MINAMOUNT Mb credits to move."
        proc_log "$USER did not have atleast $MINAMOUNT credits to move. Command was: $*"
        exit 0
      else
        if [ "$CREDSMB" -gt "$MAXAMOUNT" ]; then
          echo "Max amount is $MAXAMOUNT Mb. Setting it to that amount."
          proc_log "$USER moves ALL creds, but its more then the max: $MAXAMOUNT MB. Setting it to that amount. Command was: $*"
          CREDSMB="$MAXAMOUNT"
          CREDSKB="$( echo "$CREDSMB * 1024" | bc -l | awk -F"." '{print $1}' )"
        else
          echo "Moving ALL credits ($SOURCECREDSMB Mb) from $SOURCENAME to $DESTNAME."
          proc_log "$USER starts moving ALL credits ($SOURCECREDSMB Mb) from $SOURCENAME to $DESTNAME. Command was: $*"
        fi
      fi
    fi  

    if [ "$CREDSKB" -gt "$SOURCECREDSKB" ]; then
      echo "You do not have $CREDSMB MB on $SOURCENAME - Only $SOURCECREDSMB MB"
      proc_log "$USER tried to move $CREDSMB MB from $SOURCENAME but only have $SOURCECREDSMB MB. Command was: $*"
      exit 0
    else
      ## Check that no .lock file exists on source.
      if [ -e $USERSOURCE/$USER.lock ]; then
        echo "Your userfile is locked on $SOURCENAME - Log out for secure transfer or try again."
        proc_log "$USER have a locked userfile on $SOURCENAME. Command was: $*"
        exit 0
      fi

      ## Check that no .lock file exists on destination.
      if [ -e $USERDEST/$USER.lock ]; then
        echo "Your userfile is locked on $DESTNAME - Log out any other sessions or try again."
        proc_log "$USER have a locked userfile on $DESTNAME. Command was: $*"
        exit 0
      fi

      echo "Transfering credits. Do NOT log out."
      NEWCREDSDESTKB="$( echo "$DESTCREDSKB + $CREDSKB" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSDESTMB="$( echo "$NEWCREDSDESTKB / 1024" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSSOURCEKB="$( echo "$SOURCECREDSKB - $CREDSKB" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSSOURCEMB="$( echo "$NEWCREDSSOURCEKB / 1024" | bc -l | awk -F"." '{print $1}' )"
      if [ "$ALL" != "TRUE" ]; then
        echo "Transfering $CREDSKB Kb ($CREDSMB Mb) from $SOURCENAME to $DESTNAME"
        proc_log "$USER starts transfering $CREDSKB Kb ($CREDSMB Mb) from $SOURCENAME to $DESTNAME. Command was: $*"
      fi
      if [ -w "$USERSOURCE/$USER" ]; then

        ## Give credits to source.

        if [ -w $USERSOURCE/$USER ]; then
          if [ -w $USERDEST/$USER ]; then
            ## Take credits from source.
            sed -e "s/^CREDITS .*/CREDITS $NEWCREDSSOURCEKB/" $USERSOURCE/$USER > $TMP/TEMP.$USER.CREDITS
            ## Take credits from destination.
            sed -e "s/^CREDITS .*/CREDITS $NEWCREDSDESTKB/" $USERDEST/$USER > $TMP/TEMP.$USER.DEST.CREDITS

            ## Verify new file ment for hub.
            OLDUSERNAME="$USER"
            USER="TEMP.$USER.CREDITS"
            CHECKPATH="$TMP"
            proc_userver
            if [ ! -z "$VERERR" ]; then
              echo "Warning. Userfile corruption during editing. Problem with: $VERERR. Aborting"
              proc_log "Warning. Edited userfile for $OLDUSER, ment for $SOURCENAME has a problem with: $VERERR. Aboring."
              rm -f $TMP/TEMP.$USER.CREDITS
              rm -f $TMP/TEMP.$USER.DEST.CREDITS
              exit 0
            else
              USER="$OLDUSERNAME"
              unset OLDUSERNAME
              unset CHECKPATH
            fi

            ## Verify new file ment for slave
            OLDUSERNAME="$USER"
            USER="TEMP.$USER.DEST.CREDITS"
            CHECKPATH="$TMP"
            proc_userver
            if [ ! -z "$VERERR" ]; then
              echo "Warning. Userfile corruption duing editing to the following fields: $VERERR. Aborting"
              proc_log "Warning. Edited userfile for $OLDUSER, ment for $DESTNAME has a problem with: $VERERR. Aboring."
              rm -f $TMP/TEMP.$USER.CREDITS
              rm -f $TMP/TEMP.$USER.DEST.CREDITS
              exit 0
            else
              USER="$OLDUSERNAME"
              unset OLDUSERNAME
              unset CHECKPATH
            fi

            ## Log it.
             if [ "$ALL" = "TRUE" ]; then
               proc_log "OK! $USER transfers ALL his creds, $CREDSMB Mb, from $SOURCENAME to $DESTNAME - Moving userfiles"
             else
               proc_log "OK! $USER transfers $CREDSMB Mb from $SOURCENAME to $DESTNAME - Moving userfiles"
            fi

            proc_lock_dst
            proc_lock_src
            if [ "$SKIP" != "YES" ]; then
              if [ -w "$TMP/TEMP.$USER.CREDITS" ] && [ -w "$TMP/TEMP.$USER.DEST.CREDITS" ]; then
                mv -f $TMP/TEMP.$USER.CREDITS $USERSOURCE/$USER
                mv -f $TMP/TEMP.$USER.DEST.CREDITS $USERDEST/$USER
              else
                echo "Error: For some reason I dont have access to do this.."
                proc_log "Error: No read access to temp files in $TMP for $USER. Check perms"
                proc_unlock_dst
                proc_unlock_src
              fi

            else
              sleep 1
              proc_unlock_dst
              proc_unlock_src
              exit 0
            fi
            proc_unlock_dst
            proc_unlock_src
          else
            echo "Cant write destination file $USERDEST/$USER - Quitting" 
            proc_log "Cant write destination file $USERDEST/$USER - Quitting. Command was: $*" 
            exit 0
          fi
        else
          echo "Cant write source file $USERSOURCE/$USER - Quitting"
          proc_log "Cant write source file $USERSOURCE/$USER - Quitting. Command was: $*"
          exit 0
        fi
      else
        echo "Hrmp, seems I cant write to userfile. Either link went down or perms are wrong."
        proc_log "Cant write to userfile on $SOURCENAME for $USER. link went down?  Command was: $*"
        exit 0
      fi
      echo "All done. Please verify both sites BEFORE you use this command again."
      echo "( you can verify with: site $COMMAND status )"
      exit 0
    fi
  fi

  ## Give credits to source.
  if [ "$TAKE" = "give" ]; then

    if [ "$ALL" = "TRUE" -a "$CREDS" = "666" ]; then
      CREDSMB="$DESTCREDSMB"
      CREDSKB="$( echo "$CREDSMB * 1024" | bc -l | awk -F"." '{print $1}' )"
      if [ "$CREDSMB" -lt "$MINAMOUNT" ]; then
        echo "You must have atleast $MINAMOUNT Mb credits to move."
        proc_log "$USER did not have atleast $MINAMOUNT credits to move. Command was: $*"
        exit 0
      else
        if [ "$CREDSMB" -gt "$MAXAMOUNT" ]; then
          echo "Max amount is $MAXAMOUNT Mb. Setting it to that amount."
          proc_log "$USER moves ALL creds, but its more then the max: $MAXAMOUNT MB. Setting it to that amount. Command was: $*"
          CREDSMB="$MAXAMOUNT"
          CREDSKB="$( echo "$CREDSMB * 1024" | bc -l | awk -F"." '{print $1}' )"
        else
          echo "Moving ALL credits ($DESTCREDSMB Mb) from $DESTNAME to $SOURCENAME."
          proc_log "$USER starts moving ALL credits ($DESTCREDSMB Mb) from $DESTNAME to $SOURCENAME. Command was: $*"
        fi
      fi
    fi  

    if [ "$CREDSKB" -gt "$DESTCREDSKB" ]; then
      echo "You do not have $CREDSMB Mb on $DESTNAME - Only $DESTCREDSMB Mb"
      proc_log "$USER tried to move $CREDSMB MB from $DESTNAME but only have $DESTCREDSMB MB. Command was: $*"
      exit 0
    else
      if [ -e $USERSOURCE/$USER.lock ]; then
        echo "Your userfile is locked on $SOURCENAME - Log out for secure transfer or try again."
        exit 0
      fi

      ## Check that no .lock file exists on destination.
      if [ -e $USERDEST/$USER.lock ]; then
        echo "Your userfile is locked on $DESTNAME - Log out any other sessions or try again."
        proc_log "$USER have a locked userfile on $DESTNAME. Command was: $*"
        exit 0
      fi

      echo "Transfering credits. Do NOT log out."
      NEWCREDSDESTKB="$( echo "$DESTCREDSKB - $CREDSKB" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSDESTMB="$( echo "$NEWCREDSDESTKB / 1024" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSSOURCEKB="$( echo "$SOURCECREDSKB + $CREDSKB" | bc -l | awk -F"." '{print $1}' )"
      NEWCREDSSOURCEMB="$( echo "$NEWCREDSSOURCEKB / 1024" | bc -l | awk -F"." '{print $1}' )"
      if [ "$ALL" != "TRUE" ]; then
        echo "Transfering $CREDSKB Kb ($CREDSMB Mb) from $DESTNAME to $SOURCENAME"
        proc_log "$USER starts transfering $CREDSKB Kb ($CREDSMB Mb) from $DESTNAME to $SOURCENAME Command was: $*"
      fi
      if [ -w "$USERSOURCE/$USER" ]; then

        if [ -w $USERSOURCE/$USER ]; then
          if [ -w $USERDEST/$USER ]; then
            ## Take credits from source.
            sed -e "s/^CREDITS .*/CREDITS $NEWCREDSSOURCEKB/" $USERSOURCE/$USER > $TMP/TEMP.$USER.CREDITS

            ## Give credits to destination.
            sed -e "s/^CREDITS .*/CREDITS $NEWCREDSDESTKB/" $USERDEST/$USER > $TMP/TEMP.$USER.DEST.CREDITS
 
            ## Verify new file ment for hub.
            OLDUSERNAME="$USER"
            USER="TEMP.$USER.CREDITS"
            CHECKPATH="$TMP"
            proc_userver
            if [ ! -z "$VERERR" ]; then
              echo "Warning. Userfile corruption duing editing to the following fields: $VERERR. Aborting"
              proc_log "Warning. Edited userfile for $OLDUSER, ment for $SOURCENAME has a problem with: $VERERR. Aboring."
              rm -f $TMP/TEMP.$USER.CREDITS
              rm -f $TMP/TEMP.$USER.DEST.CREDITS
              exit 0
            else
              USER="$OLDUSERNAME"
              unset OLDUSERNAME
              unset CHECKPATH
            fi

            ## Verify new file ment for slave
            OLDUSERNAME="$USER"
            USER="TEMP.$USER.DEST.CREDITS"
            CHECKPATH="$TMP"
            proc_userver
            if [ ! -z "$VERERR" ]; then
              echo "Warning. Userfile corruption duing editing to the following fields: $VERERR. Aborting"
              proc_log "Warning. Edited userfile for $OLDUSER, ment for $DESTNAME has a problem with: $VERERR. Aboring."
              rm -f $TMP/TEMP.$USER.CREDITS
              rm -f $TMP/TEMP.$USER.DEST.CREDITS
              exit 0
            else
              USER="$OLDUSERNAME"
              unset OLDUSERNAME
              unset CHECKPATH
            fi

            ## Log it.
            if [ "$ALL" = "TRUE" ]; then
              proc_log "OK! $USER transfers ALL his creds, $CREDSMB Mb, from $DESTNAME to $SOURCENAME - Moving userfiles."
            else
              proc_log "OK! $USER transfers $CREDSMB Mb from $DESTNAME to $SOURCENAME - Moving userfiles"
            fi

            proc_lock_dst
            proc_lock_src
            if [ "$SKIP" != "YES" ]; then
              if [ -w "$TMP/TEMP.$USER.CREDITS" ] && [ -w "$TMP/TEMP.$USER.DEST.CREDITS" ]; then
                mv -f $TMP/TEMP.$USER.CREDITS $USERSOURCE/$USER
                mv -f $TMP/TEMP.$USER.DEST.CREDITS $USERDEST/$USER
              else
                echo "Error: For some reason I dont have access to do this.."
                proc_log "Error: No read access to temp files in $TMP for $USER. Check perms."
                proc_unlock_dst
                proc_unlock_src
              fi
            else
              sleep 1
              proc_unlock_dst
              proc_unlock_src
              exit 0
            fi
            proc_unlock_dst
            proc_unlock_src
          else
            echo "Cant write to destination file $USERDEST/$USER - Quitting"
            proc_log "Cant write destination file $USERDEST/$USER - Quitting. Command was: $*" 
            exit 0
          fi
        else
          echo "Cant write to source file $USERSOURCE/$USER - Quitting"
          proc_log "Cant write source file $USERSOURCE/$USER - Quitting. Command was: $*" 
          exit 0
        fi
      else
        echo "Hm, seems I cant write to userfiles anymore. Either link is down or perms are wrong."
        proc_log "Cant write to userfile on $SOURCENAME for $USER. link went down?  Command was: $*"
        exit 0
      fi
      echo "All done. Please verify both sites BEFORE you use this command again."
      echo "( you can verify with: site $COMMAND status )"
      exit 0
    fi
  fi
fi