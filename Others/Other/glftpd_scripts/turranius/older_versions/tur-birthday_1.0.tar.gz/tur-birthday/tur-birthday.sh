#!/bin/bash
VER=1.0
#--[ Intro ]----------------------------------------------------#
#                                                               #
# Tur-Birthday. A script to reward users on their birthday!     #
# They can get leech for 24 hours and can also be given credits.#
#                                                               #
# Since a birthday present is supposed to be a suprise, you     #
# can set a percentage value if they should get leech or not.   #
# For the credits part, you may specify a min and max value.    #
# A number in between will be awarded to the user.              #
#                                                               #
# The users can add themselfs to the birthday database. They    #
# can also change their birthday and ops can del, but it will   #
# always save that user in the db anyway with the time of their #
# last gift. In other words, you can only get ONE present per   #
# year, no matter if you del and add yourself again.            #
#                                                               #
# A crontab, once a day, is required to check who has a         #
# birthday and reward those appropriate. It also removes the    #
# leech at the 24 hour mark, had they been given that yesterday #
#                                                               #
# You can add users with leech too, but they will only get a    #
# "congratulations" in the channel.                             #
#                                                               #
#--[ Installation ]---------------------------------------------#
#                                                               #
# Its a standard (c)Tur- certified install. =)                  #
#                                                               #
# Copy tur-birthday.sh to /glftpd/bin. Chmod it to 755 or so.   #
# Copy tur-birthday.tcl to your boths scripts dir, add it to    #
# the bots config and rehash it.                                #
# Edit the .tcl if you wish to change the default binds.        #
#                                                               #
# Add the following to crontab to run it 1 min past midnight    #
# each day: 1 0 * * * /glftpd/bin/tur-birthday.sh daily         #
#                                                               #
# It does NOT have to be executed at midnight. It will announce #
# and start the 24H leech clock at this time though, but you    #
# might just as well run it at 9am or something.                #
# As long as its only executed once a day, you'll be fine.      #
#                                                               #
#--[ Requirements ]---------------------------------------------#
#                                                               #
# The only non-standard binary that is needed is bc. Its only   #
# needed for givecreds, so if you have that disabled, you wont  #
# even need that ( try: echo "100 + 100" | bc -l ).             #
# I dont trust expr or bash's internal calculator to count high #
# numbers and I guess you agree that nulled credits sucks.      #
#                                                               #
#--[ Settings ]-------------------------------------------------#
#                                                               #
# DATAFILE    = This is the database text file in which we keep #
#               everyone who is added. Its in the format:       #
#               username^birthday^lastgift^former_ratio         #
#               Lastgift is the number of seconds, since 1970   #
#               from when they got their last gift. When        #
#               adding someone, it will set it to 1.            #
#               Former_ratio is their former ratio, if they got #
#               leech as a gift.                                #
#               If former_ratio is set and its not their        #
#               birthday, they will get that ratio back.        #
#                                                               #
#               If you want to reset someones last gift day,    #
#               edit this file and set the 3rd value to 1.      #
#                                                               #
#               Create this file and set chmod 777 on it.       #
#                                                               #
# USERS       = Path to users directory.                        #
#                                                               #
# LOG         = Full path to glftpd.log if you want the bot to  #
#               announce birthdays and gifts.                   #
#               add/del/info commands are not bound by this.    #
#               Set to "" to disable logging to glftpd.log      #
#                                                               #
# TMP         = A temporary directory. Make sure the user that  #
#               is running the bot has full access to it.       #
#                                                               #
# SKIPLEECH   = TRUE/FALSE. Dont allow users with leech to be   #
#               added. Its ok if they are as they will get      #
#               congratulated, but not given a gift if so.      #
#                                                               #
# HEADER      = This will be the header of every announce to    #
#               the chan. Note that ^B is start and stop of     #
#               bold text, but you cant just write it. Its a    #
#               control char made with ctrl-b in vi.            #
#                                                               #
# INFOBREAK   = When doing !bdinfo, it will show everyones      #
#               birthdays sorted by date. Problem is that if    #
#               the output is more then 400 chars, irc will cut #
#               it short. So by default, this is set to 400 to  #
#               make it 2 lines if it gets above 400 ( or 3 if  #
#               it gets above 800 ).                            #
#               You can use this to output one user per line    #
#               if you wish. Set it to 4 or so and each user    #
#               will get his/her own line of output.            #
#                                                               #
# FORCEDAY    = If you want to test or something, this will     #
#               emulate the set day. in MMDD format ONLY !      #
#               Disabled with ="" by default.                   #
#                                                               #
# GIVE24HLEECH = This is a percentage between 0 - 101. The      #
#                higher you set this, the greater the chance of #
#                the birthday boy/girl getting leech for 24H.   #
#                0 = Disable. 101 = Always.                     #
#                                                               #
# GIVECREDS    = This one has 2 values seperated by a colon (:) #
#                First value is the minimum credits the user    #
#                get and the second the max value. In other     #
#                words, setting it to 1000:5000 will give the   #
#                user between 1000 and 5000 MB credits.         #
#                Evil siteops set this to a negative value, lol #
#                0:0 to disable.                                #
#                                                               #
#--[ Running it ]-----------------------------------------------#
#                                                               #
# Once the tcl is loaded, 3 new commands are available. Unless  #
# changed in the tcl, those are !bdadd, !bddel & !bdinfo.       #
#                                                               #
# If you are adding a user, specify his username and birthday   #
# in the MMDD format ( !bdadd ostnissse 1231 ).                 #
# It will make extensive tests to make sure the date is valid.  #
#                                                               #
# If you are deleting a user, just the username will do. Note   #
# that it will only set his birthday to 0000 if you delete him. #
# He will still be in the DB. The only time he is actually      #
# deleted from this file is if 'tur-birthday.sh daily' runs and #
# he is deleted from the site. As I said before, we keep a      #
# record of when he got his last gift, so if we just deleted    #
# him from the db, he could del and then add himself for a      #
# second gift this year.                                        #
# Delling a user is locked to ops only in the tcl.              #
#                                                               #
# To update the birthday of a user, just add him again. The     #
# birthday will be changed, but NOT the time of the last gift.  #
# If he should change his birthday so he gets 2 in one year, it #
# will congratulate him on his second birthday and call him a   #
# cheater =) ( no he wont get leech or creds then ).            #
#                                                               #
# If you want a list on everyones birthdays, issue !bdinfo.     #
# You can also specify a user with !bdinfo to info on him/her   #
# only.                                                         #
#                                                               #
# Another neat trick. If, seperate from this script, you give   #
# someone leech for a day, for whatever reason, and you do not  #
# want to forget to put them back to ratio, edit the DATAFILE.  #
# If they are not in here already, add him normally (!bdadd).   #
# Then find his line in the DATAFILE. Should look something     #
# like: OstNisse^0920^1                                         #
# Change it so it reads: OstNisse^0910^1^3  (just add ^3)       #
# Now, the next time its running in crontab, it will reset that #
# users ratio with 3 and announce his leech period expired.     #
#                                                               #
#--[ Zipscript-c Announce ]-------------------------------------#
#                                                               #
# Ok, all the text is set in this script, so all we need to do  #
# is get it to announce just a %msg. I decided TURGEN might be  #
# a good trigger so we can use it for other scripts in the      #
# future.                                                       #
#                                                               #
# This is only used when running 'tur-birthday.sh daily'. Any   #
# other command is echoed in the channel the command was        #
# executed (add/del/info).                                      #
#                                                               #
# Do the following in dZSbot.tcl and rehash the bot.            #
# To test it, cut and paste this in your shell and it should    #
# announce "Test Announce" to the channel:                      #
#--                                                           --#
# echo `date "+%a %b %e %T %Y"` TURGEN: \"Test Announce\" >> /glftpd/ftp-data/logs/glftpd.log
#--                                                           --#
#                                                               #
# To 'set msgtypes(DEFAULT)', add TURGEN                        #
#                                                               #
# Add the following in the appropriate places:                  #
#--                                                           --#
# set chanlist(TURGEN) "#YourChan"
#
# set disable(TURGEN) 0
#
# set variables(TURGEN) "%msg"
#
# set announce(TURGEN)   "%msg"
#--                                                           --#
# You may also want to add the following to your dZSbot.help:   #
# !bdadd            Add/change your birthday. Get a gift on that day! 
# !bdinfo (user)    Check birthday of all or a specific user.   
#                                                               #
#--[ Config ]---------------------------------------------------#

DATAFILE=/glftpd/etc/birthday.index
USERS=/glftpd/ftp-data/users
LOG=/glftpd/ftp-data/logs/glftpd.log
TMP=/tmp
SKIPLEECH=TRUE
HEADER="-NiA- [BIRTHDAY] -"
INFOBREAK=400
FORCEDAY=""

## Percentage. 0 or "" = Never. 101 = Always
GIVE24HLEECH=70

## Give MB Creds between:between. 0:0 to disable.
GIVECREDS=1000:5000


#--[ Script Start ]----------------------------------------------#

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number=0
    while [ "$number" -le $LOW ]; do
      number=$RANDOM
      if [ "$number" -gt "$HIGH" ]; then
        let "number %= $HIGH"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

## Verify that the datafile is working and can be written to.
proc_verifydata() {
  if [ ! -r "$DATAFILE" ]; then
    echo "$HEADER Error. Cant read $DATAFILE. Create it first and set 777 on it."
    exit 1
  elif [ ! -w "$DATAFILE" ]; then
    echo "$HEADER Error. Cant write to DATAFILE. Set proper perms on it."
    exit 1
  fi

  ## Verify TMP functionality
  if [ ! -w "$TMP/" ]; then  
    echo "$HEADER Error. Cant write to $TMP"
    exit 0
  fi

  ## BC test calc to make sure its installed and working.
  ## Only needed for GIVECREDS.
  if [ "$GIVECREDS" != "0:0" -a "$GIVECREDS" != "" ]; then
    if [ "$( echo "100 + 100" | bc -l )" != "200" ]; then
      echo "Error. You need bc installed for some calculations."
      exit 0
    fi
  fi
}

## Add a user to DB.
proc_add() {
  ## Check that $USER and $BDATE is not empty.
  if [ -z "$USER" -o -z "$BDATE" ]; then
    echo "$HEADER Please specify a user and a date in MMDD to add."
    exit 0
  fi

  ## Check that there are no fucked up chars in the username
  if [ "$( echo "$USER" | egrep "\*|\[|\]|\{|\]|\^|\~|\(|\)" )" ]; then
    echo "Error: Unallowed char detected in username."
    exit 0
  fi

  ## Does the user exist?
  if [ ! -e "$USERS/$USER" ]; then
    echo "$HEADER User $USER was not found."
    exit 0
  fi

  ## If SKIPLEECH is TRUE, dont allow the user to be added if he has leech.
  if [ "$SKIPLEECH" != "TRUE" ]; then
    if [ "$( grep "^RATIO 0" $USERS/$USER )" ]; then
      echo "$HEADER User $USER already has leech. He dosnt deserve more gifts !"
      exit 0
    fi
  fi

  ## Verify that the BDATE is a valid one.
  if [ "$( echo "$BDATE" | wc -L | tr -d ' ' )" != "4" ]; then
    echo "$HEADER Error. Birthdate should be in MMDD format."
    exit 0
  fi
  if [ "$( echo "$BDATE" | tr -d [0123456789*REPEAT] )" ]; then
    echo "$HEADER Error. Birthdate should be in MMDD format. Use numbers only!"
    exit 0
  fi
  if [ "$( echo "$BDATE" | cut -c1-2 )" -gt "12" ]; then
    echo "$HEADER Error. MMDD format. Only 12 months in a year."
    exit 0
  fi
  if [ "$( echo "$BDATE" | cut -c1-2 )" = "00" ]; then
    echo "$HEADER Error. MMDD format. 00 is ... what month?"
    exit 0
  fi
  if [ "$( echo "$BDATE" | cut -c3-4)" -gt "31" ]; then
    echo "$HEADER Error. MMDD format. Only 31 days in the longest month."
    exit 0
  fi
  if [ "$( echo "$BDATE" | cut -c3-4)" = "00" ]; then
    echo "$HEADER Error. MMDD format. 00 is ... what day?"
    exit 0
  fi

  ## Check if there really are that many days in that month.
  SELECTEDMONTH="$( echo "$BDATE" | cut -c1-2 )"
  SELECTEDDAY="$( echo "$BDATE" | cut -c3-4 )"
  case $SELECTEDMONTH in
    01) MONTHTOTAL="31" ;;
    02) MONTHTOTAL="28" ;;
    03) MONTHTOTAL="31" ;;
    04) MONTHTOTAL="30" ;;
    05) MONTHTOTAL="31" ;;
    06) MONTHTOTAL="30" ;;
    07) MONTHTOTAL="31" ;;
    08) MONTHTOTAL="31" ;;
    09) MONTHTOTAL="30" ;;
    10) MONTHTOTAL="31" ;;
    11) MONTHTOTAL="30" ;;
    12) MONTHTOTAL="31" ;;
    *) MONTHTOTAL="31" ;;
  esac
  if [ "$SELECTEDDAY" -gt "$MONTHTOTAL" ]; then
    echo "Error. There are only $MONTHTOTAL days in month #$SELECTEDMONTH."
    exit 0
  fi

  ## Set YEARAGO to 1 so he can get his first gift without worry.
  YEARAGO="1"

  ## Check if the user is in the DATAFILE already.
  if [ "$( grep "^$USER^" $DATAFILE )" ]; then
    DBINFO="$( grep "^$USER^" $DATAFILE | head -n1 )"
    DBBD="$( echo "$DBINFO" | cut -d '^' -f2 )"
    if [ "$DBBD" = "$BDATE" ]; then
      echo "$HEADER $USER is already added with that birthday."
      exit 0
    else
      LASTGIFT="$( echo "$DBINFO" | cut -d '^' -f3 )"
      if [ -z "$LASTGIFT" ]; then
        echo "$HEADER Error. Was going to change BD from $DBBD to $BDATE, but cant read last gift date."
        exit 0
      fi
      if [ "$DBBD" = "0000" ]; then
        echo "$HEADER $USER was already in the DB. Changed birthday to $BDATE."
      else
        echo "$HEADER $USER was already in the DB with $DBBD. Changed to $BDATE."
      fi
      grep -vw "^$USER^$DBBD^$LASTGIFT" $DATAFILE > $TMP/birthday.tmp
      cp -f $TMP/birthday.tmp $DATAFILE
      rm -f $TMP/birthday.tmp
      echo "$USER^$BDATE^$LASTGIFT" >> $DATAFILE
      exit 0
    fi
  fi

  ## Add info to DB
  echo "$HEADER Adding $USER to birthday DB."
  echo "$USER^$BDATE^$YEARAGO" >> $DATAFILE
}

proc_del() {
  ## Check that $USER and $BDATE is not empty.
  if [ -z "$USER" ]; then
    echo "$HEADER Please specify a user to deny the birthday gift."
    exit 0
  fi

  ## Check if the user is in the DB.
  if [ -z "$( grep "^$USER^" $DATAFILE )" ]; then
    echo "$HEADER $USER was not found in birthday DB."
    exit 0
  fi

  ## Grab his current birthday, remove him from DB and say it if it isnt the daily run going.
  DBBD="$( grep "^$USER^" $DATAFILE | cut -d '^' -f2 | head -n1 )"
  LASTGIFT="$( grep "^$USER^" $DATAFILE | cut -d '^' -f3 | head -n1 )"
  grep -vw "^$USER^$DBBD^$LASTGIFT" $DATAFILE > $TMP/birthday.tmp
  cp -f $TMP/birthday.tmp $DATAFILE
  rm -f $TMP/birthday.tmp

  ## Say it. If it really was executed with del, save his LASTGIFT time.
  if [ "$COMMAND" = "del" ]; then
    echo "$USER^0000^$LASTGIFT" >> $DATAFILE
    echo "$HEADER $USER has been denied a birthday present on $DBBD !"
  fi
}

## Checking info.
proc_info() {
  if [ -z "$USER" ]; then
    ## Check all users since none was specified.
    unset SAYTHIS
    for RAWDATA in `cat $DATAFILE | tr -s '^' ' ' | sort -k2,2 -n | tr -s ' ' '^'`; do
      if [ "$RAWDATA" ]; then
        USER="$( echo "$RAWDATA" | cut -d '^' -f1 )"
        BDAY="$( echo "$RAWDATA" | cut -d '^' -f2 )"
        if [ "$BDAY" != "0000" ]; then
          if [ "$( echo "$SAYTHIS" | wc -c | tr -d ' ' )" -gt "$INFOBREAK" ]; then
            echo "$SAYTHIS"
            unset SAYTHIS
          fi
          if [ "$SAYTHIS" ]; then
            SAYTHIS="$SAYTHIS, $USER($BDAY)"
          else
            SAYTHIS="$HEADER Birthdays: $USER($BDAY)"
          fi
        fi
      fi
    done
    if [ "$SAYTHIS" ]; then
      echo "$SAYTHIS"
    else
      echo "$HEADER No users added to birthday DB from what I can see..."
    fi
  else
    if [ "$( grep "^$USER^" $DATAFILE )" -a "$( grep "^$USER^" $DATAFILE | cut -d '^' -f2 )" != "0000" ]; then
      DBINFO="$( grep "^$USER^" $DATAFILE | cut -d '^' -f2 | head -n1 )"
      LASTGIFT="$( grep "^$USER^" $DATAFILE | cut -d '^' -f3 | head -n1 )"
      echo "$HEADER $USER's birthday is at $DBINFO"
    else
      echo "$HEADER $USER is not added to birthday DB."
    fi
  fi
}         
        
## Running daily.
proc_daily() {
  sleep 2 ## Just incase it runs at midnight sharp, wait til the new day arrives.

  ## Set todays date, in MMDD format.
  today="$( date +%m%d )"

  ## If FORCEDAY is set, emulate that day.
  if [ "$FORCEDAY" ]; then
    today="$FORCEDAY"
  fi

  for RAWDATA in `cat $DATAFILE`; do
    unset ALREADYHAS; unset USER; unset BDAY; unset GIVELEECH; unset LEECHMSG
    unset GOTLEECHYESTERDAY; unset GOLEECH; unset SKIP; unset YEARAGO
    if [ "$RAWDATA" ]; then
      USER="$( echo "$RAWDATA" | cut -d '^' -f1 )"
      BDAY="$( echo "$RAWDATA" | cut -d '^' -f2 )"
      LASTGIFT="$( echo "$RAWDATA" | cut -d '^' -f3 )"
      GOTGIFTYESTERDAY="$( echo "$RAWDATA" | cut -d '^' -f4 )"

      ## Remove the user from DB if hes not on site anymore.
      if [ ! -e "$USERS/$USER" ]; then
        proc_del
      else

        if [ "$BDAY" = "$today" ]; then

          ## Verify that it was more then a year ago that the user got his last gift.
          YEARAGO="$( date --date "-364 day" +%s )"
          if [ "$YEARAGO" -lt "$LASTGIFT" ]; then
            if [ "$LOG" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER Congratulations to $USER on his birthday. Too bad he got another gift less then a year ago. Cheater.\" >> $LOG
            fi
            SKIP=YES
          fi

          if [ "$GOTGIFTYESTERDAY" ]; then
            if [ "$LOG" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER Congratulations to $USER again? Seems he has already been rewarded though...\" >> $LOG
            fi
            SKIP=YES
          fi

          if [ "$GIVE24HLEECH" != "0" -a "$GIVE24HLEECH" != "" -a "$SKIP" != "YES" ]; then
            unset CURRATIO; unset ALREADYHAS
            if [ "$( grep "^RATIO 0" $USERS/$USER )" ]; then
              ALREADYHAS=TRUE
              if [ "$GIVECREDS" != "" -a "$GIVECREDS" != "0:0" ]; then
                LEECHMSG="already has leech but still "
              else
                LEECHMSG="already has leech. Congrats anyway!"
              fi
            fi

            if [ "$ALREADYHAS" != "TRUE" ]; then
              LOW=0;HIGH=100
              if [ "$GIVE24HLEECH" = "101" ]; then
                GOLEECH="TRUE"
                number=0
              else
                proc_random
              fi
              if [ "$number" -lt "$GIVE24HLEECH" -o "$GOLEECH" = "TRUE" ]; then
                GIVELEECH=TRUE
                if [ "$GIVECREDS" != "" -a "$GIVECREDS" != "0:0" ]; then
                  LEECHMSG="got leech for 24 hours and "
                else
                  LEECHMSG="got leech for 24 hours!"
                fi
              else
                GIVELEECH=FALSE

                if [ "$GIVECREDS" != "" -a "$GIVECREDS" != "0:0" ]; then
                  LEECHMSG="did NOT get leech for 24 hours, whaaa. But "
                else
                  LEECHMSG="did NOT get leech for 24 hours, whaaa! Congrats anyway!"
                fi
                
              fi
              if [ "$GIVELEECH" = "TRUE" ]; then
                if [ -w "$USERS/$USER" ]; then
                  ## Change user to leech ( RATIO 0 ).
                  CURRATIO="$( grep "^RATIO " $USERS/$USER | cut -d ' ' -f2 )"
                  sed -e "s/^RATIO .*/RATIO 0/" $USERS/$USER > $TMP/$USER.TMP
                  cp -f $TMP/$USER.TMP $USERS/$USER
                  rm -f $TMP/$USER.TMP
                else
                  LEECHMSG="would have gotten leech for 24 hours, but cant write to userfile... "
                fi
              fi
            fi
          fi ## End of GIVE24HLEECH mode.
        
          ## Give CREDITS ?
          unset number; unset CREDSMSG; unset HIGH; unset LOW; unset CURCREDS; unset PLSCREDS; unset NEWCREDS
          if [ "$GIVECREDS" != "" -a "$GIVECREDS" != "0:0" -a "$SKIP" != "YES" ]; then
            LOW="$( echo "$GIVECREDS" | cut -d ':' -f1 )"
            HIGH="$( echo "$GIVECREDS" | cut -d ':' -f2 )"
            proc_random

            if [ ! -w "$USERS/$USER" ]; then
              CREDSMSG="Cant give $number MB credits either due to perms."
            else
              CURCREDS="$( grep "^CREDITS " $USERS/$USER | cut -d ' ' -f2 )"
              PLSCREDS="$( echo "$number * 1024" | bc -l | cut -d '.' -f1 )"
              if [ "$CURCREDS" = "" -o "$PLSCREDS" = "" ]; then
                CREDMSG="cant give $number MB credits though, cause a calc fudged up."
              else
                NEWCREDS="$( echo "$CURCREDS + $PLSCREDS" | bc -l | cut -d '.' -f1 )"
              fi

              ## Give the user credits.
              sed -e "s/^CREDITS .*/CREDITS $NEWCREDS/" $USERS/$USER > $TMP/$USER.TMP
              cp -f $TMP/$USER.TMP $USERS/$USER
              rm -f $TMP/$USER.TMP

              CREDSMSG="got $number MB credits!"
            fi
          fi ## End if GIVECREDS mode.

          if [ "$SKIP" != "YES" ]; then
            TODAYGIFT="$( date +%s )"
            ## Reset his LASTGIFT time in DB.
            proc_del
            if [ "$CURRATIO" ]; then
              echo "$USER^$BDAY^$TODAYGIFT^$CURRATIO" >> $DATAFILE
            else
              echo "$USER^$BDAY^$TODAYGIFT" >> $DATAFILE
            fi

            if [ "$LOG" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER Congratulations to $USER on his birthday. $USER $LEECHMSG$CREDSMSG\" >> $LOG
            fi
          fi

        ## If this users birthday was NOT today, check if he got leech yesterday.
        else
          GOTLEECHYESTERDAY="$( echo "$RAWDATA" | cut -d '^' -f4 )"
          if [ "$GOTLEECHYESTERDAY" ]; then

            ## Reset the users ratio.
            sed -e "s/^RATIO .*/RATIO $GOTLEECHYESTERDAY/" $USERS/$USER > $TMP/$USER.TMP
            cp -f $TMP/$USER.TMP $USERS/$USER
            rm -f $TMP/$USER.TMP

            ## Remove the old ratio from birthday DB.
            proc_del
            echo "$USER^$BDAY^$LASTGIFT" >> $DATAFILE
            if [ "$LOG" ]; then
              echo `date "+%a %b %e %T %Y"` TURGEN: \"$HEADER The gift of leech that $USER got yesterday has expired!\" >> $LOG
            fi
          fi
        fi ## End of birthday today check
      fi
    fi
  done
}

COMMAND="$1"
USER="$2"
BDATE="$3"

case $COMMAND in
  daily) proc_verifydata; proc_daily ;;
  add) proc_verifydata; proc_add ;;
  del) proc_verifydata; proc_del ;;
  info) proc_verifydata; proc_info ;;
  *) echo "Error. Got neither daily, add or del."; exit 1
esac

exit 0
