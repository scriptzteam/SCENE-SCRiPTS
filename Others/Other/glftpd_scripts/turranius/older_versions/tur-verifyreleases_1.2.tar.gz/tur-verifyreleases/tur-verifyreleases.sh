#!/bin/bash
VER=1.2

# Small script used to verify all rar releases. Uses 'unrar t' to look for crc errors
# and reports this both to screen and to a logfile.
#
# It also checks the .sfv files in a release, if found, that all the files are included.
#
# It can also create a CLEANSH file, which, when executed, will remove all failed
# releases.
#
# You'll need unrar installed from www.rarlabs.com
#
# v 1.2 : Added check in sfv that all files exists (look for incomplete releases).
#         Option for this: ADD_MISSING_FILE=TRUE/FALSE. With TRUE, it will add those
#         incomplete releases to the CLEANSH file as well as CRC failed releases.
#         If FALSE, missing files will only be logged (log and on screen).
#
# v 1.1 : Fixed minor error when sorting CLEANSH file at the end of scan.
#         Now checks for existance of unrar. Made UNRAR setting.

# Path to unrar binary
UNRAR=/usr/bin/unrar

# Rootsection. Just makes it easier to set SECTIONS
ROOTSECTIONS=/glftpd/site/

# Sections inside ROOTSECTIONS. Space/newline seperated.
SECTIONS="
XBOX
APPS
DIVX
SVCD
DVDR
"

# Where to create the logfile of failed rels?
# A new log will be created on each run.
LOG=/tmp/logfile.log

# Where to create the clean.sh file?
# Note, this is not executable by default when created. You'll
# need to open it and look that its ok, then chmod 700 or similar to
# be able to run it. A new file will be created on each run.
CLEANSH=/tmp/clean.sh

# If a file is in the sfv but not on disk, should it be added to the
# CLEANSH file above? Otherwise, only failed CRC releases will be added
# and missing files will only be logged.
ADD_MISSING_FILE=TRUE


#--[ Script Start ]--------------------------------------------------#

if [ ! -e "$UNRAR" ]; then
  echo "Cant find $UNRAR. Need to install unrar from www.rarlabs.com"
  exit 1
fi

proc_log() {
  if [ "$LOG" ]; then
    echo "$*" >> $LOG
  fi
}

proc_findfile() {
  unset firstfile

  firstfile="`ls -1 | grep "\.rar$" | head -n1`"
  if [ -z "$firstfile" ]; then
    firstfile="`ls -1 | grep "\.r.*.*$" | sort -n | head -n1`"
  fi
  if [ -z "$firstfile" ]; then
    firstfile="`ls -1 | grep "\.00[0.1]$" | sort -n | head -n1`"
  fi
}

proc_scan_sfv() {
  if [ "`ls -1 | grep "\.[sS][fF][vV]$" | head -n1`" ]; then
    sfv_file="`ls -1 | grep "\.[sS][fF][vV]$" | head -n1`"
    for file in `cat $sfv_file | tr -s ' ' | tr ' ' '~'| tr -d '\r' |grep -i "^[a-z0-9]" | grep ".~........$" | cut -d '~' -f1`; do
      if [ ! -e "$file" ]; then
        echo "$file found in $sfv_file but not on disk. Incomplete release."
        proc_log "$sfv_file in $section has $file but file not on disk. Incomplete release."
      fi
      if [ "$ADD_MISSING_FILE" = "TRUE" ]; then
        if [ "$CLEANSH" ]; then
          echo "rm -rf $CURPATHNOCD" >> $CLEANSH
        fi      
      fi
    done
  fi
}

proc_scan() {
  if [ "$firstfile" ]; then
    echo "Checking $section - $release $cds"

    $UNRAR t $firstfile > /tmp/reltest.tmp 2>&1

    for rawdata in `cat /tmp/reltest.tmp | grep "packed data CRC failed" | tr -s ' ' '^'`; do
      wholefile="`echo "$rawdata" | cut -d '^' -f1`"
      badfile="`echo "$rawdata" | cut -d '^' -f9`"
      echo "$badfile CRC error in $CURPATH"

      proc_log "$badfile CRC error in $CURPATH"
      if [ "$CLEANSH" ]; then
        echo "rm -rf $CURPATHNOCD" >> $CLEANSH
      fi

    done
  else
    echo "Didnt find a file to start scanning on for $section - $release $cds"
  fi
}

if [ "$CLEANSH" ]; then
  echo "#!/bin/bash" > $CLEANSH
fi
if [ "$LOG" ]; then
  rm -f "$LOG"
fi

for section in $SECTIONS; do
  cd $ROOTSECTIONS$section

  for release in `ls -1 | egrep -v "GROUPS|lost\+found"`; do
    sleep 1
    unset cds
    cd $release
    if [ "`ls -1 | grep "^[cC][dD][0-9]$"`" ]; then
      for cds in `ls -1 | grep "^CD[0-9]$"`; do
        cd $ROOTSECTIONS$section/$release/$cds
        CURPATH="$ROOTSECTIONS$section/$release/$cds"
        CURPATHNOCD="$ROOTSECTIONS$section/$release"
        proc_findfile
        proc_scan 
        proc_scan_sfv
      done
    else
      cd $ROOTSECTIONS$section/$release
      CURPATH="$ROOTSECTIONS$section/$release"
      CURPATHNOCD="$ROOTSECTIONS$section/$release"
      proc_findfile
      proc_scan
      proc_scan_sfv
    fi
    cd $ROOTSECTIONS$section
  done

done

if [ "$CLEANSH" ]; then
  if [ -e "$CLEANSH" ]; then
    cat $CLEANSH | sort -u > /tmp/cleantmp.tmp
    mv -f /tmp/cleantmp.tmp $CLEANSH
    echo "$CLEANSH created. Need to chmod 700 $CLEANSH before running it (verify it first!)"
  fi
fi

exit 0