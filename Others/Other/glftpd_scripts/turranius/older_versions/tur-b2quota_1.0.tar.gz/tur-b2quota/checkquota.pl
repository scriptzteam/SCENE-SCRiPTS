#!/usr/bin/perl -w
use HTTP::Request::Common;
use LWP::UserAgent;
use HTTP::Cookies;
my $ua = LWP::UserAgent->new;
$ua->cookie_jar(HTTP::Cookies->new);

sub get_url { 
  my $url = shift;
  my $r = $ua->request(GET $url);
  die "HTTP problem" unless $r->is_success;
  return $r->content;
}

my $answer = $ua->request(
  POST 'http://www.bredband.net/portal/MittKonto-100Mbit',
       Content_Type => 'application/x-www-form-urlencoded',
       Content      => [ server => "www.bredband.net",
                         module     => "com.med.phd.LoginModule",
                         action   => "verify",
                         Username => "b423443",
                         Password => "843FJekj",
                       ],
  )->as_string;;


$answer = $ua->request(
  GET 'http://www.bredband.net/portal/MittKonto-100Mbit',
       Content_Type => 'text/html; charset=ISO-8859-1',
                       
  )->as_string;;

if ($answer =~ /nowrap\>([0-9]+) GB\</)
{
    print $1;
    print "\n";
}
else
{
    print "-1\n";
}
