#!/bin/bash
VER=1.2
#---------------------------------------------------------------------------#
# Tur-BotSearch by Turranius.                                               #
# Two small scripts that allow users to do like 'site search' from irc.     #
# Combine this with Tur-DirClean to keep the dirlog nicely updated!!        #
#---------------------------------------------------------------------------#
# Installation:                                                             #
# Put tur-botsearch in /glftpd/bin                                          #
# Put tur-botsearch.tcl in your bots scripts folder and load it in the bots #
# config file. Rehash the bot and make sure it says that its loading it.    #
# Make tur-botsearch.sh executable with chmod 755 tur-botsearch.sh          #
# Change the settings below:                                                #
# dirlog=     The full path to your dirlog file.                            #
# strings=    The full path to the strings binary ( which strings ).        #
# maxhits=    Maximum number of hits to return.                             #
# minlenght=  Minimum lenght to search for when only search with one        #
#             argument. Set to "" to disable.                               #
# ignoredirs= Ignore these words in search. Good to add the name of the pre #
#             dirs here. Use /PRE to prevent anything starting with PRE to  #
#             be displayed. Use /PRE/ to match the exact foldername.        #
#             Seperate ignores with a |  ( ='/GROUPS/|Animalporn|ost' )     #
#                                                                           #
# Run tur-botsearch.sh from shell and make sure it works.                   #
# When you test it from the bot you might get an error like "permission     #
# denied /root/.bashrc". I have no clue how to fix that other then to do:   #
# chmod 755 /root; chmod 755 /root/.bashrc                                  #
# If you have a better idea, lemme have it.                                 #
#---------------------------------------------------------------------------#
# Note to people wondering what the frell I am doing in the for each line.. #
# There is some crap in the dirlog. If you do 'strings dirlog' you will see #
# it. What I do is look for the word 'site' and start there. Then end the   #
# line before the filename. Crude, but it works.                            #
#---------------------------------------------------------------------------#
# Contact: Turranius / Turran on efnet. Usually in #glftpd.                 #
# http://www.grandis.nu/glftpd/ <mirror> http://grandis.mine.nu/glftpd/     #
#---------------------------------------------------------------------------#
# Changelog:                                                                #
# 1.2   : Search may now start with -                                       #
# 1.1   : Ignoredirs are no longer case sensitive. Also added a few extra   #
#         to the default so you wont get those pesky CD1 CD2 etc etc.       #
#         Remember to escape any non "normal" chars (whatever their names   #
#         are). IE [incomplete] = \[incomplete\]                            #
#    Upg: change all lines with contains:                                   #
#         egrep -v $ignoredirs to egrep -vi $ignoredirs                     #
#         Paste the new ignoredirs into your old script.                    #
#         Update the version at the top to 1.1 =))                          #
#                                                                           #
# 1.0   : First public version.                                             #
#---------------------------------------------------------------------------#

dirlog=/glftpd/ftp-data/logs/dirlog
strings=/usr/bin/strings
maxhits=15
minlenght=4
ignoredirs='/GROUPS|/CD1|/CD2|/CD3|/CD4|/CD5|/CD6|Sample|\[incomplete\]'

#############################################################################
# Change everything below here. Naaah kidding. Dont change a thing.         #
#############################################################################

## Show help if no arguments.
if [ "$1" = "" ]; then
  echo "Tur-BotSearch $VER by Turranius. Used for searching on site."
  echo "Enter up to 3 arguments to search for."
  echo "One of them can be used for section. Only $maxhits hits will be shown."
  exit 0
fi

## Check if we can read dirlog. Rather.. if we cant.
if [ ! -r $dirlog ]; then
  echo "Cant read from dirlog. Ask siteops to fix perms."
  exit 0
fi

## Check if strings exists
if [ ! -x $strings ]; then
  echo "Strings is not executable or does not exist."
  exit 0
fi

## If first argument is the same as the other..
if [ "$1" = "$2" ]; then
  echo "Please dont use the same arguments twice."
  exit 0
fi

## Complain if lenght is too short (size dosnt matter!).
if [ "$minlenght" != "" ]; then
  if [ `echo $1 | wc -L | tr -d ' '` -lt "$minlenght" -a "$2" = "" ]; then
    echo "Search must be a minumum of $minlenght chars with only one arguement."
    exit 0
  fi
fi

## Make a lame fix incase ignoredirs are empty.
if [ "$ignoredirs" = "" ]; then
  ignoredirs="kJEFKLejJd3jd"
fi

## Do the search to LIST.
if [ "$2" != "" ]; then
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | egrep -vi $ignoredirs | tr -d ' ' | tail -n $maxhits )"
  if [ "$3" != "" ]; then
    LIST="$( $strings $dirlog | grep -F -i -- "$1" | grep -F -i -- "$2" | grep -F -i "$3" | egrep -vi $ignoredirs| tr -d ' ' | tail -n $maxhits )"
  fi
else
  LIST="$( $strings $dirlog | grep -F -i -- "$1" | egrep -vi $ignoredirs | tr -d ' ' | tail -n $maxhits )"
fi

## Fix each entry as they contain C.R.A.P otherwise.
num="0"
for each in $LIST; do
  gotone="yes"
  num="$( expr $num \+ 1 )"
  end="$( basename $each )"
  for part in `echo $each | tr -s '/' ' '`; do
    if [ "$go" = "yepp" ]; then
      if [ "$rel" = "" ]; then
        rel="/$part"
      else
        rel="$rel/$part"
      fi
    fi
    if [ "$part" = "site" ]; then
      go="yepp"
      unset rel
    fi
    if [ "$end" = "$each" ]; then
      unset go
    fi 
  done
  echo "$rel"
  if [ "$num" = "$maxhits" ]; then
    echo "$maxhits Maximum hits returned. Be more specific."
  fi
done

## No hits? Say this.
if [ "$gotone" != "yes" ];then
  echo "0 Results Returned"
fi

exit 0
