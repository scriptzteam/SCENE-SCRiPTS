#!/bin/bash
VER=1.5
#-------------------------------------------------------------#
# WhereAmI by Turranius ( http://www.grandis.nu/glftpd/ )     #
#--                                                         --#
# Simple script to show where you are in weektop, monthtop    #
# etc etc. Also works fine for groups.                        #
# Will also show who is in front of you, and who is after.    #
# Ment to be used in irc with the .tcl script that comes with #
# this package.                                               #
#--                                                         --#
# Installation:                                               #
# Copy whereami.sh to /glftpd/bin (default).                  #
# Make it executable to the user running the bot.             #
# Edit STATSBIN below to wherever your stats command is       #
# (see Requirements:) and also path to glftpd.conf.           #
#                                                             #
# Edit MBLIMIT to when you want it to convert to GB instead   #
# of MB. Looks better with 92GB instead of 94208MB I think.   #
# The number is in MB.                                        #
# Set it to "" to disable (always use MB).                    #
#                                                             #
# Edit USERDIR to where your users are.                       #
#                                                             # 
# Copy whereami.tcl to your bots /scripts folder and add the  #
# following to your bots .conf file, at the bottom:           #
# source scripts/whereami.tcl                                 #
# Edit whereami.tcl and change the path to wheerami.sh IF you #
# did not put it in /glftpd/bin.                              #
# If you wish to change the command users type to execute it, #
# change the 'bind pub - !alup pub:alup' lines. Only the      #
# !alup needs to be changed, not the pub:alup                 #
# Rehash the bot when ready.                                  #
# If you change there, you might want to change the help text #
# It is right below the part where you should not edit in     #
# this script.                                                #
#--                                                         --#
# Commands in whereami.tcl are:                               #
# Usage: !alup <username>                                     #
# !alup, !aldn = Alltime up, Alltime down.                    #
# !mnup, !mndn = Month up, Month down.                        #
# !wkup, !wkdn = Week up, Week down.                          #
# !tdup, !tddn = Today up, Today down.                        #
#                                                             #
# For groups: !galup <group>                                  #
# !galup, !galdn = Alltime up, Alltime down.                  #
# Well, all the commands for users works for groups, just add #
# a g infront of them.                                        #
#                                                             #
# Note: Run any command without any arguments for a brief     #
# description.                                                #
#                                                             #
# If you want to try it from shell, its whereami.sh user a u  #
# for alup. Run stats to get the arguments.                   #
#                                                             #
#--                                                         --#
# Requirements:                                               #
# This script uses glFtpD 'stats' which comes with glftpd.    #
# If it is not in your /glftpd/bin dir, look for whereever    #
# you unpacked glftpd.                                        #
# Just run /glftpd/bin/stats to check.                        #
#-------------------------------------------------------------#
# Changelog:                                                  #
# 1.5 : - Changed when grepping group/username from           #
#         'grep -w "$1"' to 'grep " $1 "' to make it not get  #
#         a hit on the wrong group etc. Thanks LPC.           #
#                                                             #
# 1.4 : - In 1.3, I changed from using expr to using bash     #
#         itself when counting numbers. Seems bash does not   #
#         like to add, for instance, 08+1. Has to be 8+1.     #
#         This could cause "Value too great for base" errors. #
#         So, went back to using expr instead.                #
# 1.3 : - Rewrote how it gets files and MB. Had cut problems  #
#         before but it should work better now.               #
#       - Replaced all awk's with cut's too.                  #
#       - Using bash for calculations instead of expr.        #
#       - Updated whereami.tcl to 1.1. Only set the binary    #
#         once now.                                           #
# 1.2 : If a user had 11 chars in the username, it would crap #
#       out. Thanks Peza.                                     #
# 1.1 : Added MBLIMIT.                                        #
# 1.0 : Initial release.                                      #
#--                                                         --#
# Settings:

STATSBIN="/glftpd/bin/stats -r /etc/glftpd.conf"
MBLIMIT="51200"
USERDIR="/glftpd/ftp-data/users"

#################################################################
# No changes needed below here unless you want to change output #
#################################################################

## Show help.
if [ -z "$1" ]; then
  echo "WhereAmI $VER. Use: !command <username/group>. Commands are, for users: alup,aldn,mnup,mndn,wkup,wkdn,tdup,tddn. For groups, just put a g infront of any user command, like !galup <group>"
  exit 0
fi

if [ "$1" = '.' ]; then
  echo "User does not exist.. try again."
  exit 0
fi

## Get all stats data for specified user.
USERDATA="$( $STATSBIN -$2 -$3 -x 500 | grep -w "$1" )"

## Didnt get any data.
if [ -z "$USERDATA" ]; then
  echo "Nothing found for $1. Misspelled or nothing is registered for this period."
  exit 0
fi

USERPOS="$( echo $USERDATA | cut -d ' ' -f1 | tr -d '[:punct:]')"

USERBEFORENR="$( expr "$USERPOS" \- "1" )"
VERIFYBEFORE="$( echo $USERBEFORENR | wc -c )"
if [ "$VERIFYBEFORE" -lt "3" ]; then
  USERBEFORENR=0$USERBEFORENR
fi

USERAFTERNR="$( expr "$USERPOS" \+ "1" )"
VERIFYAFTER="$( echo $USERAFTERNR | wc -c )"
if [ "$VERIFYAFTER" -lt "3" ]; then
  USERAFTERNR="0$USERAFTERNR"
fi

if [ "$USERPOS" = "01" ]; then
  USERBEFOREDATA="NONE"
else
  USERBEFOREDATA="$( $STATSBIN -$2 -$3 -x 500 | grep '^\['$USERBEFORENR'\] ' )"
fi

USERAFTERDATA="$( $STATSBIN -$2 -$3 -x 500 | grep '^\['$USERAFTERNR'\] ' )"
if [ -z "$USERAFTERDATA" ]; then
  USERAFTERDATA="NONE"
fi

USERNAME="$( echo $USERDATA | cut -d ' ' -f2 )"
for each in $USERDATA; do
  USERFILES=$USERMEG
  USERMEG=$last
  last=$each
done
unset each; unset last

USERFILES="$( echo "$USERFILES" | tr -d '[:alpha:]' )"

if [ "$MBLIMIT" ]; then
  USERMEG="$( echo "$USERMEG" | tr -d '[:alpha:]' )"
  if [ "$USERMEG" -gt "$MBLIMIT" ]; then
    USERMEG="$( expr "$USERMEG" \/ "1024" )"
    USERMEG="$USERMEG GB"
  else
    USERMEG="$USERMEG MB"
  fi
fi

if [ "$USERBEFOREDATA" != "NONE" ]; then
  USERBEFOREPOS="$( echo $USERBEFOREDATA | cut -d ' ' -f1 | tr -d '[:punct:]' )"
  USERBEFORENAME="$( echo $USERBEFOREDATA | cut -d ' ' -f2 )"

  for each in $USERBEFOREDATA; do
    USERBEFOREFILES=$USERBEFOREMEG
    USERBEFOREMEG=$last
    last=$each
  done
  unset each; unset last
  USERBEFOREFILES="$( echo "$USERBEFOREFILES" | tr -d '[:alpha:]' )"

  if [ "$MBLIMIT" ]; then
    USERBEFOREMEG="$( echo "$USERBEFOREMEG" | tr -d '[:alpha:]' )"
    if [ "$USERBEFOREMEG" -gt "$MBLIMIT" ]; then
      USERBEFOREMEG="$( expr "$USERBEFOREMEG" \/ "1024" )"
      USERBEFOREMEG="$USERBEFOREMEG GB"
    else
      USERBEFOREMEG="$USERBEFOREMEG MB"
    fi
  fi
fi

if [ "$USERAFTERDATA" != "NONE" ]; then
  USERAFTERPOS="$( echo $USERAFTERDATA | cut -d ' ' -f1 | tr -d '[:punct:]' )" 
  USERAFTERNAME="$( echo $USERAFTERDATA | cut -d ' ' -f2 )" 

  for each in $USERAFTERDATA; do
    USERAFTERFILES=$USERAFTERMEG
    USERAFTERMEG=$last
    last=$each
  done
  unset each; unset last
  USERAFTERFILES="$( echo "$USERAFTERFILES" | tr -d '[:alpha:]' )"

  if [ "$MBLIMIT" ]; then
    USERAFTERMEG="$( echo "$USERAFTERMEG" | tr -d '[:alpha:]' )"
    if [ "$USERAFTERMEG" -gt "$MBLIMIT" ]; then
      USERAFTERMEG="$( expr "$USERAFTERMEG" \/ "1024" )"
      USERAFTERMEG="$USERAFTERMEG GB"
    else
      USERAFTERMEG="$USERAFTERMEG MB"
    fi
  fi
fi

if [ "$USERBEFOREDATA" = "NONE" ]; then
  if [ "$USERAFTERDATA" = "NONE" ]; then
    echo "$USERNAME is 1st and ONLY on the list with $USERFILES files and $USERMEG"
  else
    echo "$USERNAME is 1st with $USERFILES files and $USERMEG, followed by $USERAFTERNAME with $USERAFTERFILES files and $USERAFTERMEG"
  fi
else
  if [ "$USERAFTERDATA" = "NONE" ]; then
    echo "$USERNAME is last at "#"$USERPOS(Tihi) with $USERFILES"F" in $USERMEG. In front, at "#"$USERBEFOREPOS is $USERBEFORENAME with $USERBEFOREFILES"F" in $USERBEFOREMEG."
  else
    echo "Ahead of $USERNAME at "#"$USERBEFOREPOS is $USERBEFORENAME with $USERBEFOREFILES"F" and $USERBEFOREMEG. $USERNAME is "#"$USERPOS with $USERFILES"F" and $USERMEG. Behind them both at "#"$USERAFTERPOS comes $USERAFTERNAME with $USERAFTERFILES"F" and $USERAFTERMEG."
  fi
fi

exit 0
