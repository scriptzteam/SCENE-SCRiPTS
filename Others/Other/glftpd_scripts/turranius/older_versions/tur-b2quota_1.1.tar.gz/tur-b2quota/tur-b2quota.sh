#!/bin/bash
VER=1.1

#--[ Intro ]-------------------------------------------------------#
#                                                                  #
# This is an "alarm" script for B2's (bredbandsbolaget) 100 Mbit   #
# service. It runs checkquota.pl at different intervals and will   #
# set off an alarm in your irc chan/staff chan if the quota limit  #
# goes below a set limit.                                          #
#                                                                  #
# Multiple 'checkquota.pl' scripts can be defined if you have more #
# then one site.                                                   #
#                                                                  #
#--[ Setup ]-------------------------------------------------------#
#                                                                  #
# Copy this script to /glftpd/bin and chmod it to 700 or similar.  #
#                                                                  #
# Make sure your checkquota.pl script works from shell first.      #
#                                                                  #
#--[ Configuration ]-----------------------------------------------#
#                                                                  #
# quota_scripts=        Here you define one or more paths to       #
#                       your checkquota.pl script(s).              #
#                       The format is SiteName:MB_limit:path       #
#                       As you can see from the example, if you    #
#                       have more then one site on 100 Mbit quota  #
#                       you can just copy checkquota.pl to another #
#                       name, using that sites login information   #
#                       and it will give an alarm on that site too #
#                                                                  #
# gllog=                Path to glftpd.log                         #
#                                                                  #
# trigger=              The trigger to use when announcing to      #
#                       glftpd.log. I already have MSSREP setup to #
#                       announce in the staffchan so that is the   #
#                       default.                                   #
#                       If you already have TURGEN setup and want  #
#                       this in your mainchan, simply set TURGEN   #
#                       instead.                                   #
#                                                                  #
#                       If you use SS5 (bleh) then set this to RAW #
#                       to output it in your mainchan.             #
#                                                                  #
#---                                                               #
# BOTSETUP:                                                        #
# We use TURGEN in this example. Use the trigger set in trigger=   #
#-                                                                 #
# For dark0n3's dZSbot.tcl, edit dZSbot.tcl                        #
#                                                                  #
#  To 'set msgtypes(DEFAULT)', add TURGEN                          #
#                                                                  #
#  Add the following in the appropriate places:                    #
#  set chanlist(TURGEN) "#YourChan"                                #
#  set disable(TURGEN) 0                                           #
#  set variables(TURGEN) "%msg"                                    #
#  set announce(TURGEN)  "%msg"                                    #
#-                                                                 #
# For pzs-ng dZSbot.tcl, edit dZSbconf.tcl                         #
#                                                                  #
#  To 'set msgtypes(DEFAULT)', add TURGEN                          #
#                                                                  #
#  Add the following in the appropriate places:                    #
#  set chanlist(TURGEN) "#YourChan"                                #
#  set disable(TURGEN) 0                                           #
#  set variables(TURGEN) "%msg"                                    #
#                                                                  #
#  Finally, to your loaded themefile, add this:                    #
#  announce.TURGEN = "%msg"                                        #
#--                                                                #
#                                                                  #
# announce_on_ok=      TRUE/FALSE. Do you want it to announce the  #
#                      current quota each time it runs?            #
#                                                                  #
# announce_on_error=   TRUE/FALSE. If the quotacheck.pl script(s)  #
#                      fail to get any information, do you want    #
#                      the bot to announce this? Might be good to  #
#                      start with TRUE.                            #
#                                                                  #
# debug=               TRUE/FALSE. Gives some extra info if TRUE.  #
#                                                                  #
#--[ Running ]-----------------------------------------------------#
#                                                                  #
# Run it from shell a few times to see that it works. After youre  #
# satisfied, crontab it to run as often as you like. If you want   #
# to run it every 65 minutes, heres a good example for crontab:    #
# */65 * * * *    /glftpd/bin/tur-b2quota.sh                       #
#                                                                  #
#--[ Changelog ]---------------------------------------------------#
#                                                                  #
# 1.1  * Updated to work with new checkquota.pl from Cruxis.       #
#                                                                  #
#--[ Settings ]----------------------------------------------------#


quota_scripts="
xXx:50:/glftpd/bin/checkquota.pl
"

gllog=/glftpd/ftp-data/logs/glftpd.log
trigger="MSSREP"

announce_on_ok=TRUE
announce_on_error=TRUE

debug=TRUE


#--[ Script Start ]-----------------------------------------------#

proc_gllog() {
  if [ "$debug" != "TRUE" ]; then
    echo `date "+%a %b %e %T %Y"` ${trigger}: \"$*\" >> $gllog
  else
    echo `date "+%a %b %e %T %Y"` ${trigger}: \"$*\"
  fi
}

proc_error() {
  if [ "$announce_on_error" = "TRUE" ]; then
    if [ "$debug" != "TRUE" ]; then
      echo `date "+%a %b %e %T %Y"` ${trigger}: \"$*\" >> $gllog
    else
      echo `date "+%a %b %e %T %Y"` ${trigger}: \"$*\"
    fi
  fi
}


for rawdata in $quota_scripts; do
  sitename="`echo "$rawdata" | cut -d ':' -f1`"
  limit="`echo "$rawdata" | cut -d ':' -f2`"
  script="`echo "$rawdata" | cut -d ':' -f3`"

  if [ ! -e "$script" ]; then
    proc_error "Error. Script for $rawdata not found."
    exit 0
  fi

  RAWDATA="`$script | tr ' ' '^'`"
  GBLEFT="`echo "$RAWDATA" | cut -d '^' -f1`"

  if [ -z "$GBLEFT" ] || [ "$GBLEFT" = "-1" ]; then
    sleep 15
    GBLEFT="`$script`"
    if [ -z "$GBLEFT" ] || [ "$GBLEFT" = "-1" ]; then
      sleep 15
      GBLEFT="`$script`"
    fi
  fi

  if [ "$GBLEFT" = "-1" ]; then
    if [ "$announce_on_error" = "TRUE" ]; then
      proc_gllog "Got no info for $sitename. Check settings in $script"
    fi
  elif [ -z "$GBLEFT" ]; then
    proc_error "Undefined error. Run $script manually to find error."
  else
    if [ "`echo "$GBLEFT" | tr -d '[:digit:]'`" ]; then
      proc_error "Undefined error2. Run $script manually to find error."
    else
      if [ "$GBLEFT" -le "$limit" ]; then
        proc_gllog "Warning. $sitename is below the $limit GB limit. At $GBLEFT GB remaning."
      else
        if [ "$announce_on_ok" = "TRUE" ]; then
          proc_gllog "$sitename looking good. $GBLEFT GB / $limit GB remaining."
        fi
      fi
    fi
  fi
done

