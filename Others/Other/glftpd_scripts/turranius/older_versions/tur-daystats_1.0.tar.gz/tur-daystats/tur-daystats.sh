#!/bin/bash
VER=1.0

#--[ Config ]------------------------------#

sitename="xXx"
gllog=/glftpd/ftp-data/logs/glftpd.log
login=/glftpd/ftp-data/logs/login.log
tmp=/glftpd/tmp

sections="0DAYS PDA SVCD DIVX VCD ISO-UTILS XBOX"
sectionspre="0DAYS SVCD DIVX UTILS"
separator="<->"
exclude='/Cd.|/Sample|/Codec'

statbin=/glftpd/bin/stats
statsection=0

groupnameinpreline=8
removefromgroup="^"
usernameinnuke=9

poslenght="...."
userlenght="............"
meglenght="........"
filelenght="......."
speedlenght="......."

#--[ Output ]------------------------------#

proc_output() {

BOLD=""
proc_tempout "At the end of this $weekname here at $bold$sitename$bold, we had:"

proc_tempout "$logins Logins. Of those, $logout logged out and $timeout timed out."

## If there were something nuked or something deleted.
if [ "$nukes" != "0" -o "$deldir" != "0" ]; then
  proc_tempout "$nukes users were nuked and $deldir dirs were deleted."
fi

## If we got a nuked user and the number of nukes for him/her.
if [ "$topnuke" -a "$topnukenr" ]; then
  proc_tempout "$topnuke wins the nukerace. Got nuked $BOLD$topnukenr$BOLD times."
fi

proc_tempout "Total New dirs: $BOLD$newdir$BOLD - $FULLINFO"

## If we found stuff that were preed.
if [ "$top" ]; then
  proc_tempout "Most Prees were made by $top with $highest fine releases."
fi

proc_tempout "Total Pred : $BOLD$pres$BOLD - $FULLPRE"

## Showing upload stats. 5 users max.
if [ "$firstupuser" ]; then
  proc_tempout "Best uploaders were:"

  proc_tempout "$firstuppos $firstupuser $firstupfiles $firstupmeg $firstupspeed"

  if [ "$secondupuser" ]; then
    proc_tempout "$seconduppos $secondupuser $secondupfiles $secondupmeg $secondupspeed"
  fi
  if [ "$thirdupuser" ]; then
    proc_tempout "$thirduppos $thirdupuser $thirdupfiles $thirdupmeg $thirdupspeed"
  fi
  if [ "$fourthupuser" ]; then
    proc_tempout "$fourthuppos $fourthupuser $fourthupfiles $fourthupmeg $fourthupspeed"
  fi
  if [ "$fifthupuser" ]; then
    proc_tempout "$fifthuppos $fifthupuser $fifthupfiles $fifthupmeg $fifthupspeed"
  fi  
else
  proc_tempout "There were NO uploaders!"
fi

if [ "$firstdnuser" ]; then
  proc_tempout "Sadly, we also had some leechers:"
  proc_tempout "$firstdnpos $firstdnuser $firstdnfiles $firstdnmeg $firstdnspeed"

  if [ "$seconddnuser" ]; then
    proc_tempout "$seconddnpos $seconddnuser $seconddnfiles $seconddnmeg $seconddnspeed"
  fi
  if [ "$thirddnuser" ]; then
    proc_tempout "$thirddnpos $thirddnuser $thirddnfiles $thirddnmeg $thirddnspeed"
  fi
  if [ "$fourthdnuser" ]; then
    proc_tempout "$fourthdnpos $fourthdnuser $fourthdnfiles $fourthdnmeg $fourthdnspeed"
  fi
  if [ "$fifthdnuser" ]; then
    proc_tempout "$fifthdnpos $fifthdnuser $fifthdnfiles $fifthdnmeg $fifthdnspeed"
  fi  
else
  proc_tempout "There were NO downloaders, wheee."
fi

if [ "$gupcheck" != "0MB" -a "$gup" != "" ]; then
  proc_tempout "Congrats to $BOLD$gup$BOLD for top upping today. $gupcheck uploaded !"
fi

if [ "$gdncheck" != "0MB" -a "$gdn" != "" ]; then
  proc_tempout "Kings of the LEECH were $BOLD$gdn$BOLD with $gdncheck down !"
fi

} ## <- Dont touch. End of proc_output()


#--[ Script Start ]------------------------------#

## Write to temp file.
proc_tempout() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $tmp/daystats.output.tmp
}

if [ "$1" = "test" ]; then
  test="yes"
fi

day=`date +%e | tr -d ' '`
if [ "$( echo "$day" | grep "^.$" )" ]; then
  day="[ 0]$day"
fi
today="$( date +%a" "%b" $day ..:..:.. "%Y )"

egrep "^$today" $gllog > $tmp/daystats.tmp
egrep "^$today" $login >> $tmp/daystats.tmp

logins="$( grep " LOGIN: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "logins" ]; then
  logins="0"
fi
logout="$( grep " LOGOUT: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "logout" ]; then
  logout="0"
fi
timeout="$( grep " TIMEOUT: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "timeout" ]; then
  timeout="0"
fi

nukes="$( grep " NUKE: " $tmp/daystats.tmp | grep -v "UNKNOWN" | wc -l | tr -d ' ' )"
if [ -z "$nukes" ]; then
  nukes="0"
fi
pres="$( grep " PRE: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "$pres" ]; then
  pres="0"
fi
newdir="$( grep " NEWDIR: " $tmp/daystats.tmp | egrep -vi $exclude | wc -l | tr -d ' ' )"
if [ -z "$newdir" ]; then
  newdir="0"
fi
deldir="$( grep " DELDIR: " $tmp/daystats.tmp | wc -l | tr -d ' ' )"
if [ -z "$deldir" ]; then
  deldir="0"
fi

for section in $sections; do
  if [ "$FULLINFO" ]; then
    FULLINFO="$FULLINFO $separator"
  fi
  if [ "$FULLINFO" ]; then
    FULLINFO="$FULLINFO $section: `grep " NEWDIR: " $tmp/daystats.tmp | grep -F -- "/$section/" | egrep -vi $exclude | wc -l | tr -d ' '`"
  else
    FULLINFO="$section: `grep " NEWDIR: " $tmp/daystats.tmp | grep -F -- "/$section/" | egrep -vi $exclude | wc -l | tr -d ' '`"
  fi
done

for section in $sectionspre; do
  if [ "$FULLPRE" ]; then
    FULLPRE="$FULLPRE $separator"
  fi
  if [ "$FULLPRE" ]; then
    FULLPRE="$FULLPRE $section: `grep " PRE: " $tmp/daystats.tmp | grep "$section" | wc -l | tr -d ' '`"
  else
    FULLPRE="$section: `grep " PRE: " $tmp/daystats.tmp | grep "$section" | wc -l | tr -d ' '`"
  fi
done

if [ "$groupnameinpreline" ]; then
  new="1"
  highest="0"
  for pre in `grep " PRE: " $tmp/daystats.tmp | cut -d ' ' -f$groupnameinpreline | tr -d "$removefromgroup" | sort`; do
    if [ "$pre" ]; then
      if [ "$last" != "$pre" ]; then
        new="1"
      fi
      if [ "first" = "" -o "$last" = "$pre" ]; then
        new="$( expr $new + 1 )"
      fi

      if [ "$new" = "$highest" ]; then
        top="$top & $pre"
        highest="$new"
      else
        if [ "$new" -gt "$highest" ]; then
          top="$pre"
          highest="$new"
        fi
      fi
      last="$pre"
      first="no"
    fi
  done
  if [ "$top" ]; then
    top="$( echo "$top" | tr -d '[:cntrl:]' )"
  fi
fi

nukenr="0"
highestnuke="0"
for nuke in `grep " NUKE: " $tmp/daystats.tmp | cut -d ' ' -f$usernameinnuke | grep -v "UNKNOWN" | tr -d '"' | sort`; do
  if [ "$nuke" ]; then
    if [ "$lastnuke" != "$nuke" ]; then
      nukenr="1"
    fi
    if [ "$firstnuke" = "" -o "$lastnuke" = "$nuke" ]; then
      nukenr=$[$nukenr+1]
    fi

    if [ "$nukenr" -gt "$highestnuke" ]; then
      topnuke="$nuke"
      topnukenr="$nukenr"
      highestnuke="$nukenr"
    fi
    lastnuke="$nuke"
    firstnuke="no"
  fi
done

proc_split() {
  unset topuser; unset pos; unset meg; unset files; unset speed
  raw=`echo "$each" | tr -s '^' ' ' | tr -d '[' | tr -d ']'`
  for eachsection in $raw; do
    if [ -z "$pos" ]; then
      pos=`echo "$eachsection"` # | tr -d '[' | tr -d ']'`
    else
      if [ -z "$topuser" ]; then
        topuser="$eachsection"
      else
        if [ "$( echo "$eachsection" | grep "MB$" )" -a "$meg" = "" ]; then
          files=$last"F"
          meg="$eachsection"
        else
          if [ "$( echo "$eachsection" | grep "KBs$" )" ]; then
            speed="$eachsection"
          fi
        fi
      fi
    fi
    last=$eachsection    
  done

  S=' '
  while [ -z "$( echo "$pos" | grep "$poslenght" )" ]; do
    pos="$pos$S"
  done
  while [ -z "$( echo "$topuser" | grep "$userlenght" )" ]; do
    topuser="$topuser$S"
  done
  while [ -z "$( echo "$meg" | grep "$meglenght" )" ]; do
    meg="$meg$S"
  done
  while [ -z "$( echo "$files" | grep "$filelenght" )" ]; do
    files="$files$S"
  done
  while [ -z "$( echo "$speed" | grep "$speedlenght" )" ]; do
    speed="$speed$S"
  done
}

UPLIST=`$statbin -u -t -x 5 -s $statsection | grep "\[..\]" | tr -s ' ' '^'`
for each in $UPLIST; do
  if [ "$( echo "$each" | grep '\[01\]' )" ]; then
    proc_split
    firstuppos="$pos"
    firstupuser="$topuser"
    firstupfiles="$files"
    firstupmeg="$meg"
    firstupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[02\]' )" ]; then
    proc_split
    seconduppos="$pos"
    secondupuser="$topuser"
    secondupfiles="$files"
    secondupmeg="$meg"
    secondupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[03\]' )" ]; then
    proc_split
    thirduppos="$pos"
    thirdupuser="$topuser"
    thirdupfiles="$files"
    thirdupmeg="$meg"
    thirdupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[04\]' )" ]; then
    proc_split
    fourthuppos="$pos"
    fourthupuser="$topuser"
    fourthupfiles="$files"
    fourthupmeg="$meg"
    fourthupspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[05\]' )" ]; then
    proc_split
    fifthuppos="$pos"
    fifthupuser="$topuser"
    fifthupfiles="$files"
    fifthupmeg="$meg"
    fifthupspeed="$speed"
  fi
done

UPLIST=`$statbin -d -t -x 5 -s $statsection | grep "\[..\]" | tr -s ' ' '^'`
for each in $UPLIST; do
  if [ "$( echo "$each" | grep '\[01\]' )" ]; then
    proc_split
    firstdnpos="$pos"
    firstdnuser="$topuser"
    firstdnfiles="$files"
    firstdnmeg="$meg"
    firstdnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[02\]' )" ]; then
    proc_split
    seconddnpos="$pos"
    seconddnuser="$topuser"
    seconddnfiles="$files"
    seconddnmeg="$meg"
    seconddnspeed="$speed"    
  fi

  if [ "$( echo "$each" | grep '\[03\]' )" ]; then
    proc_split
    thirddnpos="$pos"
    thirddnuser="$topuser"
    thirddnfiles="$files"
    thirddnmeg="$meg"
    thirddnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[04\]' )" ]; then
    proc_split
    fourthdnpos="$pos"
    fourthdnuser="$topuser"
    fourthdnfiles="$files"
    fourthdnmeg="$meg"
    fourthdnspeed="$speed"
  fi

  if [ "$( echo "$each" | grep '\[05\]' )" ]; then
    proc_split
    fifthdnpos="$pos"
    fifthdnuser="$topuser"
    fifthdnfiles="$files"
    fifthdnmeg="$meg"
    fifthdnspeed="$speed"
  fi
done

gup="$( $statbin -u -T -x 1 -s $statsection | cut -b 1-16,48-80 | grep '\[01\]' | head -n1 )"
gupcheck="$( echo $gup | cut -d ' ' -f4 )"
gup="$( echo $gup | cut -d ' ' -f2 )"

gdn="$( $statbin -d -T -x 1 -s $statsection | cut -b 1-16,48-80 | grep '\[01\]' | head -n1 )"
gdncheck="$( echo $gdn | cut -d ' ' -f4 )"
gdn="$( echo $gdn | cut -d ' ' -f2 )"

weekname="$( date +%A )"

if [ -e "$tmp/daystats.output.tmp" ]; then
  rm -f "$tmp/daystats.output.tmp"
fi

proc_output

#test=yes

if [ "$test" = "yes" ]; then
  cat $tmp/daystats.output.tmp
else
  cat $tmp/daystats.output.tmp >> $gllog
fi

exit 0
