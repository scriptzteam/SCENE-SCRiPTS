#!/bin/bash
VER=1.0

# Small script to check if the primary group on the user is the one specified
# in the passwd file for that user. Run it without arguments to display any
# users that are "out of sync". Specify 'fix' to fix the problems.
# !! Always run without arguments the first time !!

# It will make a backup of the passwd file to /tmp before starting the fix.
# If the script fucks up, DONT run it again directly afterwards
# as your backup of passwd will be overwritten Restore it first if so.

## Path to users dir
USERS=/glftpd/ftp-data/users

## Path to passwd file.
PASSWD=/glftpd/etc/passwd


#--[ Script Start ]---------------------------------------#

if [ "$1" = "fix" ]; then
  echo "Making backup of $PASSWD to /tmp/passwd.backup"
  cp -f $PASSWD /tmp/passwd.backup
else
  echo "Hang on."
fi

if [ ! -d "$USERS" ]; then
  echo "Error. USERS dir does not exist or isnt a dir: $USERS"
  exit 0
fi

if [ ! -e "$PASSWD" ]; then
  echo "Error. passwd does not exist in defined path: $PASSWD"
  exit 0
else
  groupfile=`dirname $PASSWD`
  if [ ! -e "$groupfile" ]; then
    echo "Error. group file not found. Should be in same dir as the passwd, ie $groupfile"
    exit 0
  fi
fi

cd $USERS
for user in `grep "^FLAGS " * | cut -d ':' -f1 | grep -v "default.user" `; do
      groupnow=`grep "^GROUP " $user | head -n1 | cut -d ' ' -f2`
      if [ "$groupnow" ]; then
        gidinpasswd=`grep "^$user:" $PASSWD | cut -d ':' -f4`
        groupfile=`dirname $PASSWD`
        gidingroup=`grep "^$groupnow:" $groupfile/group | cut -d ':' -f3`
        if [ "$gidinpasswd" != "$gidingroup" ]; then
          echo "$user: $groupnow has $gidingroup in group file but $user has $gidinpasswd in passwd"
          rawdata=`grep "^$user:" $PASSWD`
          pass=`echo "$rawdata" | cut -d ':' -f2`
          uid=`echo "$rawdata" | cut -d ':' -f3`
          pregid=`echo "$rawdata" | cut -d ':' -f4`
          dateadded=`echo "$rawdata" | cut -d ':' -f5`
          homedir=`echo "$rawdata" | cut -d ':' -f6`
          crap=`echo "$rawdata" | cut -d ':' -f7`
          echo "Old: $rawdata"
          echo "New: $user:$pass:$uid:$gidingroup:$dateadded:$homedir:$crap"
          echo ""
          if [ "$1" = "fix" ]; then
            grep -v "$rawdata" $PASSWD > /tmp/passwd.tmp
            cp -f /tmp/passwd.tmp $PASSWD
            echo "$user:$pass:$uid:$gidingroup:$dateadded:$homedir:$crap" >> $PASSWD
          fi
        fi
      else
        echo "$user has no primary group. Skipping."
        echo ""
      fi
done

if [ -z "$rawdata" ]; then
  echo "All users are ok!"
  exit 0
fi

if [ "$1" != "fix" ]; then
  echo "Specify 'fix' to fix the error(s) if everything looks good above."
  exit 0
else
  echo "All done. Please run this script again without 'fix' to verify that all users are ok."
  exit 0
fi