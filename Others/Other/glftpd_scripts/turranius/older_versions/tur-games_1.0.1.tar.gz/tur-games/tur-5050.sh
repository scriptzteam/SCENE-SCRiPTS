#!/bin/sh
VER=1.0

USERPATH=/ftp-data/users
BACKUPPATH=/ftp-data/users/backup
LOCKFILE=/tmp/play.lock
GLLOGFILE=/ftp-data/logs/games.log
LOGFILE=/ftp-data/logs/play.log
LOGFILETMP=/ftp-data/logs/playtmp.log
USERFILETMP=/tmp/$USER.TMP
NODELAYPASS=onlycoolppl

MINBET="100"
MAXBET="4000"

######################################################

proc_output() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $GLLOGFILE
}

BOLD=""
ULINE=""

currenttime=0
lasttime=0
delayedtime=0

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

## If the user does not type anything after 'site play', this is displayed.
if [ -z $1 ]; then
  echo "-------------------------------------------------------------"
  echo "This is a game of win or loose."
  echo "You have as much chance to win as you do loosing."
  echo "Usage: site play <MB Credits> - To play."
  echo "Usage: site play status       - To see your status."
  echo "Usage: site play highscores   - To see the highscores."
  echo "Usage: site myscore           - Your score in all games"
  echo "-------------------------------------------------------------"
  echo "Rules are:"
  echo "You can only play once every 12 hours."
  echo "You can bet ${MINBET}-${MAXBET} dollah's (MB credits)."
  echo "You can hit the jackpot, or even a super jackpot but..."
  echo "There is also a chance for something bad to happen."
  echo "Be adviced: If you are unlucky, you can loose 3x what you bet"
  echo "but you can also gain 3x ..."
  echo "(C)Turranius 2002"
  echo "-------------------------------------------------------------"
  exit 0
fi

## Create or update filedate on logfile.
touch $LOGFILE

## Check that the user does not have leech
RATIO=$(grep RATIO $USERPATH/$USER | awk -F" " '{print $2}')
if [ $RATIO = "0" ]; then
  echo "Sorry, you are banned from the casino cause your credits arent worth anything."
  exit 0
fi

## Check that another game isnt running.
if [ -e $LOCKFILE ]; then
  echo "Another game is in progress. Try again in a few seconds."
  exit 0
fi

## If the user gives the nodelaypass, delete his timer file.
if [ "$1" = "$NODELAYPASS" ]; then
  ## If a second variable is set, check if that is a user, and if so, reset that users timer.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      echo "Admin password detected. Clearing timer for $2"
      proc_output "${BOLD}-(50-50)- $USER's${BOLD} grants ${BOLD}$2${BOLD} another slot!"
      rm -f /tmp/play_$2
      exit 0
    else
      echo "Cant clear timer for $2. No such user."
      exit 0
    fi
  else
    echo "Admin password detected. Clearing your timer."
    rm -f /tmp/play_$USER
    exit 0
  fi
fi

## User requested his status.
if [ "$1" = "status" ]; then
  ## If a second variable is set, check if that is a user, and if so, show his stats.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      USER="$2"
    else
      echo "User not found."
      exit 0
    fi
  fi
  echo "Status for $USER in the Casino."
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"
  echo "You have $USERCREDSMB dollah's to play with."

  currenttime=`date +%s`
  if [ -e /tmp/play_$USER ]; then
    lasttime=`cat /tmp/play_$USER`
    lasttime=`expr $lasttime / 60`
    currenttime=`expr $currenttime / 60`
    delayedtime=`expr $currenttime - $lasttime`
    if [ `expr $delayedtime "<=" 299` = 1 ] ; then
      x=300
      delayedtime=$[x - $delayedtime ]
      echo "Your slot will open in $delayedtime minutes."
    else
      echo "Your slot to play is open now."
    fi
  else
    echo "Your slot to play is open now."
  fi

  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "You have never played before."
    exit 0
  else
    echo "Your total standing vs the casino is $LOG dollah's (mb credits)."
    exit 0
  fi
fi

## User selected to see highscores.
  if [ "$1" = "highscores" ]; then
    echo "-----[ Highscore for the casino ]------"
    cat $LOGFILE | sort -k 2,2 -n -r
    echo "--[ Casino 5050 was created by Turranius ]--"
    exit 0
  fi

## If another game isnt running, create the lockfile so noone else can play.
touch $LOCKFILE

## Make the bet x 1024 cause the userfiles contains kilobytes, not megabytes
BETCREDS="$(expr $1 \* 1024)"

## If the above calculation crapped out, the $BETCREDS is empty. User typed something other than numbers.
if [ "$BETCREDS" = "" ]; then
  echo "Bad amount of credits. Only use numbers!"
  rm -f $LOCKFILE
  exit 0
fi

## Minumum amount of credits to gamble.
if [ "$1" -lt "$MINBET" ]; then
  echo "Sorry, minumum amount to gamble with is ${MINBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

## Maximum amount of credits to gamble.
if [ "$1" -gt "$MAXBET" ]; then
  echo "Sorry, maximum amount to gamble with is ${MAXBET}MB."
  rm -f $LOCKFILE
  exit 0
fi

## Make a backup of the userfile before doing anything.
if [ "$BACKUPPATH" ]; then
  cp -f $USERPATH/$USER $BACKUPPATH/$USER.5050
fi

## Check that the user really has that much credits
USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"

## Translate it to megabytes.
USERCREDSMB="$(expr $USERCREDS \/ 1024)"

## If the user does not have enough credits...
if [ "$USERCREDS" -lt "$BETCREDS" ]; then
  echo "The guards grab you and toss you out! They toss your $USERCREDSMB credits after you!"
  proc_output "${BOLD}-(50-50)-${BOLD} The guards throws out ${BOLD}$USER${BOLD} from the casino cause he tryed to gamble with more then he had!"
  rm -f $LOCKFILE
  exit 0
fi

## Check the time since it was last run.
currenttime=`date +%s`
if [ -e /tmp/play_$USER ]; then
     lasttime=`cat /tmp/play_$USER`
     lasttime=`expr $lasttime / 60`
     currenttime=`expr $currenttime / 60`
     delayedtime=`expr $currenttime - $lasttime`
  if [ `expr $delayedtime "<=" 299` = 1 ] ; then
     x=300
     delayedtime=$[x - $delayedtime ]
     echo "You can only play once every 5 hours. Your slot will open in $delayedtime minutes."
     echo "Use 'site play status' to keep updated."
     rm -f $LOCKFILE
     exit 0
  fi
fi

VALIDATE="$(expr $1 \* 2)"
if [ "$VALIDATE" = "" ]; then
  echo "Seems to be a problem with your bet. Did you use dots?"
  rm -f $LOCKFILE
  exit 0
fi

## Make sure the current credits can be read.
if [ "$USERCREDS" = "" ]; then
  echo "Hm, cant seem to read your userfile, or you are piss poor."
  rm -f $LOCKFILE
  exit 0
else
  echo "You put in $1 dollah's in the slot machine and pull the lever."
  proc_output "${BOLD}-(50-50)- $USER${BOLD} puts${BOLD} $1 ${BOLD}dollah's in the slot machine."
  sleep 3
  echo "The tension is high while the numbers are rolling."
  sleep 3
fi

## Update the time when play was last run. Comment out this line for no delay.
echo `date +%s` > /tmp/play_$USER

## Make the actual random number.
#NUM="$(/bin/randomit 0 100)"
LOW=0
HIGH=100
proc_random
NUM="$number"

echo "The machine says: $NUM/100"
proc_output "${BOLD}-(50-50)- ${BOLD}The machine says: ${BOLD}$NUM/100${BOLD}"

## If the number is 0, take triple credits.
if [ "$NUM" = "0" ]; then
  CREDS="$(expr $BETCREDS \* 3)"
  CREDSMB="$(expr $1 \* 3)"
  echo "The maffia raid the casino and takes $CREDSMB dollah's. They also shoot you in the head."
  proc_output "${BOLD}-(50-50)- The maffia${BOLD} raids the casino! They take ${BOLD}$CREDSMB${BOLD} dollah's from ${BOLD}$USER${BOLD} and shoots him in the ${BOLD}head!${BOLD}"
  AFTERCREDS="$(expr $USERCREDS - $CREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
#  sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP

  ## Add NEG results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER -$CREDSMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG - $CREDSMB)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
  exit 0
fi

## If the number is 100, give triple credits.
if [ "$NUM" = "100" ]; then
  CREDS="$(expr $BETCREDS \* 3)"
  CREDSMB="$(expr $1 \* 3)"
  echo "SUUUPER JACKPOT!!!!!!!! The machine spits out $CREDSMB dollah's"
  proc_output "${BOLD}-(50-50)- $USER HITS THE SUPER JACKPOT! $CREDSMB${BOLD} dollah's awarded"
  AFTERCREDS="$(expr $USERCREDS + $CREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
#  sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP
  rm -f $LOCKFILE

  ## Add PLUS results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER $CREDSMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG \+ $CREDSMB)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
  exit 0
fi

## If the number is lower than 5, take double credits.
if [ "$NUM" -lt "5" ]; then
  CREDS="$(expr $BETCREDS \* 2)"
  CREDSMB="$(expr $1 \* 2)"
  echo "Police raid the casino and takes $CREDSMB dollah's from you. you get off with a warning."
  proc_debug "${BOLD}-(50-50)- Cops${BOLD} raid the casino and confiscates ${BOLD}$CREDSMB dollah's from $USER${BOLD}. $USER gets off with a warning."
  AFTERCREDS="$(expr $USERCREDS - $CREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
#  sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP

  ## Add NEG results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER -$CREDSMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG - $CREDSMB)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
  exit 0
fi

## If the number is greater than 92, give double credits.
if [ "$NUM" -gt "92" ]; then
  CREDS="$(expr $BETCREDS \* 2)"
  CREDSMB="$(expr $1 \* 2)"
  echo "JACKPOT! The machine spits out $CREDSMB dollah's"
  proc_output "${BOLD}-(50-50)- $USER${BOLD} hits the jackpot. The machine spits out ${BOLD}$CREDSMB${BOLD} dollah's."
  AFTERCREDS="$(expr $USERCREDS + $CREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
#  sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP

  ## Add PLUS results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER $CREDSMB" >> $LOGFILE
  else
    STANDING="$(expr $LOG \+ $CREDSMB)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
  exit 0
fi

## If the number is greater than 50, the user looses. Otherwise he wins.
if [ "$NUM" -lt "50" ]; then
  echo "Sorry, you loose your $1 dollah's !"
  proc_output "${BOLD}-(50-50)-${BOLD} Luck is not with ${BOLD}$USER${BOLD} today, for he lost ${BOLD}$1${BOLD} dollah's"
  AFTERCREDS="$(expr $USERCREDS - $BETCREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
# sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP  

  ## Add NEG results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER -$1" >> $LOGFILE
  else
    STANDING="$(expr $LOG \- $1)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
else
  echo "You WIN $1 dollah's. Congratulations!"
  proc_output "${BOLD}-(50-50)- $USER${BOLD} feels lucky. He wins ${BOLD}$1${BOLD} dollah's!"
  AFTERCREDS="$(expr $USERCREDS + $BETCREDS)"
  sed -e "s/^CREDITS [0-9]* /CREDITS $AFTERCREDS /1" $USERPATH/$USER > $USERFILETMP
#  sed -e "s/^CREDITS.*/CREDITS $AFTERCREDS/" $USERPATH/$USER > $USERFILETMP
  cp -f $USERFILETMP $USERPATH/$USER
  rm -f $USERFILETMP
 
  ## Add PLUS results to logfile.
  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "$USER $1" >> $LOGFILE
  else
    STANDING="$(expr $LOG \+ $1)"
    echo "Your total standing is $STANDING dollah's"
    proc_output "${BOLD}-(50-50)- $USER's${BOLD} total standing in the casino is ${BOLD}$STANDING${BOLD} dollah's"
    sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
    mv -f $LOGFILETMP $LOGFILE
  fi
  rm -f $LOCKFILE
fi

rm -f $LOCKFILE
exit 0
