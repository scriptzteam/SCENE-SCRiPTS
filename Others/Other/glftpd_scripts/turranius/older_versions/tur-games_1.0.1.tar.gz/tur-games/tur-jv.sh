#!/bin/sh
VER=1.0

USERPATH=/ftp-data/users
BACKUPPATH=/ftp-data/users/backup
LOCKFILE=/tmp/jv.lock
GLLOGFILE=/ftp-data/logs/games.log
LOGFILE=/ftp-data/logs/jv.log
LOGFILETMP=/ftp-data/logs/jvtmp.log
USERFILETMP=/tmp/$USER.JVTMP
BINPATH=/bin
PLAYFILE=/tmp/jv_$USER
NODELAYPASS=onlycoolppl

MINBET="50"
MAXBET="1000"

#--[ Script Start ]--#

proc_output() {
  echo `date "+%a %b %e %T %Y"` TURGEN: \""$@\"" >> $GLLOGFILE
}

BOLD=""
ULINE=""

## Random generator. Set LOW and HIGH first.
proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

## If the user does not type anything after 'site jv', this is displayed.
if [ -z $1 ]; then
  echo "-------------------[ Jack Vegas v$VER ]-----------------------"
  echo "Usage: site jv bet <MB Credits>   - To play                   "
  echo "Usage: site jv hold <CARDS>       - Select which cards to hold"
  echo "                                    (none = reroll all)       "
  echo "Usage: site jv status             - To see your status.       "
  echo "Usage: site jv highscores         - To see the highscores.    "
  echo "Usage: site myscore               - Your score in all games.  "
  echo "--------------------------------------------------------------"
  echo "Rules are:                                                    "
  echo "You can only play once every 15 minutes.                      "
  echo "You can bet ${MINBET}-${MAXBET} dollah's (MB credits).        "
  echo "You can hold any or all cards, or selecting 'hold none' to    "
  echo "reroll all cards.                                             "
  echo "--                                                          --"
  echo "You win on:                                                   "
  echo "- One pair above 10 =   1x Bet                                "
  echo "- Two pares         =   3x Bet                                "
  echo "- Three of a kind   =   4x Bet                                "
  echo "- Straight          =   5x Bet                                "
  echo "- Flush             =   6x Bet                                "
  echo "- Full house        =   7x Bet                                "
  echo "- Four of a kind    =  11x Bet                                "
  echo "- Straight Flush    =  99x Bet                                "
  echo "----------------------------------------[ Turranius 2002 ]----"
  exit 0
fi

## Create or update filedate on logfile.
  touch $LOGFILE

## Check that the user does not have leech
  RATIO=$(grep RATIO $USERPATH/$USER | awk -F" " '{print $2}')
  if [ $RATIO = "0" ]; then
    echo "Sorry, you are banned from the casino cause your credits arent worth anything."
    exit 0
  fi

## If the user gives the nodelaypass, delete his timer file.
if [ "$1" = "$NODELAYPASS" ]; then
  if [ "$2" = "lock" ]; then
    echo "Removing lockfile."
    rm -f $LOCKFILE
    exit 0
  fi
  ## If a second variable is set, check if that is a user, and if so, reset that users timer.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      echo "Admin password detected. Clearing timer for $2"
      proc_output "${BOLD}-(JV)- $USER${BOLD} grants ${BOLD}$2${BOLD} another go at Jack Vegas."
      rm -f /tmp/jvtime_$2
      exit 0
    else
      echo "Cant clear timer for $2. No such user."
      exit 0
    fi
  else
    echo "Admin password detected. Clearing your timer."
    rm -f /tmp/jvtime_$USER
    exit 0
  fi
fi

## Check that another game isnt running.
if [ -e $LOCKFILE ]; then
  echo "Someone else is at the machine. Wait your turn."
  exit 0
fi

## User requested his status.
if [ "$1" = "status" ]; then
  ## If a second variable is set, check if that is a user, and if so, show his stats.
  if [ "$2" != "" ]; then
    if [ -e $USERPATH/$2 ]; then
      USER="$2"
    else
      echo "User not found."
      exit 0
    fi
  fi
  echo "Status for $USER in the JV Casino."
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"
  echo "You have $USERCREDSMB dollah's to play with."

  currenttime=`date +%s`
  if [ -e /tmp/jvtime_$USER ]; then
    lasttime=`cat /tmp/jvtime_$USER`
    lasttime=`expr $lasttime / 60`
    currenttime=`expr $currenttime / 60`
    delayedtime=`expr $currenttime - $lasttime`
    if [ `expr $delayedtime "<=" 14` = 1 ] ; then
      x=15
      delayedtime=$[x - $delayedtime ]
      echo "Your slot will open in $delayedtime minutes."
    else
      echo "Your slot to play is open now."
    fi
  else
    echo "Your slot to play is open now."
  fi

  LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
  if [ "$LOG" = "" ]; then
    echo "You have never played before."
    exit 0
  else
    echo "Your total standing vs the jv casino is $LOG dollah's (mb credits)."
    exit 0
  fi
fi

## User selected to see highscores.
if [ "$1" = "highscores" ]; then
  echo "-------[ Highscore for the Jack Vegas casino ]--------"
  cat $LOGFILE | sort -k 2,2 -n -r
  echo "-------[ Jack Vegas was created by Turranius ]--------"
  exit 0
fi

## Make the structure for the deck.
## Hearts
CARDNAME2="    2 of Hearts  "
CARDNAME3="    3 of Hearts  "
CARDNAME4="    4 of Hearts  "
CARDNAME5="    5 of Hearts  "
CARDNAME6="    6 of Hearts  "
CARDNAME7="    7 of Hearts  "
CARDNAME8="    8 of Hearts  "
CARDNAME9="    9 of Hearts  "
CARDNAME10="   10 of Hearts  "
CARDNAME11=" Jack of Hearts  "
CARDNAME12="Queen of Hearts  "
CARDNAME13=" King of Hearts  "
CARDNAME14="  Ace of Hearts  "

## Spades..
CARDNAME15="    2 of Spades  "
CARDNAME16="    3 of Spades  "
CARDNAME17="    4 of Spades  "
CARDNAME18="    5 of Spades  "
CARDNAME19="    6 of Spades  "
CARDNAME20="    7 of Spades  "
CARDNAME21="    8 of Spades  "
CARDNAME22="    9 of Spades  "
CARDNAME23="   10 of Spades  "
CARDNAME24=" Jack of Spades  "
CARDNAME25="Queen of Spades  "
CARDNAME26=" King of Spades  "
CARDNAME27="  Ace of Spades  "

## Diamonds
CARDNAME28="    2 of Diamonds"
CARDNAME29="    3 of Diamonds"
CARDNAME30="    4 of Diamonds"
CARDNAME31="    5 of Diamonds"
CARDNAME32="    6 of Diamonds"
CARDNAME33="    7 of Diamonds"
CARDNAME34="    8 of Diamonds"
CARDNAME35="    9 of Diamonds"
CARDNAME36="   10 of Diamonds"
CARDNAME37=" Jack of Diamonds"
CARDNAME38="Queen of Diamonds"
CARDNAME39=" King of Diamonds"
CARDNAME40="  Ace of Diamonds"

## Clubs
CARDNAME41="    2 of Clubs   "
CARDNAME42="    3 of Clubs   "
CARDNAME43="    4 of Clubs   "
CARDNAME44="    5 of Clubs   " 
CARDNAME45="    6 of Clubs   "
CARDNAME46="    7 of Clubs   "
CARDNAME47="    8 of Clubs   "
CARDNAME48="    9 of Clubs   "
CARDNAME49="   10 of Clubs   "
CARDNAME50=" Jack of Clubs   "
CARDNAME51="Queen of Clubs   "
CARDNAME52=" King of Clubs   "
CARDNAME53="  Ace of Clubs   "

if [ "$1" = "bet" ]; then
  if [ "$2" = "" ]; then
    echo "And how many dollahs would you like to bet too please?"
    rm -f $LOCKFILE
    exit 0
  fi

  if [ -e $PLAYFILE ]; then
    echo "You have a current game going on. You must end that game first."
    rm -f $LOCKFILE
    exit 0
  fi

  ## If another game isnt running, create the lockfile so noone else can play.
  touch $LOCKFILE

  ## Make the bet x 1024 cause the userfiles contains kilobytes, not megabytes
  BETCREDS="$( expr "$2" \* "1024" )"

  ## If the above calculation crapped out, the $BETCREDS is empty. User typed something other than numbers.
  if [ "$BETCREDS" = "" ]; then
    echo "Bad amount of credits. Only use numbers!"
    rm -f $LOCKFILE
    exit 0
  fi

  ## Minumum amount of credits to gamble.
  if [ "$2" -lt "$MINBET" ]; then
    echo "Sorry, minumum amount to gamble with is ${MINBET}MB."
    rm -f $LOCKFILE
    exit 0
  fi

  ## Maximum amount of credits to gamble.
  if [ "$2" -gt "$MAXBET" ]; then
    echo "Sorry, maximum amount to gamble with is ${MAXBET}MB."
    rm -f $LOCKFILE
   exit 0
  fi

  ## Make a backup of the userfile before doing anything.
  if [ "$BACKUPPATH" ]; then
    cp -f $USERPATH/$USER $BACKUPPATH/$USER.jv
  fi

  ## Check that the user really has that much credits
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"

  ## Translate it to megabytes.
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"

  ## If the user does not have enough credits...
  BETCREDS="$2"
  if [ "$USERCREDS" -lt "$BETCREDS" ]; then
    echo "The guards grab you and toss you out! They toss your $USERCREDSMB credits after you!"
    proc_output "${BOLD}-(JV)-${BOLD} The Pizza shack owner throws out ${BOLD}$USER${BOLD} from the resturant cause he tryed to gamble with more then he had!"
    rm -f $LOCKFILE
    exit 0
  fi

  ## Check the time since it was last run.
  currenttime=`date +%s`
  if [ -e /tmp/jvtime_$USER ]; then
    lasttime=`cat /tmp/jvtime_$USER`
    lasttime=`expr $lasttime / 60`
    currenttime=`expr $currenttime / 60`
    delayedtime=`expr $currenttime - $lasttime`
    if [ `expr $delayedtime "<=" 14` = 1 ] ; then
      x=15
      delayedtime=$[x - $delayedtime ]
      echo "You can only play once every 15 minutes. Your slot will open in $delayedtime minutes."
      echo "Use 'site jv status' to keep updated."
      rm -f $LOCKFILE
      exit 0
    fi
  fi

  ## Make sure the current credits can be read.
  if [ "$USERCREDS" = "" ]; then
    echo "Hm, cant seem to read your userfile, or you are piss poor."
    rm -f $LOCKFILE
    exit 0
  else
    echo "You put $2 dollah's in the Jack Vegas machine."
    proc_output "${BOLD}-(JV)- $USER${BOLD} toss ${BOLD}$2${BOLD} Dollah's in the Jack Vegas machine."
    sleep 2
  fi

  ## Update the time when play was last run. Comment out this line for no delay.
  echo `date +%s` > /tmp/jvtime_$USER

  ## Random the first card.
  #RANDCARD1="$($BINPATH/randomit 2 53)"

  LOW=2
  HIGH=53
  proc_random
  RANDCARD1="$number"

  case $RANDCARD1 in
    2) CARD1="$CARDNAME2"; CARDNR1="2" ;;
    3) CARD1="$CARDNAME3"; CARDNR1="3" ;;
    4) CARD1="$CARDNAME4"; CARDNR1="4" ;;
    5) CARD1="$CARDNAME5"; CARDNR1="5" ;;
    6) CARD1="$CARDNAME6"; CARDNR1="6" ;;
    7) CARD1="$CARDNAME7"; CARDNR1="7" ;;
    8) CARD1="$CARDNAME8"; CARDNR1="8" ;;
    9) CARD1="$CARDNAME9"; CARDNR1="9" ;;
    10) CARD1="$CARDNAME10"; CARDNR1="10" ;;
    11) CARD1="$CARDNAME11"; CARDNR1="11" ;;
    12) CARD1="$CARDNAME12"; CARDNR1="12" ;;
    13) CARD1="$CARDNAME13"; CARDNR1="13" ;;
    14) CARD1="$CARDNAME14"; CARDNR1="14" ;;
    15) CARD1="$CARDNAME15"; CARDNR1="2" ;;
    16) CARD1="$CARDNAME16"; CARDNR1="3" ;;
    17) CARD1="$CARDNAME17"; CARDNR1="4" ;;
    18) CARD1="$CARDNAME18"; CARDNR1="5" ;;
    19) CARD1="$CARDNAME19"; CARDNR1="6" ;;
    20) CARD1="$CARDNAME20"; CARDNR1="7" ;;
    21) CARD1="$CARDNAME21"; CARDNR1="8" ;;
    22) CARD1="$CARDNAME22"; CARDNR1="9" ;;
    23) CARD1="$CARDNAME23"; CARDNR1="10" ;;
    24) CARD1="$CARDNAME24"; CARDNR1="11" ;;
    25) CARD1="$CARDNAME25"; CARDNR1="12" ;;
    26) CARD1="$CARDNAME26"; CARDNR1="13" ;;
    27) CARD1="$CARDNAME27"; CARDNR1="14" ;;
    28) CARD1="$CARDNAME28"; CARDNR1="2" ;;
    29) CARD1="$CARDNAME29"; CARDNR1="3" ;; 
    30) CARD1="$CARDNAME30"; CARDNR1="4" ;;
    31) CARD1="$CARDNAME31"; CARDNR1="5" ;;
    32) CARD1="$CARDNAME32"; CARDNR1="6" ;;
    33) CARD1="$CARDNAME33"; CARDNR1="7" ;;
    34) CARD1="$CARDNAME34"; CARDNR1="8" ;;
    35) CARD1="$CARDNAME35"; CARDNR1="9" ;;
    36) CARD1="$CARDNAME36"; CARDNR1="10" ;;
    37) CARD1="$CARDNAME37"; CARDNR1="11" ;;
    38) CARD1="$CARDNAME38"; CARDNR1="12" ;;
    39) CARD1="$CARDNAME39"; CARDNR1="13" ;;
    40) CARD1="$CARDNAME40"; CARDNR1="14" ;;
    41) CARD1="$CARDNAME41"; CARDNR1="2" ;;
    42) CARD1="$CARDNAME42"; CARDNR1="3" ;;
    43) CARD1="$CARDNAME43"; CARDNR1="4" ;;
    44) CARD1="$CARDNAME44"; CARDNR1="5" ;;
    45) CARD1="$CARDNAME45"; CARDNR1="6" ;;
    46) CARD1="$CARDNAME46"; CARDNR1="7" ;;
    47) CARD1="$CARDNAME47"; CARDNR1="8" ;;
    48) CARD1="$CARDNAME48"; CARDNR1="9" ;;
    49) CARD1="$CARDNAME49"; CARDNR1="10" ;;
    50) CARD1="$CARDNAME50"; CARDNR1="11" ;;
    51) CARD1="$CARDNAME51"; CARDNR1="12" ;;
    52) CARD1="$CARDNAME52"; CARDNR1="13" ;;
    53) CARD1="$CARDNAME53"; CARDNR1="14" ;;
    *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac

  echo "You get, A: $CARD1"
  proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}A: $CARD1${BOLD}"

  sleep 1
  sleep 1

  ## Random the seconds card.
  UNIQUE="NO"
  while [ "$UNIQUE" = "NO" ]; do
    #RANDCARD2="$($BINPATH/randomit 2 53)"

    LOW=2
    HIGH=53
    proc_random
    RANDCARD2="$number"

    if [ "$RANDCARD2" = "$RANDCARD1" ]; then
      UNIQUE="NO"
      # echo "$RANDCARD2 is the same as $RANDCARD1 - Trying again"
      sleep 1
    else
      UNIQUE="YES"
    fi
  done

  case $RANDCARD2 in
    2) CARD2="$CARDNAME2"; CARDNR2="2" ;;
    3) CARD2="$CARDNAME3"; CARDNR2="3" ;;
    4) CARD2="$CARDNAME4"; CARDNR2="4" ;;
    5) CARD2="$CARDNAME5"; CARDNR2="5" ;;
    6) CARD2="$CARDNAME6"; CARDNR2="6" ;;
    7) CARD2="$CARDNAME7"; CARDNR2="7" ;;
    8) CARD2="$CARDNAME8"; CARDNR2="8" ;;
    9) CARD2="$CARDNAME9"; CARDNR2="9" ;;
    10) CARD2="$CARDNAME10"; CARDNR2="10" ;;
    11) CARD2="$CARDNAME11"; CARDNR2="11" ;;
    12) CARD2="$CARDNAME12"; CARDNR2="12" ;;
    13) CARD2="$CARDNAME13"; CARDNR2="13" ;;
    14) CARD2="$CARDNAME14"; CARDNR2="14" ;;
    15) CARD2="$CARDNAME15"; CARDNR2="2" ;;
    16) CARD2="$CARDNAME16"; CARDNR2="3" ;;
    17) CARD2="$CARDNAME17"; CARDNR2="4" ;;
    18) CARD2="$CARDNAME18"; CARDNR2="5" ;;
    19) CARD2="$CARDNAME19"; CARDNR2="6" ;;
    20) CARD2="$CARDNAME20"; CARDNR2="7" ;;
    21) CARD2="$CARDNAME21"; CARDNR2="8" ;;
    22) CARD2="$CARDNAME22"; CARDNR2="9" ;;
    23) CARD2="$CARDNAME23"; CARDNR2="10" ;;
    24) CARD2="$CARDNAME24"; CARDNR2="11" ;;
    25) CARD2="$CARDNAME25"; CARDNR2="12" ;;
    26) CARD2="$CARDNAME26"; CARDNR2="13" ;;
    27) CARD2="$CARDNAME27"; CARDNR2="14" ;;
    28) CARD2="$CARDNAME28"; CARDNR2="2" ;;
    29) CARD2="$CARDNAME29"; CARDNR2="3" ;; 
    30) CARD2="$CARDNAME30"; CARDNR2="4" ;;
    31) CARD2="$CARDNAME31"; CARDNR2="5" ;;
    32) CARD2="$CARDNAME32"; CARDNR2="6" ;;
    33) CARD2="$CARDNAME33"; CARDNR2="7" ;;
    34) CARD2="$CARDNAME34"; CARDNR2="8" ;;
    35) CARD2="$CARDNAME35"; CARDNR2="9" ;;
    36) CARD2="$CARDNAME36"; CARDNR2="10" ;;
    37) CARD2="$CARDNAME37"; CARDNR2="11" ;;
    38) CARD2="$CARDNAME38"; CARDNR2="12" ;;
    39) CARD2="$CARDNAME39"; CARDNR2="13" ;;
    40) CARD2="$CARDNAME40"; CARDNR2="14" ;;
    41) CARD2="$CARDNAME41"; CARDNR2="2" ;;
    42) CARD2="$CARDNAME42"; CARDNR2="3" ;;
    43) CARD2="$CARDNAME43"; CARDNR2="4" ;;
    44) CARD2="$CARDNAME44"; CARDNR2="5" ;;
    45) CARD2="$CARDNAME45"; CARDNR2="6" ;;
    46) CARD2="$CARDNAME46"; CARDNR2="7" ;;
    47) CARD2="$CARDNAME47"; CARDNR2="8" ;;
    48) CARD2="$CARDNAME48"; CARDNR2="9" ;;
    49) CARD2="$CARDNAME49"; CARDNR2="10" ;;
    50) CARD2="$CARDNAME50"; CARDNR2="11" ;;
    51) CARD2="$CARDNAME51"; CARDNR2="12" ;;
    52) CARD2="$CARDNAME52"; CARDNR2="13" ;;
    53) CARD2="$CARDNAME53"; CARDNR2="14" ;;
    *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac

  echo "You get, B: $CARD2"
  proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}B: $CARD2${BOLD}"
  sleep 1
  sleep 1

  ## Random the third card.
  UNIQUE="NO"
  while [ "$UNIQUE" = "NO" ]; do
    #RANDCARD3="$($BINPATH/randomit 2 53)"

    LOW=2
    HIGH=53
    proc_random
    RANDCARD3="$number"

    if [ "$RANDCARD3" = "$RANDCARD2" -o "$RANDCARD3" = "$RANDCARD1" ]; then
      UNIQUE="NO"
      # echo "$RANDCARD3 is the same as $RANDCARD1 or $RANDCARD2 - Trying again"
      sleep 1
    else
      UNIQUE="YES"
    fi
  done

  case $RANDCARD3 in
    2) CARD3="$CARDNAME2"; CARDNR3="2" ;;
    3) CARD3="$CARDNAME3"; CARDNR3="3" ;;
    4) CARD3="$CARDNAME4"; CARDNR3="4" ;;
    5) CARD3="$CARDNAME5"; CARDNR3="5" ;;
    6) CARD3="$CARDNAME6"; CARDNR3="6" ;;
    7) CARD3="$CARDNAME7"; CARDNR3="7" ;;
    8) CARD3="$CARDNAME8"; CARDNR3="8" ;;
    9) CARD3="$CARDNAME9"; CARDNR3="9" ;;
    10) CARD3="$CARDNAME10"; CARDNR3="10" ;;
    11) CARD3="$CARDNAME11"; CARDNR3="11" ;;
    12) CARD3="$CARDNAME12"; CARDNR3="12" ;;
    13) CARD3="$CARDNAME13"; CARDNR3="13" ;;
    14) CARD3="$CARDNAME14"; CARDNR3="14" ;;
    15) CARD3="$CARDNAME15"; CARDNR3="2" ;;
    16) CARD3="$CARDNAME16"; CARDNR3="3" ;;
    17) CARD3="$CARDNAME17"; CARDNR3="4" ;;
    18) CARD3="$CARDNAME18"; CARDNR3="5" ;;
    19) CARD3="$CARDNAME19"; CARDNR3="6" ;;
    20) CARD3="$CARDNAME20"; CARDNR3="7" ;;
    21) CARD3="$CARDNAME21"; CARDNR3="8" ;;
    22) CARD3="$CARDNAME22"; CARDNR3="9" ;;
    23) CARD3="$CARDNAME23"; CARDNR3="10" ;;
    24) CARD3="$CARDNAME24"; CARDNR3="11" ;;
    25) CARD3="$CARDNAME25"; CARDNR3="12" ;;
    26) CARD3="$CARDNAME26"; CARDNR3="13" ;;
    27) CARD3="$CARDNAME27"; CARDNR3="14" ;;
    28) CARD3="$CARDNAME28"; CARDNR3="2" ;;
    29) CARD3="$CARDNAME29"; CARDNR3="3" ;; 
    30) CARD3="$CARDNAME30"; CARDNR3="4" ;;
    31) CARD3="$CARDNAME31"; CARDNR3="5" ;;
    32) CARD3="$CARDNAME32"; CARDNR3="6" ;;
    33) CARD3="$CARDNAME33"; CARDNR3="7" ;;
    34) CARD3="$CARDNAME34"; CARDNR3="8" ;;
    35) CARD3="$CARDNAME35"; CARDNR3="9" ;;
    36) CARD3="$CARDNAME36"; CARDNR3="10" ;;
    37) CARD3="$CARDNAME37"; CARDNR3="11" ;;
    38) CARD3="$CARDNAME38"; CARDNR3="12" ;;
    39) CARD3="$CARDNAME39"; CARDNR3="13" ;;
    40) CARD3="$CARDNAME40"; CARDNR3="14" ;;
    41) CARD3="$CARDNAME41"; CARDNR3="2" ;;
    42) CARD3="$CARDNAME42"; CARDNR3="3" ;;
    43) CARD3="$CARDNAME43"; CARDNR3="4" ;;
    44) CARD3="$CARDNAME44"; CARDNR3="5" ;;
    45) CARD3="$CARDNAME45"; CARDNR3="6" ;;
    46) CARD3="$CARDNAME46"; CARDNR3="7" ;;
    47) CARD3="$CARDNAME47"; CARDNR3="8" ;;
    48) CARD3="$CARDNAME48"; CARDNR3="9" ;;
    49) CARD3="$CARDNAME49"; CARDNR3="10" ;;
    50) CARD3="$CARDNAME50"; CARDNR3="11" ;;
    51) CARD3="$CARDNAME51"; CARDNR3="12" ;;
    52) CARD3="$CARDNAME52"; CARDNR3="13" ;;
    53) CARD3="$CARDNAME53"; CARDNR3="14" ;;
    *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac

  echo "You get, C: $CARD3"
  proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}C: $CARD3${BOLD}"
  sleep 1
  sleep 1

  ## Random the fourth card.
  UNIQUE="NO"
  while [ "$UNIQUE" = "NO" ]; do
    #RANDCARD4="$($BINPATH/randomit 2 53)"

    LOW=2
    HIGH=53
    proc_random
    RANDCARD4="$number"

    if [ "$RANDCARD4" = "$RANDCARD3" -o "$RANDCARD4" = "$RANDCARD2" -o "$RANDCARD4" = "$RANDCARD1" ]; then
      UNIQUE="NO"
      # echo "$RANDCARD4 is the same as $RANDCARD1, $RANDCARD2 or $RANDCARD3 - Trying again"
      sleep 1
    else
      UNIQUE="YES"
    fi
  done

  case $RANDCARD4 in
    2) CARD4="$CARDNAME2"; CARDNR4="2" ;;
    3) CARD4="$CARDNAME3"; CARDNR4="3" ;;
    4) CARD4="$CARDNAME4"; CARDNR4="4" ;;
    5) CARD4="$CARDNAME5"; CARDNR4="5" ;;
    6) CARD4="$CARDNAME6"; CARDNR4="6" ;;
    7) CARD4="$CARDNAME7"; CARDNR4="7" ;;
    8) CARD4="$CARDNAME8"; CARDNR4="8" ;;
    9) CARD4="$CARDNAME9"; CARDNR4="9" ;;
    10) CARD4="$CARDNAME10"; CARDNR4="10" ;;
    11) CARD4="$CARDNAME11"; CARDNR4="11" ;;
    12) CARD4="$CARDNAME12"; CARDNR4="12" ;;
    13) CARD4="$CARDNAME13"; CARDNR4="13" ;;
    14) CARD4="$CARDNAME14"; CARDNR4="14" ;;
    15) CARD4="$CARDNAME15"; CARDNR4="2" ;;
    16) CARD4="$CARDNAME16"; CARDNR4="3" ;;
    17) CARD4="$CARDNAME17"; CARDNR4="4" ;;
    18) CARD4="$CARDNAME18"; CARDNR4="5" ;;
    19) CARD4="$CARDNAME19"; CARDNR4="6" ;;
    20) CARD4="$CARDNAME20"; CARDNR4="7" ;;
    21) CARD4="$CARDNAME21"; CARDNR4="8" ;;
    22) CARD4="$CARDNAME22"; CARDNR4="9" ;;
    23) CARD4="$CARDNAME23"; CARDNR4="10" ;;
    24) CARD4="$CARDNAME24"; CARDNR4="11" ;;
    25) CARD4="$CARDNAME25"; CARDNR4="12" ;;
    26) CARD4="$CARDNAME26"; CARDNR4="13" ;;
    27) CARD4="$CARDNAME27"; CARDNR4="14" ;;
    28) CARD4="$CARDNAME28"; CARDNR4="2" ;;
    29) CARD4="$CARDNAME29"; CARDNR4="3" ;; 
    30) CARD4="$CARDNAME30"; CARDNR4="4" ;;
    31) CARD4="$CARDNAME31"; CARDNR4="5" ;;
    32) CARD4="$CARDNAME32"; CARDNR4="6" ;;
    33) CARD4="$CARDNAME33"; CARDNR4="7" ;;
    34) CARD4="$CARDNAME34"; CARDNR4="8" ;;
    35) CARD4="$CARDNAME35"; CARDNR4="9" ;;
    36) CARD4="$CARDNAME36"; CARDNR4="10" ;;
    37) CARD4="$CARDNAME37"; CARDNR4="11" ;;
    38) CARD4="$CARDNAME38"; CARDNR4="12" ;;
    39) CARD4="$CARDNAME39"; CARDNR4="13" ;;
    40) CARD4="$CARDNAME40"; CARDNR4="14" ;;
    41) CARD4="$CARDNAME41"; CARDNR4="2" ;;
    42) CARD4="$CARDNAME42"; CARDNR4="3" ;;
    43) CARD4="$CARDNAME43"; CARDNR4="4" ;;
    44) CARD4="$CARDNAME44"; CARDNR4="5" ;;
    45) CARD4="$CARDNAME45"; CARDNR4="6" ;;
    46) CARD4="$CARDNAME46"; CARDNR4="7" ;;
    47) CARD4="$CARDNAME47"; CARDNR4="8" ;;
    48) CARD4="$CARDNAME48"; CARDNR4="9" ;;
    49) CARD4="$CARDNAME49"; CARDNR4="10" ;;
    50) CARD4="$CARDNAME50"; CARDNR4="11" ;;
    51) CARD4="$CARDNAME51"; CARDNR4="12" ;;
    52) CARD4="$CARDNAME52"; CARDNR4="13" ;;
    53) CARD4="$CARDNAME53"; CARDNR4="14" ;;
    *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac

  echo "You get, D: $CARD4"
  proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}D: $CARD4${BOLD}"
  sleep 1
  sleep 1

  ## Random the fifth card.
  UNIQUE="NO"
  while [ "$UNIQUE" = "NO" ]; do
    #RANDCARD5="$($BINPATH/randomit 2 53)"

    LOW=2
    HIGH=53
    proc_random
    RANDCARD5="$number"

    # echo "RANDOMs: $RANDCARD1 - $RANDCARD2 - $RANDCARD3 - $RANDCARD4 - $RANDCARD5" 
    if [ "$RANDCARD5" = "$RANDCARD4" -o "$RANDCARD5" = "$RANDCARD3" -o "$RANDCARD5" = "$RANDCARD2" -o "$RANDCARD5" = "$RANDCARD1" ]; then
      UNIQUE="NO"
      # echo "$RANDCARD5 is the same as $RANDCARD1, $RANDCARD2, $RANDCARD3 or $RANDCARD4 - Trying again"
      sleep 1
    else
      UNIQUE="YES"
    fi
  done

  case $RANDCARD5 in
    2) CARD5="$CARDNAME2"; CARDNR5="2" ;;
    3) CARD5="$CARDNAME3"; CARDNR5="3" ;;
    4) CARD5="$CARDNAME4"; CARDNR5="4" ;;
    5) CARD5="$CARDNAME5"; CARDNR5="5" ;;
    6) CARD5="$CARDNAME6"; CARDNR5="6" ;;
    7) CARD5="$CARDNAME7"; CARDNR5="7" ;;
    8) CARD5="$CARDNAME8"; CARDNR5="8" ;;
    9) CARD5="$CARDNAME9"; CARDNR5="9" ;;
    10) CARD5="$CARDNAME10"; CARDNR5="10" ;;
    11) CARD5="$CARDNAME11"; CARDNR5="11" ;;
    12) CARD5="$CARDNAME12"; CARDNR5="12" ;;
    13) CARD5="$CARDNAME13"; CARDNR5="13" ;;
    14) CARD5="$CARDNAME14"; CARDNR5="14" ;;
    15) CARD5="$CARDNAME15"; CARDNR5="2" ;;
    16) CARD5="$CARDNAME16"; CARDNR5="3" ;;
    17) CARD5="$CARDNAME17"; CARDNR5="4" ;;
    18) CARD5="$CARDNAME18"; CARDNR5="5" ;;
    19) CARD5="$CARDNAME19"; CARDNR5="6" ;;
    20) CARD5="$CARDNAME20"; CARDNR5="7" ;;
    21) CARD5="$CARDNAME21"; CARDNR5="8" ;;
    22) CARD5="$CARDNAME22"; CARDNR5="9" ;;
    23) CARD5="$CARDNAME23"; CARDNR5="10" ;;
    24) CARD5="$CARDNAME24"; CARDNR5="11" ;;
    25) CARD5="$CARDNAME25"; CARDNR5="12" ;;
    26) CARD5="$CARDNAME26"; CARDNR5="13" ;;
    27) CARD5="$CARDNAME27"; CARDNR5="14" ;;
    28) CARD5="$CARDNAME28"; CARDNR5="2" ;;
    29) CARD5="$CARDNAME29"; CARDNR5="3" ;; 
    30) CARD5="$CARDNAME30"; CARDNR5="4" ;;
    31) CARD5="$CARDNAME31"; CARDNR5="5" ;;
    32) CARD5="$CARDNAME32"; CARDNR5="6" ;;
    33) CARD5="$CARDNAME33"; CARDNR5="7" ;;
    34) CARD5="$CARDNAME34"; CARDNR5="8" ;;
    35) CARD5="$CARDNAME35"; CARDNR5="9" ;;
    36) CARD5="$CARDNAME36"; CARDNR5="10" ;;
    37) CARD5="$CARDNAME37"; CARDNR5="11" ;;
    38) CARD5="$CARDNAME38"; CARDNR5="12" ;;
    39) CARD5="$CARDNAME39"; CARDNR5="13" ;;
    40) CARD5="$CARDNAME40"; CARDNR5="14" ;;
    41) CARD5="$CARDNAME41"; CARDNR5="2" ;;
    42) CARD5="$CARDNAME42"; CARDNR5="3" ;;
    43) CARD5="$CARDNAME43"; CARDNR5="4" ;;
    44) CARD5="$CARDNAME44"; CARDNR5="5" ;;
    45) CARD5="$CARDNAME45"; CARDNR5="6" ;;
    46) CARD5="$CARDNAME46"; CARDNR5="7" ;;
    47) CARD5="$CARDNAME47"; CARDNR5="8" ;;
    48) CARD5="$CARDNAME48"; CARDNR5="9" ;;
    49) CARD5="$CARDNAME49"; CARDNR5="10" ;;
    50) CARD5="$CARDNAME50"; CARDNR5="11" ;;
    51) CARD5="$CARDNAME51"; CARDNR5="12" ;;
    52) CARD5="$CARDNAME52"; CARDNR5="13" ;;
    53) CARD5="$CARDNAME53"; CARDNR5="14" ;;
    *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac

  echo "You get, E: $CARD5"
  proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}E: $CARD5${BOLD}"

  echo ""
  echo "Select which cards to hold (keep!). Example: site jv hold ADE"
  echo "The other cards will be played again."

  echo "A^$RANDCARD1" > $PLAYFILE
  echo "B^$RANDCARD2" >> $PLAYFILE
  echo "C^$RANDCARD3" >> $PLAYFILE
  echo "D^$RANDCARD4" >> $PLAYFILE
  echo "E^$RANDCARD5" >> $PLAYFILE
  echo "HELD^NO" >> $PLAYFILE
  echo "BET^$2" >> $PLAYFILE
  rm -f $LOCKFILE
  exit 0
fi

if [ "$1" = "hold" ]; then
  if [ -e "$PLAYFILE" ]; then
    HOLDOK="YES"
  else
    echo "Hold what? You have not even bet yet."
    exit 1
  fi
 
  if [ "$2" = "none" ]; then
    HOLDS="none"
  fi

  if [ "$HOLDS" != "none" ]; then
    if [ "$2" = "" ]; then
      echo "You must chose which cards to hold too!"
      echo "Do this with 'site jv hold ABCDE' (to hold all)."
      exit 1
    fi
  fi

  if [ "$3" != "" ]; then
    echo "There should be no third argument."
    echo "Do not 'site jv hold A B C'"
    echo "Instead, do 'site jv hold ABC'"
    exit 1
  fi

  touch $LOCKFILE

  HOLD1=""
  HOLD2=""
  HOLD3=""
  HOLD4=""
  HOLD5=""

  if [ "$HOLDS" != "none" ]; then
    HOLDA="$( echo "$2" | grep -i A )"
    if [ "$HOLDA" != "" ]; then
      HOLD1="A"
    fi
    HOLDB="$( echo "$2" | grep -i B )"
    if [ "$HOLDB" != "" ]; then
      HOLD2="B"
    fi
    HOLDC="$( echo "$2" | grep -i C )"
    if [ "$HOLDC" != "" ]; then
      HOLD3="C"
    fi
    HOLDD="$( echo "$2" | grep -i D )"
    if [ "$HOLDD" != "" ]; then
      HOLD4="D"
    fi
    HOLDE="$( echo "$2" | grep -i E )"
    if [ "$HOLDE" != "" ]; then
      HOLD5="E"
    fi
    RANDCARD1=""
    RANDCARD2=""
    RANDCARD3=""
    RANDCARD4=""
    RANDCARD5=""

    if [ "$HOLDA" = "" -a "$HOLDB" = "" -a "$HOLDC" = "" -a "$HOLDD" = "" -a "$HOLDE" = "" ]; then
      echo "Nonono. You can only hold letters A,B,C,D or E."
      proc_output "${BOLD}-(JV)- $USER${BOLD} chooses to hold the Waitress's ass, and gets smacked!"
      rm -f $LOCKFILE
      exit 1
    fi
    echo "You have selected to hold [ $HOLD1 $HOLD2 $HOLD3 $HOLD4 $HOLD5 ]"
    proc_output "${BOLD}-(JV)- $USER${BOLD} chooses to hold ${BOLD}( $HOLD1 $HOLD2 $HOLD3 $HOLD4 $HOLD5 )${BOLD}"
    if [ "$HOLD1"  != "" ]; then
      RANDCARD1="$( cat $PLAYFILE | grep -w A | awk -F"^" '{print $2}' )"
    fi
    if [ "$HOLD2"  != "" ]; then
      RANDCARD2="$( cat $PLAYFILE | grep -w B| awk -F"^" '{print $2}' )"
    fi
    if [ "$HOLD3"  != "" ]; then
      RANDCARD3="$( cat $PLAYFILE | grep -w c | awk -F"^" '{print $2}' )"
    fi
    if [ "$HOLD4"  != "" ]; then
      RANDCARD4="$( cat $PLAYFILE | grep -w d | awk -F"^" '{print $2}' )"
    fi
    if [ "$HOLD5"  != "" ]; then
      RANDCARD5="$( cat $PLAYFILE | grep -w e | awk -F"^" '{print $2}' )"
    fi
  else
    echo "You have selected to reroll all cards"
    proc_output "${BOLD}-(JV)- $USER${BOLD} chooses to reroll ${BOLD}all${BOLD} cards."
  fi

  RANDCARD1="$( cat $PLAYFILE | grep -w A | awk -F"^" '{print $2}' )"
  RANDCARD2="$( cat $PLAYFILE | grep -w B | awk -F"^" '{print $2}' )"
  RANDCARD3="$( cat $PLAYFILE | grep -w C | awk -F"^" '{print $2}' )"
  RANDCARD4="$( cat $PLAYFILE | grep -w D | awk -F"^" '{print $2}' )"
  RANDCARD5="$( cat $PLAYFILE | grep -w E | awk -F"^" '{print $2}' )"
  BETCREDSMB="$( cat $PLAYFILE | grep -w BET | awk -F"^" '{print $2}' )"

  if [ "$HOLD1" = "" ]; then
    UNIQUE="NO"
    while [ "$UNIQUE" = "NO" ]; do
      #RANDCARD1="$($BINPATH/randomit 2 53)"

      LOW=2
      HIGH=53
      proc_random
      RANDCARD1="$number"

      if [ "$RANDCARD1" = "$RANDCARD2" -o "$RANDCARD1" = "$RANDCARD3" -o "$RANDCARD1" = "$RANDCARD4" -o "$RANDCARD1" = "$RANDCARD5" ]; then
        UNIQUE="NO"
        # echo "$RANDCARD1 is the same as $RANDCARD2, $RANDCARD3, $RANDCARD4 or $RANDCARD5  - Trying again"
        sleep 1
      else
        UNIQUE="YES"
      fi
    done
  fi
  case $RANDCARD1 in
      2) CARD1="$CARDNAME2"; CARDNR1="2" ;;
      3) CARD1="$CARDNAME3"; CARDNR1="3" ;;
      4) CARD1="$CARDNAME4"; CARDNR1="4" ;;
      5) CARD1="$CARDNAME5"; CARDNR1="5" ;;
      6) CARD1="$CARDNAME6"; CARDNR1="6" ;;
      7) CARD1="$CARDNAME7"; CARDNR1="7" ;;
      8) CARD1="$CARDNAME8"; CARDNR1="8" ;;
      9) CARD1="$CARDNAME9"; CARDNR1="9" ;;
      10) CARD1="$CARDNAME10"; CARDNR1="10" ;;
      11) CARD1="$CARDNAME11"; CARDNR1="11" ;;
      12) CARD1="$CARDNAME12"; CARDNR1="12" ;;
      13) CARD1="$CARDNAME13"; CARDNR1="13" ;;
      14) CARD1="$CARDNAME14"; CARDNR1="14" ;;
      15) CARD1="$CARDNAME15"; CARDNR1="2" ;;
      16) CARD1="$CARDNAME16"; CARDNR1="3" ;;
      17) CARD1="$CARDNAME17"; CARDNR1="4" ;;
      18) CARD1="$CARDNAME18"; CARDNR1="5" ;;
      19) CARD1="$CARDNAME19"; CARDNR1="6" ;;
      20) CARD1="$CARDNAME20"; CARDNR1="7" ;;
      21) CARD1="$CARDNAME21"; CARDNR1="8" ;;
      22) CARD1="$CARDNAME22"; CARDNR1="9" ;;
      23) CARD1="$CARDNAME23"; CARDNR1="10" ;;
      24) CARD1="$CARDNAME24"; CARDNR1="11" ;;
      25) CARD1="$CARDNAME25"; CARDNR1="12" ;;
      26) CARD1="$CARDNAME26"; CARDNR1="13" ;;
      27) CARD1="$CARDNAME27"; CARDNR1="14" ;;
      28) CARD1="$CARDNAME28"; CARDNR1="2" ;;
      29) CARD1="$CARDNAME29"; CARDNR1="3" ;; 
      30) CARD1="$CARDNAME30"; CARDNR1="4" ;;
      31) CARD1="$CARDNAME31"; CARDNR1="5" ;;
      32) CARD1="$CARDNAME32"; CARDNR1="6" ;;
      33) CARD1="$CARDNAME33"; CARDNR1="7" ;;
      34) CARD1="$CARDNAME34"; CARDNR1="8" ;;
      35) CARD1="$CARDNAME35"; CARDNR1="9" ;;
      36) CARD1="$CARDNAME36"; CARDNR1="10" ;;
      37) CARD1="$CARDNAME37"; CARDNR1="11" ;;
      38) CARD1="$CARDNAME38"; CARDNR1="12" ;;
      39) CARD1="$CARDNAME39"; CARDNR1="13" ;;
      40) CARD1="$CARDNAME40"; CARDNR1="14" ;;
      41) CARD1="$CARDNAME41"; CARDNR1="2" ;;
      42) CARD1="$CARDNAME42"; CARDNR1="3" ;;
      43) CARD1="$CARDNAME43"; CARDNR1="4" ;;
      44) CARD1="$CARDNAME44"; CARDNR1="5" ;;
      45) CARD1="$CARDNAME45"; CARDNR1="6" ;;
      46) CARD1="$CARDNAME46"; CARDNR1="7" ;;
      47) CARD1="$CARDNAME47"; CARDNR1="8" ;;
      48) CARD1="$CARDNAME48"; CARDNR1="9" ;;
      49) CARD1="$CARDNAME49"; CARDNR1="10" ;;
      50) CARD1="$CARDNAME50"; CARDNR1="11" ;;
      51) CARD1="$CARDNAME51"; CARDNR1="12" ;;
      52) CARD1="$CARDNAME52"; CARDNR1="13" ;;
      53) CARD1="$CARDNAME53"; CARDNR1="14" ;;
      *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac
  echo "You get, A: $CARD1"
  if [ "$HOLD1" = "" ]; then
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}A: $CARD1${BOLD}"
  else
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets A: $CARD1" 
  fi

  ## Random the seconds card.
  if [ "$HOLD2" = "" ]; then
    sleep 1
    sleep 1
    UNIQUE="NO"
    while [ "$UNIQUE" = "NO" ]; do
      #RANDCARD2="$($BINPATH/randomit 2 53)"

      LOW=2
      HIGH=53
      proc_random
      RANDCARD2="$number"

      if [ "$RANDCARD2" = "$RANDCARD1" -o "$RANDCARD2" = "$RANDCARD3" -o "$RANDCARD2" = "$RANDCARD4" -o "$RANDCARD2" = "$RANDCARD5" ]; then
        UNIQUE="NO"
        # echo "$RANDCARD2 is the same as $RANDCARD1 - Trying again"
        sleep 1
      else
        UNIQUE="YES"
      fi
    done
  fi
  case $RANDCARD2 in
      2) CARD2="$CARDNAME2"; CARDNR2="2" ;;
      3) CARD2="$CARDNAME3"; CARDNR2="3" ;;
      4) CARD2="$CARDNAME4"; CARDNR2="4" ;;
      5) CARD2="$CARDNAME5"; CARDNR2="5" ;;
      6) CARD2="$CARDNAME6"; CARDNR2="6" ;;
      7) CARD2="$CARDNAME7"; CARDNR2="7" ;;
      8) CARD2="$CARDNAME8"; CARDNR2="8" ;;
      9) CARD2="$CARDNAME9"; CARDNR2="9" ;;
      10) CARD2="$CARDNAME10"; CARDNR2="10" ;;
      11) CARD2="$CARDNAME11"; CARDNR2="11" ;;
      12) CARD2="$CARDNAME12"; CARDNR2="12" ;;
      13) CARD2="$CARDNAME13"; CARDNR2="13" ;;
      14) CARD2="$CARDNAME14"; CARDNR2="14" ;;
      15) CARD2="$CARDNAME15"; CARDNR2="2" ;;
      16) CARD2="$CARDNAME16"; CARDNR2="3" ;;
      17) CARD2="$CARDNAME17"; CARDNR2="4" ;;
      18) CARD2="$CARDNAME18"; CARDNR2="5" ;;
      19) CARD2="$CARDNAME19"; CARDNR2="6" ;;
      20) CARD2="$CARDNAME20"; CARDNR2="7" ;;
      21) CARD2="$CARDNAME21"; CARDNR2="8" ;;
      22) CARD2="$CARDNAME22"; CARDNR2="9" ;;
      23) CARD2="$CARDNAME23"; CARDNR2="10" ;;
      24) CARD2="$CARDNAME24"; CARDNR2="11" ;;
      25) CARD2="$CARDNAME25"; CARDNR2="12" ;;
      26) CARD2="$CARDNAME26"; CARDNR2="13" ;;
      27) CARD2="$CARDNAME27"; CARDNR2="14" ;;
      28) CARD2="$CARDNAME28"; CARDNR2="2" ;;
      29) CARD2="$CARDNAME29"; CARDNR2="3" ;; 
      30) CARD2="$CARDNAME30"; CARDNR2="4" ;;
      31) CARD2="$CARDNAME31"; CARDNR2="5" ;;
      32) CARD2="$CARDNAME32"; CARDNR2="6" ;;
      33) CARD2="$CARDNAME33"; CARDNR2="7" ;;
      34) CARD2="$CARDNAME34"; CARDNR2="8" ;;
      35) CARD2="$CARDNAME35"; CARDNR2="9" ;;
      36) CARD2="$CARDNAME36"; CARDNR2="10" ;;
      37) CARD2="$CARDNAME37"; CARDNR2="11" ;;
      38) CARD2="$CARDNAME38"; CARDNR2="12" ;;
      39) CARD2="$CARDNAME39"; CARDNR2="13" ;;
      40) CARD2="$CARDNAME40"; CARDNR2="14" ;;
      41) CARD2="$CARDNAME41"; CARDNR2="2" ;;
      42) CARD2="$CARDNAME42"; CARDNR2="3" ;;
      43) CARD2="$CARDNAME43"; CARDNR2="4" ;;
      44) CARD2="$CARDNAME44"; CARDNR2="5" ;;
      45) CARD2="$CARDNAME45"; CARDNR2="6" ;;
      46) CARD2="$CARDNAME46"; CARDNR2="7" ;;
      47) CARD2="$CARDNAME47"; CARDNR2="8" ;;
      48) CARD2="$CARDNAME48"; CARDNR2="9" ;;
      49) CARD2="$CARDNAME49"; CARDNR2="10" ;;
      50) CARD2="$CARDNAME50"; CARDNR2="11" ;;
      51) CARD2="$CARDNAME51"; CARDNR2="12" ;;
      52) CARD2="$CARDNAME52"; CARDNR2="13" ;;
      53) CARD2="$CARDNAME53"; CARDNR2="14" ;;
      *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac
  echo "You get, B: $CARD2"
  if [ "$HOLD2" = "" ]; then
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}B: $CARD2${BOLD}"
  else
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets B: $CARD2" 
  fi

  ## Random the third card.
  if [ "$HOLD3" = "" ]; then
    sleep 1
    sleep 1
    UNIQUE="NO"
   while [ "$UNIQUE" = "NO" ]; do
      #RANDCARD3="$($BINPATH/randomit 2 53)"

      LOW=2
      HIGH=53
      proc_random
      RANDCARD3="$number"


      if [ "$RANDCARD3" = "$RANDCARD1" -o "$RANDCARD3" = "$RANDCARD2" -o "$RANDCARD3" = "$RANDCARD4" -o "$RANDCARD3" = "$RANDCARD5" ]; then
        UNIQUE="NO"
        # echo "$RANDCARD3 is the same as $RANDCARD1, $RANDCARD2, $RANDCARD4 or $RANDCARD5  - Trying again"
        sleep 1
      else
        UNIQUE="YES"
      fi
    done
  fi
  case $RANDCARD3 in
      2) CARD3="$CARDNAME2"; CARDNR3="2" ;;
      3) CARD3="$CARDNAME3"; CARDNR3="3" ;;
      4) CARD3="$CARDNAME4"; CARDNR3="4" ;;
      5) CARD3="$CARDNAME5"; CARDNR3="5" ;;
      6) CARD3="$CARDNAME6"; CARDNR3="6" ;;
      7) CARD3="$CARDNAME7"; CARDNR3="7" ;;
      8) CARD3="$CARDNAME8"; CARDNR3="8" ;;
      9) CARD3="$CARDNAME9"; CARDNR3="9" ;;
      10) CARD3="$CARDNAME10"; CARDNR3="10" ;;
      11) CARD3="$CARDNAME11"; CARDNR3="11" ;;
      12) CARD3="$CARDNAME12"; CARDNR3="12" ;;
      13) CARD3="$CARDNAME13"; CARDNR3="13" ;;
      14) CARD3="$CARDNAME14"; CARDNR3="14" ;;
      15) CARD3="$CARDNAME15"; CARDNR3="2" ;;
      16) CARD3="$CARDNAME16"; CARDNR3="3" ;;
      17) CARD3="$CARDNAME17"; CARDNR3="4" ;;
      18) CARD3="$CARDNAME18"; CARDNR3="5" ;;
      19) CARD3="$CARDNAME19"; CARDNR3="6" ;;
      20) CARD3="$CARDNAME20"; CARDNR3="7" ;;
      21) CARD3="$CARDNAME21"; CARDNR3="8" ;;
      22) CARD3="$CARDNAME22"; CARDNR3="9" ;;
      23) CARD3="$CARDNAME23"; CARDNR3="10" ;;
      24) CARD3="$CARDNAME24"; CARDNR3="11" ;;
      25) CARD3="$CARDNAME25"; CARDNR3="12" ;;
      26) CARD3="$CARDNAME26"; CARDNR3="13" ;;
      27) CARD3="$CARDNAME27"; CARDNR3="14" ;;
      28) CARD3="$CARDNAME28"; CARDNR3="2" ;;
      29) CARD3="$CARDNAME29"; CARDNR3="3" ;; 
      30) CARD3="$CARDNAME30"; CARDNR3="4" ;;
      31) CARD3="$CARDNAME31"; CARDNR3="5" ;;
      32) CARD3="$CARDNAME32"; CARDNR3="6" ;;
      33) CARD3="$CARDNAME33"; CARDNR3="7" ;;
      34) CARD3="$CARDNAME34"; CARDNR3="8" ;;
      35) CARD3="$CARDNAME35"; CARDNR3="9" ;;
      36) CARD3="$CARDNAME36"; CARDNR3="10" ;;
      37) CARD3="$CARDNAME37"; CARDNR3="11" ;;
      38) CARD3="$CARDNAME38"; CARDNR3="12" ;;
      39) CARD3="$CARDNAME39"; CARDNR3="13" ;;
      40) CARD3="$CARDNAME40"; CARDNR3="14" ;;
      41) CARD3="$CARDNAME41"; CARDNR3="2" ;;
      42) CARD3="$CARDNAME42"; CARDNR3="3" ;;
      43) CARD3="$CARDNAME43"; CARDNR3="4" ;;
      44) CARD3="$CARDNAME44"; CARDNR3="5" ;;
      45) CARD3="$CARDNAME45"; CARDNR3="6" ;;
      46) CARD3="$CARDNAME46"; CARDNR3="7" ;;
      47) CARD3="$CARDNAME47"; CARDNR3="8" ;;
      48) CARD3="$CARDNAME48"; CARDNR3="9" ;;
      49) CARD3="$CARDNAME49"; CARDNR3="10" ;;
      50) CARD3="$CARDNAME50"; CARDNR3="11" ;;
      51) CARD3="$CARDNAME51"; CARDNR3="12" ;;
      52) CARD3="$CARDNAME52"; CARDNR3="13" ;;
      53) CARD3="$CARDNAME53"; CARDNR3="14" ;;
      *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac
  echo "You get, C: $CARD3"
  if [ "$HOLD3" = "" ]; then
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}C: $CARD3${BOLD}"
  else
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets C: $CARD3" 
  fi

  ## Random the fourth card.
  if [ "$HOLD4" = "" ]; then
    sleep 1
    sleep 1
    UNIQUE="NO"
    while [ "$UNIQUE" = "NO" ]; do
      #RANDCARD4="$($BINPATH/randomit 2 53)"

      LOW=2
      HIGH=53
      proc_random
      RANDCARD4="$number"


      if [ "$RANDCARD4" = "$RANDCARD3" -o "$RANDCARD4" = "$RANDCARD2" -o "$RANDCARD4" = "$RANDCARD1" -o "$RANDCARD4" = "$RANDCARD5" ]; then
        UNIQUE="NO"
        # echo "$RANDCARD4 is the same as $RANDCARD1, $RANDCARD2, $RANDCARD3 or $RANDCARD5 - Trying again"
        sleep 1
      else
        UNIQUE="YES"
      fi
    done
  fi

  case $RANDCARD4 in
      2) CARD4="$CARDNAME2"; CARDNR4="2" ;;
      3) CARD4="$CARDNAME3"; CARDNR4="3" ;;
      4) CARD4="$CARDNAME4"; CARDNR4="4" ;;
      5) CARD4="$CARDNAME5"; CARDNR4="5" ;;
      6) CARD4="$CARDNAME6"; CARDNR4="6" ;;
      7) CARD4="$CARDNAME7"; CARDNR4="7" ;;
      8) CARD4="$CARDNAME8"; CARDNR4="8" ;;
      9) CARD4="$CARDNAME9"; CARDNR4="9" ;;
      10) CARD4="$CARDNAME10"; CARDNR4="10" ;;
      11) CARD4="$CARDNAME11"; CARDNR4="11" ;;
      12) CARD4="$CARDNAME12"; CARDNR4="12" ;;
      13) CARD4="$CARDNAME13"; CARDNR4="13" ;;
      14) CARD4="$CARDNAME14"; CARDNR4="14" ;;
      15) CARD4="$CARDNAME15"; CARDNR4="2" ;;
      16) CARD4="$CARDNAME16"; CARDNR4="3" ;;
      17) CARD4="$CARDNAME17"; CARDNR4="4" ;;
      18) CARD4="$CARDNAME18"; CARDNR4="5" ;;
      19) CARD4="$CARDNAME19"; CARDNR4="6" ;;
      20) CARD4="$CARDNAME20"; CARDNR4="7" ;;
      21) CARD4="$CARDNAME21"; CARDNR4="8" ;;
      22) CARD4="$CARDNAME22"; CARDNR4="9" ;;
      23) CARD4="$CARDNAME23"; CARDNR4="10" ;;
      24) CARD4="$CARDNAME24"; CARDNR4="11" ;;
      25) CARD4="$CARDNAME25"; CARDNR4="12" ;;
      26) CARD4="$CARDNAME26"; CARDNR4="13" ;;
      27) CARD4="$CARDNAME27"; CARDNR4="14" ;;
      28) CARD4="$CARDNAME28"; CARDNR4="2" ;;
      29) CARD4="$CARDNAME29"; CARDNR4="3" ;; 
      30) CARD4="$CARDNAME30"; CARDNR4="4" ;;
      31) CARD4="$CARDNAME31"; CARDNR4="5" ;;
      32) CARD4="$CARDNAME32"; CARDNR4="6" ;;
      33) CARD4="$CARDNAME33"; CARDNR4="7" ;;
      34) CARD4="$CARDNAME34"; CARDNR4="8" ;;
      35) CARD4="$CARDNAME35"; CARDNR4="9" ;;
      36) CARD4="$CARDNAME36"; CARDNR4="10" ;;
      37) CARD4="$CARDNAME37"; CARDNR4="11" ;;
      38) CARD4="$CARDNAME38"; CARDNR4="12" ;;
      39) CARD4="$CARDNAME39"; CARDNR4="13" ;;
      40) CARD4="$CARDNAME40"; CARDNR4="14" ;;
      41) CARD4="$CARDNAME41"; CARDNR4="2" ;;
      42) CARD4="$CARDNAME42"; CARDNR4="3" ;;
      43) CARD4="$CARDNAME43"; CARDNR4="4" ;;
      44) CARD4="$CARDNAME44"; CARDNR4="5" ;;
      45) CARD4="$CARDNAME45"; CARDNR4="6" ;;
      46) CARD4="$CARDNAME46"; CARDNR4="7" ;;
      47) CARD4="$CARDNAME47"; CARDNR4="8" ;;
      48) CARD4="$CARDNAME48"; CARDNR4="9" ;;
      49) CARD4="$CARDNAME49"; CARDNR4="10" ;;
      50) CARD4="$CARDNAME50"; CARDNR4="11" ;;
      51) CARD4="$CARDNAME51"; CARDNR4="12" ;;
      52) CARD4="$CARDNAME52"; CARDNR4="13" ;;
      53) CARD4="$CARDNAME53"; CARDNR4="14" ;;
      *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac
  echo "You get, D: $CARD4"
  if [ "$HOLD4" = "" ]; then
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}D: $CARD4${BOLD}"
  else
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets D: $CARD4" 
  fi

  ## Random the fifth card.
  if [ "$HOLD5" = "" ]; then
    sleep 1
    sleep 1
    UNIQUE="NO"
    while [ "$UNIQUE" = "NO" ]; do
      #RANDCARD5="$($BINPATH/randomit 2 53)"

      LOW=2
      HIGH=53
      proc_random
      RANDCARD5="$number"

      # echo "RANDOMs: $RANDCARD1 - $RANDCARD2 - $RANDCARD3 - $RANDCARD4 - $RANDCARD5" 
      if [ "$RANDCARD5" = "$RANDCARD4" -o "$RANDCARD5" = "$RANDCARD3" -o "$RANDCARD5" = "$RANDCARD2" -o "$RANDCARD5" = "$RANDCARD1" ]; then
        UNIQUE="NO"
        # echo "$RANDCARD5 is the same as $RANDCARD1, $RANDCARD2, $RANDCARD3 or $RANDCARD4 - Trying again"
        sleep 1
      else
        UNIQUE="YES"
      fi
    done
  fi
  case $RANDCARD5 in
      2) CARD5="$CARDNAME2"; CARDNR5="2" ;;
      3) CARD5="$CARDNAME3"; CARDNR5="3" ;;
      4) CARD5="$CARDNAME4"; CARDNR5="4" ;;
      5) CARD5="$CARDNAME5"; CARDNR5="5" ;;
      6) CARD5="$CARDNAME6"; CARDNR5="6" ;;
      7) CARD5="$CARDNAME7"; CARDNR5="7" ;;
      8) CARD5="$CARDNAME8"; CARDNR5="8" ;;
      9) CARD5="$CARDNAME9"; CARDNR5="9" ;;
      10) CARD5="$CARDNAME10"; CARDNR5="10" ;;
      11) CARD5="$CARDNAME11"; CARDNR5="11" ;;
      12) CARD5="$CARDNAME12"; CARDNR5="12" ;;
      13) CARD5="$CARDNAME13"; CARDNR5="13" ;;
      14) CARD5="$CARDNAME14"; CARDNR5="14" ;;
      15) CARD5="$CARDNAME15"; CARDNR5="2" ;;
      16) CARD5="$CARDNAME16"; CARDNR5="3" ;;
      17) CARD5="$CARDNAME17"; CARDNR5="4" ;;
      18) CARD5="$CARDNAME18"; CARDNR5="5" ;;
      19) CARD5="$CARDNAME19"; CARDNR5="6" ;;
      20) CARD5="$CARDNAME20"; CARDNR5="7" ;;
      21) CARD5="$CARDNAME21"; CARDNR5="8" ;;
      22) CARD5="$CARDNAME22"; CARDNR5="9" ;;
      23) CARD5="$CARDNAME23"; CARDNR5="10" ;;
      24) CARD5="$CARDNAME24"; CARDNR5="11" ;;
      25) CARD5="$CARDNAME25"; CARDNR5="12" ;;
      26) CARD5="$CARDNAME26"; CARDNR5="13" ;;
      27) CARD5="$CARDNAME27"; CARDNR5="14" ;;
      28) CARD5="$CARDNAME28"; CARDNR5="2" ;;
      29) CARD5="$CARDNAME29"; CARDNR5="3" ;; 
      30) CARD5="$CARDNAME30"; CARDNR5="4" ;;
      31) CARD5="$CARDNAME31"; CARDNR5="5" ;;
      32) CARD5="$CARDNAME32"; CARDNR5="6" ;;
      33) CARD5="$CARDNAME33"; CARDNR5="7" ;;
      34) CARD5="$CARDNAME34"; CARDNR5="8" ;;
      35) CARD5="$CARDNAME35"; CARDNR5="9" ;;
      36) CARD5="$CARDNAME36"; CARDNR5="10" ;;
      37) CARD5="$CARDNAME37"; CARDNR5="11" ;;
      38) CARD5="$CARDNAME38"; CARDNR5="12" ;;
      39) CARD5="$CARDNAME39"; CARDNR5="13" ;;
      40) CARD5="$CARDNAME40"; CARDNR5="14" ;;
      41) CARD5="$CARDNAME41"; CARDNR5="2" ;;
      42) CARD5="$CARDNAME42"; CARDNR5="3" ;;
      43) CARD5="$CARDNAME43"; CARDNR5="4" ;;
      44) CARD5="$CARDNAME44"; CARDNR5="5" ;;
      45) CARD5="$CARDNAME45"; CARDNR5="6" ;;
      46) CARD5="$CARDNAME46"; CARDNR5="7" ;;
      47) CARD5="$CARDNAME47"; CARDNR5="8" ;;
      48) CARD5="$CARDNAME48"; CARDNR5="9" ;;
      49) CARD5="$CARDNAME49"; CARDNR5="10" ;;
      50) CARD5="$CARDNAME50"; CARDNR5="11" ;;
      51) CARD5="$CARDNAME51"; CARDNR5="12" ;;
      52) CARD5="$CARDNAME52"; CARDNR5="13" ;;
      53) CARD5="$CARDNAME53"; CARDNR5="14" ;;
       *) echo "I CRAPPED OUT! HELP!"; exit 1 ;;
  esac
  echo "You get, E: $CARD5"  
  if [ "$HOLD5" = "" ]; then
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets ${BOLD}E: $CARD5${BOLD}"
  else
    proc_output "${BOLD}-(JV)-${BOLD} $USER gets E: $CARD5" 
  fi

  ## TESTING section.
  #CARD1="Queen of Clubs   "
  #CARD2="Queen of Clubs   "
  #CARD3=" Jack of Clubs   "
  #CARD4="Queen of Clubs   "
  #CARD5="    8 of Hearts  "
  #CARDNR1="7"
  #CARDNR2="12"
  #CARDNR3="2"
  #CARDNR4="5"
  #CARDNR5="12"

  #echo "[-------[ A ]-------]"
  #echo "[ $CARD1 ]"
  #echo "[-------------------]"
  #echo ""
  #echo "[-------[ B ]-------]"
  #echo "[ $CARD2 ]"
  #echo "[-------------------]"
  #echo ""
  #echo "[-------[ C ]-------]"
  #echo "[ $CARD3 ]"
  #echo "[-------------------]"
  #echo ""
  #echo "[-------[ D ]-------]"
  #echo "[ $CARD4 ]"
  #echo "[-------------------]"
  #echo ""
  #echo "[-------[ E ]-------]"
  #echo "[ $CARD5 ]"
  #echo "[-------------------]"

  RATIO="0"
  ALLNAMES="$CARD1 $CARD2 $CARD3 $CARD4 $CARD5"
  ALLNUMBERS="$CARDNR1 $CARDNR2 $CARDNR3 $CARDNR4 $CARDNR5"

  ####################################
  # STRAITES                         #
  ####################################
  STRAITE="NO"
  ## ace-5
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "14" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "2" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "3" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "4" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "5" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 2-6
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "2" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "3" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "4" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "5" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "6" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 3-7
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "3" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "4" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "5" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "6" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "7" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 4-8
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "4" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "5" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "6" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "7" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "8" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 5-9
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "5" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "6" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "7" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "8" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "9" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 6-10
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "6" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "7" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "8" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "9" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "10" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 7-11
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "7" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "8" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "9" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "10" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "11" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 8-12
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "8" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "9" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "10" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "11" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "12" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 9-13
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "9" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "10" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "11" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "12" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "13" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  ## 10-14
  CHECK1="$( echo "$ALLNUMBERS" | grep -w "10" )"
  if [ "$CHECK1" != "" ]; then
    CHECK2="$( echo "$ALLNUMBERS" | grep -w "11" )"
    if [ "$CHECK2" != "" ]; then
      CHECK3="$( echo "$ALLNUMBERS" | grep -w "12" )"
      if [ "$CHECK3" != "" ]; then
        CHECK4="$( echo "$ALLNUMBERS" | grep -w "13" )"
        if [ "$CHECK4" != "" ]; then
          CHECK5="$( echo "$ALLNUMBERS" | grep -w "14" )"
          if [ "$CHECK5" != "" ]; then
            STRAITE="YES"
          fi
        fi
      fi
    fi
  fi
  if [ "$STRAITE" = "YES" ]; then
    if [ "$RATIO" -lt "4" ]; then
      WINWITH="A Straight!"
      RATIO="5"
    fi
  fi


  ####################################
  ## Flushes                         #
  ####################################
  HEARTS1="$( echo $CARD1 | grep -w Hearts )"
  HEARTS2="$( echo $CARD2 | grep -w Hearts )"
  HEARTS3="$( echo $CARD3 | grep -w Hearts )"
  HEARTS4="$( echo $CARD4 | grep -w Hearts )"
  HEARTS5="$( echo $CARD5 | grep -w Hearts )"
  SPADES1="$( echo $CARD1 | grep -w Spades )"
  SPADES2="$( echo $CARD2 | grep -w Spades )"
  SPADES3="$( echo $CARD3 | grep -w Spades )"
  SPADES4="$( echo $CARD4 | grep -w Spades )"
  SPADES5="$( echo $CARD5 | grep -w Spades )"
  DIAMONDS1="$( echo $CARD1 | grep -w Diamonds )"
  DIAMONDS2="$( echo $CARD2 | grep -w Diamonds )"
  DIAMONDS3="$( echo $CARD3 | grep -w Diamonds )"
  DIAMONDS4="$( echo $CARD4 | grep -w Diamonds )"
  DIAMONDS5="$( echo $CARD5 | grep -w Diamonds )"
  CLUBS1="$( echo $CARD1 | grep -w Clubs )"
  CLUBS2="$( echo $CARD2 | grep -w Clubs )"
  CLUBS3="$( echo $CARD3 | grep -w Clubs )"
  CLUBS4="$( echo $CARD4 | grep -w Clubs )"
  CLUBS5="$( echo $CARD5 | grep -w Clubs )"
  if [ "$HEARTS1" != "" -a "$HEARTS2" != "" -a "$HEARTS3" != "" -a "$HEARTS4" != "" -a "$HEARTS5" != "" ]; then
    FLUSH="YES"
  fi
  if [ "$SPADES1" != "" -a "$SPADES2" != "" -a "$SPADES3" != "" -a "$SPADES4" != "" -a "$SPADES5" != "" ]; then
    FLUSH="YES"
  fi
  if [ "$DIAMONDS1" != "" -a "$DIAMONDS2" != "" -a "$DIAMONDS3" != "" -a "$DIAMONDS4" != "" -a "$DIAMONDS5" != "" ]; then
    FLUSH="YES"
  fi
  if [ "$CLUBS1" != "" -a "$CLUBS2" != "" -a "$CLUBS3" != "" -a "$CLUBS4" != "" -a "$CLUBS5" != "" ]; then
    FLUSH="YES"
  fi
  if [ "$FLUSH" = "YES" ]; then
    if [ "$STRAITE" = "YES" ]; then
      if [ "$RATIO" -lt "100" ]; then
        WINWITH="STRAIGHT FLUSH!!"
        RATIO="99"
      fi
    else
      if [ "$RATIO" -lt "5" ]; then
        WINWITH="Flush!"
        RATIO="6"
      fi
    fi    
  fi

  ######################################
  # One pair above Jacks               #
  ######################################

  if [ "$CARDNR1" = "$CARDNR2" -o "$CARDNR1" = "$CARDNR3" -o "$CARDNR1" = "$CARDNR4" -o "$CARDNR1" = "$CARDNR5" ]; then
    if [ "$CARDNR1" -gt "10" ]; then
      if [ "$RATIO" -lt "1" ]; then
        WINWITH="A Pair-1"
        RATIO="1"
      fi
    fi
    PAIR="YES"
    PAIRS="$CARDNR1 $PAIRS"
  fi
  if [ "$CARDNR2" = "$CARDNR3" -o "$CARDNR2" = "$CARDNR4" -o "$CARDNR2" = "$CARDNR5" ]; then
    if [ "$CARDNR2" -gt "10" ]; then
      if [ "$RATIO" -lt "1" ]; then
        WINWITH="A Pair-2"
        RATIO="1"
      fi
    fi
    PAIR="YES"
    PAIRS="$CARDNR2 $PAIRS"
  fi
  if [ "$CARDNR3" = "$CARDNR4" -o "$CARDNR3" = "$CARDNR5" ]; then
    if [ "$CARDNR3" -gt "10" ]; then
      if [ "$RATIO" -lt "1" ]; then
        WINWITH="A Pair-3"
        RATIO="1"
      fi
    fi
    PAIR="YES"
    PAIRS="$CARDNR3 $PAIRS"
  fi
  if [ "$CARDNR4" = "$CARDNR5" ]; then
    if [ "$CARDNR4" -gt "10" ]; then
      if [ "$RATIO" -lt "1" ]; then
        WINWITH="A Pair-4"
        RATIO="1"
      fi
    fi
    PAIR="YES"
    PAIRS="$CARDNR4 $PAIRS"
  fi

  ######################################
  # 3 of a kind and full house         #
  ######################################

  if [ "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR3" -o "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR4" -o "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR5" -o "$CARDNR1" = "$CARDNR4" -a "$CARDNR1" = "$CARDNR5" -o "$CARDNR1" = "$CARDNR3" -a "$CARDNR1" = "$CARDNR4" ]; then
    if [ "$RATIO" -lt "3" ]; then
      WINWITH="Three of a kind!"
      THREES="$CARDNR1 $THREES"
      TOAK="YES"
      RATIO="4"
    fi
  fi
  if [ "$CARDNR2" = "$CARDNR3" -a "$CARDNR2" = "$CARDNR4" -o "$CARDNR2" = "$CARDNR3" -a "$CARDNR2" = "$CARDNR5" -o "$CARDNR2" = "$CARDNR4" -a "$CARDNR2" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "3" ]; then
      WINWITH="Three of a kind!"
      THREES="$CARDNR2 $THREES"
      TOAK="YES"
      RATIO="4"
    fi
  fi
  if [ "$CARDNR3" = "$CARDNR4" -a "$CARDNR3" = "$CARDNR5" -o "$CARDNR3" = "$CARDNR1" -a "$CARDNR3" = "$CARDNR2" -o "$CARDNR3" = "$CARDNR1" -a "$CARDNR3" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "3" ]; then
      WINWITH="Three of a kind!"
      THREES="$CARDNR3 $THREES"
      TOAK="YES"
      RATIO="4"
    fi
  fi

  ##########################################
  # Full house                             #
  ##########################################
  
  if [ "$PAIR" = "YES" -a "$TOAK" = "YES" ]; then
    for each in $PAIRS; do
      VERIFY="$( echo "$each" | grep -w $THREES )"
       if [ "$VERIFY" = "" ]; then
        echo "$each is not $THREES"
        if [ "$RATIO" -lt "6" ]; then
          WINWITH="A Full House"
          RATIO="7"
        fi
      fi
    done
  fi

  ##########################################
  # Two Pares                              #
  ##########################################
## -lt "2" before change


  if [ "$PAIR" = "YES" ]; then
    for each in $PAIRS; do
      if [ "$DO" = "YES" ]; then
        if [ "$each" != "$LAST" ]; then
          if [ "$RATIO" -lt "3" ]; then
            WINWITH="Two Pares"
            RATIO="3"
          fi
        fi
      else
        DO="YES"
        LAST="$each"
      fi
    done
  fi

  ##########################################
  # Four of a kind                         #
  ##########################################
  
  if [ "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR3" -a "$CARDNR1" = "$CARDNR4" ]; then
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi
  if [ "$CARDNR1" = "$CARDNR3" -a "$CARDNR1" = "$CARDNR4" -a "$CARDNR1" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi
  if [ "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR3" -a "$CARDNR1" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi
  if [ "$CARDNR1" = "$CARDNR2" -a "$CARDNR1" = "$CARDNR4" -a "$CARDNR1" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi
  if [ "$CARDNR2" = "$CARDNR3" -a "$CARDNR2" = "$CARDNR4" -a "$CARDNR2" = "$CARDNR5" ]; then  
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi
  if [ "$CARDNR3" = "$CARDNR1" -a "$CARDNR3" = "$CARDNR2" -a "$CARDNR3" = "$CARDNR4" -a "$CARDNR3" = "$CARDNR5" ]; then
    if [ "$RATIO" -lt "10" ]; then
      WINWITH="Four of a kind!"
      RATIO="11"
    fi
  fi

  if [ "$RATIO" = "1" ]; then
    if [ "$WINWITH" != "Two Pares" ]; then
      echo "You win your money back on a pair above 10's"
      proc_output "${BOLD}-(JV)- $USER${BOLD} wins his money back with ${BOLD}A Pair${BOLD}."
      rm -f $PLAYFILE
      rm -f $LOCKFILE
      exit 0
    fi
  fi

  ## Make a backup of the userfile before doing anything.
  if [ "$BACKUPPATH" ]; then
    cp -f $USERPATH/$USER $BACKUPPATH/$USER.jv
  fi

  ## Check that the user really has that much credits
  USERCREDS="$(cat $USERPATH/$USER | grep CREDITS | awk -F" " '{print $2}')"

  ## Translate it to megabytes.
  USERCREDSMB="$(expr $USERCREDS \/ 1024)"
  BETCREDSKB="$( expr $BETCREDSMB \* 1024 )"

  ## Calculate win or loose.
  if [ "$RATIO" != "0" ]; then
    WINMB="$( expr $BETCREDSMB \* $RATIO )"
    WINKB="$( expr $BETCREDSKB \* $RATIO )"
    echo "Congratulations. You won $WINMB dollah's on $WINWITH"
    proc_output "${BOLD}-(JV)- $USER${BOLD} won $WINMB dollah's on ${BOLD}$WINWITH${BOLD}."
    NEWCREDSMB="$(expr $USERCREDSMB \+ $WINMB)"
    NEWCREDSKB="$(expr $NEWCREDSMB \* 1024)"
  else
    NEWCREDSMB="$(expr $USERCREDSMB \- $BETCREDSMB)"
    NEWCREDSKB="$(expr $NEWCREDSMB \* 1024)"
    echo "Sorry, you lost $BETCREDSMB dollah's"
    proc_output "${BOLD}-(JV)- $USER${BOLD} lost $BETCREDSMB dollah's"
  fi
  sed -e "s/^CREDITS.*/CREDITS $NEWCREDSKB/" $USERPATH/$USER > $USERFILETMP
  mv -f $USERFILETMP $USERPATH/$USER
  
  ## Log file
  if [ "$RATIO" = "0" ]; then
    ## echo "Add NEG results to logfile."
    LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
    if [ "$LOG" = "" ]; then
      echo "$USER -$BETCREDSMB" >> $LOGFILE
    else
      STANDING="$(expr $LOG - $BETCREDSMB)"
      echo "Your total standing with the JV machine is $STANDING dollah's"
      proc_output "${BOLD}-(JV)- $USER${BOLD}'s total standing vs the JV machine is $STANDING dollah's"
      if [ "$STANDING" -lt "-15000" ]; then
        proc_output "${BOLD}-(JV)-${BOLD} The pizza resturant owner is pleased. 'Give you free pizza, you wanker. Mau-haha'. "
      fi
      sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
      mv -f $LOGFILETMP $LOGFILE
    fi
  else
    ## echo "Add PLUS results to logfile."
    LOG="$(grep $USER $LOGFILE | awk -F" " '{print $2}')"
    if [ "$LOG" = "" ]; then
      echo "$USER $WINMB" >> $LOGFILE
    else
      STANDING="$(expr $LOG \+ $WINMB)"
      echo "Your total standing with the JV machine is $STANDING dollah's"
      proc_output "${BOLD}-(JV)- $USER${BOLD}'s total standing vs the JV machine is $STANDING dollah's"
      if [ "$STANDING" -gt "15000" ]; then
        proc_output "${BOLD}-(JV)-${BOLD} The pizza resturant owner is crying in a corner. 'Me go back to Italy. Mooommma!'"
      fi
      sed -e "s/^$USER.*/$USER $STANDING/" $LOGFILE > $LOGFILETMP
      mv -f $LOGFILETMP $LOGFILE
    fi
  fi

  rm -f $PLAYFILE
  rm -f $LOCKFILE
  exit 0

fi ## END HOLD FI

echo "Dont kick the machine!"
echo "Just do 'site jv' for help."

rm -f $LOCKFILE
exit 0