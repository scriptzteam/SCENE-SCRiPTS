#!/bin/bash

echo "Test script for the random function. Spits out a random"
echo "number between 1 and 10."
echo "Press CTRL-C to break it."
echo "Otherwise, it stops after 30 runs."

proc_random() {
  ## If the numbers are the same, just set it to the HIGH one...
  if [ "$LOW" = "$HIGH" ]; then
    number=$HIGH
  else
    number="-1"
    while [ "$number" -lt "$LOW" ]; do
      number="$RANDOM"
      if [ "$number" -gt "$HIGH" ]; then
        temphigh=$[$HIGH+1]
        let "number %= $temphigh"  # Scales $number down within $HIGH range.
      fi
    done
  fi
}

LOW=1
HIGH=10

num=0

while [ "$num" -lt "60" ]; do
  proc_random
  echo "$number"
  num=$[$num+1]
  sleep 1
done
