#!/bin/bash
VER=1.1

#--[ Different Case Settings ]----------------------------------------#

SKIPSECTIONS="
/GROUPS
/REQUESTS
/Archive
/site/DIVX/_PRE
"

#--[ On Site Before Settings ]----------------------------------------#

CHECKPREEXIST=TRUE
DIRLOG=/ftp-data/logs/dirlog
STRINGS=/bin/strings

SKIPDIRS="
^sample$
^vobsub.*
^extra.*
^cover.*
^sub.*
^bonus.*
^approved$
^allowed$
^ac3.*
^xvid\.decoder.*
^oggdec.*
^trailer.*
^CD[0-9]
"

NOPARENTCHECK="
/PDA/
/0DAYS/
/MP3/
/SVCD
"

ALLOWFILE=/tmp/tur-predircheck.allow

#--[ Error Output ]---------------------------------------------------#

## $1 = CreateDir, $2 = InPath
ERROR1="$1 already exists with a different case structure. Skipping."
ERROR2="$1 is already on site or was nuked. Wanker."

DEBUG=TRUE

#--[ Script Start ]---------------------------------------------------#

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "#0PreDirCheck: $@"
  fi
}

if [ -z "$1" -o -z "$2" ]; then
  proc_debug "Stop & Allow: Didnt get 2 arguments."
  exit 0
fi

if [ "$DEBUG" = "TRUE" ]; then
  if [ "$CHECKPREEXIST" = "TRUE" ]; then
    if [ ! -x "$STRINGS" ]; then
      proc_debug "ERROR: Cant execute STRINGS: $STRINGS"
      exit 1
    elif [ ! -r "$DIRLOG" ]; then
      proc_debug "ERROR: Cant read DIRLOG: $DIRLOG"
      exit 1
    fi
    proc_debug "Testing strings binary. Should output 5 last lines in dirlog."
    for rawdata in `$STRINGS $DIRLOG | tail -n5`; do
      proc_debug "$rawdata"
    done
  fi
fi

if [ "$SKIPSECTIONS" ]; then
  XSECTIONS="`echo $SKIPSECTIONS | tr -s ' ' '|'`"

  if [ "`echo "$2" | egrep -i "$XSECTIONS"`" ]; then
    proc_debug "Stop & Allow: Excluded section in SKIPSECTIONS"
    exit 0
  fi
fi

proc_checkallow() {
  if [ "$ALLOWFILE" ]; then
    if [ -e "$ALLOWFILE" ]; then
      if [ "`grep "^$1$" "$ALLOWFILE" `" ]; then
        proc_debug "Stop & Allow: This file has been allowed"
        exit 0
      fi
    fi
  fi
}

if [ ! -d "$2/$1" ]; then
  if [ -d "$2" ]; then
    if [ "`ls -al "$2" | grep -i "[0-9] $1$" | cut -c1`" = "d" ]; then
      proc_debug "Stop & Deny: This dir exists here with another case structure already."
      echo -e "$ERROR1\n"
      exit 1
    fi
  fi

  if [ "$CHECKPREEXIST" = "TRUE" ]; then

    XDIRS="`echo $SKIPDIRS | tr -s ' ' '|'`"
    if [ "`echo "$1" | egrep -i "$XDIRS"`" ]; then
      proc_debug "Stop & Allow: This dirname is excluded in SKIPDIRS"
      exit 0
    fi

    if [ "$NOPARENTCHECK" ]; then
      NOPARENTS="`echo $NOPARENTCHECK | tr -s ' ' '|'`"
      if [ "`echo "$2" | egrep "$NOPARENTS"`" ]; then
        proc_debug "Check: Current path defined as NOPARENTCHECK. Not checking parent dirs."
        NOPARENT="TRUE"
      fi
    fi
  
    if [ "$NOPARENT" = "TRUE" ]; then
      if [ "$( $STRINGS "$DIRLOG" | grep "/$1$" )" ]; then
        proc_checkallow "$1"
        proc_debug "Stop & Deny: It was found in dirlog, thus already upped before (NOPARENT CHECK)."
        echo -e "$ERROR2\n"
        exit 1
      fi
    else
      if [ "$( $STRINGS "$DIRLOG" | grep "$2/$1$" )" ]; then
        proc_checkallow "$1"
        proc_debug "Stop & Deny: It was found in dirlog, thus already upped before (PARENT CHECK)."
        echo -e "$ERROR2\n"
        exit 1
      fi
    fi
  fi

fi

proc_debug "Stop & Allow: This dir passed all checks."

exit 0
