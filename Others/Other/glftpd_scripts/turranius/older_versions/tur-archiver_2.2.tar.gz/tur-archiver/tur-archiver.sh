#!/bin/bash
VER=2.2

#--[ Intro ]--------------------------------------------------------#
#                                                                   #
# Tur-Archiver 2.x is a total rewrite from 1.x. It can copy, move   #
# or make symlinks from whatever you want, to wherever you want.    #
#                                                                   #
# It is NOT a spacemaker and shouldnt be used as such.              #
#                                                                   #
#--[ Installation ]-------------------------------------------------#
#                                                                   #
# Copy tur-archiver.sh to /glftpd/bin and chmod it to 700 or so.    #
#                                                                   #
# The included file_date binary is only needed if you wish to set a #
# time, in minutes, before this script touches it. If so, either    #
# copy the binary to /glftpd/bin or compile the source:             #
# gcc -o /glftpd/bin/file_date file_date.c                          #
#                                                                   #
#--[ Settings ]-----------------------------------------------------#
#                                                                   #
# GLROOT     = Simple the root of your glftpd dir.                  #
#              This is automatically added to the front of each     #
#              source and destination dir you soon choose.          #
#                                                                   #
# SITEROOT   = Path to 'site', from $GLROOT. /site is usually ok.   #
#                                                                   #
# today      = Incase you wish to use this in dated dirs, this will #
#              automatically set $today to todays dated dir (MMDD). #
#              The we can use $today in MOVE below.                 #
#                                                                   #
# MOVE       = Ahh, the heart of it all.                            #
#              Format is:                                           #
#              Where_To_Look:What_To_Look_For:Where_To_Put_It       #
#                                                                   #
#              Where_To_Look is the source section, relative to     #
#              $GLROOT$SITEROOT, which it will look for stuff in.   #
#              If you must use a space here, use [space] instead.   #
#                                                                   #
#              What_To_Look_For is a standard egrep query. That     #
#              means you should know something about basic egrep to #
#              use it at best. For instance GROUPS means it will    #
#              match the word GROUPS anywhere in the release.       #
#                                                                   #
#              ^GROUPS means the dir must START with GROUPS.        #
#              GROUPS$ means the dir must END with GROUPS.          #
#              ^GROUPS$ means the dir must be named exactly GROUPS. #
#                                                                   #
#              Any odd chars must be escaped. For instance a .      #
#              would mean "anything" whereas \. means a real dot.   #
#                                                                   #
#              Do NOT use spaces in this one. If you must, use "\ " #
#              (ie, escape the space).                              #
#                                                                   #
#              If you want to search for - . OR _  do [\_-\.]       #
#              For instance [\_-\.]internal[\_-\.]                  #
#                                                                   #
#              Seperate different querys with a | sign.             #
#                                                                   #
#              Where_To_Put_It is where to put the resulting dir.   #
#              If you must use a space here, use [space] instead.   #
#                                                                   #
# CASE_SENSITIVE= TRUE/FALSE. Do you want the What_To_Look_For to   #
#                 be case sensitive or not? (egrep -i)              #
#                                                                   #
# WHAT_TO_DO = What would you like to do in the destination dir?    #
#              S = Make a symlink.                                  #
#              C = Copy the release here.                           #
#              M = Move the release here.                           #
#                                                                   #
# EXCLUDE    = This too is a default egrep line, case sensitive.    #
#              Anything matched here will be totally ignored        #
#              even if it matches a hit.                            #
#                                                                   #
# MINUTES_OLD= How old, in minutes, must the release be before we   #
#              do anything to it?   Set to "" to move instantly.    #
#              (setting it to 0 will also, but script will run      #
#              faster if you set it to "" since it wont even check) #
#                                                                   #
# CHECK_FOR  = Anything that must be in the dir before we move it.  #
#                                                                   #
#              By default, its "\ COMPLETE\ \)\ \-"                 #
#              which translates to " COMPLETE ) -"                  #
#              That happens to be the default line for a complete   #
#              release with zipscript-c.                            #
#                                                                   #
#              If the release has multiple CD's, each CDx dir must  #
#              contain this (We'll only check CD1 -> CD9)           #
#                                                                   #
#              This is also an egrep search, case sensitive, so if  #
#              you want to add other stuff that should also make    #
#              the release ok to move just add it here, | seperated #
#                                                                   #
#              Set to "" to disable or put a # infront of it.       #
#                                                                   #
# NO_SFV_OK  = TRUE/FALSE. With FALSE, it will just check CHECK_FOR #
#              and if it exists, its ok to move it (if its old      #
#              enough), but some releases would never get moved.    #
#              Specifically, DIRFIX etc, which has no .sfv and does #
#              not have a complete dir.                             #
#                                                                   #
#              With TRUE, it will check that there really is a sfv  #
#              in the dir. If there is a sfv and CHECK_FOR is not   #
#              found, its NOT ok to move yet (not completed).       #
#                                                                   #
#              In short, if no sfv exists, its ok to move it anyway #
#              as long as its old enough in MINUTES_OLD.            #
#                                                                   #
# HOW_TO_SYMLINK = This is how it will run if WHAT_TO_DO is S.      #
# HOW_TO_MOVE    = This is how it will run if WHAT_TO_DO is M.      #
# HOW_TO_COPY    = This is how it will run if WHAT_TO_DO is C.      #
#                                                                   #
# SYMLINK_CLEAR  = TRUE/FALSE. This is only valid if WHAT_TO_DO is  #
#                  set to S.                                        #
#                  If this is TRUE, it will delete every            #
#                  Where_To_Put_It dir before it starts and then    #
#                  recreate them with 755 permissions.              #
#                  Its to make sure there are no "dead" symlinks.   #
#                  Be careful with this, as it will rm -f any dir   #
#                  you set as destination for the symlinks.         #
#                                                                   #
#                  If you dont want 755 perms, search for -m755     #
#                  below and change it to whatever you want.        #
#                                                                   #
# REVERSED_SYMLINK= TRUE/FALSE.                                     #
#                   This is ONLY if you want to move releases. In   #
#                   other words, if WHAT_TO_DO is M.                #
#                   Setting this to TRUE will move the release as   #
#                   usual but then make a symlink in its original   #
#                   location.                                       #
#                                                                   #
#                   The symlink will be created using               #
#                   HOW_TO_SYMLINK, set above.                      #
#                                                                   #
#                   These symlinks will not be cleared and          #
#                   SYMLINK_CLEAR has no function here.             #
#                                                                   #
# FILE_DATE  = Incase MINUTES_OLD is set, we use the included       #
#              file_date binary to check its age. Here you specify  #
#              it location.                                         #
#                                                                   #
# DATE_BIN   = Incase MINUTES_OLD is set, we need a GNU compliant   #
#              date binary that supports the -d option.             #
#              Most users can leave it at just "date".              #
#              FBSD users will want to download sh-utils. It will   #
#              install a binary called gdate which you must specify #
#              here.                                                #
#                                                                   #
# DEBUG      = TRUE/FALSE. Just a precation. You must set this to   #
#              FALSE for it to actually do anything. With it on     #
#              TRUE, its the same as if you used the 'debug' arg.   #
#                                                                   #
#--[ Running it ]---------------------------------------------------#
#                                                                   #
# Running it with the argument 'debug' (without the '') will not do #
# anything except show you what it WOULD have done. I recomend you  #
# use this everytime you make a change in any part.                 #
#                                                                   #
# Running it without args will make a live run. Shouldnt output     #
# anything then.                                                    #
#                                                                   #
#--[ Changelog ]----------------------------------------------------#
#                                                                   #
# 2.2   : Added REVERSED_SYMLINK function. This will make a symlink #
#         in the original location of the release if WHAT_TO_DO is  #
#         set to move stuff.                                        #
#         Idea by LPC.                                              #
#                                                                   #
#         Changed ROOT=/glftpd/site to GLROOT=/glftpd               #
#         Changed SYM_ROOT=/site to SITEROOT=/site                  #
#         Above changes was made to more easely create symlinks.    #
#                                                                   #
# 2.1   : Added NO_SFV_OK. Check explanation above.                 #
#                                                                   #
#         Fixed a problem if the release was less then 60 seconds   #
#         old. It would get moved even if MINUTES_OLD was set.      #
#                                                                   #
#         Big thanks to DaShizNit for ideas and testing the 2.+     #
#         versions.                                                 #
#                                                                   #
# 2.0   : Total rewrite of the 1.x series. Can do a lot more now.   #
#                                                                   #
#--[ Contact ]------------------------------------------------------#
#                                                                   #
# http://www.grandis.nu/glftpd <-> http://grandis.mine.nu/glftpd    #
#                                                                   #
#--[ Configuration ]------------------------------------------------#

GLROOT=/glftpd
SITEROOT=/site

today="`date +%m%d`"

MOVE="
/DIVX:^The\.|\-BP$:/Archive/DIVX/SomeDir
/SVCD:\-Flix$|[\_-\.]Int[\_-\.]:/Archive/SVCD/SomeDir
/0DAYS/$today:^3D\.|\-SomeCrapGroup$:/Archive/SVCD/SomeDir
"

CASE_SENSITIVE=FALSE

WHAT_TO_DO=M

EXCLUDE="^lost\+found$|^GROUPS$|^\_PRE$"

MINUTES_OLD=200

CHECK_FOR="\ COMPLETE\ \)\ \-"

NO_SFV_OK=TRUE

## Advanced options.

HOW_TO_SYMLINK="ln -f -s"
HOW_TO_MOVE="mv -f"
HOW_TO_COPY="cp -f"

SYMLINK_CLEAR=FALSE

REVERSED_SYMLINK=FALSE

FILE_DATE=/glftpd/bin/file_date
DATE_BIN=date

DEBUG=TRUE


#--[ Script Start ]-------------------------------------------------#

## Set DEBUG=TRUE if first argument is debug or DEBUG
if [ "$1" = "debug" -o "$1" = "DEBUG" ]; then
  DEBUG="TRUE"
fi

## Set how we want to egrep.
if [ "$CASE_SENSITIVE" = "TRUE" ]; then
  EGREP="egrep"
else
  EGREP="egrep -i"
fi

proc_debug() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$*"
  fi
}

## Move, copy or make symlinks. Heres where its done.
proc_copy() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$HOW_TO_COPY \"$FROM_DIR/$releasename\" \"$TO_DIR\""
    echo ""
  else
    $HOW_TO_COPY "$FROM_DIR/$releasename" "$TO_DIR"
  fi
}

proc_move() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$HOW_TO_MOVE \"$FROM_DIR/$releasename\" \"$TO_DIR\""
    if [ "$REVERSED_SYMLINK" != "TRUE" ]; then
      echo ""
    fi
  else
    $HOW_TO_MOVE "$FROM_DIR/$releasename" "$TO_DIR"
  fi

  ## Make a symlink it the original location, if enabled.
  if [ "$REVERSED_SYMLINK" = "TRUE" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "$HOW_TO_SYMLINK \"$TO_DIRSYM/$releasename\" \"$FROM_DIR/$releasename\""
      echo ""
    else
      $HOW_TO_SYMLINK "$TO_DIRSYM/$releasename" "$FROM_DIR/$releasename"
    fi
  fi
}

proc_symlink() {
  if [ "$DEBUG" = "TRUE" ]; then
    echo "$HOW_TO_SYMLINK \"$FROM_DIRSYM/$releasename\" \"$TO_DIR/$releasename\""
    echo ""
  else
    $HOW_TO_SYMLINK "$FROM_DIRSYM/$releasename" "$TO_DIR/$releasename"
  fi
}

## Procedure for checking if the release is old enough.
proc_checkold() {
  if [ "$MINUTES_OLD" ] && [ "$SKIP" != "YES" ]; then
    REL_DATE="`$DATE_BIN -d "$($FILE_DATE $releasename)" +%s`"
    if [ -z "$REL_DATE" ]; then
      SKIP=YES
      proc_debug "Skipping move of $releasename - Seems to be from right now or in the future... or $FILE_DATE dosnt work."
    else
      REL_SEC_OLD="`echo "$NOW_DATE - $REL_DATE" | bc -l | cut -d '.' -f1`"
      REL_MIN_OLD="`echo "$REL_SEC_OLD / 60" | bc -l | cut -d '.' -f1`"
      if [ -z "$REL_MIN_OLD" ]; then
        REL_MIN_OLD="0"
      fi
      proc_debug "$releasename seems to be $REL_MIN_OLD minutes old."
      if [ "$REL_MIN_OLD" -lt "$MINUTES_OLD" ]; then
        SKIP=YES
        proc_debug "Skipping move of $releasename - Only $REL_MIN_OLD minutes old."
      fi
    fi
  fi
}

## Procedure for checking for other stuff in the release to OK it.
proc_checkfor() {
  if [ "$CHECK_FOR" ] && [ "$SKIP" != "YES" ]; then

    ## Multiple CD's ?
    if [ "`ls -1 $releasename | grep "^[cC][dD][1-9]$"`" ]; then

      for each_cd in `ls -1 $releasename | grep "^[cC][dD][1-9]$"`; do
        if [ -z "`ls -1 $releasename/$each_cd | egrep "$CHECK_FOR"`" ]; then
          if [ "$NO_SFV_OK" = "TRUE" ]; then
            if [ "`ls -1 $releasename/$each_cd | grep "\.[sS][fF][vV]$"`" ]; then
              proc_debug "Skipping $releasename - $each_cd does not seem complete and a sfv exists."
              SKIP=YES
              break
            else
              proc_debug "OK on $releasename/$each_cd - $each_cd does not seem complete and no sfv exists."
            fi
          else
            proc_debug "Skipping $releasename - $each_cd does not seem completed."
            SKIP=YES
            break
          fi
        fi
      done

    ## Single CD release.
    else
      if [ -z "`ls -1 $releasename | egrep "$CHECK_FOR"`" ]; then
        if [ "$NO_SFV_OK" = "TRUE" ]; then
          if [ "`ls -1 $releasename | grep "\.[sS][fF][vV]$"`" ]; then
            proc_debug "Skipping $releasename - Does not seem complete and a sfv exists."
            SKIP=YES
          else
            proc_debug "OK on $releasename - does not seem complete and no sfv exists."
          fi
        else
          proc_debug "Skipping $releasename - Does not seem complete."
          SKIP=YES
        fi
      fi
    fi
  fi
}

if [ "$MINUTES_OLD" ]; then
  NOW_DATE="`$DATE_BIN +%s`"
  if [ ! -x "$FILE_DATE" ]; then
    echo "Error. MINUTES_OLD is defined but cant find/execute file_date from $FILE_DATE"
    exit 1
  fi
fi

## If we use symlinks and SYMLINK_CLEAR is TRUE, delete all TO_DIRs and recreate
if [ "$WHAT_TO_DO" = "S" ] && [ "$SYMLINK_CLEAR" = "TRUE" ]; then
  for rawdata in $MOVE; do
    TO_DIR="$ROOT`echo "$rawdata" | cut -d ':' -f3 | sed -e 's/\[space\]/ /g'`"
    if [ "$TO_DIR" != "$LAST_TO_DIR" ]; then
      if [ -d "$TO_DIR" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Deleting and recreating $TO_DIR"
        else
          rm -rf "$TO_DIR"
          mkdir -m755 "$TO_DIR"
        fi
      fi
    fi
    LAST_TO_DIR="$TO_DIR"
  done
fi  

## Go. Main loop.
for rawdata in $MOVE; do
  unset SKIP
  FROM_DIR="$GLROOT$SITEROOT`echo "$rawdata" | cut -d ':' -f1 | sed -e 's/\[space\]/ /g'`"
  FROM_DIRSYM="$SITEROOT`echo "$rawdata" | cut -d ':' -f1 | sed -e 's/\[space\]/ /g'`"

  GRAB_WHAT="`echo "$rawdata" | cut -d ':' -f2`"

  TO_DIR="$GLROOT$SITEROOT`echo "$rawdata" | cut -d ':' -f3 | sed -e 's/\[space\]/ /g'`"
  TO_DIRSYM="$SITEROOT`echo "$rawdata" | cut -d ':' -f3 | sed -e 's/\[space\]/ /g'`"

  if [ ! -d "$FROM_DIR" ]; then
    echo "Error. \"$FROM_DIR\" does not exist."
    SKIP=YES
  fi
  if [ ! -d "$TO_DIR" ]; then
    echo "Error. \"$TO_DIR\" does not exist."
    SKIP=YES
  fi

  if [ "$SKIP" != "YES" ]; then
    proc_debug ""
    proc_debug "Entering $FROM_DIR - Looking for \"$GRAB_WHAT\""

    cd "$FROM_DIR"

    for releasename in `ls -1 | $EGREP "$GRAB_WHAT" | egrep -v "$EXCLUDE" | tr ' ' '^'`; do
      unset SKIP
      releasename="`echo "$releasename" | tr '^' ' '`"

      proc_checkold
      proc_checkfor

      if [ "$SKIP" != "YES" ]; then
        case $WHAT_TO_DO in
          [mM]) proc_move;;
          [cC]) proc_copy;;
          [sS]) proc_symlink;;
        esac
      fi

    done
  fi

done

proc_debug""
proc_debug "All done."

exit 0