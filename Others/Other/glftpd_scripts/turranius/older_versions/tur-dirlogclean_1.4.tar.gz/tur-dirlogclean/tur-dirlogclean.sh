#!/bin/bash
VER=1.4
#--[ Intro ]--------------------------------------#
# Tur-DirlogClean. For a nice and updated search  #
# function in glftpd. Keep the dirlog up to date! #
#                                                 #
# Note: 'site dupe' is not affected by this and   #
#       shouldnt be. 'site dupe' is for what WAS  #
#       on site and 'site search' is for what IS! #
#                                                 #
# All this script really does, is                 #
# 1: Run olddirclean2, thus removing all releases #
#    that is not on the site anymore.             #
# 2: Run glupdate on every section you define,    #
#    updating with what is there now. Works for   #
#    dated dirs too.                              #
#--[ Installation ]-------------------------------#
#                                                 #
# Copy this script to where ever (/glftpd/bin).   #
# Make it executable (chmod 755 tur-dirclean.sh). #
# Edit the settings:                              #
#                                                 #
# glconf=  Full path to your glftpd.conf file.    #
#          This will be added automatically to    #
#          cleanold and glupdate below so dont    #
#          specify it on those settings.          #
#                                                 #
# cleanold=  What to run to clean out old folders #
#            that are not there anymore.          #
#            If you havent, put olddirclean2 from #
#            glftpd in /glftpd/bin.               #
#                                                 #
# cleanlog=  Where to log to. Only one day will   #
#            be logged at a time (no point to log #
#            more stuff).                         #
#                                                 #
# glupdate=  Where is glupdate? As with           #
#            olddirclean2, this comes with glftpd #
#            and should be working from shell.    #
#                                                 #
# dirlog=    "/glftpd/ftp-data/logs/dirlog"       #
#            The path to the dirlog file itself.  #
#                                                 #
# keepchmod= What to chmod 'dirlog' above with?   #
#            olddirclean2 sets it to 644, so we   #
#            might need to chmod it so that any   #
#            pre script or whatever can write to  #
#            it. "" = Disable.                    #
#                                                 #
# glroot=    Specify where /site is. This is just #
#            so you can use $glroot/<section> in  #
#            sections below. For lazy people.     #
#                                                 #
# sections=  Specify each section on your site    #
#            that you want to search for releases #
#            in. Add :DEEP to the end to dive one #
#            dir into that (for dated dirs).      #
#                                                 #
#            If you set this to "", it will only  #
#            remove dir from dirlog that isnt     #
#            there anymore ( from all sections ). #
#                                                 #
#            If you have a space in your sections #
#            then use [:space:]                   #
#                                                 #
# exclude=   This is only if you specify :DEEP    #
#            What NOT to add to dirlog? Pre       #
#            folders, !today symlinks, .message   #
#            file, etc etc. Anything that can be  #
#            in the dirs, but does not belong     #
#            in the dirlog.                       #
#                                                 #
#--[ Running it ]---------------------------------#
#                                                 #
# You may run this script with the argument       #
# 'debug' and it will show you what it is doing.  #
#                                                 #
# Try it by adding a dir from shell in any of     #
# the defined sections. Then search for it with   #
# site search and make sure it does not find it.  #
# Run this script and try and search for it again.#
#                                                 #
# Second try: Remove a dir from site. Search for  #
# it. It should be found still. Now run this      #
# script again and it should be gone when         #
# searching.                                      #
#                                                 #
# Crontab this script to run whenever you like.   #
# like:                                           #
# 1 1 * * * /glftpd/bin/tur-dirlogclean.sh        #
# to run it 01:01AM each day.                     #
#                                                 #
#-[ Contact ]-------------------------------------#
# WEB: http://www.grandis.nu                      #  
#      http://grandis.mine.nu                     #  
#                                                 #
#-[ Changelog ]-----------------------------------####
#                                                    #
# 1.4  : Add: You can now use [:space:] in sections  #
#             incase you have spaces in them.        #
#                                                    #
#        Add: For all you lazy people, added         #
#             glroot option to specify where /site   #
#             is, then you can use $glroot/section   #
#             in sections.                           #
#                                                    #
# 1.3  : Fix: Some people reporting having problems  #
#             with the '-r $glconf' usage. Changed   #
#             it to -r${glconf} instead.             #
#             Thanks |_SL_|                          #
#                                                    #
# 1.2  : Add: With 'debug' it now shows where it is. #
#                                                    #
#        Add: Added two new settings. dirlog and     #
#             keepchmod. When running olddirclean2,  #
#             changed the chmod on the file to 644.  #
#             With keepchmod set, it will chmod the  #
#             file set in 'dirlog' to that value.    #
#             Pre scripts might have had problems    #
#             adding the rel to dirlog if it was 644.#
#                                                    #
#        Add: Added checks to see if it can find/run #
#             the required binaries.                 #
#                                                    #
#        Chg: Renamed from tur-dirclean.sh           #
#             tur-dirlogclean.sh. Dont forget to     #
#             change your crontabs.                  #
#             Changed all 'awk' into 'cut'.          #
#                                                    #
# 1.1  : Fix: Added -r options to proggs for         #
#             that do not have glftpd.conf in /etc   #
#                                                    #
# 1.0. Initial release.                           ####
#                                                 #  ^
#-[ Settings ]------------------------------------#  |
#                                                 Lazy

glconf="/etc/glftpd.conf"

cleanold="/glftpd/bin/olddirclean2"
cleanlog="/glftpd/ftp-data/logs/olddirclean.log"

glupdate="/glftpd/bin/glupdate"

dirlog="/glftpd/ftp-data/logs/dirlog"
keepchmod=777

glroot="/glftpd/site"

sections="
$glroot/DIVX
$glroot/SVCD
$glroot/MP3:DEEP
$glroot/0DAY:DEEP
"

exclude='GROUPS|!Today|!Yesterday|.message'


#-[ Script Start ]--------------------------------#

if [ "$1" = "debug" ]; then
  echo "Verifying existance of required bins.."
fi

if [ ! -x "$cleanold" ]; then
  echo "Error. Cant execute $cleanold. Check existance and perms."
  exit 1
fi
if [ ! -x "$glupdate" ]; then
  echo "Error. Cant execute $glupdate. Check existance and perms."
  exit 1
fi
if [ ! -r "$glconf" ]; then
  echo "Error. Cant read $glconf. Check existance and perms."
  exit 1
fi

## Run olddircleaner.
if [ "$1" = "debug" ]; then
  echo "Checking for files that does not exist anymore. This could take some time."
fi

$cleanold -P -D -r${glconf} > $cleanlog

if [ "$keepchmod" ]; then
  if [ "$1" = "debug" ]; then
    echo "Running chmod $keepchmod $dirlog"
  fi
  chmod $keepchmod $dirlog
fi

echo "" >> $cleanlog

if [ "$1" = "debug" ]; then
  echo "Checking for new or moved files to add to db."
fi

for section in $sections; do
  section="`echo "$section" | sed -e 's/\[\:space\:\]/ /g'`"
  dated="$( echo $section | cut -d ':' -f2 )"
  if [ "$dated" != "DEEP" ]; then
    if [ "$1" = "debug" ]; then
      echo "Entering \"$section\""
    fi
    $glupdate -r${glconf} "$section" >> $cleanlog
  else
    section="$( echo $section | cut -d ':' -f1 )"
    if [ ! -d "$section" ]; then
      echo "Error. \"$section\" does not exist. Skipping."
    else
      cd "$section"
      LIST="$( ls -1 | egrep -vi "$exclude" )"
      for folder in $LIST; do
        if [ "$1" = "debug" ]; then
          echo "Entering \"$section/$folder\""
        fi
        $glupdate -r${glconf} "$section/$folder" >> $cleanlog
      done
    fi
  fi
done

if [ "$keepchmod" ]; then
  if [ "$1" = "debug" ]; then
    echo "Running chmod $keepchmod $dirlog"
  fi
  chmod $keepchmod $dirlog
fi

exit 0
