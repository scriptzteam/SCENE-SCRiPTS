#!/bin/bash
################################################
# Lame script to use for disabled commands.    #
################################################

SOURCENAME=NiA
################################################

echo "This command is disabled at this server."
echo "Please do all changes on $SOURCENAME and it will be replicated here after a set time."

exit 0
