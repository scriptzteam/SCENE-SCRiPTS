#!/bin/bash
VER=1.2.1
#---------------------------------------------------------------#
#                                                               #
# Tur-Requests. My own little version of it..                   #
# Supposed to replace 'site request','site reqfilled' on site   #
# and add !request, !reqfilled & !requests functions to irc.    #
# Bot parts ment for Dark0n3's zipscript-c.                     #
#                                                               #
# Will create a .requests file (definable) and optionally the   #
# directories (REQ-Release and FILLED-Release).                 #
#                                                               #
#-[ Installation ]----------------------------------------------#
#                                                               #
# Copy tur-request.sh to /glftpd/bin. Make it executable.       #
# Copy tur-request.conf to /glftpd/bin.                         #
# Copy tur-request.tcl to your bots config folder and load it.  #
# Edit tur-request.tcl and change any triggers if you dont like #
# the default settings. Take note of my mad tcl skillz =)       #
#                                                               #
# Edit tur-request.conf and change the settings.                #
#                                                               #
#-[ glftpd.conf settings ]--------------------------------------#
#                                                               #
# Add this to glftpd.conf to replace the request and reqfilled  #
# commands.                                                     #
#--                                                           --#
# site_cmd request       EXEC    /bin/tur-request.sh request
# site_cmd reqfilled     EXEC    /bin/tur-request.sh reqfilled
# site_cmd requests      EXEC    /bin/tur-request.sh status
# site_cmd reqdel        EXEC    /bin/tur-request.sh reqfilled[:space:]-hide
# site_cmd reqwipe       EXEC    /bin/tur-request.sh reqwipe
#
# custom-request         1
# custom-reqfilled       *
# custom-requests        *
# custom-reqdel          1
# custom-reqwipe         1
#--                                                           --#
#                                                               #
# If you add the variable '-hide' after either request/reqfilled#
# or status, it will not announce to irc.                       #
# This works from irc too and it will not say stuff in the      #
# channel it was executed in, instead of the main one.          #
# This is used by default with reqdel from both irc and glftpd. #
#--                                                           --#
#                                                               #
#-[ zipscript-c settings ]--------------------------------------#
#                                                               #
# To make this mofo announce, add the following to dZSbot.tcl:  #
#                                                               #
# To 'set msgtypes(DEFAULT)', add REQUEST REQFILLED REQSTATUS   #
#                                                               #
# Add the following in the appropriate places:                  #
#--                                                           --#
# set chanlist(REQUEST)   "#YourChan"
# set chanlist(REQFILLED) "#YourChan"
# set chanlist(REQSTATUS) "#YourChan"
#
# set disable(REQUEST)   0
# set disable(REQFILLED) 0
# set disable(REQSTATUS) 0
#
# set variables(REQUEST)   "%request %user"
# set variables(REQFILLED) "%request %user"
# set variables(REQSTATUS) "%msg"
#
# set announce(REQUEST)     "%bold-\[Request\]-%bold %user adds a request for %bold%request%bold. Please fill ASAP."
# set announce(REQFILLED)   "%bold-\[Request\]-%bold %user reqfilled %bold%request%bold. Good work."
# set announce(REQSTATUS)   "%bold-\[Request\]-%bold %msg"      
#--                                                           --#
# Change the announce text anyway you like.                     #
#                                                               #
#-[ Other ]-----------------------------------------------------#
#                                                               #
# If you run 'tur-request.sh status auto' it will check if      #
# there are any requests and if so, announce it to the channel. #
# If there are no requests, it will just quit. This is if you   #
# want a reminder in irc on all the requests from time to time. #
# You can just crontab it to do 'status auto' whenever you like.#
# If you leave out the 'auto', it will announce even if there   #
# are no releases requests.                                     #
#                                                               #
# When filling a request, you can enter either the release      #
# both with the requestheader and well as without. It will      #
# check both.                                                   #
#                                                               #
# When running it from shell, it will think its running in irc. #
# Thats normal.                                                 #
#                                                               #
# When requesting, you can specify who the request is for.      #
# Simple add -for:username to the request and this will show in #
# the list when checking requests. Examples:                    #
# site request -for:turranius More.Money.BP                     #
# !request "-for:turranius More.Money.BP"                       #
#                                                               #
# Reqwipe will WIPE OUT THE FOLDER too, even if its not empty.  #
# Used with 'site reqwipe' or '!reqwipe'.                       #
#                                                               #
# If you want to request or reqfill something from shell, the   #
# syntax is:                                                    #
# tur-request.sh request/reqfilled user request                 #
# ie, tur-request.sh request Turranius More.Money               #
# User does not have to be an existing user. Anything will do.  #
#                                                               #
# !request is by default locked to ops only. !reqfilled and     #
# !requests are not. If you enable !request for the public, you #
# dont need !requests really as !request shows the list if you  #
# give it no arguments. ( This is done in tur-request.tcl ).    #
# !reqwipe is for ops only as well.                             #
#                                                               #
# I was going to make a complete script for zipscript-c that    #
# would automatically fill the request when it was completed    #
# but it wouldnt work very well. First of all, zipscript-c does #
# not return the full path, only filename. I can get around it  #
# by checking xferlog for where that file is. But what if a req #
# has 2 CD's ? When first was filled, it would reqfill the dir. #
# So, wont add that right now. You're free to make a working    #
# complete script as an addon for this and I'l gladly add it.   #
#                                                               #
# Using numbers instead of names is prefered. Will probably add #
# that feature in the future (site reqfilled 1).                #
#                                                               #
#-[ Changelog ]-------------------------------------------------#
#                                                               #
# 1.2.1 : Fix: Crap fixes.                                      #
#                                                               #
# 1.2   : Fix: Modified instructions for reqdel above.          #
#                                                               #
#         Fix: If you had 3 requests, test1, test2 & test3 and  #
#              reqfilled 'test', it would remove them all from  #
#              the reqfile. Thanks LPC for reporting these.     #
#                                                               #
#         Add: Split up config to tur-request.conf              #
#                                                               #
# 1.1.1 : Fix: -hide didnt work when requesting.                #
#                                                               #
# 1.1   : Fix: The requested folder created had a space at the  #
#              end if you requested from glftpd.                #
#                                                               #
#         Fix: Requests starting with a - had problems.         #
#                                                               #
#         Fix: All checks for if a request exists or is filled  #
#              are now done in the file instead of checking if  #
#              the directory exists. This was flaky before.     #
#                                                               #
#         Add: You can now use -for:name to specify WHO the     #
#              request is for. REQINFILE2 text added.           #
#              ( site request -for:turranius More.Money-BP )    #
#              This will be displayed when checking requests.   #
#                                                               #
#         Add: Added another command. !reqdel. This will do a   #
#              normal reqfilled, but will not announce in main  #
#              chan. Replace the tcl for this to work from irc. #
#              Basically just a reqfilled -hide                 #
#                                                               #
#         Add: Added another command. reqwipe. This will delete #
#              the request from the reqfile AND wipe out the    #
#              folder if there is one, even if its not empty.   #
#              Replace the tcl as well if you want to use this. #
#                                                               #
# 1.0   : Initial release.                                      #
#-[ Contact ]---------------------------------------------------#
#                                                               #
# Turranius on efnet/linknet. Usually in #glftpd.               #
# http://www.grandis.nu/glftpd and http://grandis.mine.nu       #
#                                                               #
#-[ Settings ]--------------------------------------------------#

## Leave this marked out and it will read the config from the
## same directory as tur-request.sh is located. Otherwise you may
## specify where it is.
# config=/glftpd/bin/tur-request.conf


#-[ Script Start ]----------------------------------------------#
#                                                               #
# No changes below here unless you want to change some text.    #
#                                                               #
#---------------------------------------------------------------#


## Read config
if [ -z $config ]; then
  config="$( dirname $0 )/tur-request.conf"
fi
if [ ! -r $config ]; then
  echo "Error. Cant not read $config"
  exit 0
else
  . $config
fi

## Check if we're in glftpd or shell (irc)..
if [ "$FLAGS" -a "$GROUP" ]; then
  mode=gl
else
  mode=irc
  requests=$glroot$requests
  reqfile=$glroot$reqfile

  if [ "$gllog" ]; then
    gllog=$glroot$gllog
  fi
fi

proc_mainerror() {
  echo "Got neither request, reqfilled, reqwipe nor status... quitting."
  exit 1
}

if [ -z "$1" ]; then
  proc_mainerror
fi

proc_cookies() {
  if [ "$WHO" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WHO%/$WHO/g" )"
  fi
  if [ "$WHAT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WHAT%/$WHAT/g" )"
  fi
  if [ "$mode" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%MODE%/$mode/g" )"
  fi
  if [ "$name" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%NAME%/$name/g" )"
  fi
  if [ "$adddate" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ADDDATE%/$adddate/g" )"
  fi
  if [ "$requesthead" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%REQUESTHEAD%/"$requesthead"/g" )"
  fi
  if [ "$filledhead" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%FILLEDHEAD%/$filledhead/g" )"
  fi
  if [ "$HOWTOFILL" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%HOWTOFILL%/$HOWTOFILL/g" )"
  fi
  if [ "$sitename" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SITENAME%/$sitename/g" )"
  fi
  if [ "$towho" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%FOR%/$towho/g" )"
  fi
  if [ "$mode" = "irc" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  else
    OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
    OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
  fi
}

if [ "$1" = "request" ]; then
  request=true
  name=request
elif [ "$1" = "reqfilled" ]; then
  reqfilled=true
  name=fill
elif [ "$1" = "reqwipe" ]; then
  reqwipe=true
  name=wipe
elif [ "$1" = "status" ]; then
  status=true
  name=status
else
  proc_mainerror
fi

if [ "$mode" = "gl" ]; then
  WHO=$USER
  if [ "$2" = "-hide" ]; then
    HIDE=TRUE
    echo "Hidden mode on. Nothing will be written to glftpd.log."
    WHAT="$*"
    if [ -z "$( echo "$WHAT" | grep ' ' )" ]; then
      WHAT=""
    else
      WHAT="$( echo "$WHAT" | cut -d' ' -f3- | tr -s ' ' )"
    fi
  else
    HIDE=FALSE
    WHAT="$*"
    if [ -z "$( echo "$WHAT" | grep ' ' )" ]; then
      WHAT=""
    else
      WHAT="$( echo "$WHAT" | cut -d' ' -f2- | tr -s ' ' )"
    fi
  fi
  HOWTOFILL='site reqfilled <name>'
else
  if [ "$( echo $* | grep -w -- "-hide" )" ]; then
    echo "Quiet mode on. Shhh."
    HIDE=TRUE
    WHO="$2"
    WHAT="$4"
  else
    HIDE=FALSE
    WHO="$2"
    WHAT="$3"
  fi
  HOWTOFILL='!reqfilled <name>'
fi

## Clean up. Remove -hide, requester and any extra spaces from request.
if [ "$WHAT" ]; then
  WHAT="$( echo "$*" | sed -e 's/-hide//' | sed -e "s/$WHO//" | tr -s ' ' | cut -d ' ' -f2- )"
fi

if [ "$status" = "true" ]; then 
  WHAT=somecrap
fi

if [ "$WHAT" = "" ]; then
  OUTPUT="$NOARGUMENT"
  proc_cookies
  echo "$OUTPUT"
  unset request
  unset reqfilled
  unset reqwipe
  status=true
fi

## Check if first argument of request is -for:
if [ "$request" = "true" ]; then
  if [ "$( echo $WHAT | cut -d ' ' -f1 | cut -d ':' -f1 )" = "-for" ]; then
    towho="$( echo $WHAT | cut -d ' ' -f1 | cut -d ':' -f2 )"
    if [ "$towho" = "-for" -o "$towho" = "" ]; then
      echo "You must specify who its for. -for:username"
      exit 0
    fi
    WHAT="$( echo $WHAT | cut -d ' ' -f2- )"
    ## echo "DEBUG: -for mode on"
    REQINFILE="$REQINFILE2"
  fi
fi

# echo "DEBUG: What is : >$WHAT<"
# echo "DEBUG: hide is : >$HIDE<"
# echo "DEBUG: who is  : >$WHO<"
# echo "DEBUG: towho is: ->$towho<-"
# exit 0

## If allowspace isnt TRUE, check if there is a space in the req.
if [ "$allowspace" != "TRUE" ]; then
  if [ "$( echo "$WHAT" | grep ' ' )" ]; then
    OUTPUT="$NOSPACES"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  fi
fi

if [ ! -w "$requests" ]; then
  echo "Request error. Cant write to requests directory. Check path and perms."
  exit 0
fi

## REQUEST MODE

if [ "$request" = "true" ]; then

  if [ "$requesthead" ]; then
    ## Check if folder is created..  
    if [ -d "$requests/$filledhead$WHAT" ]; then
      OUTPUT="$ALREADYFILLED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    elif [ -d "$requests/$requesthead$WHAT" ]; then
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  else
    ## Check if request is in file..
    if [ "$( grep -w -- "$WHAT" "$reqfile" )" ]; then
      OUTPUT="$ALREADYREQUESTED"
      proc_cookies
      echo "$OUTPUT"
      exit 0
    fi
  fi

  if [ "$reqfile" ]; then
    if [ ! -e "$reqfile" ]; then
      touch "$reqfile"
    fi
    if [ -w "$reqfile" ]; then
      OUTPUT="$REQINFILE"
      proc_cookies
      echo "$OUTPUT" >> $reqfile
    else
      error="$( basename $reqfile )"
      echo "Error: Cant write to $error. Check paths and perms."
      exit 0
    fi
  fi
 
  if [ "$gllog" ]; then
    if [ -w "$gllog" ]; then
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQUEST: \"$WHAT\" \"$WHO\" >> $gllog
      fi
    else
      echo "Error. Cant write to $gllog. Check paths and perms."
      exit 0
    fi
  fi

  if [ "$mode" = "gl" ]; then
    OUTPUT="$GLOK"
    proc_cookies
    echo "$OUTPUT"
  fi

  if [ "$requesthead" ]; then
    mkdir -m777 "$requests/$requesthead$WHAT"
  fi

fi

## REQFILL MODE

if [ "$reqfilled" = "true" -o "$reqwipe" = "true" ]; then

  ## Check if its requested by checking file.
  ## Dont bother checking folder too. Not interesting.

  WHATCHECK="$( echo "$WHAT" | tr -s ' ' '~' )"
  for line in `cat $reqfile | tr -s ' ' '~'`; do
    if [ "$( echo "$line" | grep -w -- "^$WHATCHECK" )" ]; then
      FOUND="YEAH"
    fi
  done
  if [ "$FOUND" != "YEAH" ]; then
    OUTPUT="$NOTREQUESTED"
    proc_cookies
    echo "$OUTPUT"
    exit 0
  else
    unset FOUND
    unset WHATCHECK
  fi

  ## REMOVE THE REQUESTHEAD IF ITS ON $WHAT
  WHAT="$( echo "$WHAT" | sed -e "s/^$requesthead//" )"

  if [ "$reqfile" ]; then
    if [ ! -w "$reqfile" ]; then
      error="$( basename $reqfile )"
      echo "Error. Cant write to $error file. Check paths and perms."
      exit 0
    else
      grep -viw -- "$WHAT" "$reqfile" > $tmp/reqfile.tmp
      cp -f $tmp/reqfile.tmp $reqfile
      rm -f $tmp/reqfile.tmp
    fi
  fi

  if [ "$reqfilled" = "true" ]; then
    reqword="marked as filled"
  else
    ## REQWIPE mode
    reqword="wiped"
    HIDE=TRUE
  fi
    
  if [ "$gllog" ]; then
    if [ -w "$gllog" ]; then
      if [ "$mode" = "gl" -o "$HIDE" = "TRUE" ]; then
        echo "Ok, < $WHAT > has been $reqword"
      fi
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQFILLED: \"$WHAT\" \"$WHO\" >> $gllog
      fi
    else
      echo "Error. Cant write to $gllog. Check paths and perms."
      exit 0
    fi
  fi

  ## IF WIPE COMMAND, DEL THE REQUEST. IF NOT, FILL IT.
  if [ "$reqwipe" = "true" ]; then
    if [ -d "$requests/$requesthead$WHAT" ]; then
      rm -rf "$requests/$requesthead$WHAT"
    else
      echo "Gee, I would love to wipe out $WHAT, but there is no such folder."
    fi
  else
    if [ "$requesthead" ]; then
      if [ -d "$requests/$requesthead$WHAT" ]; then
        mv -f "$requests/$requesthead$WHAT" "$requests/$filledhead$WHAT"
      fi
    fi
  fi

fi

if [ "$status" = "true" ]; then
  if [ -z "$reqfile" ]; then
    echo "To use status, you must have a reqfile defined."
    exit 0
  fi

  if [ "$2" = "auto" ]; then
    if [ ! -e $reqfile ]; then
      exit 0
    fi
    if [ -z "$( cat $reqfile )" ]; then
      exit 0
    fi      
  fi

  if [ ! -r "$reqfile" ]; then
    echo "Cant read $reqfile. Check paths and perms."
    exit 0
  fi

  OUTPUT="$STATUSHEAD"
  proc_cookies
  if [ "$mode" = "gl" ]; then
    echo "$OUTPUT"
  else
    if [ "$HIDE" = "FALSE" ]; then
      echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
    fi
  fi

  for line in `cat $reqfile | tr -s ' ' '^'`; do
    WHAT="$( echo $line | cut -d'^' -f1 )"
    gotone=yeah
    if [ ! -r "$reqfile" ]; then
      if [ ! -d "$requests/$requesthead$WHAT" ]; then
        grep -vi -- "$WHAT" "$reqfile" > $tmp/reqfile.tmp
        cp -f $tmp/reqfile.tmp $reqfile
        rm -f $tmp/reqfile.tmp
 
        OUTPUT="$FORCEFILL"
        proc_cookies
      fi

      if [ "$mode" = "gl" ]; then
        echo "$OUTPUT"
      fi
      if [ "$gllog" ]; then
        if [ "$HIDE" = "FALSE" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
        fi
      fi
    else
      gotone=yeah
      line="$( echo $line | tr -s '^' ' ' )"
      if [ "$mode" = "gl" ]; then
        echo "$line"
      else
        if [ "$HIDE" = "FALSE" ]; then
          echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$line\" >> $gllog
        fi
      fi
    fi
  done
  if [ -z "$gotone" ]; then
    OUTPUT="$NOREQUESTS"
    proc_cookies
    if [ "$mode" = "gl" -o "$mode" = "irc" -a "$HIDE" = "TRUE" ]; then
      echo "$OUTPUT"
    else
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
      fi
    fi
  else
    OUTPUT="$TOFILL"
    proc_cookies
    if [ "$mode" = "gl" ]; then
      echo "$OUTPUT"
    else
      if [ "$HIDE" = "FALSE" ]; then
        echo `date "+%a %b %e %T %Y"` REQSTATUS: \"$OUTPUT\" >> $gllog
      fi
    fi
  fi
fi

exit 0
