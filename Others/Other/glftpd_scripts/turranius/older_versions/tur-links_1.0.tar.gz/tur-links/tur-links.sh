#!/bin/bash
VER=1.0

#--[ Intro ]---------------------------------------------------#
#                                                              #
# Tur-Links. An addon to Tur-Space (works fine alone too).     #
#                                                              #
# This script will create symlinks to all your releases in a   #
# central dir somewhere. Its useful if you have, for example,  #
# your DIVX's spread out over multiple harddrives but still    #
# wish to provide the means for users to see all of them in    #
# the same dir.                                                #
#                                                              #
#--[ Installation ]--------------------------------------------#
#                                                              #
# Copy this script to /glftpd/bin. Chmod it to 700 or similar. #
#                                                              #
# Change the settings follows:                                 #
#                                                              #
# TULS     = Full path to "tuls". A required binary. If you    #
#            dont have this one, its available at my webpage   #
#            at www.grandis.nu/glftpd                          #
#            Make sure its working before continuing.          #
#                                                              #
# GLROOT   = The path to your glftpd dir. Usually just /glftpd #
#                                                              #
# SECTIONS = Here is what you specify from where to symlink &  #
#            where to put those symlinks.                      #
#            Seperate sources (where to look) with a : and the #
#            final location should have a * infront of it.     #
#                                                              #
#            Example:                                          #
#            /site/1:/site/2:/site3*/site/All                  #
#                                                              #
#            The above example would put symlinks from the 3   #
#            directories /site/1, /site/2 and /site/3 into     #
#            the /site/All directory.                          #
#                                                              #
#            This all have to be on one line. You can no use   #
#            a newline to seperate this.                       #
#            However, you can add as many of these as you like #
#            and if so, seperate them with a newline. Example: #
#                                                              #
#            SECTIONS="                                        #
#            /site/1:/site/2:/site3*/site/All_Mp3              #
#            /site/A:/site/B:/siteC*/site/All_0day             #
#            "                                                 #
#                                                              #
#            You can use more then one newline to clean it up  #
#            if that helps (see example).                      #
#                                                              #
#            Now, you can NOT use the same destination dir for #
#            more then one section. This is because it will    #
#            remove every symlink it finds in the destination  #
#            dir before it starts. This ensures that there are #
#            no dead symlinks.                                 #
#                                                              #
#            It is recomended that you do not keep anything    #
#            important in the destination dir. It will only    #
#            delete symlinks and nothing else, but better safe #
#            then sorry (anyone remember the old game, better  #
#            dead then alien? Lol).                            #
#                                                              #
# EXCLUDE  = Any dirs you do not want to get a symlink.        #
#            Normally, you'd use ^ and $ to specify start and  #
#            end, but since we use tuls to read dirs, you use  #
#            : to specify start and end instead.               #
#                                                              #
#            Like the example: ":GROUPS:" means it will not    #
#            create symlinks if the dir is called exactly      #
#            GROUPS. If you were you specify only "GROUPS", it #
#            would not create a symlink if the dir contained   #
#            the word GROUPS somewhere in it.                  #
#                                                              #
#            Likewise, specifying "GROUPS:" means it must END  #
#            with GROUPS only.                                 #
#                                                              #
#            Seperate exclusions with a | (see example).       #
#                                                              #
#--[ Running ]-------------------------------------------------#
#                                                              #
# There is no debug or test mode. It wont output stuff to the  #
# shell unless there are any errors.                           #
#                                                              #
# I run this every 45 minutes in the crontab. Why so often?    #
# Its fairly quick and then I know the symlinks are up to date.#
# To crontab it to run every 45 minutes past the hour:         #
# 45 * * * *      /glftpd/bin/tur-links.sh                     #
#                                                              #
#--[ Notes ]---------------------------------------------------#
#                                                              #
# There is no way to get the symlinks to be the "correct" date.#
# I've tried but can not get it to do that. Cant even 'touch'  #
# a symlink with the correct date.                             #
#                                                              #
# No, it dosnt work for dated dirs contents. You do not want   #
# that many symlinks in the same location anyway (slooow).     #
#                                                              #
# Doing it like this opens another option for you as mentioned #
# by nm0. Mount all the seperate disks in /Archive/DISKS or so #
# and then hide it with hidden_files in glftpd.conf.           #
# Make symlinks from them to a central dir, like /Archive/MP3. #
# Now, the users does not even see the seperate disks and      #
# instead see it all as one big section. Atleast until they    #
# click on a symlink =).                                       #
#                                                              #
#--[ Configuration ]-------------------------------------------#

TULS=/glftpd/bin/tuls

GLROOT=/glftpd


SECTIONS="

/site/DIVX:/site/Archive/DIVX/DIVX1:/site/Archive/DIVX/DIVX2*/site/Archive/DIVX/All

/site/DVDR:/site/Archive/DVDR/DVDR1:/site/Archive/DVDR/DVDR2*/site/Archive/DVDR/All

" # <- end of SECTIONS. Dont touch.


EXCLUDE=":GROUPS:|:\_PRE:|:lost\+found:"


#--[ Script Start ]--------------------------------------------#

if [ ! -x "$TULS" ]; then
  echo "Error. $TULS could not be executed or dosnt exist."
  exit 1
fi
if [ ! -d "$GLROOT" ]; then
  echo "Error. $GLROOT was not found or is not a directory."
  exit 1
fi

## Go !
for section in $SECTIONS; do
  FROMRAW="`echo "$section" | cut -d '*' -f1`"
  TO="`echo "$section" | cut -d '*' -f2`"

  if [ -z "$FROMRAW" ]; then
    echo "Error. Did not get any 'from' location from $section"
    exit 1
  elif [ -z "$TO" ]; then
    echo "Error. Did not get any 'to' location from $section"
    exit 1
  fi

  FROMRAW="`echo "$FROMRAW" | tr ':' ' '`"

  if [ ! -d "$GLROOT$TO" ]; then
    echo "Error. $GLROOT$TO does not exist or is not a directory. Skipping."
  else
    ## Clean out old symlinks.
    cd $GLROOT$TO
    for symlink in `$TULS | grep "^l" | awk -F"::::" '{print $4}'`; do
      rm -f "$symlink"
    done

    for FROM in $FROMRAW; do

      if [ ! -d "$GLROOT$FROM" ]; then
        echo "Error. $GLROOT$FROM does not exist or is not a dir. Skipping."
      else
        cd $GLROOT$FROM
        for release in `$TULS | grep "^d" | egrep -iv "$EXCLUDE|:\.\.:|:\.\:" | awk -F"::::" '{print $4}'`; do
          ln -s $FROM/$release $GLROOT$TO/$release
        done
      fi
    done
  fi
done

exit 0
