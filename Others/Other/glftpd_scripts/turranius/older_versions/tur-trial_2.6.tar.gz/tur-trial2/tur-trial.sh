#!/bin/bash
VER=2.6

## See README for detailed instructions, changelog and contact information

## Remove # below to hardset config location
## If not, it will be read from the same dir as tur-trial.sh is in.
# config=/glftpd/bin/tur-trial.conf

###############################################################################
# No changes should be needed under here.                                     #
###############################################################################

## Load config file
if [ -z "$config" ]; then
  config="$( dirname $0 )/tur-trial.conf"
fi

. $config

USER="$1"

## Little check that $USER does not contain .. or /
if [ "$( echo "$USER" | grep '/' )" -o "$( echo "$USER" | grep '\.\.' )" ]; then
  echo "Dumbass =)"
  exit 0
fi

if [ -z "$DATEBIN" ]; then
  DATEBIN="date"
fi

## Replace those %bla% with actual text.
proc_cookies() {
  if [ "$USER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%USER%/$USER/g" )"
  fi
  if [ "$SHOWL" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SHOWL%/$SHOWL/g" )"
  fi
  if [ "$RATIO" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%RATIO%/$RATIO/g" )"
  fi
  if [ "$DURNAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DURNAME%/$DURNAME/g" )"
  fi
  if [ "$g" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%GROUP%/$MAINGROUP/g" )"
  fi
  if [ "$EG" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%EGROUP%/$EG/g" )"
  fi
  if [ "$DAY" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DAY%/$DAY/g" )"
  fi
  if [ "$SITENAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%SITENAME%/$SITENAME/g" )"
  fi
  if [ "$PERDAY" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%PERDAY%/$PERDAY/g" )"
  fi
  if [ "$PERDAYNAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%PERDAYNAME%/$PERDAYNAME/g" )"
  fi
  if [ "$POS" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%POS%/$POS/g" )"
  fi
  if [ "$GONESINCE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%GONESINCE%/$GONESINCE/g" )"
  fi
  if [ "$DIFFERENCE" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%GONEDAYS%/$DIFFERENCE/g" )"
  fi
  if [ "$ORIGQUOTALIMIT" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%OSHOWL%/$ORIGQUOTALIMIT/g" )"
  fi

  if [ "$DUR" ]; then
    if [ "$DUR" = "MONTHUP" ]; then
      DUR="MNUP"
    fi
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DUR%/$DUR/g" )"
  fi
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

## Make sure we dont go into a infinite loop on the custom announces...
if [ -z "$C_PASSED_TRIALTOT" ]; then
  C_PASSED_TRIALTOT=0
fi
if [ -z "$C_NOTPASSED_TRIALTOT" ]; then
  C_NOTPASSED_TRIALTOT=0
fi
if [ -z "$C_PASSED_NEXTDURTOT" ]; then
  C_PASSED_NEXTDURTOT=0
fi
if [ -z "$C_NOTPASSED_NEXTDURTOT" ]; then
  C_NOTPASSED_NEXTDURTOT=0
fi
if [ -z "$C_PASSED_NOTRIALTOT" ]; then
  C_PASSED_NOTRIALTOT=0
fi
if [ -z "$C_NOTPASSED_NOTRIALTOT" ]; then
  C_NOTPASSED_NOTRIALTOT=0
fi
if [ -z "$C_QUOTA_EX_PASSEDTOT" ]; then
  C_QUOTA_EX_PASSEDTOT=0
fi
if [ -z "$C_QUOTA_EX_NOTPASSEDTOT" ]; then
  C_QUOTA_EX_NOTPASSEDTOT=0
fi
if [ -z "$C_QUOTA_PASSEDTOT" ]; then
  C_QUOTA_PASSEDTOT=0
fi
if [ -z "$C_QUOTA_NOTPASSEDTOT" ]; then
  C_QUOTA_NOTPASSEDTOT=0
fi
if [ -z "$C_FIRST_QUOTA_PASSEDTOT" ]; then
  C_FIRST_QUOTA_PASSEDTOT=0
fi
if [ -z "$C_FIRST_QUOTA_NOTPASSEDTOT" ]; then
  C_FIRST_QUOTA_NOTPASSEDTOT=0
fi

## Procedure for getting wkup/monthup position
proc_getpos() {
  POS="?"
  if [ "$STATSBIN" ]; then

    ## Are we checking w (weekup) or m (monthup)?
    if [ "$WHEN" = "NOT" -a "$NOTRIALLIMIT" != "" ]; then
      ## WHEN = NOT is set if the user is NOT on trial. If so, take the quota duration.
      ## However, if NOTRIALLIMIT is empty, quota is disabled. Dont do this then =)
      if [ "$NOTRIALDURATION" = "M" ]; then
        POSCHECK="m"
      else
        POSCHECK="w"
      fi
    else
      ## We are looking for the duration of trials in this case. Not quota.
      if [ "$DURATION" = "M" ]; then
        POSCHECK="m"
      else
        POSCHECK="w"
      fi
    fi

    POS=`$STATSBIN -u -$POSCHECK -x500 | grep "] $USER " | cut -d ' ' -f1 | tr -d '[' | tr -d ']'`
    if [ -z "$POS" ]; then
      POS="?"
    fi

  ## STATSBIN is empty. Cant get a POS. Set this incase %POS% is in the cookie.
  else
    POS="- STATSBIN not defined. POS cant be used in cookies. -"
  fi
}

ORIGQUOTALIMIT="$NOTRIALLIMIT"

## Procedure for check if users and on vacation.
## Decuct amount from monthly quota amount if so.
proc_vacation() {
  ## Read vacationdata if its defined. Else quit. Only works on Montly quota.
  if [ "$VACATIONDATA" != "" -a "$NOTRIALDURATION" = "M" ]; then

    unset DIFFERENCE; unset GONESINCE

    if [ ! -r "$VACATIONDATA" ]; then
      echo "Error. VACATIONDATA set to $VACATIONDATA, but I cant read that file."
    else
      VACATIONTIME="$( grep -w "^$USER" $VACATIONDATA | cut -d '^' -f2 )"
      if [ "$VACATIONTIME" ]; then

        LIMIT="$NOTRIALLIMIT"

        ## This is just used for outputting WHEN he went on vacation in YYYY-MM-DD format.
        GONESINCE=`$DATEBIN -d "1970-01-01 $VACATIONTIME sec" +%Y"-"%m"-"%d`

        ## If the user came back from vacation, we should get a third number
        ## Otherwise, hes still on it.
        BACKTIME=`grep -w "^$USER" $VACATIONDATA | cut -d '^' -f3`
        if [ "$BACKTIME" ]; then
          ## User back from vacation. Set "now" to the time they got back.
          VACATIONTIMENOW="$BACKTIME"
        else
          ## User still on vacation. Count from the end of today.
          YEARMONTHDAY=`$DATEBIN +%Y"-"%m"-"%d`
          VACATIONTIMENOW="$( $DATEBIN -d "$YEARMONTHDAY 23:59:59" +%s )"
          unset YEARMONTHDAY
        fi

        ## Check if hes been gone for longer then current month.
        ## If so, set the time he went on vacation to the start of this month.
        YEARMONTH=`$DATEBIN +%Y"-"%m`
        MONTHSTART=`$DATEBIN -d "$YEARMONTH-01 00:00:01" +%s`
        if [ "$VACATIONTIME" -lt "$MONTHSTART" ]; then
          VACATIONTIME="$MONTHSTART"
        fi
        unset YEARMONTH

        ## Recalc the time "now" to days since 1970.
        TIMETHEN="$( expr $VACATIONTIME \/ 60 )"
        TIMETHEN="$( expr $TIMETHEN \/ 60 )"
        TIMETHEN="$( expr $TIMETHEN \/ 24 )"

        ## Recalc the time he was back to days since 1970.
        TIMENOW="$( expr $VACATIONTIMENOW \/ 60 )"
        TIMENOW="$( expr $TIMENOW \/ 60 )"
        TIMENOW="$( expr $TIMENOW \/ 24 )"

        unset VACATIONTIME; unset VACATIONTIMENOW

        ## Calc the number of day difference.
        DIFFERENCE="$( expr $TIMENOW \- $TIMETHEN )"

        ## How many days are there in the current month?
        MONTHNOW="$( $DATEBIN +%b )"
        case $MONTHNOW in
          Jan) MONTHTOTAL="31" ;;
          Feb) MONTHTOTAL="28" ;;
          Mar) MONTHTOTAL="31" ;;
          Apr) MONTHTOTAL="30" ;;
          May) MONTHTOTAL="31" ;;
          Jun) MONTHTOTAL="30" ;;
          Jul) MONTHTOTAL="31" ;;
          Aug) MONTHTOTAL="31" ;;
          Sep) MONTHTOTAL="30" ;;
          Oct) MONTHTOTAL="31" ;;
          Nov) MONTHTOTAL="30" ;;
          Dec) MONTHTOTAL="31" ;;
          *) MONTHTOTAL="31" ;;
        esac

        ## If the user did NOT go on vacation today, count new quota limit.
        if [ "$DIFFERENCE" != "0" ]; then

          ## If the user has been gone the whole or more then this current month...
          if [ "$DIFFERENCE" -ge "$MONTHTOTAL" ]; then

            ## Set the diff to match full month (if hes been gone longer. Dont want to deduct too much from limit).
            DIFFERENCE="$MONTHTOTAL"
            if [ "$AUTOQUOTA" = "TRUE" -a "$DEBUG" = "TRUE" ]; then
              echo "DEBUG: $USER has been on vacation all month (since $GONESINCE). Setting his quota to -1"
            fi

            ## Set limit to -1 which will cause him to pass.
            LIMIT="-1"

          ## If the user has not been gone all month.
          else

            ## If user went on vacation last month, but not this full month (yet), set difference to today date.
            DAYNOW=`$DATEBIN +%d`
            if [ "$DIFFERENCE" -gt "$DAYNOW" ]; then
              DIFFERENCE="$DAYNOW"; unset DAYNOW
            fi
            if [ "$AUTOQUOTA" = "TRUE" -a "$DEBUG" = "TRUE" ]; then
              echo "DEBUG: $USER is on vacation since $GONESINCE. Removing $DIFFERENCE days from quota."
            fi
          fi

          ## Deduct how much we should into variable LIMIT.
          DAYSOFF=$[$MONTHTOTAL-DIFFERENCE]

          PERDAY=$[$LIMIT/MONTHTOTAL]
          DEDUCT=$[$DIFFERENCE*$PERDAY]
          LIMIT=$[$LIMIT-$DEDUCT]
        else

          ## User went on vacation today. Dont set specific limit for him.
          if [ "$AUTOQUOTA" = "TRUE" ]; then
            unset LIMIT
          fi
        fi

      else
        if [ "$AUTOQUOTA" = "TRUE" ]; then
          unset LIMIT
        fi
      fi
    fi
  fi
}

## Procedure for resetting the seconds in the VACATIONDATA db.
## This is done if its the end of the month on 'dummy quota'
proc_vacationreset() {
  if [ "$VACATIONDATA" ]; then
    if [ ! -w "$VACATIONDATA" ]; then
      echo "DEBUG: Error. Cant write to $VACATIONDATA to reset vacationtimes."
    else
      for each in `cat $VACATIONDATA`; do
        username=`echo "$each" | cut -d '^' -f1`

        ## Does this user even exist anymore ?
        if [ ! -e "$USERSLOCATION/$username" ]; then
          if [ "$DEBUG" = "TRUE" ]; then
            if [ "$VACATIONRESETONLY" = "TRUE" ]; then
              echo "$username, while in $VACATIONDATA, does not exist on site anymore. Removing from DB file."
            else
              echo "DEBUG: $username, while in $VACATIONDATA, does not exist on site anymore.. Removing from DB file." >> $TMP/quota_exclude.tmp
            fi
          fi
        else
          if [ "$( grep "^GROUP $VACATIONGROUP" $USERSLOCATION/$username )" ]; then
            ## This username WAS found in the quota_vacation db.
            GOTONE="TRUE"
            echo "$each" >> $TMP/vacationdata.tmp

            if [ "$DEBUG" = "TRUE" -a "$VACATIONRESETONLY" = "TRUE" ]; then
              echo "$username, still on vacation. Keeping in $VACATIONDATA"
            fi

          else
            ## This username was NOT found in the quota_vacation db.
            if [ "$DEBUG" = "TRUE" ]; then
              if [ "$VACATIONRESETONLY" = "TRUE" ]; then
                echo "$username, while in $VACATIONDATA, is not in group $VACATIONGROUP. Removing from DB file."
              else
                echo "DEBUG: $username, while in $VACATIONDATA, is not in group $VACATIONGROUP. Removing from DB file." >> $TMP/quota_exclude.tmp
              fi
            fi
          fi      
        fi

      done

      if [ "$username" != "" -a "$GOTONE" != "TRUE" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          echo "" > $VACATIONDATA
        fi
        if [ "$DEBUG" = "TRUE" -a "$VACATIONRESETONLY" = "TRUE" ]; then
          echo "No users on vacation detected. Clearing out $VACATIONDATA"
        fi
      fi

      if [ -e "$TMP/vacationdata.tmp" ]; then
        if [ "$DEBUG" != "TRUE" ]; then
          cp -f "$TMP/vacationdata.tmp" "$VACATIONDATA"
        fi
        rm -f "$TMP/vacationdata.tmp"
      fi
    fi
  fi
}

## Running 'dummy quota'
if [ "$2" = "quota" -o "$2" = "vacationreset" ]; then
  if [ "$3" = "test" -o "$3" = "debug" ]; then
    echo "Test mode on. Setting TEST=TRUE"
    DEBUG="TRUE"
    TEST="TRUE"
  fi

  if [ -z "$NOTRIALLIMIT" ]; then
    echo "Error. Running 'dummy quota' but there is no NOTRIALLIMIT set."
    echo "If you plan on not using quota, remove 'dummy quota' from crontab."
    exit 1
  fi

  if [ "$EXCLUDEDUSERS" ]; then
    EXCLUDEDUSERS="$( echo $EXCLUDEDUSERS | tr -s ' ' '|' )"
  fi

  ## Do we want weekly or monthly trials?
  case $NOTRIALDURATION in
   W)
     DUR="WKUP"
     DURNAME="week"
     ;;
   M)
     DUR="MONTHUP"
     DURNAME="month"
     ;;
   *)
     echo "NOTRIALDURATION not set right. Either W or M"
     exit 0
     ;;
  esac
  
  if [ "$NOTRIALDURATION" = "M" ]; then
    MONTHNOW="$( $DATEBIN +%b )"
    case $MONTHNOW in
      Jan) MONTHTOTAL="31" ;;
      Feb) MONTHTOTAL="28" ;;
      Mar) MONTHTOTAL="31" ;;
      Apr) MONTHTOTAL="30" ;;
      May) MONTHTOTAL="31" ;;
      Jun) MONTHTOTAL="30" ;;
      Jul) MONTHTOTAL="31" ;;
      Aug) MONTHTOTAL="31" ;;
      Sep) MONTHTOTAL="30" ;;
      Oct) MONTHTOTAL="31" ;;
      Nov) MONTHTOTAL="30" ;;
      Dec) MONTHTOTAL="31" ;;
      *) MONTHTOTAL="31" ;;   
    esac
    
    DAYOFMONTH="$( $DATEBIN +%d )"   

    if [ "$MONTHTOTAL" != "$DAYOFMONTH" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Not the end of the month. Since this is a test I'm gonna run anyway."
      else
        exit 0
      fi
    fi
  fi
  
  if [ "$NOTRIALDURATION" = "W" ]; then
    DAYNOW="$( $DATEBIN +%w )"
    if [ "$EUROWEEK" = "FALSE" ]; then
      if [ "$DAYNOW" != "6" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the week. Since this is a test I'm gonna run anyway."
        else
          exit 0
        fi
      fi
    else
      if [ "$DAYNOW" != "0" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the week. Since this is a test I'm gonna run anyway."
        else
          exit 0
        fi
      fi
    fi
  fi
  
  if [ "$2" = "vacationreset" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "Only running the vacationreset part."
    fi
    VACATIONRESETONLY="TRUE"
    proc_vacationreset
    exit 0
  fi

  if [ "$QANNOUNCE" = "TRUE" ]; then
    if [ "$DEBUG" != "TRUE" ]; then
      echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"Quota $DURNAME has reached the end.\" >> $GLLOG
    else
      echo "Announce: Quota $DURNAME has reached the end."
    fi
  fi

  date=`$DATEBIN +%m%d`
  if [ "$DEBUG" = "TRUE" ]; then
    echo "-- Quota $DURNAME ended $date. Limit is $NOTRIALLIMIT MB / $DURNAME --"
  else
    echo "" >> $QLOGFILE
    echo "-- Quota $DURNAME ended $date. Limit is $NOTRIALLIMIT MB / $DURNAME --" >> $QLOGFILE
  fi

  if [ "$AFFILSFOLDER" ]; then
    for folder in `echo $AFFILSFOLDER`; do
      cd $folder
      for affils in `ls`; do
        GAFFILS="$affils $GAFFILS"
      done
    done
    if [ -z "$GAFFILS" ]; then
      GAFFILS="$AFFILS"
    else
      GAFFILS="$AFFILS $GAFFILS"
    fi
  else
    GAFFILS="$AFFILS"
  fi
  GAFFILS=" $GAFFILS "


  if [ -e "$TMP/quota_exclude.tmp" ]; then
    rm -f $TMP/quota_exclude.tmp
  fi
  if [ -e "$TMP/quota_finito.tmp" ]; then
    rm -f $TMP/quota_finito.tmp
  fi

  ## Making a dummy here incase EXCLUDEDUSERS is empty in conf..
  if [ -z "$EXCLUDEDUSERS" ]; then
    EXCLUDEDUSERS="KFJekFFjek38"
  fi
  
  cd $USERSLOCATION
  for user in `grep "^FLAGS " * | grep -v "default.user" | egrep -v $EXCLUDEDUSERS | cut -d ':' -f1`; do
    unset DELLED; MATCH="NOPE"; EX="NO"

    ## Group exclude ?
    for usergroup in `grep "^GROUP " $user | cut -d ' ' -f2`; do
      if [ "$( echo "$GAFFILS" | grep " $usergroup " )" ]; then       
        EX="YES"
        if [ "$DEBUG" = "TRUE" ]; then
          echo "DEBUG: Group Exclude Match for $usergroup on $user" >> $TMP/quota_exclude.tmp
        fi
        break
      fi
      ## Automatic exclude on trial groups.
      if [ "$usergroup" = "$TRIALGROUP" -o "$usergroup" = "$TRIALGROUPN" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "DEBUG: Automatic Group Exclude Match for $usergroup on $user" >> $TMP/quota_exclude.tmp
        fi
        EX="YES"
        break
      fi
    done

    ## Leech exclude ?   
    if [ "$EX" != "YES" ]; then
      if [ "$EXCLUDELEECH" = "TRUE" ]; then

        if [ "$DEBUG" = "TRUE" ]; then
          if [ "$EXCLUDESAID" != "YEPP" ]; then
            echo "DEBUG: Excluding users with leech." >> $TMP/quota_exclude.tmp
            EXCLUDESAID="YEPP"
          fi
        fi

        if [ "$( grep "^RATIO 0" $user )" ]; then
          EX="YES"
          if [ "$DEBUG" = "TRUE" ]; then
            echo "DEBUG: Leech Exclude Match for $user" >> $TMP/quota_exclude.tmp
          fi
        fi
      fi
    fi

    ## Check if the user has been on site for more then one month.
    if [ "$EX" != "YES" ]; then

      MONTHNOWCHECK=`$DATEBIN +%m"-"%y`

      MONTHADDEDMMDDYY="$( grep "^$user:" $PASSWD | cut -d ':' -f5 | cut -d '-' -f1-3 )"
      MONTHADDED=`echo "$MONTHADDEDMMDDYY" | cut -d '-' -f1,3`

      if [ "$MONTHADDED" = "$MONTHNOWCHECK" ]; then
        EX="YES"
        if [ "$DEBUG" = "TRUE" ]; then
          echo "DEBUG: Auto Excluding $user. User added this month." >> $TMP/quota_exclude.tmp
        fi
      else
        if [ "$GRACEPERIOD" ]; then

          MONTHBACKCHECK=`$DATEBIN -d "-1 month" +%m"-"%y`

          if [ "$MONTHADDED" = "$MONTHBACKCHECK" ]; then
            DAYADDED=`echo "$MONTHADDEDMMDDYY" | cut -d '-' -f2`
            if [ "$DAYADDED" -gt "$GRACEPERIOD" ]; then
              EX="YES"
              if [ "$DEBUG" = "TRUE" ]; then
                echo "DEBUG: Auto Excluding $user. User added less then one full month ago." >> $TMP/quota_exclude.tmp
              fi
            fi
          fi

        fi
      fi

#      Old System
#      if [ "$MONTHADDED" = "$MONTHNOWCHECK" ]; then
#        EX="YES"
#        if [ "$DEBUG" = "TRUE" ]; then
#          echo "DEBUG: Auto Excluding $user. User added this month." >> $TMP/quota_exclude.tmp
#        fi
#      else
        
    fi

    if [ "$EX" != "YES" ]; then
      unset MONTH; unset MONTH2; unset MONTH3; unset MONTH4; unset MONTH5
      unset MONTH6; unset MONTH7; unset MONTH8; unset MONTH9

      MONTH="$( grep "^$DUR " $user | cut -d ' ' -f3 )"

      ## Check and add the other sections to MONTH.
      MONTH2="$( grep "^$DUR " $user | cut -d ' ' -f6 )"
      if [ "$MONTH2" ]; then
        MONTH3="$( grep "^$DUR " $user | cut -d ' ' -f9 )"
        if [ "$MONTH3" ]; then
          MONTH4="$( grep "^$DUR " $user | cut -d ' ' -f12 )"
          if [ "$MONTH4" ]; then
            MONTH5="$( grep "^$DUR " $user | cut -d ' ' -f15 )"
            if [ "$MONTH5" ]; then
              MONTH6="$( grep "^$DUR " $user | cut -d ' ' -f18 )"
              if [ "$MONTH6" ]; then
                MONTH7="$( grep "^$DUR " $user | cut -d ' ' -f21 )"
                if [ "$MONTH7" ]; then
                  MONTH8="$( grep "^$DUR " $user | cut -d ' ' -f24)"
                  if [ "$MONTH8" ]; then
                    MONTH9="$( grep "^$DUR " $user | cut -d ' ' -f27 )"
                    if [ "$MONTH9" ]; then
                      if [ "$DEBUG" = "TRUE" ]; then
                        echo "DEBUG: Nine stat sections found for $user" >> $TMP/quota_exclude.tmp
                      fi
                      MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4+$MONTH5+$MONTH6+$MONTH7+$MONTH8+$MONTH9]
                    else
                      if [ "$DEBUG" = "TRUE" ]; then
                        echo "DEBUG: Eight stat sections found for $user" >> $TMP/quota_exclude.tmp
                      fi
                      MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4+$MONTH5+$MONTH6+$MONTH7+$MONTH8]
                    fi
                  else
                    if [ "$DEBUG" = "TRUE" ]; then
                      echo "DEBUG: Seven stat sections found for $user" >> $TMP/quota_exclude.tmp
                    fi
                    MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4+$MONTH5+$MONTH6+$MONTH7]
                  fi
                else
                  if [ "$DEBUG" = "TRUE" ]; then
                    echo "DEBUG: Six stat sections found for $user" >> $TMP/quota_exclude.tmp
                  fi
                  MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4+$MONTH5+$MONTH6]
                fi
              else
                if [ "$DEBUG" = "TRUE" ]; then
                  echo "DEBUG: Five stat sections found for $user" >> $TMP/quota_exclude.tmp
                fi
                MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4+$MONTH5]
              fi
            else
              if [ "$DEBUG" = "TRUE" ]; then
                echo "DEBUG: Four stat sections found for $user" >> $TMP/quota_exclude.tmp
              fi
              MONTH=$[$MONTH+$MONTH2+$MONTH3+$MONTH4]
            fi
          else
            if [ "$DEBUG" = "TRUE" ]; then
              echo "DEBUG: Three stat sections found for $user" >> $TMP/quota_exclude.tmp
            fi
            MONTH=$[$MONTH+$MONTH2+$MONTH3]
          fi
        else
          if [ "$DEBUG" = "TRUE" ]; then
            echo "DEBUG: Two stat sections found for $user" >> $TMP/quota_exclude.tmp
          fi
          MONTH=$[$MONTH+$MONTH2]
        fi
        NADA="Yepp"
      else
        if [ "$DEBUG" = "TRUE" ]; then
          echo "DEBUG: One stat section found for $user" >> $TMP/quota_exclude.tmp
        fi        
      fi
    fi

    if [ "$EX" != "YES" ]; then

      AUTOQUOTA=TRUE

      #--[ VACATION SETTINGS ]--#
      if [ "$VACATIONDATA" ]; then
        USER=$user
        proc_vacation
        if [ "$LIMIT" ]; then
          OLDNOTRIALLIMIT="$NOTRIALLIMIT"
          NOTRIALLIMIT="$LIMIT"
        fi
        unset USER
      fi
      #--[ END VACATION SETTINGS ]--#

      ## Grab users primary group.
      GROUP=`grep "^GROUP " $user | head -n1 | cut -d ' ' -f2`
      if [ -z "$GROUP" ]; then
        GROUP="NoGroup"
      fi

      MONTHUP="$( expr $MONTH \/ 1024 )"
      if [ "$MONTHUP" -ge "$NOTRIALLIMIT" -o "$NOTRIALLIMIT" = "-1" ]; then
        echo "$user - $MONTHUP MB - $GROUP - Safe ($NOTRIALLIMIT)" >> $TMP/quota_finito.tmp
      else
        if [ "$MONTH" -lt "1024" ]; then
           MSG="Idle? (MustUp:$NOTRIALLIMIT)"
        else
           MSG="Below limit ($NOTRIALLIMIT)"
        fi

        ## FLAGDEL is TRUE. Lets put some 6 flags on users.
        if [ "$FLAGDEL" = "TRUE" ]; then
          FLAGS="$( grep "^FLAGS " $user | cut -d ' ' -f2 )"

          if [ "$( echo $FLAGS | grep 6 )" ]; then
            DELLED="YES"
            if [ "$DEBUG" = "TRUE" ]; then
              echo "DEBUG: $user - $MONTHUP MB - $GROUP - $MSG . Already delled though." >> $TMP/quota_exclude.tmp
            fi
          fi

          if [ "$DELLED" != "YES" ]; then
            if [ "$TEST" != "TRUE" ]; then
              sed -e "s/^FLAGS $FLAGS.*/FLAGS "$FLAGS"6/" $USERSLOCATION/$user > $TMP/$USER.TMP
              cp -f $TMP/$USER.TMP $USERSLOCATION/$user
              rm -f $TMP/$USER.TMP
            else
              if [ "$DEBUG" = "TRUE" ]; then
                if [ "$YESYES" != "TRUE" ]; then
                  echo "DEBUG: Test mode activated. No users actually delled." >> $TMP/quota_exclude.tmp
                  YESYES="TRUE"
                fi
              fi
            fi
            FLAGSAFTER="$( grep "^FLAGS " $user | cut -d ' ' -f2 )"
            echo "$user - $MONTHUP MB - $GROUP - $MSG - Putting flag 6 on him!" >> $TMP/quota_finito.tmp
          fi
        else
          ## FLAGDEL isnt TRUE. Lets see..
          FLAGS="$( grep "^FLAGS " $user | cut -d ' ' -f2 )"
          CHECK="$( echo $FLAGS | grep 6 )"
          if [ "$CHECK" != "" -a "$FLAGDEL" != "TESTING" ]; then
            DELLED="YES"
            if [ "$DEBUG" = "TRUE" ]; then
              echo "$user - $MONTHUP MB - $GROUP - $MSG , but hes already delled. Not touching." >> $TMP/quota_exclude.tmp
            fi
          else
            if [ "$ADDTOGROUP" ]; then
              if [ "$DEBUG" != "TRUE" ]; then
                echo "GROUP $ADDTOGROUP" >> $user
                echo "$user - $MONTHUP MB - $GROUP - $MSG - Adding to group $ADDTOGROUP" >> $TMP/quota_finito.tmp
              else
                echo "$user - $MONTHUP MB - $GROUP - $MSG - Adding to group $ADDTOGROUP (test)" >> $TMP/quota_finito.tmp
              fi
            else
              echo "$user - $MONTHUP MB - $GROUP - $MSG" >> $TMP/quota_finito.tmp
            fi
            if [ "$SETCREDS" ]; then
              PREVIOUSCREDS="`grep "^CREDITS " "$USERSLOCATION/$user" | cut -d ' ' -f2`"
              if [ "$SETCREDS" -lt "$PREVIOUSCREDS" ]; then
                PREVIOUSCREDSMB=$[$PREVIOUSCREDS/1024]
                if [ "$DEBUG" != "TRUE" ]; then
                  echo "$user - Credits changed to $SETCREDS - Previous value was $PREVIOUSCREDS ( $PREVIOUSCREDSMB MB )." >> $TMP/quota_finito.tmp
                  sed -e "s/^CREDITS [0-9]* /CREDITS $SETCREDS /" $USERSLOCATION/$user > $TMP/$USER.TMP2
                  cp -f $TMP/$USER.TMP2 $USERSLOCATION/$user
                  rm -f $TMP/$USER.TMP2
                else
                  echo "$user - Setting credits to $SETCREDS - Previous value was $PREVIOUSCREDS ( $PREVIOUSCREDSMB MB ) (test)" >> $TMP/quota_finito.tmp
                fi
              else
                if [ "$DEBUG" = "TRUE" ]; then
                  echo "$user - Not touching credits. Only has $PREVIOUSCREDS so no point in setting it to $SETCREDS" >> $TMP/quota_finito.tmp
                fi
              fi
            fi
          fi
        fi

        if [ "$QANNOUNCE" = "TRUE" -a "$DELLED" != "YES" ]; then
          if [ -z "$failedusers" ]; then
            failedusers="$user/$MONTHUP"
          else
            failedusers="$user/$MONTHUP -=- $failedusers"
          fi
        fi
      fi

      #--[ VACATION SETTINGS ]--#
      if [ "$VACATIONDATA" ]; then
        if [ "$LIMIT" -a "$OLDNOTRIALLIMIT" ]; then
          NOTRIALLIMIT="$OLDNOTRIALLIMIT"
          unset LIMIT; unset OLDNOTRIALLIMIT
        fi
      fi
      #--[ END VACATION SETTINGS ]--#

    fi ## End of "not excluded part"...

  done

  if [ "$VACATIONDATA" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "DEBUG: Checking if anyone should be delled from $VACATIONDATA (test)" >> $TMP/quota_exclude.tmp
    else
      proc_vacationreset
    fi
  fi

  if [ -e "$TMP/quota_exclude.tmp" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      cat $TMP/quota_exclude.tmp | sort
    else
      cat $TMP/quota_exclude.tmp | sort >> $QLOGFILE
    fi
 
  fi
  if [ -e "$TMP/quota_finito.tmp" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      cat $TMP/quota_finito.tmp 
#| sort -k3 -n -r
    else
      cat $TMP/quota_finito.tmp >> $QLOGFILE
    fi
  fi
  if [ "$QANNOUNCE" = "TRUE" ]; then
    if [ "$DEBUG" != "TRUE" ]; then
      if [ "$ADDTOGROUP" != "" -a "$FLAGDEL" = "FALSE" ]; then
        echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"Failed users added to group $ADDTOGROUP: $failedusers\" >> $GLLOG
      else
        echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"Failed users: $failedusers\" >> $GLLOG
      fi
    else
      if [ "$ADDTOGROUP" != "" -a "$FLAGDEL" = "FALSE" ]; then
        echo "--------------------------------------------------"
        echo "Announce: Failed users added to group $ADDTOGROUP: $failedusers"
      else
        echo "--------------------------------------------------"
        echo "Announce: Failed users: $failedusers"
      fi
    fi
  fi

exit 0 ## Exist "dummy quota" part.
fi

## Executed with 'dummy triallist'
if [ "$2" = "triallist" ]; then
  if [ "$3" = "test" ]; then
    echo "Test mode on. Setting AUTOCHANGE=FALSE and DELFAIL=FALSE"
    DEBUG="TRUE"
    AUTOCHANGE="FALSE"
    DELFAIL="FALSE"
  fi

  if [ "$DISABLETRIAL" = "TRUE" ]; then
    echo "Error. Cant run 'dummy triallist' if DISABLETRIAL is TRUE"
    exit 1
  fi
  if [ -z "$LIMIT" ]; then
    echo "Error. Cant run 'dummy triallist' if LIMIT is not set."
    exit 1
  fi

  ## Do we want weekly or monthly trials?
  case $DURATION in
   W)
     DUR="WKUP"
     DURNAME="week"
     ;;
   M)
     DUR="MONTHUP"
     DURNAME="month"
     ;;
   *)
     echo "Duration not set right. Either W or M"
     exit 0
     ;;
  esac
  
  if [ "$DURATION" = "M" ]; then
    MONTHNOW="$( $DATEBIN +%b )"
    case $MONTHNOW in
      Jan) MONTHTOTAL="31" ;;
      Feb) MONTHTOTAL="28" ;;
      Mar) MONTHTOTAL="31" ;;
      Apr) MONTHTOTAL="30" ;;
      May) MONTHTOTAL="31" ;;
      Jun) MONTHTOTAL="30" ;;
      Jul) MONTHTOTAL="31" ;;
      Aug) MONTHTOTAL="31" ;;
      Sep) MONTHTOTAL="30" ;;
      Oct) MONTHTOTAL="31" ;;
      Nov) MONTHTOTAL="30" ;;
      Dec) MONTHTOTAL="31" ;;
      *) MONTHTOTAL="31" ;;   
    esac
    
    DAYOFMONTH="$( $DATEBIN +%d )"   
    if [ "$MONTHTOTAL" != "$DAYOFMONTH" ]; then
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Not the end of the month. Test mode, so running anyway."
      else
        exit 0
      fi
    fi
  fi
  
  if [ "$DURATION" = "W" ]; then
    DAYNOW="$( $DATEBIN +%w )"
    if [ "$EUROWEEK" = "FALSE" ]; then
      if [ "$DAYNOW" != "6" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the month. Test mode, so running anyway."
        else
          exit 0
        fi
      fi
    else
      if [ "$DAYNOW" != "0" ]; then
        if [ "$DEBUG" = "TRUE" ]; then
          echo "Not the end of the month. Test mode, so running anyway."
        else
          exit 0
        fi
      fi
    fi
  fi

  if [ "$ANNOUNCE" = "TRUE" ]; then
    if [ "$DEBUG" != "TRUE" ]; then
      echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"Trial $DURNAME has reached the end.\" >> $GLLOG
    else
      echo "Announce: Trial $DURNAME has reached the end."
    fi
  fi

  cd $USERSLOCATION
  for user in `grep -i "^GROUP $TRIALGROUP" * | grep -v "default.user" | cut -d ':' -f1`; do
    unset UP; unset UP2; unset UP3; unset UP4; unset UP5; unset UP6; unset UP7; unset UP8; unset UP9  

    group="$( grep "^GROUP $TRIALGROUP" $user | cut -d ' ' -f2 )"

    UP="$( grep "^$DUR " $user | cut -d ' ' -f3 )"
    ## Check for other stat sections.
    UP2="$( grep "^$DUR " $user | cut -d ' ' -f6 )"
    if [ "$UP2" ]; then
      UP3="$(grep "^$DUR " $user | cut -d ' ' -f9 )"
      if [ "$UP3" ]; then
        UP4="$(grep "^$DUR " $user | cut -d ' ' -f12 )"
        if [ "$UP4" ]; then
          UP5="$(grep "^$DUR " $user | cut -d ' ' -f15 )"
          if [ "$UP5" ]; then
            UP6="$(grep "^$DUR " $user | cut -d ' ' -f18 )"
            if [ "$UP6" ]; then
              UP7="$(grep "^$DUR " $user | cut -d ' ' -f21 )"
              if [ "$UP7" ]; then
                UP8="$(grep "^$DUR " $user | cut -d ' ' -f24 )"
                if [ "$UP8" ]; then
                  UP9="$(grep "^$DUR " $user | cut -d ' ' -f27 )"
                  if [ "$UP9" ]; then
                    UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7+$UP8+$UP9]
                  else
                    UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7+$UP8]
                  fi
                else
                  UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7]
                fi
              else
                UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6]
              fi
            else
              UP=$[$UP+$UP2+$UP3+$UP4+$UP5]
            fi
          else
            UP=$[$UP+$UP2+$UP3+$UP4]
          fi
        else
          UP=$[$UP+$UP2+$UP3]
        fi
      else
        UP=$[$UP+$UP2]
      fi
    fi
    UP=$[$UP/1024]

    if [ "$UP" -ge "$LIMIT" ]; then
      ## User passed trial.
      if [ "$group" = "$TRIALGROUP" ]; then
        ## User is in the TRiAL group.
        if [ "$AUTOCHANGE" = "TRUE" ]; then
          grep -v "GROUP $TRIALGROUP" $user > $TMP/$user.new
          cp -f $TMP/$user.new $user
          rm -f $TMP/$user.new
          INOTHERGROUP="$( grep "^GROUP " $user )"
          if [ -z "$INOTHERGROUP" ]; then
            echo "GROUP $PASSGROUP" >> $user
          fi
          echo "$user / $group Passed with: $UP"MB"/$LIMIT - Changing group to $PASSGROUP" >> $TMP/trial.tmp
        else
          echo "$user / $group Passed with: $UP"MB"/$LIMIT - No automatic action taken." >> $TMP/trial.tmp
        fi
        if [ "$ANNOUNCE" = "TRUE" ]; then
          if [ "$DEBUG" != "TRUE" ]; then
            echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Congratulations on passing with $UP MB. Well done.\" >> $GLLOG
          else
            echo "Announce: $user - Congratulations on passing with $UP MB. Well done."
          fi
        fi
      else
        ## User is in the TRiAL-2 group.
        if [ "$AUTOCHANGE" = "TRUE" ]; then
          grep -v "^GROUP $TRIALGROUPN" $user > $TMP/$user.new
          cp -f $TMP/$user.new $user
          rm -f $TMP/$user.new
          if [ "$PASSEARLY" = "TRUE" ]; then
            INOTHERGROUP="$( grep "^GROUP " $user )"
            if [ -z "$INOTHERGROUP" ]; then
              echo "GROUP $PASSGROUP" >> $user
              echo "$user / $group Passed with: $UP"MB"/$LIMIT - PASSEARLY kicked in. Changing group to $PASSGROUP" >> $TMP/trial-2.tmp
            else
              echo "$user / $group Passed with: $UP"MB"/$LIMIT - PASSEARLY kicked in. Just removing from $TRIALGROUPN" >> $TMP/trial-2.tmp
            fi
            if [ "$ANNOUNCE" = "TRUE" ]; then
              if [ "$DEBUG" != "TRUE" ]; then
                echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Congratulations on passing early with $UP MB. Well done.\" >> $GLLOG
              else
                echo "Announce: $user - Congratulations on passing early with $UP MB. Well done."
              fi
            fi
          else
            echo "GROUP $TRIALGROUP" >> $user
            if [ "$ANNOUNCE" = "TRUE" ]; then
              if [ "$DEBUG" != "TRUE" ]; then
                echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Trial starts NOW. Gogogo.\" >> $GLLOG
              else
                echo "Announce: $user - Trial starts NOW. Gogogo."
              fi
            fi
            echo "$user / $group Passed with: $UP"MB"/$LIMIT - Changing group to $TRIALGROUP" >> $TMP/trial-2.tmp
          fi
        else
          if [ "$ANNOUNCE" = "TRUE" ]; then
            if [ "$DEBUG" != "TRUE" ]; then
              echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Congratulations on passing with $UP MB. Well done.\" >> $GLLOG
            else
              echo "Announce: $user - Congratulations on passing with $UP MB. Well done."
            fi
          fi
          echo "$user / $group Passed with: $UP"MB"/$LIMIT - No automatic action taken." >> $TMP/trial-2.tmp
        fi
      fi
###############################

    else
      ## User FAILED trial.
      if [ "$group" = "$TRIALGROUP" ]; then
        ## User is in the TRiAL group.
        if [ "$AUTOCHANGE" = "TRUE" ]; then
          if [ "$DELFAIL" = "TRUE" ]; then
            FLAGS="$( grep "^FLAGS " $user | cut -d ' ' -f2 )"
            CHECK="$( echo $FLAGS | grep 6 )"
            if [ "$CHECK" ]; then
              unset CHECK
              if [ "$ANNOUNCE" = "TRUE" ]; then
                if [ "$DEBUG" =! "TRUE" ]; then
                  echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Failed with $UP MB. He/She already delled though, tihi.\" >> $GLLOG
                else
                  echo "Announce: $user - Failed with $UP MB. He/She already delled though, tihi."
                fi
              fi
              echo "$user / $group Failed with: $UP"MB"/$LIMIT - User already deleted." >> $TMP/trial.tmp
            else
              sed -e "s/^FLAGS $FLAGS.*/FLAGS "$FLAGS"6/" $user > $TMP/$user.new
              cp -f $TMP/$user.new $user
              rm -f $TMP/$user.new
              if [ "$ANNOUNCE" = "TRUE" ]; then
                if [ "$DEBUG" != "TRUE" ]; then
                  echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Failed with $UP MB. Better luck next time, poof.\" >> $GLLOG
                else
                  echo "Announce: $user - Failed with $UP MB. Better luck next time, poof."
                fi
              fi
              echo "$user / $group Failed with: $UP"MB"/$LIMIT - Deleting user." >> $TMP/trial.tmp
            fi

            grep -v "^GROUP $TRIALGROUP" $user > $TMP/$user.new
            cp -f $TMP/$user.new $user
            rm -f $TMP/$user.new
          else
            grep -v "^GROUP $TRIALGROUP" $user > $TMP/$user.new
            cp -f $TMP/$user.new $user
            rm -f $TMP/$user.new
            echo "GROUP $FAILGROUP" >> $user
            if [ "$ANNOUNCE" = "TRUE" ]; then
              if [ "$DEBUG" != "TRUE" ]; then
                echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Failed with $UP MB. Better luck next time.\" >> $GLLOG
              else
                echo "Announce: $user - Failed with $UP MB. Better luck next time."
              fi
            fi
            echo "$user / $group Failed with: $UP"MB" - Changing group to $FAILGROUP" >> $TMP/trial.tmp
          fi
        else
          if [ "$ANNOUNCE" = "TRUE" ]; then
            if [ "$DEBUG" != "TRUE" ]; then
              echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Failed with $UP MB.\" >> $GLLOG
            else
              echo "Announce: $user - Failed with $UP MB."
            fi
          fi
          echo "$user / $group Failed with: $UP"MB"/$LIMIT - No automatic action taken." >> $TMP/trial.tmp
        fi
      else
        ## User is in the TRiAL-2 group.
        if [ "$AUTOCHANGE" = "TRUE" ]; then
          grep -v "^GROUP $TRIALGROUPN" $user > $TMP/$user.new
          cp -f $TMP/$user.new $user
          rm -f $TMP/$user.new
          echo "GROUP $TRIALGROUP" >> $user
          echo "$user / $group Failed with: $UP"MB"/$LIMIT - Changing group to $TRIALGROUP" >> $TMP/trial-2.tmp
        else
          echo "$user / $group Failed with: $UP"MB"/$LIMIT - No automatic action taken." >> $TMP/trial-2.tmp
        fi
        if [ "$ANNOUNCE" = "TRUE" ]; then
          if [ "$DEBUG" != "TRUE" ]; then
            echo `$DATEBIN "+%a %b %e %T %Y"` TURTRIAL: \"$user - Your trial starts NOW. Good luck.\" >> $GLLOG
          else
            echo "Announce: $user - Your trial starts NOW. Good luck."
          fi
        fi
      fi
    fi

    # Make sure the user is in correct group in passwd.
    groupnow=`grep "^GROUP " $user | head -n1 | cut -d ' ' -f2`
    gidinpasswd=`grep "^$user:" $PASSWD | cut -d ':' -f4`
    groupfile=`dirname $PASSWD`
    if [ -e "$groupfile" ]; then
      gidingroup=`grep "^$groupnow:" $groupfile/group | cut -d ':' -f3`
      if [ "$gidinpasswd" != "$gidingroup" ]; then
        rawdata=`grep "^$user:" $PASSWD`
        if [ "$rawdata" ]; then
          pass=`echo "$rawdata" | cut -d ':' -f2`
          uid=`echo "$rawdata" | cut -d ':' -f3`
          pregid=`echo "$rawdata" | cut -d ':' -f4`
          dateadded=`echo "$rawdata" | cut -d ':' -f5`
          homedir=`echo "$rawdata" | cut -d ':' -f6`
          crap=`echo "$rawdata" | cut -d ':' -f7`
          if [ "$DEBUG" != "TRUE" ]; then
            grep -v "$rawdata" $PASSWD > /tmp/passwd.tmp
            cp -f /tmp/passwd.tmp $PASSWD
            echo "$user:$pass:$uid:$gidingroup:$dateadded:$homedir:$crap" >> $PASSWD
          else
            echo "Warning: $user primary group: $groupnow, has gid: $gidingroup, but $user is set to $gidinpasswd in $PASSWD."
            echo "         Had this been a live run, I would have fixed that like this:"
            echo "         Old: $rawdata"
            echo "         New: $user:$pass:$uid:$gidingroup:$dateadded:$homedir:$crap"
          fi
        else
          echo "Warning: Could not grep the userinfo from $PASSWD. Checked for: ^$user:"
        fi
      fi
    else
      if [ "$DEBUG" = "TRUE" ]; then
        echo "Warning: group file does not exist in same dir as $PASSWD. Checked in $groupfile"
      fi
    fi

  done

  date=`$DATEBIN +%m%d`
  if [ -e "$TMP/trial.tmp" -o -e "$TMP/trial-2.tmp" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "-- Trial $DURNAME ended $date. Limit is $LIMIT MB / $DURNAME --"
    else
      echo "" >> $LOGFILE
      echo "-- Trial $DURNAME ended $date. Limit is $LIMIT MB / $DURNAME --" >> $LOGFILE
    fi
  fi

  if [ -e $TMP/trial.tmp ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "-- This $DURNAME trials:"
      cat "$TMP/trial.tmp" | sort
      rm -f "$TMP/trial.tmp"
    else
      echo "-- This $DURNAME trials:" >> $LOGFILE
      cat "$TMP/trial.tmp" | sort >> $LOGFILE
      rm -f "$TMP/trial.tmp"
    fi
  fi
  if [ -e $TMP/trial-2.tmp ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "-- Next $DURNAME trials:"
      cat "$TMP/trial-2.tmp" | sort
      rm -f "$TMP/trial-2.tmp"
    else
      echo "-- Next $DURNAME trials:" >> $LOGFILE
      cat "$TMP/trial-2.tmp" | sort >> $LOGFILE
      rm -f "$TMP/trial-2.tmp"
    fi
  fi

  if [ -z "$user" ]; then
    if [ "$DEBUG" = "TRUE" ]; then
      echo "No user on trial as far as I can see."
    fi
  fi

  exit 0
fi

## If no argument is given after trigger:
if [ "$1" = "" ]; then
  echo "$SITENAME Specify a user to check too."
  exit 0
fi

if [ "$1" = "--status" ]; then
  echo "Tur-Trial $VER by Turranius"
  exit 0
fi

## Check if the user really exists.
if [ ! -e $USERSLOCATION/$1 ]; then
  OUTPUT="$NOTEXISTS"
  proc_cookies
  echo $OUTPUT
  exit 0
fi

if [ "$DISABLETRIAL" = "TRUE" ]; then
  if [ ! -z "$( grep "^GROUP $TRIALGROUP" $USERSLOCATION/$1 )" ]; then echo "$DISTEXT"; exit 0; fi
fi

## Check if the user is delled!
FLAGS="$( grep "^FLAGS " $USERSLOCATION/$1 | cut -d ' ' -f2 )"
if [ "$( echo $FLAGS | grep "6" )" ]; then
  if [ "$DELETEDTEXT" ]; then
    echo "$DELETEDTEXT"
  fi
  exit 0
fi

## Check if the group is TRiAL on the user specified.
GROUP="$(grep "^GROUP $TRIALGROUP" $USERSLOCATION/$1 | grep -iv "^GROUP $TRIALGROUPN")"
  if [ "$GROUP" ]; then
    WHEN="NOW"
  fi

## If he wasnt, check if its TRiAL-2 for next trial period.
if [ -z "$WHEN" ]; then
  GROUP="$( grep "^GROUP $TRIALGROUPN" $USERSLOCATION/$1 )"
  if [ "$GROUP" ]; then
    WHEN="NEXT"
  else
    # not on trial
    WHEN="NOT"
    if [ "$NOTRIALLIMIT" ]; then
      LIMIT="$NOTRIALLIMIT"
      DURATION="$NOTRIALDURATION"
    else
      QUOTA=DISABLED
    fi
  fi
fi

## Do we want weekly or monthly trials?
case $DURATION in
 W) 
   DUR="WKUP"
   DURNAME="week"
   ;;
 M)
   DUR="MONTHUP"
   DURNAME="month"
   ;;
 *)
   echo "Duration not set right. Either W or M"
   exit 0
   ;;
esac

## Check vacation settings..
proc_vacation

## Check position!
proc_getpos


## How much did the user upload this period? 
UP="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f3 )"
if [ -z "$UP" ]; then
  UP="0"
fi

## Check for other stat sections.
UP2="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f6 )"
if [ "$UP2" ]; then
  UP3="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f9 )"
  if [ "$UP3" ]; then
    UP4="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f12 )"
    if [ "$UP4" ]; then
      UP5="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f15 )"
      if [ "$UP5" ]; then
        UP6="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f18 )"
        if [ "$UP6" ]; then
          UP7="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f21 )"
          if [ "$UP7" ]; then
            UP8="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f24 )"
            if [ "$UP8" ]; then
              UP9="$( grep "^$DUR " $USERSLOCATION/$1 | cut -d ' ' -f27 )"
              if [ "$UP9" ]; then
                UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7+$UP8+$UP9]
              else
                UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7+$UP8]
              fi
            else
              UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6+$UP7]
            fi
          else
            UP=$[$UP+$UP2+$UP3+$UP4+$UP5+$UP6]
          fi
        else
          UP=$[$UP+$UP2+$UP3+$UP4+$UP5]
        fi
      else
        UP=$[$UP+$UP2+$UP3+$UP4]
      fi
    else
      UP=$[$UP+$UP2+$UP3]
    fi
  else
    UP=$[$UP+$UP2]
  fi
fi

## Split the uploaded number with 1024 to get MB.
UP=$[$UP/1024]

## Is the user over the limit?
if [ "$UP" -ge "$LIMIT" ]; then
  PASSED="YES"
else
  PASSED="NO"
fi

## Calculate how much under or over the limit the user is.
RATIO=$[$UP-$LIMIT]

## If the number is negative, remove the - 
RATIO="$( echo $RATIO | tr -d "-" )"

if [ "$DURATION" = "M" ]; then
  MONTHNOW="$( $DATEBIN +%b )"
  case $MONTHNOW in
    Jan) MONTHTOTAL="31" ;;
    Feb) MONTHTOTAL="28" ;;
    Mar) MONTHTOTAL="31" ;;
    Apr) MONTHTOTAL="30" ;;
    May) MONTHTOTAL="31" ;;
    Jun) MONTHTOTAL="30" ;;
    Jul) MONTHTOTAL="31" ;;
    Aug) MONTHTOTAL="31" ;;
    Sep) MONTHTOTAL="30" ;;
    Oct) MONTHTOTAL="31" ;;
    Nov) MONTHTOTAL="30" ;;
    Dec) MONTHTOTAL="31" ;;
    *) MONTHTOTAL="31" ;;   
  esac

  DAYNOW="$( $DATEBIN +%d )"
  if [ "$MONTHTOTAL" = "$DAYNOW" ]; then
    DURATION="W"
    MONTHMOVE="TRUE"
  else
    DAYSLEFT="$( expr $MONTHTOTAL \- $DAYNOW )"
    if [ "$DAYNOW" = "01" ]; then
      DAY="the whole month"
    else
      if [ "$DAYSLEFT" = "1" ]; then
        DAY="$DAYSLEFT day"
      else
        DAY="$DAYSLEFT days"
      fi
    fi
    PERDAY=$[$RATIO/$DAYSLEFT]
    PERDAYNAME="day" 
  fi
fi

if [ "$DURATION" = "W" ]; then
  DAYNOW="$( $DATEBIN +%w )"
  if [ "$EUROWEEK" = "FALSE" ]; then
    case $DAYNOW in
      0) DAY="7 days"
         SPLIT="7" ;;
      1) DAY="6 days"
         SPLIT="6" ;;
      2) DAY="5 days"
         SPLIT="5" ;;
      3) DAY="4 days"
         SPLIT="4" ;;
      4) DAY="3 days"
         SPLIT="3" ;;
      5) DAY="2 days"
         SPLIT="2" ;;
      6) DAY="1 day"
         SPLIT="1" ;;
      *) DAY="-Hell if I know what day it is-"
         SPLIT="1" ;;
    esac
  else
    case $DAYNOW in
      1) DAY="7 days"
         SPLIT="7" ;;
      2) DAY="6 days"
         SPLIT="6" ;;
      3) DAY="5 days"
         SPLIT="5" ;;
      4) DAY="4 days"
         SPLIT="4" ;;
      5) DAY="3 days"
         SPLIT="3" ;;
      6) DAY="2 days"
         SPLIT="2" ;;
      0) DAY="1 day"
         SPLIT="1" ;;
      *) DAY="-Hell if I know what day it is-"
         SPLIT="1" ;;
    esac
  fi

  if [ "$SPLIT" = "1" -o "$MONTHMOVE" = "TRUE" ]; then
    HOURNOW="$( $DATEBIN +%k )"
    HLEFT=$[24-$HOURNOW]
    if [ "$HLEFT" = "1" ]; then
      MINUTENOW="$( $DATEBIN +%M )"
      MINLEFT=$[60-$MINUTENOW]
      if [ "$MINLEFT" = "1" ]; then
        DAY="$MINLEFT minute"
      else
        DAY="$MINLEFT minutes"
      fi
      PERDAY=$[$RATIO/$MINLEFT]
      PERDAYNAME="minute" 
    else
      DAY="$HLEFT hours"
      PERDAY=$[$RATIO/$HLEFT]
      PERDAYNAME="hour" 
    fi
  else
    PERDAY=$[$RATIO/$SPLIT]
    PERDAYNAME="day" 
  fi
fi

if [ "$WHEN" = "NOT" -a "$NOTRIALLIMIT" != "" ]; then
  if [ "$AFFILSFOLDER" != "" ]; then
    for folder in `echo $AFFILSFOLDER`; do
      cd $folder
      for affils in `ls`; do
        GAFFILS="$affils $GAFFILS"
      done
    done
    if [ -z "$GAFFILS" ]; then
      GAFFILS="$AFFILS"
    else
      GAFFILS="$AFFILS $GAFFILS"
    fi
  else
    GAFFILS="$AFFILS"
  fi
  GAFFILS=" $GAFFILS "

  unset VERIFY
  for g in `grep "^GROUP " $USERSLOCATION/$1 | cut -d ' ' -f2`; do

    ## Get primary group
    if [ -z "$MAINGROUP" ]; then
      MAINGROUP=`echo "$g" | cut -d ' ' -f2`
    fi

    if [ "$EXCLUDED" != "YES" ]; then
      VERIFY="$( echo "$GAFFILS" | grep " $g " )"
      if [ "$VERIFY" ]; then
        EG="$g"
        EXCLUDED="YES"
      fi
    fi
  done
  ## Set primary group to NoGroup if none was found.
  if [ -z "$MAINGROUP" ]; then
    MAINGROUP="NoGroup"
  fi

  if [ "$DURNAME" = "month" ]; then
    if [ "$EXCLUDED" != "YES" ]; then
      ## Check if the user has been on site for more then one month.

      MONTHNOWCHECK=`$DATEBIN +%m"-"%y`

      MONTHADDEDMMDDYY="$( grep "^$1:" $PASSWD | cut -d ':' -f5 | cut -d '-' -f1-3 )"
      MONTHADDED=`echo "$MONTHADDEDMMDDYY" | cut -d '-' -f1,3`

      if [ "$MONTHADDED" = "$MONTHNOWCHECK" ]; then
        EXCLUDED="YES"
        NOTONLONGENOUGH="TRUE"
      else
        if [ "$GRACEPERIOD" ]; then
          MONTHBACKCHECK=`$DATEBIN -d "-1 month" +%m"-"%y`

          if [ "$MONTHADDED" = "$MONTHBACKCHECK" ]; then
            DAYADDED=`echo "$MONTHADDEDMMDDYY" | cut -d '-' -f2`
            if [ "$DAYADDED" -gt "$GRACEPERIOD" ]; then
              EXCLUDED="YES"
              NOTONLONGENOUGH="TRUE"
            fi
          fi

        fi
      fi

#      Old system
#      MONTHNOW="$( $DATEBIN +%m"-"%y )"
#      MONTHADDED="$( grep "^$1:" $PASSWD | cut -d ':' -f5 | cut -d '-' -f1,3 )"
#      if [ "$MONTHADDED" = "$MONTHNOW" ]; then
#        EXCLUDED="YES"
#        NOTONLONGENOUGH="TRUE"
#      fi

    fi
  fi

fi

## Is the user excluded?
EXCLUDED2="$( echo "$EXCLUDE" | grep -w $1 )"
if [ "$EXCLUDED2" ]; then
  if [ -z "$EXCLUDEDTEXT" ]; then
    if [ -z "$CUSTOMSET" ]; then
      exit 0
    fi
  else
    if [ -z "$CUSTOMSET" ]; then
      echo "$SITENAME $EXCLUDEDTEXT"
      exit 0
    fi
  fi
fi  

SHOWL="$LIMIT"

if [ -z "$g" ]; then
  g="NoGroup"
fi

listnr="0"

proc_fetchtext() {
  TMPARG="$( grep -F "$USETEXT[$listnr]" $config | head -n 1)"
  hituser="$( echo $TMPARG | cut -d':' -f1 | cut -d'"' -f2 )"
  msg2="$( echo $TMPARG | cut -d':' -f2- | tr -d '"' )"

  if [ "$hituser" = "" -o "$msg2" = "" ]; then
    echo "Error with config "$USETEXT[$listnr]" - No user or text. Result was: USER=$hituser - TEXT=$msg2"
    exit 0
  fi

  if [ "$( echo "$hituser" | cut -c1 )" = "=" ]; then
    hitgroup="$( echo $hituser | cut -c2- )"
    for searchgroup in `grep "^GROUP " $USERSLOCATION/$USER | cut -d' ' -f2`; do
      if [ "$searchgroup" = "$hitgroup" ]; then
        OUTPUT="$msg2"
      fi
    done
  else
    if [ "$hituser" = "$USER" ]; then
      OUTPUT="$msg2"
    fi
  fi
  listnr="$( expr $listnr \+ 1 )"
  unset TMPARG
}

if [ "$WHEN" != "NOT" -o "$NOTRIALLIMIT" = "" ]; then
  ## Say what we want to say, depending on if the user passed the limit or not, for users in TRiAL or TRiAL-2
  case $PASSED in
    YES)
      if [ "$WHEN" = "NOT" ]; then

        ## Custom text for user who passed trial limit but isnt on trial. 
        USETEXT="C_PASSED_NOTRIAL"
        while [ "$C_PASSED_NOTRIALTOT" != "$listnr" ]; do
          proc_fetchtext
        done
        if [ -z "$OUTPUT" ]; then
          ## No custom text found. Using standard output.
          OUTPUT="$PASSED_NOTRIAL"
        fi
        proc_cookies
        echo $OUTPUT
        exit 0

      else
        if [ "$WHEN" = "NEXT" ]; then

          ## Custom text for user on trial next duration and has passed (early).
          USETEXT="C_PASSED_NEXTDUR"
          while [ "$C_PASSED_NEXTDURTOT" != "$listnr" ]; do
            proc_fetchtext
          done
          if [ -z "$OUTPUT" ]; then
            ## No custom text found. Using standard output.
            OUTPUT="$PASSED_NEXTDUR"
          fi
          proc_cookies
          echo $OUTPUT
          exit 0

        else

          ## Custom text for users whos on trial and passed.
          USETEXT="C_PASSED_TRIAL"
          while [ "$C_PASSED_TRIALTOT" != "$listnr" ]; do
            proc_fetchtext
          done
          if [ -z "$OUTPUT" ]; then
            ## No custom text found. Using standard output.
            OUTPUT="$PASSED_TRIAL"
          fi
          proc_cookies
          echo $OUTPUT   
          exit 0

        fi
      fi
      ;;
    NO)
      if [ "$WHEN" = "NOT" ]; then

        ## Custom text for user who isnt on trial and havent passed (with quota disabled).
        USETEXT="C_NOTPASSED_NOTRIAL"
        while [ "$C_NOTPASSED_NOTRIALTOT" != "$listnr" ]; do
          proc_fetchtext
        done
        if [ -z "$OUTPUT" ]; then
          ## No custom text found. Using standard output.
          OUTPUT="$NOTPASSED_NOTRIAL"
        fi
        proc_cookies
        echo $OUTPUT   
        exit 0

      else
        if [ "$WHEN" = "NEXT" ]; then

          ## Custom text for user who is on trial next duration and didnt pass yet.
          USETEXT="C_NOTPASSED_NEXTDUR"
          while [ "$C_NOTPASSED_NEXTDURTOT" != "$listnr" ]; do
            proc_fetchtext
          done
          if [ -z "$OUTPUT" ]; then
            ## No custom text found. Using standard output.
            OUTPUT="$NOTPASSED_NEXTDUR"
          fi
          proc_cookies
          echo $OUTPUT            
          exit 0

        else

          ## Custom text for user who did not pass trial.. yet
          USETEXT="C_NOTPASSED_TRIAL"
          while [ "$C_NOTPASSED_TRIALTOT" != "$listnr" ]; do
            proc_fetchtext
          done
          if [ -z "$OUTPUT" ]; then
            ## No custom text found. Using standard output.
            OUTPUT="$NOTPASSED_TRIAL"
          fi
          proc_cookies
          echo $OUTPUT   
          exit 0

        fi
      fi
      ;;
    *)
      echo "Error in script. User neither passed or failed trial."
      exit 1
      ;;
  esac
else
  ## Users on Quota.
  case $PASSED in
    YES)
      if [ "$FULLMSG" = "TRUE" ]; then
        echo "$SITENAME $MSG"
      else
        if [ "$EXCLUDED" = "YES" ]; then

          if [ "$NOTONLONGENOUGH" = "TRUE" ]; then

            ## Custom text for excluded user who havent been on long enough and passed.
            USETEXT="C_FIRST_QUOTA_PASSED"
            while [ "$C_FIRST_QUOTA_PASSEDTOT" != "$listnr" ]; do
              proc_fetchtext
            done

          else

            ## Custom text for excluded quota user who passed.
            USETEXT="C_QUOTA_EX_PASSED"
            while [ "$C_QUOTA_EX_PASSEDTOT" != "$listnr" ]; do
              proc_fetchtext
            done

          fi

          if [ -z "$OUTPUT" ]; then
            if [ "$NOTONLONGENOUGH" = "TRUE" ]; then
              ## No custom text found. Use normal output for user who havent been on long enough.
              OUTPUT="$FIRST_QUOTA_PASSED"
            else
              ## No custom text found. Use normal output for user on quota
              OUTPUT="$QUOTA_EX_PASSED"
            fi
          fi

          proc_cookies
          echo $OUTPUT
          exit 0
        else

          ## Custom text for user on quota who passed.
          USETEXT="C_QUOTA_PASSED"
          while [ "$C_QUOTA_PASSEDTOT" != "$listnr" ]; do
            proc_fetchtext
          done

          if [ -z "$OUTPUT" ]; then
            ## No custom text found. Use normal output.
            OUTPUT="$QUOTA_PASSED"
          fi

          proc_cookies
          echo $OUTPUT
          exit 0
        fi
      fi
      ;;
    NO)
      if [ "$FULLMSG" = "TRUE" ]; then
        echo "$SITENAME $MSG"
      else
        if [ "$EXCLUDED" = "YES" ]; then
          if [ "$NOTONLONGENOUGH" = "TRUE" ]; then
 
            ## Custom text for excluded quota user who havent been on site for a month yet and have not passed.
            USETEXT="C_FIRST_QUOTA_NOTPASSED"
            while [ "$C_FIRST_QUOTA_NOTPASSEDTOT" != "$listnr" ]; do
              proc_fetchtext
            done

          else

            ## Custom text for excluded quota user who have not passed.
            USETEXT="C_QUOTA_EX_NOTPASSED"
            while [ "$C_QUOTA_EX_NOTPASSEDTOT" != "$listnr" ]; do
              proc_fetchtext
            done

          fi

          if [ -z "$OUTPUT" ]; then
            if [ "$NOTONLONGENOUGH" = "TRUE" ]; then
              OUTPUT="$FIRST_QUOTA_NOTPASSED"
            else
              OUTPUT="$QUOTA_EX_NOTPASSED"
            fi
          fi

          proc_cookies
          echo $OUTPUT
          exit 0
        else

          ## Custom text for user on quota and havent passed.
          USETEXT="C_QUOTA_NOTPASSED"
          while [ "$C_QUOTA_NOTPASSEDTOT" != "$listnr" ]; do
            proc_fetchtext
          done

          if [ -z "$OUTPUT" ]; then
            ## No custom text set. Use normal output.
            OUTPUT="$QUOTA_NOTPASSED"
          fi

          proc_cookies
          echo $OUTPUT
          exit 0
        fi
      fi
      ;;
    *)
      echo "Error in script. User neither passed or failed trial."
      exit 1
      ;;
  esac
fi

exit 0
