#!/bin/bash
VER=1.0
#-------------------------------------------------------#
#                                                       #
# Tur-GoodBoy. A script to reward the top uploader with #
# temporary leech and/or flags.                         #
#                                                       #
#--[ Intro ]--------------------------------------------#
#                                                       #
# This script can check the top upload today, this week #
# or this month and reward the #1 user. You can exclude #
# certain users/groups with it as well as users with    #
# leech.                                                #
#                                                       #
# There are two kinds of rewards. Either a flag of your #
# choise (4?) and/or a leechmode flag.                  #
#                                                       #
# You may specify how long they get to keep their       #
# reward. Its either for 24 hours, regarding of which   #
# duration you are checking OR the full duration. Ie,   #
# you set it to check weekup? The winner gets to keep   #
# the reward for a week.                                #
#                                                       #
# If you select to give them leech, you may specify     #
# WHERE they get the leech. This is done with a         #
# "creditscheck" line in glftpd.conf, but more on that  #
# soon.                                                 #
#                                                       #
# To get Turranius certified, it naturally comes with   #
# an extensive 'test' mode in where it does only show   #
# you in the shell what it will do. Just execute it     #
# with 'test' (without the quotes) as argument.         #
#                                                       #
#--[ Installation ]-------------------------------------#
#                                                       #
# Copy tur-goodboy.sh to /glftpd/bin and make it        #
# executable with chmod 755 or so.                      #
#                                                       #
# If you plan to only give the winner a specific flag   #
# and NOT leech, jump down to -[ Settings ]-. You must  #
# then leave LEECHFLAG empty.                           #
# Otherwise do this as well:                            #
#                                                       #
# Now then, at first I made this script to just give    #
# the #1 user RATIO 0 for the duration. This wasnt so   #
# smart since he does not get any credits while having  #
# leech so if he didnt leech, he basically got punished #
# because he didnt get any credits when uploading.      #
#                                                       #
# Instead, we specify a flag. Something not used by     #
# glftpd by default. I have W cause that I dont use it  #
# for anything else.                                    #
#                                                       #
# Now we add a creditcheck line to glftpd.conf. In it   #
# you specify WHERE they should get leech and WHAT flag #
# you define as leechflag (later). So, edit glftpd.conf #
# and see if you have any other creditcheck lines. If   #
# you do, add the following above them. If you do not,  #
# you can add this line anywhere:                       #
#                                                       #
# creditcheck /site/Archive/* 0 W                       #
#             ^ Leech where?    ^ Flag to use.          #
#                                                       #
# The above means he gets leech in /Archive and any     #
# subdir if he has flag W.                              #
# Once added, log on to the ftp with a ratio account    #
# and give yourself the flag. cd into the defined dir   #
# and the RATIO should change to "Unlimited". Good. Its #
# working.                                              #
#                                                       #
#--[ Settings ]-----------------------------------------#
#                                                       #
# USERSDIR    = Full path to users dir.                 #
#                                                       #
# DATAFILE    = Who got rewarded last is kept in this   #
#               file.                                   #
#               Create it and set 755 or something.     #
#                                                       #
# TMP         = Just a temporary dir.                   #
#                                                       #
# STATS       = Path to your stats binary. It comes     #
#               with glftpd. Do NOT specify -r or -s.   #
#               See below                               #
#                                                       #
# GLCONF      = Path to your glftpd.conf. Note: If it   #
#               fails to find any winner and your       #
#               glftpd.conf is in /etc, leave this      #
#               blank, ie "".                           #
#                                                       #
#               By default, it runs stats -r $GLCONF,   #
#               but some report that if you specify     #
#               where glftpd.conf is, and it is in      #
#               /etc/glftpd.conf, then stats will NOT   #
#               output any data for some reason.        #
#               Hence, if you have this problem, leave  #
#               it blank.                               #
#               I dont have this problem with stats 2.0 #
#               but those who do have stats version 2.2 #
#                                                       #
# LOG         = Where to log rewards to. Logs like      #
#               DD MM YYYY - WW - Username - Position this duration - Got reward.
#               Example: 24 08 2003 - 33 - Turran - 1 this day - Got Flag 0
#               Example: 24 08 2003 - 33 - Turran - 1 this day - Got Leech
#               WW = Weeknumber                         #
#               Do NOT specify glftpd.log here.         #
#               "" = Disable this function.             #
#                                                       #
#               Logging this is a good idea if you plan #
#               to make a custom script that checks who #
#               got rewarded this month, for instance.  #
#                                                       #
# MSGS        = Full path to msgs dir if you also want  #
#               it to send a message to the user on     #
#               site. Default is /glftpd/ftp-data/msgs  #
#               Message is only sent on giving out the  #
#               reward.                                 #
#               "" = disable this function.             #
#                                                       #
# READSECTION = Which stat section shall I check whos   #
#               the top uploader in? By default, its 0  #
#               for the default section. Its used when  #
#               executing stats with -s $READSECTION.   #
#               If this dosnt work, blame stats, not me.#
#                                                       #
# DURATION    = t/w/m. What stats to check. todays,     #
#               weekly or monthly.                      #
#               Its used with stats as weither          #
#               -t, -w or -m                            #
#                                                       #
# EUROWEEK    = If you specified DURATION as w for week #
#               and you have glftpd setup to use        #
#               european weeks, set this to TRUE.       #
#               It MUST match your setting in glftpd or #
#               stats will NOT be correctly grabbed.    #
#               If you have '-e' in your (x)inetd line  #
#               you use european weeks.                 # 
#                                                       #
# IGNORELEECH = TRUE/FALSE. When TRUE and the #1 upper  #
#               has leech, it will check the #2 user    #
#               instead, and so on.                     #
#                                                       #
# USEREXCLUDE = Users that wont get rewarded. Seperate  #
#               with a | and dont use spaces.           #
#                                                       #
# GROUPEXCLUDE= Groups that wont get rewarded. Seperate #
#               with a | and dont use spaces.           #
#                                                       #
# GIVEFLAG    = A flag to give the user for the         #
#               duration, for instance 4. Can be evil   #
#               and put 6 here and the user will be     #
#               deleted for the duration, tihi.         #
#               You can specify more flags if you want. #
#               "" = Disable.                           #
#               Dont use the leechflag here. That comes #
#               next.                                   #
#                                                       #
# JUMPONFLAG  = TRUE/FALSE. If you have GIVEFLAG set    #
#               and the user already have that flag, do #
#               you want me to skip him?                #
#               This can be bad if you set it to give   #
#               leech too as he wont get his leech if   #
#               he has the flag.                        #
#                                                       #
# LEECHFLAG   = Which flag to give. Should match the    #
#               flag used with the creditcheck line we  #
#               added to glftpd.conf.                   #
#               "" = Disable.                           #
#                                                       #
# LEECHPATH   = Just a name of the section or so that   #
#               you are giving them leech in.           #
#               This one is only valid if LEECHFLAG     #
#               and MSGS are not disabled as its just   #
#               used when sending a message to the user #
#               that he "won".                          #
#                                                       #
# ONEDAYONLY  = TRUE/FALSE. When TRUE, the reward will  #
#               only be active for ONE day. If set to   #
#               FALSE, the reward will stick until the  #
#               end of this defined period (week/month) #
#               This has no effect if DURATION is t but #
#               its recomended you set it to TRUE then  #
#               because it looks better in the MSGS to  #
#               the user.                               #
#                                                       #
# GLLOG       = If you use zipscript-c and want bot     #
#               output, specify full path to glftpd.log #
#                                                       #
# WINNERANNOUNCE = If GLLOG is set, this is what it     #
#                  will say when finding a new winner.  #
#                                                       #
# REMOVEANNOUNCE = If GLLOG is set, this is what it     #
#                  will say when leech expires on a     #
#                  previous winner.                     #
#                                                       #
# Cookes for WINNERANNOUNCE are:                        #
#  %BOLD%    = Start stop bold text.                    #
#  %ULINE%   = Start and stop underline.                #
#  %WINNER%  = The winning user.                        #
#  %DURNAME% = Will be either week or month.            #
#  %POS%     = The position of the winning user. Note   #
#              that this is not always #1 if you have   #
#              IGNORELEECH on TRUE.                     #
#                                                       #
#  For REMOVEANNOUNCE, its %BOLD%, %ULINE% and %LOOSER% #
#  where %LOOSER% is the name of the user that leech    #
#  was just removed from.                               #
#                                                       #
# Be creative with the announce so they match your      #
# settings above.                                       #
#                                                       #
#--[ Zipscript-c Announce ]-----------------------------------------------------#
#                                                                               #
# I used TURGEN again for botoutput, so if you already added that from some     #
# other script, you do not need to do so again, naturally.                      #
#                                                                               #
# Do the following in dZSbot.tcl and rehash the bot.                            #
#                                                                               #
# To 'set msgtypes(DEFAULT)', add TURGEN                                        #
#                                                                               #
# Add the following in the appropriate places:                                  #
#--                                                                           --#
# set chanlist(TURGEN) "#YourChan"
#
# set disable(TURGEN) 0
#
# set variables(TURGEN) "%msg"
#
# set announce(TURGEN)   "%msg"
#--                                                                           --#
# To test it, cut and paste this in your shell and it should                    #
# announce "Test Announce" to the channel:                                      #
#--                                                                           --#
#
# echo `date "+%a %b %e %T %Y"` TURGEN: \"Test Announce\" >> /glftpd/ftp-data/logs/glftpd.log
#
#--                                                                           --#
# If you do not use zipscript-c, search for TURGEN in the script and modify the #
# output to suit your need. The message to say is in the variable $OUTPUT. Ie:  #
# echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG                   #
#-------------------------------------------------------------------------------#
#                                                       #
# Next, test the script by running                      #
# tur-goodboy.sh test                                   #
#                                                       #
# Looks ok? Then crontab it like this:                  #
# 58 23 * * *     /glftpd/bin/tur-goodboy.sh            #
#                                                       #
# That will run it each day at 23:58. It will only give #
# leech if its actually the last day of the week or     #
# month. If ONEDAYONLY is TRUE, it will check the       #
# DATAFILE if someone got rewarded and if so, remove it.#
# This is dont before giving a new reward so its        #
# possible that it removes the reward and then puts it  #
# right back on.                                        #
#                                                       #
# NOTE: If you want to run multiple instances of this   #
# script, make sure to specify different DATAFILEs for  #
# each copy.                                            #
#                                                       #
#--[ Contact ]------------------------------------------#
#                                                       #
# Turranius on Efnet/LinkNet. Usually in #glftpd/efnet. #
# http://www.grandis.nu/glftpd                          #
#                                                       #
#--[ Configuration ]------------------------------------#

USERSDIR=/glftpd/ftp-data/users
DATAFILE=/glftpd/etc/tur-goodboy.db
TMP=/glftpd/tmp
STATS=/glftpd/bin/stats
GLCONF=/etc/glftpd.conf
LOG=/glftpd/ftp-data/logs/tur-goodboy.log
MSGS=/glftpd/ftp-data/msgs

READSECTION=0
DURATION=t
EUROWEEK=TRUE

IGNORELEECH=TRUE
USEREXCLUDE="turranius|ostnisse"
GROUPEXCLUDE="SiTEOPS|TRiAL|TRiAL-2"

GIVEFLAG=
JUMPONFLAG=FALSE
LEECHFLAG=W
LEECHPATH="/Archive"
ONEDAYONLY=TRUE

GLLOG=/glftpd/ftp-data/logs/glftpd.log

WINNERANNOUNCE="%BOLD%-SiteName-%BOLD% [TOPUL] - %BOLD%%WINNER%%BOLD% is our Non-Leech Top Uploader this %DURNAME% at position %BOLD%%POS%%BOLD%. %WINNER% gets %BOLD%leech%BOLD% in the archive for 24 hours."
REMOVEANNOUNCE="%BOLD%-SiteName-%BOLD% [TOPUL] - %BOLD%%LOOSER%%BOLD%'s leech in the archive has %ULINE%expired%ULINE% !"


#--[ Script Start ]-------------------------------------#

## Check if USERSDIR is defined correctly.
if [ ! -d "$USERSDIR" ]; then
  echo "Error. $USERDIR, defined as USERDIR does not exist."
  exit 1
fi

## Check that datafile exists and can be read and written to.
if [ ! -e "$DATAFILE" ]; then
  echo "DATAFILE does not exist; touch $DATAFILE; chmod 777 $DATAFILE"
  exit 1
elif [ ! -r "$DATAFILE" ]; then
  echo "Error: Cant read $DATAFILE. Check permissions."
  exit 1
elif [ ! -w "$DATAFILE" ]; then
  echo "Error: Cant write to $DATAFILE. Check permissions."
  exit 1
fi

## Check that TMP is defined correctly.
if [ ! -d "$TMP" ]; then
  echo "Error. $TMP, defined as TMP does not exist; mkdir -m777 $TMP"
  exit 1
fi

## Build STATSLINE which we then execute.
if [ "$GLCONF" ]; then
  STATSLINE="$STATS -$DURATION -u -x 500 -s $READSECTION -r $GLCONF"
else
  STATSLINE="$STATS -$DURATION -u -x 500 -s $READSECTION"
fi

proc_cookies() {
  if [ "$WINNER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%WINNER%/$WINNER/g" )"
  fi
  if [ "$CURUSER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%LOOSER%/$CURUSER/g" )"
  fi
  if [ "$HEADER" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%HEADER%/$HEADER/g" )"
  fi
  if [ "$DURNAME" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%DURNAME%/$DURNAME/g" )"
  fi
  if [ "$upnum" ]; then
    OUTPUT="$( echo $OUTPUT | sed -e "s/%POS%/$upnum/g" )"
  fi
  
  OUTPUT="$( echo $OUTPUT | sed -e "s/%BOLD%//g" )"
  OUTPUT="$( echo $OUTPUT | sed -e "s/%ULINE%//g" )"
}

proc_log() {
  if [ "$LOG" ]; then
    TEXT="$@"
    LOGHEADER=`date +%d" "%m" "%Y" - "%W" -"`
    echo "$LOGHEADER $TEXT" >> $LOG
  fi
}

proc_checkmonthend() {
  MONTHNOW="$( date +%b )"
  case $MONTHNOW in
    Jan) MONTHTOTAL="31" ;;
    Feb) MONTHTOTAL="28" ;;
    Mar) MONTHTOTAL="31" ;;
    Apr) MONTHTOTAL="30" ;;
    May) MONTHTOTAL="31" ;;
    Jun) MONTHTOTAL="30" ;;
    Jul) MONTHTOTAL="31" ;;
    Aug) MONTHTOTAL="31" ;;
    Sep) MONTHTOTAL="30" ;;
    Oct) MONTHTOTAL="31" ;;
    Nov) MONTHTOTAL="30" ;;
    Dec) MONTHTOTAL="31" ;;
    *) MONTHTOTAL="31" ;;
  esac

  DAYOFMONTH="$( date +%d )"

  if [ "$MONTHTOTAL" != "$DAYOFMONTH" ]; then
    if [ "$ONEDAYONLY" != "TRUE" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the month. Since this is a test I'm gonna run anyway."
        proc_removelastaward
        proc_reward
      else
        exit 0
      fi
    else
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the month. Running full anyway since were testing."
        proc_reward
      fi
      proc_removelastaward
    fi
  else
    if [ "$TEST" = "TRUE" ]; then
      echo "End of the month. Checking who wins and if anyone got leech last period."
    fi
    proc_removelastaward
    proc_reward
  fi
}

proc_checkweekend() {
  DAYNOW="$( date +%w )"

  case $EUROWEEK in
    [tT][rR][uU][eE]) WEEKENDS="0" ;;
    [fF][aA][lL][sS][eE]) WEEKENDS="6" ;;
    *) echo "Error: EUROWEEK must be TRUE or FALSE."; exit 1
  esac

  if [ "$DAYNOW" != "$WEEKENDS" ]; then
    if [ "$ONEDAYONLY" = "TRUE" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Not the end of the week (on day $DAYNOW. Week ends on $WEEKENDS). Running anyway since were just testing."
        proc_reward
      fi
      proc_removelastaward
    fi
  else
    if [ "$TEST" = "TRUE" ]; then
      echo "End of the week. Checking who wins and if anyone got leech last period."
    fi
    proc_removelastaward
    proc_reward
  fi
}

proc_checkdayend() {
  if [ "$TEST" = "TRUE" ]; then
    echo "Test run for daily stats started"
  fi
  proc_removelastaward
  proc_reward
}

proc_reward() {
  ## Make lame fixes.
  if [ -z "$USEREXCLUDE" ]; then
    USEREXCLUDE="RJ3klj3r30390"
  fi
  if [ -z "$GROUPEXCLUDE" ]; then
    GROUPEXCLUDE="Fkeljfklejfe897"
  fi

  unset NEWRATIO; unset ORGRATIO; unset OUTPUT
  ## Does the winner have leech? If so, try #2 in the list, and so on.
    if [ "$IGNORELEECH" = "TRUE" ]; then
    upnum=0
    unset WINNER
    for CURUSER in `$STATSLINE | grep "^\[..\]" | cut -d ' ' -f2`; do
      unset GROUP; unset EXCLUDED
      upnum=$[$upnum+1]
      if [ -z "$( echo "$CURUSER" | egrep "$USEREXCLUDE" )" ]; then
        if [ "$IGNORELEECH" = "TRUE" ]; then
          if [ -z "$( grep "^RATIO " $USERSDIR/$CURUSER | cut -d ' ' -f2- | grep "0" )" ]; then
            WINNER="$CURUSER"
          else
            if [ "$TEST" = "TRUE" ]; then
              echo "$upnum: $CURUSER won? NO, he has leech."
            fi
          fi
        else
          WINNER="$CURUSER"
        fi

        for GROUP in `grep "^GROUP " $USERSDIR/$CURUSER | cut -d ' ' -f2`; do
          if [ "$( echo "$GROUP" | egrep "$GROUPEXCLUDE" )" ]; then
            EXCLUDED=TRUE
            if [ "$TEST" = "TRUE" ]; then
              echo "$upnum: $CURUSER won? NO. Hes in an excluded group."
            fi
          fi
          if [ "$EXCLUDED" ]; then
            unset WINNER
            break
          fi
        done

        if [ "$JUMPONFLAG" = "TRUE" -a "$GIVEFLAG" != "" ]; then
          if [ "$( grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2 | grep "$GIVEFLAG" )" ]; then
            if [ "$TEST" = "TRUE" ]; then
              echo "$upnum: $CURUSER won? NO. JUMPONFLAG is TRUE and $GIVEFLAG already on him."
            fi
            unset WINNER
          fi
        fi        

      else
        if [ "$TEST" = "TRUE" ]; then
          echo "$upnum: $CURUSER won? NO, he is an excluded user."
        fi
      fi

      if [ "$WINNER" ]; then
        break
      fi

    done

  else
    ## IGNORELEECH is FALSE. Just grab position 1 as winner.
    upnum=1
    WINNER=`$STATSLINE | grep "^\[01\]" | cut -d ' ' -f2`
  fi

  if [ -z "$WINNER" ]; then
    echo "Error. Could not get a winner. Most likely there is no winners yet for this period."
    exit 1
  fi

  if [ "$LEECHFLAG" ]; then
    ORGFLAGS=`grep "^FLAGS " $USERSDIR/$WINNER | cut -d ' ' -f2`
    if [ "$( echo "$ORGFLAGS" | grep "$LEECHFLAG" )" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "Was going to give flag $LEECHFLAG to $WINNER but he already have it."
      fi
    else
      NEWLFLAGS="$LEECHFLAG$ORGFLAGS"
      if [ "$TEST" != "TRUE" ]; then
        sed -e "s/^FLAGS .*/FLAGS $NEWLFLAGS/" $USERSDIR/$WINNER > $TMP/tur-goodboy.leech.tmp
        cp -f $TMP/tur-goodboy.leech.tmp $USERSDIR/$WINNER
        rm -f $TMP/tur-goodboy.leech.tmp

        echo "$WINNER^GotLeech^$LEECHFLAG" >> $DATAFILE

        proc_log "$WINNER - $upnum this $DURNAME - Got Flag $LEECHFLAG for leech."
      else
        echo "Would have given $WINNER flag $LEECHFLAG and written $WINNER^GotLeech^$LEECHFLAG to DATAFILE"
      fi
    fi
  fi ## END GIVE LEECH.

  if [ "$GIVEFLAG" ]; then
    ORGFLAGS=`grep "^FLAGS " $USERSDIR/$WINNER | cut -d ' ' -f2`
    if [ -z "$ORGFLAGS" ]; then
      echo "Error. Could not read current FLAGS on $WINNER"
      exit 1
    fi

    if [ "$( echo "$ORGFLAGS" | grep "$GIVEFLAG" )" ]; then
      if [ "$TEST" = "TRUE" ]; then
        echo "$WINNER would have gotten flag $GIVEFLAG, but he already have it."
      fi
    else
      if [ "$TEST" != "TRUE" ]; then
        sed -e "s/^FLAGS .*/FLAGS $GIVEFLAG$ORGFLAGS/" $USERSDIR/$WINNER > $TMP/tur-goodboy.flag.tmp
        cp -f $TMP/tur-goodboy.flag.tmp $USERSDIR/$WINNER
        rm -f $TMP/tur-goodboy.flag.tmp      

        echo "$WINNER^GotFlag^$GIVEFLAG" >> $DATAFILE

        proc_log "$WINNER - $upnum this $DURNAME - Got Flag $GIVEFLAG"
      else
        echo "Would have given $WINNER flag $GIVEFLAG and written $WINNER^GotFlag^$GIVEFLAG to DATAFILE"
      fi
    fi
  fi ## END GIVE FLAG

  ## Build announce line.
  if [ "$WINNERANNOUNCE" -a "$GLLOG" ]; then
    OUTPUT="$WINNERANNOUNCE"
    proc_cookies
  fi

  if [ "$TEST" = "TRUE" ]; then
    echo "Winner this $DURNAME is $upnum : $WINNER"
    if [ "$OUTPUT" ]; then
      echo "Would have announced: $OUTPUT"    
    fi
  else
    if [ "$OUTPUT" ]; then
      echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
    fi
  fi

  ## Send message to winner.
  if [ "$MSGS" ]; then
    HDATE=`date +%a" "%b" "%d" "%T" "%y`
    HEADER="!HFROM: !CTur-GoodBoy !H(!C$HDATE!H)!0"
    if [ "$LEECHFLAG" ]; then
      if [ "$ONEDAYONLY" = "TRUE" ]; then
        MSG="!HCongratulation on Top-Upload this $DURNAME. You got leech in $LEECHPATH for 24 hours."
      else
        MSG="!HCongratulation on Top-Upload this $DURNAME. You got leech in $LEECHPATH this whole $DURNAME."
      fi
    fi
    if [ "$GIVEFLAG" ]; then
      if [ -z "$MSG" ]; then
        if [ "$ONEDAYONLY" = "TRUE" ]; then
          MSG="!HCongratulation on Top-Upload this $DURNAME. You got flag $GIVEFLAG for 24 hours.!0"
        else
          MSG="!HCongratulation on Top-Upload this $DURNAME. You got flag $GIVEFLAG this whole $DURNAME.!0"
        fi
      else
        MSG="$MSG You also got flag $GIVEFLAG for the same duration."
      fi
    fi
    if [ "$MSG" ]; then
      if [ "$TEST" != "TRUE" ]; then
        MSG="$MSG!0"
        echo "$HEADER" >> $MSGS/$WINNER
        echo "--------------------------------------------------------------------------" >> $MSGS/$WINNER
        echo "$MSG" >> $MSGS/$WINNER
        echo "!HThis message was generated by Tur-GoodBoy $VER by Turranius - 2003!0" >> $MSGS/$WINNER
        echo " " >> $MSGS/$WINNER
      else
        echo " "
        echo "Would have sent the following message to $MSGS/$WINNER:"
        echo "$HEADER"
        echo "--------------------------------------------------------------------------"
        echo "$MSG"
        echo "!HThis message was generated by Tur-GoodBoy $VER by Turranius - 2003!0"
      fi

    fi
  fi
}

## Procedure for removing leech they were given previously."
proc_removelastaward() {
  unset CURUSER; unset ORGRATIO; unset POS; unset OUTPUT

  for rawdata in `cat $DATAFILE`; do
    unset CURUSER; unset ORGRATIO; unset POS; unset GOTFLAG
    if [ "$rawdata" ]; then
      CURUSER=`echo "$rawdata" | cut -d '^' -f1`
      ACTION=`echo "$rawdata" | cut -d '^' -f2`
      GOTFLAG=`echo "$rawdata" | cut -d '^' -f3`

      case $ACTION in
        GotLeech) proc_restoreleech ;;
        GotFlag) proc_restoreflag ;;
        *) echo "Error. Got unknown action: $ACTION"; exit 1 ;;
      esac

    fi
  done

  if [ -z "$CURUSER" ]; then
    if [ "$TEST" = "TRUE" ]; then
      echo "No previous award found. This is NOT an error."
    fi
  else
    if [ "$REMOVEANNOUNCE" -a "$GLLOG" ]; then
      OUTPUT="$REMOVEANNOUNCE"
      proc_cookies
      if [ "$TEST" = "TRUE" ]; then
        echo "Would have announced: $OUTPUT"
      else
        echo `date "+%a %b %e %T %Y"` TURGEN: \"$OUTPUT\" >> $GLLOG
      fi
    fi
  fi
 
  LOOSER=$CURUSER
}

proc_restoreflag() {
  CURFLAGS=`grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2`
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Was going to restore flags on $WINNER but cant read his current FLAGS."
  else
    NEWFLAGS=`echo "$CURFLAGS" | tr -d "$GOTFLAG"`

    if [ "$TEST" != "TRUE" ]; then
      sed -e "s/^FLAGS .*/FLAGS $NEWFLAGS/" $USERSDIR/$CURUSER > $TMP/tur-goodboy.flag.tmp
      cp -f $TMP/tur-goodboy.flag.tmp $USERSDIR/$CURUSER
      rm -f $TMP/tur-goodboy.flag.tmp    

      proc_removefromdata
    else
      echo "Last periods winner: $CURUSER - changing flags from $CURFLAGS to $NEWFLAGS"
      if [ "$LEECHFLAG" ]; then
        echo "NOTE: Since its a test, I never really removed the GIVEFLAG. Hence the weird flagchange."
      fi
    fi
  fi
}

proc_restoreleech() {
  CURFLAGS=`grep "^FLAGS " $USERSDIR/$CURUSER | cut -d ' ' -f2`
  if [ -z "$CURFLAGS" ]; then
    echo "Error. Was going to restore leech flag on $WINNER but cant read his current FLAGS."
  else
    NEWFLAGS=`echo "$CURFLAGS" | tr -d "$GOTFLAG"`

    if [ "$TEST" != "TRUE" ]; then
      sed -e "s/^FLAGS .*/FLAGS $NEWFLAGS/" $USERSDIR/$CURUSER > $TMP/tur-goodboy.leech.tmp
      cp -f $TMP/tur-goodboy.leech.tmp $USERSDIR/$CURUSER
      rm -f $TMP/tur-goodboy.leech.tmp    

      proc_removefromdata
    else
      echo "Last periods winner: $CURUSER - changing leechflags from $CURFLAGS to $NEWFLAGS"
    fi
  fi
}

proc_removefromdata() {
  grep -vi "$rawdata" $DATAFILE > $TMP/tur-goodboydata.tmp
  cp -f $TMP/tur-goodboydata.tmp $DATAFILE
  rm -f $TMP/tur-goodboydata.tmp
}  

A1=`echo "$1" | tr '[:upper:]' '[:lower:]'`
A2=`echo "$2" | tr '[:upper:]' '[:lower:]'`

if [ "$A1" = "test" -o "$2" = "test" ]; then
  TEST="TRUE"
  echo "TEST mode on. Nothing will actually be written or changed."
fi

case $DURATION in
  t) DURNAME="day"; proc_checkdayend ;;
  w) DURNAME="week"; proc_checkweekend ;;
  m) DURNAME="month"; proc_checkmonthend ;;
  *) echo "Error: Duration must be set to t, w or m"; exit 1 ;;
esac
  
