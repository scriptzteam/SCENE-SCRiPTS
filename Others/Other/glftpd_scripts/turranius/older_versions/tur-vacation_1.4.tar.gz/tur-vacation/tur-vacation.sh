#!/bin/bash
VER=1.4
#############################################################
# Tur-Vacation. A simple way to go on vacation.             #
# Tired of people telling you they are going on vacation?   #
# Tired of having to add users to excuded list in the trial #
# script? Well, NO MORE. heh. Heres how it works:           #
#                                                           #
# Users issue a command from site. 'site vacation on yes'   #
# What it mainly does is add that user to a group. That     #
# group is already (by you) excluded in your trialscript so #
# they will not be automatically delled or something.       #
#                                                           #
# But this script can do two more things to the user.       #
# 1: It can prevent him from downloading while on vacation. #
# 2: it can prevent him from uploading while on vacation.   #
# It does this by setting max_sim_down and/or max_sim_up to #
# 0.                                                        #
# Thus they can log in and look around, but not much else.  #
#                                                           #
# It also has a minimum time that must have passed since    #
# they went on vacation, until they can turn vacation off   #
# again. This is so they cant go on vacation at the end of  #
# each month.                                               #
#                                                           #
# As with v1.4, it can work together with Tur-Trial 2.1+    #
# so that if a user was on vacation for half the month, he  #
# should only need to upload half the quota limit to pass.  #
#                                                           #
# You can also issue the command 'site vacation status' to  #
# get a status report of everyone on vacation.              #
#                                                           #
#-[ Setup ]------------------------------------------------##
#                                                           #
# Copy this script to /glftpd/bin. Make it executable.      #
# ( chmod 755 /glftpd/bin/tur-vacation.sh )                 #
#                                                           #
# Add it to glftpd.conf as a custom command:                #
# site_cmd vacation       EXEC    /bin/tur-vacation.sh      #
# custom-vacation         *                                 #
#                                                           #
# Edit the settings below:                                  #
#                                                           #
# USERS=     Location of users folder, chrooted /glftpd.    #
#                                                           #
# LOG=       Log location for vacation on and off.          #
#            Set to "" to disable logging.                  #
#            If you plan to use bot output, set this to     #
#            glftpd.log (default).                          #
#                                                           #
# MINDUR=    Minimum duration in days before they can turn  #
#            off vacation.                                  #
#            Set this one to "" to turn the function off.   #
#                                                           #
# VACATIONGROUP= Group they will be added to. Add this in   #
#                glftpd first ( site grpadd VACATION ).     #
#                                                           #
# DB=        This script will keep data about people on     #
#            vacation in this file. Create it and make sure #
#            its writable.                                  #
#            ( touch /glftpd/tmp/vacation.index )           #
#            ( chmod 777 /glftpd/tmp/vacation.index )       #
#                                                           #
# TMP=       Temporary storage for modifying user files.    #
#            Make sure users have full perms in here.       #
#                                                           #
# BLOCKUP=   Set max_sim_up to 0 when they go on vacation?  #
#            With this on TRUE, they cant upload.           #
#                                                           #
# BLOCKDN=   Set max_sim_down to 0 when they go on vacation?#
#            With this one TRUE, they cant download.        #
#                                                           #
# STATUS=    What do you want to trigger the status report  #
#            with? If you dont like your user to do this    #
#            then change it something only you know.        #
#                                                           #
# TRIALDATA= If you are using Tur-Trial 2.1+ for monthly    #
#            quota, set this file to point to the same file #
#            as VACATIONDATA in Tur-Trial.conf. It will     #
#            use this seperate file to check how long the   #
#            user was on vacation and deduct those number   #
#            days from the users quota limit.               #
#            Set a # infront of this one to disable it.     #
#            Its disabled by default.                       #
#                                                           #
# NOTE: If someone issues the command by mistake and you    #
#       wish to fix it, edit the DB file. At the end is a   #
#       long number. Set that to 1 and they can enable      #
#       themselfs again.                                    #
#       If TRIALDATA is set, edit that file as well and     #
#       remove the line with the users name on it.          #
#                                                           #
#############################################################
# If you want irc output to go with this, set LOG to your   
# glftpd.log and, if you run zipscript-c, add this to       
# dZSbot.h:                                               
# To 'set msgtypes(DEFAULT)', add VACATION and VACATIONOFF    
#
# below the other 'set chanlist', add:                        
# set chanlist(VACATION)    "#YourChan"                     
# set chanlist(VACATIONOFF) "#YourChan"                     
#
# to the other 'set disable', add:                            
# set disable(VACATION)    0                                
# set disable(VACATIONOFF) 0                                
#
# to the other 'set variables', add:
# set variables(VACATION)    "%user %prelogin %postlogin"
# set variables(VACATIONOFF) "%user %duration %prelogin %postlogin"
#
# to the other 'set announce', add:
# set announce(VACATION)     "%user goes on vacation. Have fun!"
# set announce(VACATIONOFF)  "%user is back from vacation after %duration days. Welcome back!"
# 
# %prelogin and %postlogin are just how the LOGIN field in the user
# file looked before and after. Not much to have in irc, but 
# good that its logged.
#
# Dont forget to rehash the bot.
#
##-[ Contact ]---------------------------------------------##
# http://www.grandis.nu/glftpd/ or http://grandis.mine.nu   #
# I usually hang in #glftpd on efnet as Turran.             #
#############################################################
# Changelog:
# 1.4   : Added TRIALDATA. A seperate DB file used by 
#         Tur-Trial 2.1+ to deduct credits from quotalimit
#         if the user was on vacation this month.
#         Its disabled with a # by default. If you enable it,
#         create the file and chmod 777 on it.
#
#         NOTE: If you are just upgrading, current vacation
#         users will NOT be effected by this. They need to
#         get out of vacation and back in again for this to
#         work.
#
# 1.3   : It switched the upload and download slots when a 
#         user came back from vacation.. oops.
#
# 1.2   : Counted 12 hours instead of 24 per day, giving the
#         wrong days count in status check.
#
# 1.1   : When doing a status check, it kept going down the
#         script instead of exiting. Not a big deal as nothing
#         happened *usually*.
#############################################################

USERS=/ftp-data/users            ## Users location
LOG=/ftp-data/logs/glftpd.log    ## Log location
MINDUR=7                         ## Min days to be on vaca..
VACATIONGROUP=VACATION           ## Group to add to.
DB=/tmp/vacation.index           ## Database file.
TMP=/tmp                         ## Temporary location.
BLOCKUP=TRUE                     ## No uploading?
BLOCKDN=TRUE                     ## No downloading?
STATUS=status                    ## Check status with 'site ?'

# TRIALDATA="/etc/quota_vacation.db"
## Remove above # to enable Tur-Trial 2.1+ interaction.


##############################################################
# No changes below here, unless you want to change something #
# In which case, this text is useless and.. hmm. bah.        #
##############################################################

## No argument? Show help.
if [ -z "$1" ]; then
  echo "############################################################"
  echo "# Vacation System $VER by Turranius."
  echo "# This script allows you to set yourself in vacation mode."
  echo "# During that time, you will be excluded from any quotas"
  if [ "$BLOCKUP" = "TRUE" -a "$BLOCKDN" = "TRUE" ]; then
    echo "# and you can not upload or download."
    SAIDIT="YES"
  fi
  if [ "$SAIDIT" != "YES" ]; then
    if [ "$BLOCKUP" = "TRUE" ]; then
      echo "# and you will not be able to upload while on vacation."
    fi
    if [ "$BLOCKDN" = "TRUE" ]; then
      echo "# and you will not be able to download while on vacation"
    fi
  fi
  if [ "$MINDUR" != "" ]; then
    echo "# If you set yourself on vacation, $MINDUR days must pass"
    echo "# before you are allowed to change back."
  fi
  echo "#"
  echo "# To enable vacation, issue 'site vacation on'"
  echo "# To disable it, issue 'site vacation off'"
  exit 0
fi

## Show status for everyone on vacation.
if [ "$1" = "$STATUS" ]; then
  if [ ! -r "$DB" ]; then
    echo "Can not read from $DB. Check perms or if the file even exists.."
    exit 1
  fi

  if [ -z "$( grep ^ $DB )" ]; then
    echo "No users on vacation..."
    exit 0
  fi

  for each in `cat $DB`; do
    if [ "$each" ]; then
      user="$( echo $each | awk -F"^" '{print $1}' )"
      otime="$( echo $each | awk -F"^" '{print $4}' )"
      ominutes="$( expr $otime \/ 60 )"
      ohours="$( expr $ominutes \/ 60 )"
      odays="$( expr $ohours \/ 24 )"
      
      time="$( date +%s )"
      minutes="$( expr $time \/ 60 )"
      hours="$( expr $minutes \/ 60 )"
      days="$( expr $hours \/ 24 )"

      nhours="$( expr $hours \- $ohours )"
      ndays="$( expr $days \- $odays )"

      echo "$user has been gone for $ndays days ( $nhours hours )"
    fi
  done
  exit 0
fi

## Check if we can write to userfile.
if [ ! -w $USERS/$USER ]; then
  echo "Error. Your userfile can not be edited. Bug siteops to fix perms."
  exit 1
fi

if [ "$TRIALDATA" ]; then
  if [ ! -e "$TRIALDATA" ]; then
    echo "Please create the TRIALDATA file and set 777 on it."
    exit 1
  elif [ ! -w "$TRIALDATA" ]; then
    echo "Can not write to the TRIALDATA file. Set 777 on it."
    exit 1
  fi
fi

## Going on vacation
if [ "$1" = "ON" -o "$1" = "on" ]; then
  if [ "$2" != "yes" ]; then
    echo "Are you sure?"
    if [ "$MINDUR" != "" ]; then
      echo "You will not be able to change back for $MINDUR days."
    fi
    if [ "$BLOCKUP" = "TRUE" ]; then
      echo "You will not be able to upload while on vacation."
    fi
    if [ "$BLOCKDN" = "TRUE" ]; then
      echo "You will not be able to download while on vacation."
    fi
    if [ "$TRIALDATA" ]; then
      echo "The time you are away will be deducted from your quota on the month you are back."
    fi
    echo "To verify and agree to those terms; issue 'site vacation on yes'"
    exit 0
  fi
  
  if [ ! -w "$DB" ]; then
    echo "Error. No permissons to edit vacation database. Bug siteops to fix perms"
    exit 1
  fi

  if [ "$LOG" ]; then
    if [ ! -w "$LOG" ]; then
      echo "Error. Can not write to logfile. Ask siteops to fix perms on it."
      exit 1
    fi
  fi

  if [ "$TRIALDATA" ]; then
    if [ ! -w "$TRIALDATA" ]; then
      echo "Error. Can not write to TRIALDATA file. Ask a siteop to fix perms on it."
      exit 1
    fi
  fi

  if [ "$( grep -w $USER $DB )" ]; then
    echo "You are already on vacation.. turn that off first"
    exit 1
  fi
 
  FIRST="$( grep -w LOGINS $USERS/$USER | awk '{print $2}' )"
  SECOND="$( grep -w LOGINS $USERS/$USER | awk '{print $3}' )"
  DNSLOTS="$( grep -w LOGINS $USERS/$USER | awk '{print $4}' )"
  UPSLOTS="$( grep -w LOGINS $USERS/$USER | awk '{print $5}' )"
  
  TIMENOW="$( date +%s )"

  echo $USER"^"$UPSLOTS"^"$DNSLOTS"^"$TIMENOW >> $DB

  if [ "$TRIALDATA" ]; then
    echo $USER"^"$TIMENOW >> $TRIALDATA
  fi

  if [ -z "$( grep -w $USER $DB )" ]; then
    echo "Could not verify saved data. Contact siteops."
    echo "Write to $DB with your info must have failed."
    exit 1
  fi

  if [ "$TRIALDATA" ]; then
    if [ -z "$( grep -w $USER $TRIALDATA )" ]; then
      echo "Could not verify saved data. Contact siteops."
      echo "Write to $TRIALDATA with your info must have failed."

      grep -vw "^$USER" $DB > $TMP/db.tmp
      cp -f $TMP/db.tmp $DB
      rm -f $TMP/db.tmp

      exit 1
    fi
  fi

  BEFORELOGINS="$FIRST $SECOND $DNSLOTS $UPSLOTS"

  if [ "$BLOCKDN" = "TRUE" ]; then
    DNSLOTS="0"
  fi

  if [ "$BLOCKUP" = "TRUE" ]; then
    UPSLOTS="0"
  fi 

  AFTERLOGINS="$FIRST $SECOND $DNSLOTS $UPSLOTS"

  if [ "$LOG" ]; then
    echo `date "+%a %b %e %T %Y"` VACATION: \"$USER\" \"$BEFORELOGINS\" \"$AFTERLOGINS\"  >> $LOG
  fi

  sed -e "s/^LOGINS $BEFORELOGINS/LOGINS $AFTERLOGINS/" $USERS/$USER > $TMP/$USER.tmp
  cp -f $TMP/$USER.tmp $USERS/$USER
  rm -f $TMP/$USER.tmp
  echo "GROUP $VACATIONGROUP" >> $USERS/$USER

  echo "All done. Issue 'site vacation off' when back."
  exit 0
fi

if [ "$1" = "OFF" -o "$1" = "off" ]; then
  if [ ! -w "$DB" ]; then
    echo "Can not write to vacation db. Ask siteops to fix perms."
    exit 1
  fi 

  if [ "$TRIALDATA" ]; then
    if [ ! -w "$TRIALDATA" ]; then
      echo "Can not write to TRIALDATA file. Ask siteops to fix perms."
      exit 1
    fi
  fi

  if [ -z "$( grep -w $USER $DB )" ]; then
    if [ -z "$( grep "GROUP $VACATIONGROUP" $USERS/$USER )" ]; then
      echo "You are not marked for vacation..."
      exit 1
    else
      echo "Can not find you in vacation database. You need a siteop to restore you."
      exit 1
    fi
  fi

  USERRAWDATA="$( grep -w $USER $DB )"

  if [ "$USERRAWDATA" = "" ]; then
    echo "Couldnt grab your previous info from vacation db. Ask a siteop to fix perms or fix you manually."
    exit 1
  fi

  FIRST="$( grep -w LOGINS $USERS/$USER | awk '{print $2}' )"
  SECOND="$( grep -w LOGINS $USERS/$USER | awk '{print $3}' )"
  ODNSLOTS="$( grep -w LOGINS $USERS/$USER | awk '{print $4}' )"
  OUPSLOTS="$( grep -w LOGINS $USERS/$USER | awk '{print $5}' )"

  DNSLOTS="$( echo $USERRAWDATA | awk -F"^" '{print $2}' )"
  UPSLOTS="$( echo $USERRAWDATA | awk -F"^" '{print $3}' )"
  TIMETHEN="$( echo $USERRAWDATA | awk -F"^" '{print $4}' )"
  TIMENOW="$( date +%s )"
  
  if [ "$TIMETHEN" = "" -o "$TIMENOW" = "" ]; then
    echo "Error. Can not see when you went on vacation, or cant check what time it is now."
    exit 1
  fi

  if [ "$MINDUR" != "" ]; then
    TIMETHEN="$( expr $TIMETHEN \/ 60 )"
    TIMETHEN="$( expr $TIMETHEN \/ 60 )"
    TIMETHEN="$( expr $TIMETHEN \/ 24 )"
    TIMENOW="$( expr $TIMENOW \/ 60 )"
    TIMENOW="$( expr $TIMENOW \/ 60 )"
    TIMENOW="$( expr $TIMENOW \/ 24 )"

    DIFFERENCE="$( expr $TIMENOW \- $TIMETHEN )"
 
    if [ "$DIFFERENCE" -lt "$MINDUR" ]; then
      echo "Minimum duration not yet reached."
      echo "You went on vacation $DIFFERENCE days ago and minimum is $MINDUR days"
      echo "If you feel this is in error, contact your favorite siteop."
      exit 1
    fi
  fi
 
  if [ "$ODNSLOTS" != "$DNSLOTS" -a "$OUPSLOTS" != "$UPSLOTS" ]; then
    BEFORELOGINS="$FIRST $SECOND $ODNSLOTS $OUPSLOTS"
    AFTERLOGINS="$FIRST $SECOND $UPSLOTS $DNSLOTS"

    sed -e "s/^LOGINS $BEFORELOGINS/LOGINS $AFTERLOGINS/" $USERS/$USER > $TMP/$USER.tmp
    cp -f $TMP/$USER.tmp $USERS/$USER
    rm -f $TMP/$USER.tmp
  fi

  if [ "$( grep "^GROUP $VACATIONGROUP" $USERS/$USER )" ]; then
    grep -vw "^GROUP $VACATIONGROUP" $USERS/$USER > $TMP/$USER.2.tmp
    cp -f $TMP/$USER.2.tmp $USERS/$USER
    rm -f $TMP/$USER.2.tmp
  fi

  grep -vw "^$USER" $DB > $TMP/db.tmp
  cp -f $TMP/db.tmp $DB
  rm -f $TMP/db.tmp

  if [ "$TRIALDATA" ]; then
    grep -vw "^$USER" $TRIALDATA > $TMP/trialdata.tmp
    cp -f $TMP/trialdata.tmp $TRIALDATA
    rm -f $TMP/trialdata.tmp
  fi

  if [ "$LOG" ]; then
    echo `date "+%a %b %e %T %Y"` VACATIONOFF: \"$USER\" \"$DIFFERENCE\" \"$BEFORELOGINS\" \"$AFTERLOGINS\"  >> $LOG
  fi
 
  echo "Welcome back!"
fi

exit 0
