#!/bin/bash
VER=1.2
################################################################
# Dupecheck by Turranius ( http://www.grandis.nu/glftpd/ )     #
#--------------------------------------------------------------#
# This is a dupechecker, exactly like the one in glftpd, but   #
# is ment to be used from irc to check the dupelog with        #
# !dupe <releasename>                                          #
#                                                              #
# First a note to those of you who didnt know this. dupe is    #
# not search. Dupe is what WAS on site. Search is what IS.     #
# Therefor, you should not try and keep the dupelog updated.   #
# It should basically contain everything on your site.         #
# Get Tur-DirLogClean to keep 'site search' up to date instead.#
#                                                              #
#-[ Installation ]---------------------------------------------#
# Copy dupecheck_shell.sh to /glftpd/bin.                      #
# Copy dupecheck.tcl to your bots script folder and load it in #
# the bots config file.                                        #
#                                                              #
# Edit dupecheck_shell.sh (you already are), and change the    #
# settings like you want it.                                   #
# Make sure everything is executable and the permissions are   #
# set to the user running the bot!                             #
#                                                              #
#-[ Requirements ]---------------------------------------------#
# Grep tail and echo must be in the path. Change full path to  #
# them near the bottom otherwise.                              #
#                                                              #
#-[ Testing ]--------------------------------------------------#
# Run dupecheck_shell.sh from shell and see that it does what  #
# it should do.                                                #
# Once satisfied, .rehash the bot with the .tcl loaded and try #
# !dupe from irc. Thats about it.                              #
#                                                              #
#-[ Changelog ]------------------------------------------------#
#                                                              #
# 1.2 : Now takes up to 5 arguments instead of just 1.         #
#       Use the new tcl to get this function.                  #
#                                                              #
#       Strips any control chars from arguments to be safe.    #
#                                                              #
#       Exclude is a bit more advanced. You can use a space to #
#       start a word and it will have to start with that word. #
#       for instance ' CD.'                                    #
#       The . is *. Ie, any character.                         #
#                                                              #
# 1.1 : Can now start a search with '-'.                       #
#       Changed how its searching. Should be faster now.       #
#                                                              #
# 1.0 : Yeah..                                                 #
#                                                              #
#-[ Settings ]-------------------------------------------------#

DUPELOG=/glftpd/ftp-data/logs/dupelog # Full path to dupelog
EXCLUDE='SAMPLE| CD.'            # What to exclude from hits. | delimited. 
                                 # . = Any char.
                                 # $ = Force end only.

                                 # Space to start = Force start only.
MAXHITS="5"                      # Max number of hits to return. (new>old)
MINCHARS="3"                     # Minumum search string.


################################################################
# No changes below here should be needed.                      #
################################################################


if [ -z "$1" ]; then
  echo "Also specify what to look for."
  echo "The last $MAXHITS hits will be shown."
  echo "Up to 5 arguments are accepted."
  exit 0
fi

if [ "$LENGHT" ]; then
  LENGHT="$( echo $1 | wc -c )"
  LENGHT=$[$LENGHT-1]
  if [ "$LENGHT" -lt "$MINCHARS" ]; then
    echo "Minimum amount of chars for a search is $MINCHARS"
    exit 0
  fi
fi

A1=`echo "$1" | tr -d '[:cntrl:]'`
A2=`echo "$2" | tr -d '[:cntrl:]'`
A3=`echo "$3" | tr -d '[:cntrl:]'`
A4=`echo "$4" | tr -d '[:cntrl:]'`
A5=`echo "$5" | tr -d '[:cntrl:]'`

if [ "$A5" ]; then
  grep -F -i -- "$A1" $DUPELOG | grep -F -i -- "$A2" | grep -F -i -- "$A3" | egrep -vi "$EXCLUDE" | grep -F -i -- "$A4" | grep -F -i -- "$A5" | tail -n $MAXHITS
elif [ "$A4" ]; then
  grep -F -i -- "$A1" $DUPELOG | grep -F -i -- "$A2" | grep -F -i -- "$A3" | egrep -vi "$EXCLUDE" | grep -F -i -- "$A4" | tail -n $MAXHITS
elif [ "$A3" ]; then
  grep -F -i -- "$A1" $DUPELOG | grep -F -i -- "$A2" | grep -F -i -- "$A3" | egrep -vi "$EXCLUDE" | tail -n $MAXHITS
elif [ "$A2" ]; then 
  grep -F -i -- "$A1" $DUPELOG | grep -F -i -- "$A2" | grep -F -i -- "$A2" | egrep -vi "$EXCLUDE" | tail -n $MAXHITS
else
  grep -F -i -- "$A1" $DUPELOG | egrep -vi "$EXCLUDE" | tail -n $MAXHITS
fi

exit 0
