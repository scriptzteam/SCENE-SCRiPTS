#!/bin/bash
VER=1.1

#---------------------------------------------------------------#
# Small script to reset the SPEED for stats in the userfiles.   #
# Ment mostly as a fix after old version of MSS "synced" speed  #
# back to the hub, making the speed greater then it was.        #
#                                                               #
# This will set it back to 0 (leaving files and MB untouched).  #
#---------------------------------------------------------------#
# NOTE: Only works if you have ONE stat section on this box.    #
# It wont run if you have more.                                 #
#---------------------------------------------------------------#

## Where are the users.
usersdir=/glftpd/ftp-data/users

## Some temp dir.
tmp=/glftpd/tmp

## Which stats to reset speed on.
reset="ALLUP ALLDN WKUP WKDN DAYUP DAYDN MONTHUP MONTHDN"

## What to set speed to (or very near)? Its kb/Sec.
value="1000"

## If you wish to test on a single user, enter him here. Otherwise leave blank.
testuser="glftpd"

#--[ Script Start ]--------------------------------------------#

if [ ! -d "$usersdir" ]; then
  echo "Error. usersdir ($usersdir) does not exist or is not a directory."
  exit 1
fi
if [ ! -d "$tmp" ]; then
  echo "Error. tmp ($tmp) does not exist or is not a directory."
  exit 1
fi
if [ -z "$reset" ]; then
  echo "Error. reset is not defined. Nothing to delete."
  exit 1
fi
if [ "$testuser" ]; then
  if [ ! -e "$usersdir/$testuser" ]; then
    echo "Error. testuser ($testuser) does not exist."
    exit 1
  fi
  echo "Start. Set to reset $reset on $testuser."
else
  testuser="."
  echo "Start. Set to reset $reset on ALL users."
fi


proc_reset() {
  unset NEWSPDVALUE; unset KBVALUE; unset NEWLINE

  KBVALUE=`grep "^$stats " $username | cut -d ' ' -f3`
  NEWSPDVALUE=`echo "$KBVALUE / $value" | bc -l | cut -d '.' -f1`
  NEWLINE=`grep "^$stats " $username | awk '{print $1" "$2" "$3}'`
  NEWLINE="$NEWLINE $NEWSPDVALUE"

  grep -v "^$stats " $username > $tmp/$username.tmp
  echo "$NEWLINE" >> $tmp/$username.tmp
  cp -f $tmp/$username.tmp $username
  rm -f $tmp/$username.tmp

}

cd $usersdir
for username in `grep "^FLAGS " * | grep -v "default.user" | grep "$testuser" | cut -d ':' -f1`; do

  if [ "`grep "^ALLUP " $username | awk '{print $5}'`" ]; then
    echo "Error. Seems $username has more then one stat section in userfile. Quitting."
    exit 1
  fi

  echo "Resetting speed for $username"

  for stats in $reset; do
    proc_reset $stats
  done
done

exit 0
