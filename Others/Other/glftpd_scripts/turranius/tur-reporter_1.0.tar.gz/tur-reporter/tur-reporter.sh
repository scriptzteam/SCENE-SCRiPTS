#!/bin/bash
VER=1.0

#--[ Intro ]-------------------------------------------------------------------#
#                                                                              #
# A small script ment to read log files of your choise, and report errors to   #
# your staffchan. Can be used on the message log to get warnings on disks or   #
# whatever you like.                                                           #
#                                                                              #
#--[ Setup ]-------------------------------------------------------------------#
#                                                                              #
# Copy to where ever you like. Chmod it to 700 or so (root executable).        #
#                                                                              #
#--[ Settings ]----------------------------------------------------------------#
#                                                                              #
# CHECKER=   Here you specify what file(s) to check and what to check them for.#
#            Its simply filename^what_to_look_for                              #
#            filename is the full path to the logfile and what_to_look_for is  #
#            a standard egrep line to look for.                                #
#            If you dont know egrep, I recomend you read up on it.             #
#            Making it hd[a-z] will look for anything from hda to hdz and      #
#            report that. The default is hd[a-z]|sd[a-z] to check both IDE and #
#            SCSI disks.                                                       #
#            If you want to specify a space in the egrep line, make it '\ '    #
#            (without the '').                                                 #
#                                                                              #
#            You can add multiple files. Just seperate the above with a space  #
#            (or newline, like the example).                                   #
#                                                                              #
#            Yes, you can still use ^ to force start, even though ^ is the     #
#            seperator between filename and what_to_look_for.                  #
#                                                                              #
# LINES=     How many lines back do you want to check each time it runs?       #
#            If you have a spammy logfile (firewall blocks to messages file?)  #
#            you will want to raise this. No worry to do it. It will just be a #
#            tiny bit slower.                                                  #
#                                                                              #
# GLLOG=     Where is your glftpd.log file?                                    #
#            If this is another machine in your network without a bot, mount   #
#            a dir from the botbox so you can write to glftpd.log from this    #
#            machine.                                                          #
#                                                                              #
# TMP=       A temporary dir. We'll store old reported stuff here so we do not #
#            report it again. This file is called tur-reporter.tmp             #
#                                                                              #
# proc_log   This is the logformat that will be written to glftpd.log.         #
#            By default, its ment for dZSbot.tcl with the trigger STAFF.       #
#            The $* is the actual message if you modify it to suit your bot.   #
#                                                                              #
#            If this is running on multiple boxes, you might want to include   #
#            the computername or something in here. Just add it inside the     #
#            \"$*\", like:  \"BoxName1: $*\"  or something.                    #
#                                                                              #
# Note: The first time you run it, it might spit out old errors. It will only  #
# do this once.                                                                #
# If you dont want this to happen, you can change the proc_log. Just put a #   #
# infront of >> $GLLOG, like: '# >> $GLLOG', and it will output it to screen.  #
#                                                                              #
#--[ dZSbot.tcl ]--------------------------------------------------------------#
#                                                                              #
# In order to get it to announce, we need to add another trigger to the bot.   #
# In dZSbot.tcl, do the following:                                             #
#                                                                              #
# To the already existing "set msgtypes(DEFAULT)", add the word: STAFF         #
# By all the others "set chanlist()", add: set chanlist(STAFF) "#Staffchan"    #
# (Staffchan should be replaced with the chan you want it announced in).       #
# By all the others "set disabled()", add: set disabled(STAFF) 0               #
# By all the others "set variables()", add: set variables(STAFF) "%msg"        #
# By all the others "set announce()", add: set announce(STAFF) "%msg"          #
#                                                                              #
# Thats it. Dont miss any of them or you'll get errors in partyline or no      #
# announce at all. Remember to rehash the bot.                                 #
#                                                                              #
# Incase it outputs in your normal chan instead of the staffchan, you might    #----[ Lazy. Thihi ]--------------#
# want to modify your dZSbot.tcl some more. Read this thread:                                                    #
# http://www.grandis.nu/glftpd/modules.php?name=Forums&file=viewtopic&t=174&sid=989444ac7acda54845a7c0a4b274e980 #
#                                                                                                                #
#                                                                                              #-----------------#
# To test it, cut and paste this line in your shell:                                           #
# echo `date "+%a %b %e %T %Y"` STAFF: \"Testing. Works!\" >> /glftpd/ftp-data/logs/glftpd.log #
#                                                                                              #
#--[ Crontabbing ]-------------------------------------------------------------#---------------#
#                                                                              #
# This dosnt read the log in realtime. It does it in intervals. How often is   #
# depending on how often you crontab it. To run it every 10 minutes, add this  #
# to your crontab: */10 * * * * /path_to/tur-reporter.sh                       #
#                                                                              #
#--[ Configuration ]-----------------------------------------------------------#


CHECKER="
/var/log/messages^hd[a-z]|sd[a-z]
/var/log/3dmExtLog^WARNING\:|INFORMATION\:
"

LINES=20

GLLOG=/glftpd/ftp-data/logs/glftpd.log
TMP=/tmp

proc_log() {
  echo `date "+%a %b %e %T %Y"` STAFF: \"$*\" >> $GLLOG
}


#--[ Script Start ]------------------------------------------------------------#

for rawdata in $CHECKER; do
  file_to_check="`echo "$rawdata" | cut -d '^' -f1`"

  if [ "$file_to_check" = "$GLLOG" ]; then
    echo "Error. Cant specify glftpd.log to check.. think loooooop"
    exit 1
  fi

  egrep_for="`echo "$rawdata" | cut -d '^' -f2-`"
  
  if [ ! -e "$file_to_check" ]; then
    proc_log "Error. Cant read $file_to_check - Skipping."
  else
    for each in `tail -n$LINES $file_to_check | tr -s ' ' '~'`; do
      if [ "`echo "$each" | egrep "$egrep_for"`" ]; then
        real_each="`echo "$each" | tr '~' ' '`"
        if [ -e "$TMP/tur-reporter.tmp" ]; then
          if [ -z "`grep "^$real_each$" $TMP/tur-reporter.tmp`" ]; then
            proc_log "$real_each"
            echo "$real_each" >> "$TMP/tur-reporter.tmp"
          fi
        else
          proc_log "$real_each"
          echo "$real_each" >> "$TMP/tur-reporter.tmp"
        fi
      fi
    done
  fi
done

exit 0           
