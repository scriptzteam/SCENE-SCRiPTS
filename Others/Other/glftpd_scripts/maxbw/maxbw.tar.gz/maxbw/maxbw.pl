#!/usr/bin/perl

## Little script that shows users max bw and when that was reached.
## This script is depending on the binary "sitewho", so please
## have that in your /glftpd/bin
##
## Remember that you need to create /glftpd/ftp-data/logs/bw.log
## and chmod it 777.
##
## Its a good idea to move me (maxbw.pl) to /glftpd/bin if you
## whant the .tcl to work without modifications.
##
## Its a good idea to run this script crontabbed every 5 minute
## or so, then it will post a new record automaticly in channel.
##
## If you want your bot to output data, then you must configure
## your dZbot.tcl (or whatever botscript your using)
##
## The .tcl that comes with this package enables the !sitemaxbw
## trigger and will (with some help of dZbot.tcl) post site records
## into the channel.

## Where is your sitewho binary?
$sitewho = "/glftpd/bin/sitewho";

## Wheres youre glftpd.log?
$glftpdlog = "/glftpd/ftp-data/logs/glftpd.log";

## Wheres bw.log?
$bwlog = "/glftpd/ftp-data/logs/bw.log";

### Okok lets go!

print "Trying $sitewho\n";
my $output = `$sitewho`;
my @fastest;
my $date = scalar localtime(time);	

if ($output) {

	print "Success!\n";
	@out = split(/\n/, $output);
	foreach $thing (@out) {

		@gay = split(/ +/, $thing);
		## Fastest user right now
		if ($gay[4] eq "Up:" or $gay[4] eq "Dn:") {
			$speed = $gay[5];
			$speed =~ s/KBs//;
			$speed =~ s/\./,/;
			if ($speed > $fastest[1]) {
				$fastest[0] = $gay[1];
				$fastest[1] = $speed;
				$fastest[2] = $gay[4];
				$fastest[2] =~ s/://;
				$fastest[2] =~ s/\n//;
			}
		}

		## Here I will find total
		if ($gay[1] eq "Up:" and $gay[6] eq "Dn:" and $gay[11] eq "Total:") {
			$upnum = $gay[2];
			$dnnum = $gay[7];
			$upsp = $gay[4];
			$dnsp = $gay[9];
			$totnum = $gay[12];
			$totsp = $gay[14];
		 	# Cleaning
			$totsp =~ s/kbs//;
			$upsp =~ s/kbs//;
			$dnsp =~ s/kbs//;
                        $totsp =~ s/\./,/;
                        $upsp =~ s/\./,/;
                        $dnsp =~ s/\./,/;

		}

	}
	
	## Ok, trying to see if this is a record of any kind
	open LOG, "< $bwlog" or die "Cant open your bw.log! ($bwlog)\n";
	@LOG = <LOG>;
	close LOG;

	($lnick, $lspeed, $ldir) = split(/\//, $LOG[0]);
	($ltotbw, $ltotup, $ltotdn) = split(/\//, $LOG[1]);

	## Cleaning
	$lnick =~ s/\n//;
	$lspeed =~ s/\n//;
	$ldir =~ s/\n//;
	$ltotbw =~ s/\n//;
	$ltotup =~ s/\n//;
	$ltotdn =~ s/\n//;

	if ($lspeed < $fastest[1]) {
		open GL, ">> $glftpdlog" or die "Cant open your glftpd.log! ($glftpdlog)\n";
		print GL "$date RECO: \"New \002speed record!\002 \002$fastest[0]\002 is setting a new record when going \002$fastest[1] kb/s\002, pushing $lnick at $lspeed kb/s of the chart!\"\n";	
		close GL;
		$lnick = $fastest[0];
		$lspeed = $fastest[1];
		$ldir = $fastest[2];
		$change = 1;
	}

	if ($ltotbw < $totsp) {
		open GL, ">> $glftpdlog" or die "Cant open your glftpd.log! ($glftpdlog)\n";
		print GL "$date RECO: \"New total \002bandwidth record!\002 Total speed is now \002$totsp kb/s\002, wich is faster than the old record $ltotbw kb/s\"\n";
		close GL;
		$ltotbw = $totsp;
		$change = 1;
	}


        if ($ltotup < $upsp) {
                open GL, ">> $glftpdlog" or die "Cant open your glftpd.log! ($glftpdlog)\n";
                print GL "$date RECO: \"New upload \002bandwidth record!\002 Combined upload speed is now \002$upsp kb/s\002, wich is faster than the old record $ltotup kb/s\"\n";
                close GL;
		$ltotup = $upsp;
		$change = 1;
        }

        if ($ltotdn < $dnsp) {
                open GL, ">> $glftpdlog" or die "Cant open your glftpd.log! ($glftpdlog)\n";
                print GL "$date RECO: \"New download \002bandwidth record!\002 Combined download speed is now \002$dnsp kb/s\002, wich is faster than the old record $ltopdnkb/s\"\n";
                close GL;
		$ltotdn = $dnsp;
		$change = 1;
        }

	## Printing to logfile if any change were made
	if ($change) {
		print "Updating with new record\n";
		open LOG, "> $bwlog" or die "Couldnt open $bwlog!\n";
		print LOG "$lnick/$lspeed/$ldir\n";
		print LOG "$ltotbw/$ltotup/$ltotdn";
		close LOG;
	}

	if ($ARGV[0] eq "scan") {
		open GL, ">> $glftpdlog" or die "Cant open your glftpd.log! ($glftpdlog)\n";
		print GL "$date RECSCAN \"\002Fastest user\002 right now is: $fastest[0] @ $fastest[1] $fastest[2]\" \"\002Previous speed records\002 for this site was( Up: $ltotup / Dn: $ltotdn / Total: $ltotbw)\" \"\002Fastest user ever\002 was: $lnick with $lspeed going $ldir\"\n"; 
		print "Added scan to glftpd.log\n";
	}

} else {

	print "Failed, try setting your sitewho path\n";

}
