#!/bin/bash

#<dnmp3pre.sh> by dn (#glftpd@efnet) (based on pre-dator.sh by SlaSk and Noctural)
#<September 8th, 2001
#Please direct any questions, comments, ideas or bugs to dn@blaze.ca

#VARIABLES
# Site Name Short, usually the abbreviate of your site name
sns="SNS"

# Enter your username and email address, use for contact info if 
# an error is displayed when executing a pre.  If you don't wish
# your contact information displayed on an error message, set these
# to some default value, they can not be blank.
siteop="dn"
email="dn@blaze.ca"

# Path to where your mp3 dated dirs are located, no trailing /
incoming="/site/Incoming"

# This is the log that dnmp3pre will record the pre information,
# most users will not want to change this as most bots only post
# data from this log
log="/ftp-data/logs/glftpd.log" 

# If you run two pre scripts, say this one for mp3 and another one
# for 0day etc then you may want to change the tag so you can
# specify your bot to scan for a different pre line
logtag="PRE:"

# This option enables the logging of mp3 bitrate, genre, year and mode.
# This information can then be used by your bot in your pre post.  If
# this option is disabled blank fields will be echo'd to the log file
mp3info="1"

# One line per group that may pre.
# Format "<group>:<dir group may pre from>:<username in log>:<group in log>:<unfo in log>"
data[0]="GROUP1:/site/PRE/Groups/GROUP1:GROUP1-PRE:GROUP1:GROUP1_PRE_MACHINE"
data[1]="GROUP2:/site/PRE/Groups/GROUP2:GROUP2-PRE:GROUP2:GROUP2_PRE_MACHINE"

# "vfreespace" and "incdev" need a file in /glftpd/etc called mtab.  In this file
# you must cut/paste from your /etc/fstab the device you set incdev to.  This
# should be your incoming device.  You must change the path to one that would be 
# found under a chroot environment.  A default mtab is included in this package
vfreespace="1"     #Verify there is freespace before executing the pre
incdev="/dev/hda1" #Your incoming device (/dev/hda1 etc).  Must be set for the
                   #verification of freespace to work.

vcomplete="1"      #Verify the release is complete before executing the pre

# "vcompletetag" must be set to something unique in your complete tag.  This
# is what will be searched for in order to verify a dir is complete, it is also
# needed to verify the sfv/nfo/multnfo/m3u exist.  This is case sensitive.  
# For now this only works with directories that are created as tags.  This
# can not be blank, if you don't use complete tags, then make this something
# that is highly unlikely to ever match.
# Complete Tag Example:
# ex: -[iP-MP3]-[100%]-[192kbps-Rock-2001]-[iP-MP3]-
# In the example above, I would choose "100%" as the string to search for.
# Unlikely Match Example:
# vcompletetag="servukicksmajorass"
vcompletetag="100%"

# "vdupe" and "updupelog" both require the "dupelog" to be set in order to work
vdupe="1"          #Search the dupelog for the pre before executing the pre
updupelog="1"	   #Update the dupelog

# Most users will not need to change this unless they use a different dupelog
# than glftpd uses by default.
dupelog="/ftp-data/logs/dupelog"

# The "vsfv", "vnfo", "vmultnfo" and "vm3u" all need the "vcompletetag" to
# be set.
vsfv="1"           #Verify an sfv exists before executing the pre
vnfo="1"           #Verify an nfo exists before executing the pre
vmultnfo="1"       #Disallow the pre if multiple nfo's are found
vm3u="1"           #Verify an m3u exists before executing the pre
updirlog="1"	   #Update the glftpd dirlog (requires pre_dirlog binary)
updupefile="1"     #Update the glftpd dupefile (requires pre_dupe binary)

#----------------------------------------------------------------------------#
#DO NOT EDIT THE BELOW
ver="dnmp3pre v1.08"

echo "[$sns] MP3 PRE System [$sns]"
echo ""

#Check the $siteop variable has been set
[ -z "$siteop" ] && {
    echo "ERROR: The option \"siteop\" has not been set.  Please contact"
    echo "the siteop and mention this error so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Check the $email variable has been set
[ -z "$email" ] && {
    echo "ERROR: The option \"email\" has not been set.  Please contact"
    echo "$siteop on IRC and mention this error so it can be fixed."
    echo "..:    $ver    :.."       
    exit 0
}

BINS="echo date du cut ls wc tr grep fgrep head cp rm df sort uniq find"

missingbin=0
for bin in $BINS; do
    type "$bin" > /dev/null 2>&1 || {
        echo "ERROR : Could not find the required binary '$bin'"
        missingbin=1
    }
done
[ "$missingbin" = "1" ] && {
    echo "Please contact $siteop on IRC or send an email to"
    echo "$email and mention this error so it"
    echo "can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Check the $incoming variable has been set and that the directory exists
[ -z "$incoming" -o ! -d "$incoming" ] && {
    echo "ERROR: The option \"incoming\" has not been set or the path"
    echo "can't be found, please contact $siteop on IRC or send an"
    echo "email to $email and mention this error so"
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Check that the $incoming variable does not end with a trailing / as this may
#cause the script to fail
[ -n "$(echo "$incoming" | grep -E "/$")" ] && {
    echo "ERROR: The option \"incoming\" has been set incorrectly"
    echo "due to the trailing \"/\".  Please contact $siteop on IRC"
    echo "or send an email to $email and mention this error"
    echo "so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Check that the $log variable has been set and that the log exists
[ -z "$log" -o ! -e "$log" ] && {
    echo "ERROR: The option \"log\" has not been set or the log"
    echo "can't be found, please contact $siteop on IRC or send an"
    echo "email to $email and mention this error so"
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Check that the $logtag variable has been set and that it ends with a ":" and
#that it contains no spaces
[ -z "$logtag" -o -n "$(echo "$logtag" | grep -E " ")" -o -z "$(echo "$logtag" | grep -E ":$")" ] && {
    echo "ERROR: The option \"logtag\" has not been set or has been"
    echo "set incorrectly either do to it containing spaces or not"
    echo "ending with a \":\", please contact $siteop on IRC or send an"
    echo "email to $email and mention this error so"
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If the $mp3info variable is set to 1, then ensure it exists and is the right
#version
[ "$mp3info" = 1 ] && {
    { [ -e "/bin/mp3info" ] && mp3info 2>/dev/null | grep "0.8.2" > /dev/null; } || {
        echo "ERROR: The \"mp3info\: option is enabled but the mp3info"
        echo "binary either can't be found or is the wrong version."
        echo "Please contact $siteop on IRC or send an email to"
        echo "$email and mention this error so it can be fixed."
        echo "..:    $ver    :.."
        exit 0
    }
}

#If the $vfreespace variable is set to 1, then ensure the $incdev variable
#has been set
[ "$vfreespace" = "1" -a -z "$incdev" ] && {
    echo "ERROR: The \"vfreespace\" option is enabled but the"
    echo "\"incdev\" option has not been set.  Please contact"
    echo "$siteop on IRC or send an email to $email"
    echo "and mention this error so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If the $vfreespace variable is set to 1, then ensure /etc/mtab exists
[ "$vfreespace" = "1" -a ! -e "/etc/mtab" ] && {
    echo "ERROR: The \"vfreespace\" option is enabled but the"
    echo "\"/etc/mtab\" file can't be found.  Please contact"
    echo "$siteop on IRC or send an email to $email"
    echo "and mention this error so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#Ensure the $incdev is found in /etc/mtab
[ -z "$(grep -E "^$incdev" /etc/mtab)" ] && {
    echo "ERROR: The \"vfreespace\" option is enabled but"
    echo "\"$incdev\" can't be found in the \"/etc/mtab\" file,"
    echo "please contact $siteop on IRC or send an email to"
    echo "$email and mention this error so it can"
    echo "be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If either the $vcomplete, $vsfv, $vnfo, $vmultnfo, $vm3u variable is set to 1,
#then ensure the $vcompletetag has been set
[ "$vcomplete" = 1 -o "$vsfv" = 1 -o "$vnfo" = 1 -o "$vmultnfo" = 1 -o "$vm3u" = 1 ] && [ -z "$vcompletetag" ] && {
    echo "ERROR: Option(s) are enabled that require the"
    echo "\"vcompletetag\" option to be set.  Please contact"
    echo "$siteop on IRC or send an email to $email"
    echo "and mention this error so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If the $vdupe or $updupelog variables are set to 1, then ensure the $dupelog
#variable has been set and can be found
[ "$vdupe" = "1" -o "$updupelog" = "1" ] && [ ! -e "$dupelog" ] && {
    echo "ERROR: The \"vdupe\" or \"updupelog\" option is enabled, but"
    echo "the \"dupelog\" option has not been set or the log can't"
    echo "be found, please contact $siteop on IRC or send an"
    echo "email to $email and mention this error so"
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If the $updirlog variable is set to 1, then ensure we can locate /bin/pre_dirlog
[ "$updirlog" = "1" -a ! -e "/bin/pre_dirlog" ] && {
    echo "ERROR: An option is enabled which needs to use the \"pre_dirlog\""   
    echo "binary and it can't be found.  Please contact $siteop on"
    echo "IRC or send an email to $email and mention this error so" 
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

#If the $updupefile variable is set to 1, then ensure we can locate /bin/pre_dupe
[ "$updupefile" = "1" -a ! -e "/bin/pre_dupe" ] && {
    echo "ERROR: An option is enabled which needs to use the \"pre_dupe\""   
    echo "binary and it can't be found.  Please contact $siteop on"
    echo "IRC or send an email to $email and mention this error so" 
    echo "it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

[ ! -e /ftp-data/users/$USER ] && {
    echo "ERROR: I couldn't find user info for $USER"
    echo "Please contact $siteop on IRC or send an email"
    echo "to $email and mention this error so it can be fixed."
    echo "..:    $ver    :.."
    exit 0
}

[ -z "$1" ] && {
    echo "ERROR: It looks like you forgot to include the dir to pre!" 
    echo "Usage: SITE PRE <dir>"
    echo "..:    $ver    :.."
    exit 0
}

today=`date +%m%d`
groups="$(grep -wE "^GROUP|^PRIVATE" /ftp-data/users/$USER | cut -d' ' -f2)"
group_match_flag=0
i=0

while [ -n "${data[$i]}" ]; do 
    group=$(echo ${data[$i]} | cut -d ':' -f1)
    dir=$(echo ${data[$i]} | cut -d ':' -f2)
    user=$(echo ${data[$i]} | cut -d ':' -f3)
    grp=$(echo ${data[$i]} | cut -d ':' -f4)
    unfo=$(echo ${data[$i]} | cut -d ':' -f5)

    echo -n "$groups" | fgrep -q "$group" || { i=$[i+1]; continue; }
    echo "Verifying your group ............... PASSED"
    group_match_flag=1
    echo -n "$PWD" | fgrep -q "$dir" || { i=$[i+1]; continue; }

        if [ -e "$PWD/$1" ] ; then
            [ "$vfreespace" = "1" ] && {
                echo -n "Verifying free space ............... "
    		relsize="$(du -s -m $1 | cut -f1)"
                incsf=$(df -m | while read dev a b free c; do [ "$dev" = "$incdev" ] && { echo $free; break; }; done)
                    [ "$incsf" -lt "$relsize" ] && {
                        echo "NOT ENOUGH FREESPACE"
                        echo "There is currently not enough freespace,"
                        echo "if this seems to be incorrect, contact"
                        echo "$siteop or send an email to $email"
                        echo "or try again later."
                        echo "..:    $ver    :.."
                        exit 0
                    }
                echo "PASSED"     
            }

            [ "$vdupe" = "1" ] && {
                echo -n "Searching dupelog for the pre ...... "
                dupe=$(grep $1 $dupelog)
                    [ -n "$dupe" ] && {
	                echo "FOUND!!!"
                        echo "This looks like a dupe, dupelog return:"
                        echo "\"$dupe\""
                        echo "If this is incorrect, please contact $siteop"
                        echo "or send an email to $email"
                        echo "..:    $ver    :.."
                        exit 0
                    }
                echo "PASSED"
            }

            [ "$vcomplete" = "1" ] && {
  	        echo -n "Verifying release is complete ...... "	
                subs=$(ls -lA $1 | grep -E "^d" | grep -vE "$vcompletetag" | wc -l | tr -d ' ')
                    if [ "$subs" -eq 0 ]; then
                        [ -z "`ls -d $1/*"$vcompletetag"* 2>/dev/null`" ] && {
                            echo "NOT COMPLETE!!!"
                            echo "If this release is complete, please"
                            echo "contact $siteop or send an email to"
                            echo "$email"
                            echo "..:    $ver    :.."
                            exit 0
                        }
                    else
                        for subdir in `ls -A $1`; do
                            [ -z "`ls -d $1/$subdir/*"$vcompletetag"* 2>/dev/null`" ] && {
                                echo "$subdir NOT COMPLETE!!!"
                                exit 0
                            }
                        done
                    fi
	        echo "COMPLETE"
            }

            [ "$vsfv" = "1" ] && echomsg="$echomsg sfv "
            [ "$vnfo" = "1" ] && echomsg="$echomsg nfo "
            [ "$vm3u" = "1" ] && echomsg="$echomsg m3u"
            echomsg=$(echo $echomsg | tr ' ' '/')
            [ ${#echomsg} -eq 3 ] && echomsg="$echomsg ......... FOUND: "
            [ ${#echomsg} -eq 7 ] && echomsg="$echomsg ..... FOUND: "
            [ ${#echomsg} -eq 11 ] && echomsg="$echomsg . FOUND: "

            [ -n "$echomsg" ] && {
                echo -n "Verifying existance of $echomsg"
                subs=$(ls -lA $1 | grep -E "^d" | grep -vE "$vcompletetag" | wc -l | tr -d ' ')
                [ "$vsfv" = "1" ] && {
                    if [ "$subs" -eq 0 ]; then
                        [ -z "`ls $1/*.[Ss][Ff][Vv] 2>/dev/null | head -1`" ] && {
                            echo ""
                            echo ""
                            echo "NO SFV FOUND!!!"
                            echo ""
                            echo "If there is an sfv file present, please"
                            echo "contact $siteop or send an email to"
                            echo "$email"
                            echo "..:    $ver    :.."
                            exit 0
                        }
                    else
                        for subdir in `ls -A $1`; do
                            [ -z "`ls $1/$subdir/*.[Ss][Ff][Vv] 2>/dev/null`" ] && {
                                echo ""
                                echo ""
                                echo "$subdir: NO SFV FOUND!!!"
                                echo ""
                                echo "If there is an sfv file present, please"
                                echo "contact $siteop or send an email to"
                                echo "$email"
                                echo "..:    $ver    :.."
                                exit 0
                            }
                        done
                    fi       
	            echo -n "SFV(s) "
                }

                [ "$vnfo" = "1" ] && {
                    if [ "$subs" -eq 0 ]; then
                        [ -z "`ls $1/*.[Nn][Ff][Oo] 2>/dev/null | head -1`" ] && {
                            echo ""
                            echo ""
                            echo "NO NFO FOUND!!!"     
                            echo ""
                            echo "If there is an nfo file present, please"
                            echo "contact $siteop or send an email to"
                            echo "$email"
                            echo "..:    $ver    :.."
                            exit 0
                        }
                    else
                        for subdir in `ls -A $1`; do
                            [ -z "`ls $1/$subdir/*.[Nn][Ff][Oo] 2>/dev/null`" ] && {
                                echo ""
                                echo ""
                                echo "$subdir: NO NFO FOUND!!!"     
                                echo ""
                                echo "If there is an nfo file present, please"
                                echo "contact $siteop or send an email to"
                                echo "$email"
                                echo "..:    $ver    :.."
                                exit 0
                            }  
                        done
                    fi
                    echo -n "NFO(s) "
                }

                [ "$vm3u" = "1" ] && {
                    if [ "$subs" -eq 0 ]; then
                        [ -z "`ls $1/*.[Mm][3][Uu] 2>/dev/null | head -1`" ] && {
                            echo ""
                            echo ""
                            echo "NO M3U FOUND!!!"     
                            echo ""
                            echo "If there is an m3u file present, please"
                            echo "contact $siteop or send an email to"
                            echo "$email"
                            echo "..:    $ver    :.."
                            exit 0
                        }
                    else
                        for subdir in `ls -A $1`; do
                            [ -z "`ls $1/$subdir/*.[Mm][3][Uu] 2>/dev/null`" ] && {
                                echo ""
                                echo ""
                                echo "$subdir: NO M3U FOUND!!!"     
                                echo ""
                                echo "If there is an m3u file present, please"
                                echo "contact $siteop or send an email to"
                                echo "$email"
                                echo "..:    $ver    :.."
                                exit 0
                            }  
                        done
                    fi
                    echo "M3U(s)"
                }
            }

            [ "$vmultnfo" = "1" ] && {
                echo -n "Verifying single nfo(s) per dir .... "
                if [ "$subs" -eq 0 ]; then
                    [ "$(ls $1/*.[Nn][Ff][Oo] 2>/dev/null | wc -l | tr -d ' ')" -gt "1" ] && {
                        echo "FAILED"
                        echo ""
                        echo "MULTIPLE NFO'S FOUND!!!"
                        echo ""
                        echo "There seems to be more than one nfo file,"
                        echo "please remove them and try again.  If"
                        echo "this is correct, please contact $siteop or"
                        echo "send an email to $email"
                        echo "..:    $ver    :.."
                        exit 0
                    }
                else
                    [ "$(ls -R $1/* | grep -iE "\.nfo$" | wc -l | tr -d ' ')" -gt "$subs" ] && {
                        for subdir in `ls -A $1`; do 
                            [ "$(ls $1/$subdir/*.[Nn][Ff][Oo] 2>/dev/null | wc -l | tr -d ' ')" -gt "1" ] && {
                                echo "FAILED"
                                echo ""
                                echo "$subdir: MULTIPLE NFO'S FOUND!!!"
                                echo ""
                                echo "There seems to be more than one nfo file,"
                                echo "please remove them and try again.  If"
                                echo "this is correct, please contact $siteop or"
                                echo "send an email to $email"
                                echo "..:    $ver    :.."
                                exit 0
                            }
                        done
                    }
                fi
                echo "PASSED"
            }

            echo ""      
            echo "ALL SYSTEMS GO FOR PRE!!!"
            echo ""

            #echo setup tag info to post to log
            disks="$(ls -R $1/* 2>/dev/null | grep -iE "\.mp3$" | wc -l | tr -d ' ')"

            [ "$mp3info" = "1" ] && {
                mp3=$(find $1 2>/dev/null | grep -iE "\.mp3$" | head -1)
                mp3br="$(mp3info -p "%r" $mp3)"
                mp3genre="$(mp3info -p "%g" $mp3 | tr ' ' '_')"
                mp3year="$(mp3info -p "%y" $mp3)"
                mp3mode="$(mp3info -p "%o" $mp3 | tr ' ' '_')"
            }

            echo "Copying the pre, please be patient..."
	    cp -R $1 $incoming/$today
	    rm -rf $1

            [ "$updupelog" = "1" ] && {
                #echo "Updating dupelog"
                echo "`date "+%m%d%y"` $1" >> $dupelog
            }

            #echo "Updating glftpd.log"
            echo "`date "+%a %b %d %T %Y"` "$logtag" \"$incoming/$today/$1\" \"$grp\" \"$relsize\" \"$disks\" \"sfvdirs\" \"$user\" \"$unfo\" \"$USER\" \"$mp3br\" \"$mp3genre\" \"$mp3year\" \"$mp3mode\"" >> $log
 
            [ "$updirlog" = "1" ] && {
                #echo "Updating dirlog"
                pre_dirlog $incoming/$today/$1
            }

            [ "$updupefile" = "1" ] && {
                #echo "Updating dupefile"
                    uploader=$(ls -lAR $incoming/$today/$1 | grep -iE "\.mp3$" | head -1 | tr -s ' ' | cut -d ' ' -f3)
                    for file in `ls -lAR $incoming/$today/$1 | grep -iE "^\-" | tr -s ' ' | cut -d ' ' -f9 | grep -viE "^\.|\.nfo$" | sort | uniq`; do
                        pre_dupe "$file" "$uploader" /ftp-data
                    done
            }   

            echo "PRE Completed Successfully, Thanks $group"
            echo "..:    $ver    :.."
		    exit 0
	else
            echo ""
            echo "ERROR: \""$1"\" can't be found,"
            echo "Please make sure you are spelling the pre"
            echo "correctly, using the right case and that you"
            echo "are in the root of your pre dir and try again"
            echo "..:    $ver    :.."
	    exit 0
	fi
    i=$[i + 1]
done

if [ $group_match_flag -eq 1 ]; then
    echo "ERROR: You are either not in the root of your pre dir"
    echo "or your pre dir has been set incorrectly.  Please"
    echo "contact $siteop on IRC or send an email to"
    echo "$email and mention this error if it persists."
    echo "Usage: SITE PRE <dir>"
    echo "..:    $ver    :.."
    exit 0
else
    echo "Verifying your group ............... FAILED"
    echo ""
    echo "Please contact $siteop on IRC or send an email to"
    echo "$email and mention this error so it can"
    echo "be fixed."
    echo "..:    $ver    :.."
    exit 0
fi
