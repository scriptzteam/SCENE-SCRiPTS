// Most of this is ripped from GreyLine's code from glftpd
#include <string.h>
#include <stdio.h>
#include <sys/param.h>

struct dupefile {
  char filename[256];
  time_t timeup;
  char uploader[25];
};

main(int argc, char *argv[]) {
  FILE *dfile;
  uid_t oldid = getuid();
  char dupepath[MAXPATHLEN];
  struct dupefile dupeentry;
  char filename[256];
  char uploader[25];

  if (argc < 3) {
    printf("Usage: %s filename uploader [/glftpd/ftp-data]\n", argv[0]);
    return;
  }
  if (argc < 4)
    strcpy(dupepath, "/glftpd/ftp-data");
  else 
    strncpy(dupepath, argv[3], sizeof(dupepath)-15);
  strcat(dupepath, "/logs/dupefile");
  strncpy(filename, argv[1], sizeof(filename));
  strncpy(uploader, argv[2], sizeof(uploader));

  seteuid(0);
  if((dfile = fopen(dupepath, "r+b")) == NULL) {
    printf("Unable to open %s\n", dupepath);
    return 0;
  }
  while (!feof(dfile)) {
    if (fread(&dupeentry, sizeof(struct dupefile), 1, dfile) < 1)
      continue;
  }
  dupeentry.timeup = time(NULL);
  strncpy(dupeentry.uploader, uploader, 23);
  strncpy(dupeentry.filename, filename, 254);
  fwrite(&dupeentry, sizeof(struct dupefile), 1, dfile);
  fflush(dfile);
  fclose(dfile);
}
