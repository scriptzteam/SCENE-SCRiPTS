#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <paths.h>

struct passwd *pw;
struct passwd *sgetpwnam(char *name);
char *sgetsave (char *s);

int main(int argc, char *argv[])
{
	char passwd[BUFSIZ];
	char *xpasswd;
	char *salt;
	register char cp;
	char user[BUFSIZ];

	if (argc < 3) {
		printf("GLFTPD Password Checker\n\n");
		printf("Location of password file is expected to be...\n");
		printf("/glftpd/etc/passwd\n\n");
		printf("Usage: \n%s user password\n", argv[0]);
		exit(1);
	}
	strncpy(user, argv[1], sizeof(user));
	strncpy(passwd, argv[2], sizeof(passwd));
	chroot("/glftpd");

	if (!(pw = sgetpwnam(user))) {
		printf("User (%s) not found.\n", user);
		pw = (struct passwd *) NULL;
		exit (1);
	}
	salt = pw->pw_passwd;
	xpasswd = (char *)crypt(passwd, salt);

	if ((pw == NULL) || *pw->pw_passwd == '\0' ||
			strcmp(xpasswd, pw->pw_passwd)) {
		printf("NO MATCH!\n");
		exit (1);
	}
	printf("MATCH!\n");
	exit(0);
}

/***************************************************************************
	SGETPWNAM
****************************************************************************/
struct passwd *
sgetpwnam( char *name)
{
	static struct passwd save;
	register struct passwd *p;
	char *sgetsave();

	if ( (p = getpwnam(name)) == NULL)
	{
		printf("(%s) unknown.\n",name);
		return(p);
	}
	if (save.pw_name)
	{
		free(save.pw_name);
		free(save.pw_passwd);
		free(save.pw_gecos);
		free(save.pw_dir);
		free(save.pw_shell);
	}
	save = *p;
	save.pw_name = sgetsave(p->pw_name);
	save.pw_passwd = sgetsave(p->pw_passwd);
	save.pw_gecos = sgetsave(p->pw_gecos);
	save.pw_dir = sgetsave(p->pw_dir);
	save.pw_shell = sgetsave(p->pw_shell);

	return (&save);
}
/***************************************************************************
	SGETSAVE
****************************************************************************/
char *
sgetsave( char *s)
{
	char *new = malloc( (unsigned)strlen(s) + 1 );
	if (new == NULL)
	{
		printf("Out of memory error.\n");
		exit (1);
	}
	(void)strcpy(new,s);
	return(new);
}
/* END */
