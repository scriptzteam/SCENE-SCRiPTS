echo -e  "`ls $1 | grep -v staff | awk '{ print $1 "" }' | tr '\012' ' '`"
exit