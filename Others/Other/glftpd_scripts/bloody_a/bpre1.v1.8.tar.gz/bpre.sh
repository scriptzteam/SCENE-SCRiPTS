#!/bin/bash
#NOTE: All files specified here are in a chrooted envoirement
#      so leave out the root-path.

# BPre configuration file
preconfig=/etc/bpre.conf

# BPre binary
prebin=/bin/bpre

###########################
###########################

if [ -z "$1" ] ; then
	$prebin -r $preconfig -p $PWD 
	echo "BPre: Usage: SITE PRE <dir> <section>"
	exit
fi

if [ -z "$2" ] ; then
	$prebin -r $preconfig -p $PWD -s $1
	echo "BPre: Usage: SITE PRE <dir> <section>" 
	exit
fi

$prebin -r $preconfig -p $PWD -s $1 -d $2
