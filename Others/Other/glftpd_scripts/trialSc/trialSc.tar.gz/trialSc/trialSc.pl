#!/usr/bin/perl
##
## Trial script made by pnG
## Monitors new users and msg siteop/deletes them as they dont succeed
## Its a good idea to run this script crontabed to match the minimum setting.
##
## For example:
##   If you have monthup as your setting, run this script once in the end of every month
##   If you have weekup as your setting, run this script once every sunday
##
## Its all in the README that came with this package. Please read that.
## If you have any questions, ask pnG on efnet in #getnfoscript
##
## // pnG 

############
# Settings #
##################################
## glftpd dir? 			##
##################################
$gldir = "/glftpd";

##################################
## Group to monitor		##
##################################
$group = "trial";

##########################################
## Minimum what (weekup/dayup/monthup)	##
##########################################
$minimum = "monthup";

############################################
## How many mBytes is the minimum upload? ##
############################################
$mBytes = "2000";

#############################################
## If I find idle user, do what? (msg/del) ##
#############################################
$action = "del";

###################
## Who do I msg? ##
###################
$siteop = "png";

##########################[ Thats all, now watch the magic ]##

print "-- TrialScript by pnG --\n\n";
$date = scalar localtime(time);
$cnt = 0;
opendir(DIR, "$gldir/ftp-data/users");
my @files = readdir(DIR);
for my $file (@files) {

        $readfile = "$gldir/ftp-data/users/$file";
        open(INFO, $readfile) or die "Cant open $readfile stupid!\n";
        @lines = <INFO>;
        close(INFO);
        foreach $thing (@lines) {
		if ($thing =~ /GROUP (\w*)/) {
			if ($group eq $1) {
				foreach $thing (@lines) {
					## Checking monthup
					if ($minimum eq "monthup") {
						if ($thing =~ /MONTHUP (\d*) (\d*) (\d*)/) {
							$up = $2 / 1024^2;
							print "User $file \@ $group has: $up Mbytes $minimum\n";
							if ($up < $mBytes) {
								print "User didnt pass trial\n\n";
								$userArry[$cnt] = $file;
								$cnt++;
							} else {
								print "User passed trial\n\n"
							};
						};
					};
					## Checking dayup
                                        if ($minimum eq "dayup") {
                                                if ($thing =~ /DAYUP (\d*) (\d*) (\d*)/) {
                                                        $up = $2 / 1024^2;
                                                        print "User $file \@ $group has: $up Mbytes $minimum\n";
                                                        if ($up < $mBytes) {
                                                                print "User didnt pass trial\n\n";
                                                                $userArry[$cnt] = $file;
                                                                $cnt++;
                                                        } else {
                                                                print "User passed trial\n\n"
                                                        };
                                                };
                                        };
                                        ## Checking weekup
                                        if ($minimum eq "weekup") {
                                                if ($thing =~ /WKUP (\d*) (\d*) (\d*)/) {
                                                        $up = $2 / 1024^2;
                                                        print "User $file \@ $group has: $up Mbytes $minimum\n";
                                                        if ($up < $mBytes) {
                                                                print "User didnt pass trial\n\n";
                                                                $userArry[$cnt] = $file;
                                                                $cnt++;
                                                        } else {
                                                                print "User passed trial\n\n"
                                                        };
                                                };
                                        };

				};
			};
		};
	};

};

if ($action eq "msg") {	
	$msg = "!HFrom: !CtrialScript !H(!C$date!H)!0\n--------------------------------------------------------------------------\n";
	foreach $thing (@userArry) {
		$msg .= "!H$thing didnt make $minimum of trial.!0\n";
	};
	$msg .= "\n";
	open MSG, ">> $gldir/ftp-data/msgs/$siteop" or die "Cant open $siteop msg file!\n";
        print MSG $msg;
        close MSG;
};

if ($action eq "del") {
        $msg = "!HFrom: !CtrialScript !H(!C$date!H)!0\n--------------------------------------------------------------------------\n";	
	foreach $thing (@userArry) {
	        $usrfile = "$gldir/ftp-data/users/$thing";
        	open(INFO, $usrfile) or die "Cant open $usrfile\n";
       		@lines = <INFO>;
        	close(INFO);
        	foreach (@lines) {s/FLAGS (\d*)/FLAGS 6/};
        	open USERFILE, "> $gldir/ftp-data/users/$thing";
        	@file = <USERFILE>;
        	print USERFILE @lines;
        	close USERFILE;
		$msg .= "!H$thing didnt make $minimum of trial. Deleted him!0\n";
	};
        $msg .= "\n";
        open MSG, ">> $gldir/ftp-data/msgs/$siteop" or die "Cant open $siteop msg file!\n";
        print MSG $msg;
        close MSG;

};

print "DONE! Scanned for:\n";
print "Users in: $group\n";
print "With a minimum of $mBytes on $minimum\n\n";

