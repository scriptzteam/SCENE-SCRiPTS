#!/bin/sh
# ^-- You can script in any shell you want; the environment variables are there for you. :)

#uncomment the next line to see all the environment variables
#export

#here are the variables that vCheck creates and a brief summary for each:
#$required_filesA	:A list of file names (zip/rar/ace) delimited by whitespaces that are
#			 derived from either the sfv or assumed for zip files.  example:
#			 -> "moo1.rar moo1.r00 moo2.r01"
#$required_filesB	:The quantity of required files based on required_filesA.  example:
#			 -> 3
#$missing_filesA	:A list of file names just like required_filesA but those files which
#			 have not been found in the .crc dir (i.e. they are missing!).  example:
#			 -> "moo.rar moo.r01"
#$missing_filesB	:The quantity of missing files based on missing_filesA.  example:
#			 -> 2
#$current_filesA	:A list of file names derived from the release's dir.  These files may
#			 or may not have passed the crc yet because they may be in the middle
#			 of being uploaded.  example:
#			 -> "moo.r00"
#$current_filesB	:The quantity of current files based on current_filesA.  example:
#			 -> 1
#$completed_files	:The quantity of files that have in fact passed crc and are the "true"
#			 current_files.  example
#			 -> 0
#$release_percent	:The percentage of how complete the release is derived from
#			 (completed_files / required_files).  example:
#			 -> 69.69
#$release_size		:The total size of the release thus far (in kBytes) based on the
#			 current_files.  example:
#			 -> 13000.23
#$uwon_tag		:The current user-winner's tagline.  example:
#			 -> "here is my elite tagline"
#$users			:The total amount of user-racers.  example:
#			 -> 1
#$uracers		:A very long string delimited twice.  The "outter" delimiter is
#			 whitespaces, and within that a string is delimited by colons (`:').
#			 The format is as follows: "kBytes:username:groupname:files:percentage".
#			 kBytes=how many kilobytes the user has uploaded; username=his/her name;
#			 groupname=his/her group; files=how many files has the user uploaded;
#			 percentage=what percentage of the current kBytes does the user
#			 contribute for.  Not surprisginly, the entries separated by the
#			 whitespaces are in descending order based on kBytes.  example:
#			 -> "50298.23:moo:ADMIN:3:75.00 14982.69:vman:ADMIN:1:25.00"
#$gwon_tag		:The current group-winner's tagline.  example:
#			 -> "fear this group, ya babie!"
#$groups		:The total amount of group-racers.  example:
#			 -> 1
#$gracers>		:The same as $uracers except the format is as follows:
#			 "kBytes:groupname:files:percentage".  example:
#			 -> "75982.69:ADMIN:4:100.00"
#$race_duration		:How long (in minutes) since the first file and the last file have been
#			 uploaded.  example:
#			 -> 1.69
#$revision		:vCheck's current revision (version).  example:
#			 -> "01/01/2000"
#$sfv_date		:If found, the package date specified in the sfv in the form of
#			 MM/DD/YYYY.  example:
#			 -> "01/29/2000"
#$timelog		:The current time in 12-hour view with timezone.  example:
#			 -> "12:23PM EST"
#
#*Note*: Environment variables were created so vCheck can be more customizable.  The .message
#	 file stays static for now, but you can output whatever you want to your users and
#	 write to the logfile with whatever information you want to send to it.  If you come
#	 up with a nice template for outputting the race information and you don't mind giving
#	 it out, please submit it to me (vman@x3d.net)!  I'm looking for a nice, clean output
#	 of the data (not necessarily all of the data).
#	 The file requirements are whatever you choose to use; by default, you'll need:
#	 expr, echo, cut.  Have fun!




echo "||  -> $completed_files of $required_filesB uploaded at "$release_size"KB - "$release_percent"%%"
echo "||"

a=0
echo "||  -== Users ==-"
for stats in $uracers; do
  echo "||  #`expr $a + 1` - `echo $stats | cut -d : -f 2`@`echo $stats | cut -d : -f 3` - \
`echo $stats | cut -d : -f 4` files at `echo $stats | cut -d : -f 1`KB - \
`echo $stats | cut -d : -f 5`%%"
a=`expr $a + 1`
done
echo "||"

a=0
echo "||  -== Groups ==-"
for stats in $gracers; do
  echo "||  #`expr $a + 1` - `echo $stats | cut -d : -f 2` - `echo $stats | cut -d : -f 3` files at \
`echo $stats | cut -d : -f 1`KB - `echo $stats | cut -d : -f 4`%%"
a=`expr $a + 1`
done
echo ""

