#!/bin/sh
#  vCheck Copyright (C) 1999-2000, by vman (vman@x3d.net)
#  (pfft!  ya, copyright :P)
#
#  Compatible with glftpd-1.17.x and glftpd-1.18a (Linux)
#
#  vCheck Revision: 02/10/2000
#
#*DUMBO SANITY NOTES*
#For those that are completely computer-impaired -- `0' usually means 
#OFF/DISABLED.  Quotes, no quotes; it doesn't matter!  Well, quotes are needed 
#if your setting has whitespaces but if you set a variable at `"0"' or `0', it 
#will not matter (no, those single quotes are NOT part of it).  Final point: 
#when I say `/site/path/to' or `/bin/path/to', you understand that's not really 
#the path, right?  :o
#
###-[   Configuration   ]-######################################################
#[ PATHS, PATHS AND MORE PATHS!@#%!@$#%!$#@% ]
#`/site/path/to/users/'
usrdir="/ftp-data/users"

#`/ftp-data/path/to/glftpd.log'
gllog="/ftp-data/logs/glftpd.log"

#`0' or `/site/path/to/sfv_check'
sfv_check="/bin/sfv_check"

#`0' or `/bin/path/to/flysfv': this variable only matters if $sfv_check is 
#disabled.  you must have this enabled in glftpd.conf.  if both $sfv_check and 
#$flysfv are disabled, then you are using vCheck for race+completion.  this is 
#a good method to use if you want to do your own file integrity checking.
flysfv=0


#[ GENERAL COMPLETION STUFF ]
#`0' or the minimum number of disks a release must have to go through with 
#race+completion stats
required_amount=0

#`0' or `<dir name>': the dir name to create when a release has been completed 
#(this indirectly enables a progress dir to be made as well)
completion_dir="[_COMPLETE_]"


#[ SFV ]
#`0' or `1': post how complete a release is as users upload?  this accounts for 
#the progress dir and anything related to completion.  this also accounts for 
#sending the RACE: line to glftpd.log since it is only sent out when the 
#release is complete
sfv_completion=1

#`0' or `1': announce how many files are expected?
announce_sfv=1


#[ ZIPPIE ZIP ZIP ]
#`0' or `1': just like sfv completion, but for zip files.  if the total files 
#can be determined, it will go further to determine the "base file structure" 
#in order to post which files are missing! :)
zip_completion=1

#`0' or `1': announce how many files are expected if the total files can be 
#determined?
announce_zip=1

#`0' or `1': if disabled, zip integrity check will be skipped.
unzip=1

#`0' or `1': extract file_id.diz from zip files and put them in .message (above 
#raceinfo)?
getdiz=1

#`0' or `/some/path/to/your/comment.txt':  this adds a comment to zip files that 
#you receive (the little banner that scrolls as you unzip :))
comment=0

#`0' or `/some/path/to/your/site.nfo': this adds a file to the zip files you 
#receive (a super-duper-elite banner with your beautiful machine specifications 
#so you can be narced easier?)
sitenfo=0

#`/tmp/path/to/your/.missing': this holds a list of current incompletes.  if 
#you screw with the format of the file, it will go nuts :P.  just delete the 
#file and it'll make a new one.  the point of this file is to scroll it as 
#users switch dirs, so add a line in glftpd.conf such as: `msgpath /site/* 
#/tmp/path/to/your/dirmsg.txt' and/or add a `site_cmd' so you can SITE 
#INCOMPLETE and view the list...you get the idea :)
dirmsg="/tmp/.missing"


#[ MISC ]
#`0' or `1': is your glftpd NEWER THAN 1.17.3?
new_gl=1

#what dirs to ignore for completion but still sfv_check them.  this may be 
#useful for your grppaths because the bot will announce the completion of the 
#release whether you have dirlog set to `no' or `yes'.  the variable is colon-
#delimited, meaning, you enter in more than one path by placing a `:' in between 
#them (_not_ spaces).  cAsE matters. :)  you can use most of the regular 
#expression matching schemes, such as: `?' `*' `[pP][rR][eE][0-9]' `[a-zA-Z]'.
deny="/site/*/_*"

#`0' or `/bin/path/to/output/script.sh': enable environment variables? (if you 
#aren't going to use it, disable it!).  You may need extra external utils, so 
#read output.sh.
vars="/bin/output.sh"
################################################################################


#call the actual script and send in the variables (dont modify this :))
exec /bin/vCheck "$1" "$2" "$sfv_check" "$usrdir" "$gllog" $required_amount \
"$deny" "$completion_dir" $new_gl "$flysfv" "$3" "$unzip" $getdiz "$comment" \
"$sitenfo" "$dirmsg" $announce_sfv $zip_completion $announce_zip \
$sfv_completion $vars

