#!/bin/sh
#
# v_cryptofs.sh, LoopAES-glftpd site mount utility
set revision "Jul/19/2002"
 
#
# official homepage      : http://vware.hypermart.net
# author's email         : moopowah@yahoo.com
# author's handle        : vman
#
#
# :: Description::
#     this script is intended for those who use loop-aes with glftpd.
#     it's used to mount all encrypted filesystems and start any
#     necessary services in order to put your ftp online for use.  it is
#     also used to dismount all the filesystems.  so what it essentially
#     does is start and stop your ftp site.  for example, you can close
#     down your site even if you have users logged in.  this particular
#     script moutns filesystems formatted to JFS and before it mounts it
#     performs a filesystem check (fsck); fortunately this does not take
#     long since JFS is a Journaling FileSystem.  i recommend you place
#     this script in your rc.0|6 with the Kill attribute so it is run
#     the with parameter "stop".  i'd place it as one of the first scripts
#     to execute so it gets out of the way during reboot/halt.  this
#     file will make more sense if you read my 'encrypted filesystem
#     howto' on the website listed above.
#
# :: Requirements ::
#     1) lsof, you can find it at:
#        ftp://vic.cc.purdue.edu/pub/tools/unix/lsof/, install into an
#        execuatable area.
#
# :: Installation ::
#     this script isn't intended to simply install and use -- it serves
#     as an example in how to design a toggle script for loopaes-glftpd
#     use.  it shouldn't even be considered code, it's merely a series
#     of commands to accomplish the necessary tasks; not to mention that
#     i know very little bash scripting.  you'd need to understand how loopaes
#     works before this file is of any use to you.  it's a life saver though.
#     remember to place it in your processes to Kill in the run command portion
#     of your operating system (rc.0|6).  for example, in Slackware you'd edit
#     /etc/rc.d/rc.0 (add a line at the beginning to run this file with the
#     "stop" parameter).  on Redhat you typically make symlinks in
#     /etc/rc.d/rc[06].d.  name the symlink something like K01foobar so it is
#     executed before the rest.  also, notice that all details for the
#     loopaes devices are contained in this file and not in /etc/fstab.
#     since i like performing fsck before i mount, i stuffed all those
#     specifications in this file, thus, this script does not depend on
#     fstab for any values.
#
# :: Changes ::
#     [Jul/19/2002]: no longer using external 'getpass' program, using
#     'read -s'.
#
################################################################################




PATH=$PATH:/sbin:/usr/sbin

case $1 in
    start)

        # Check if /glftpd is mounted.
        if [ "`df -h | grep \/glftpd$`" != "" ]; then
                echo "/glftpd is mounted already!"
                exit 1
        fi

        # Get the user pass and attempt to mount disks.
        echo -n "enter password: "
	read -s myPass
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S vkuup6Q6qfejQklrV7H1rWntgorO/zfAaxNEaU0UWgeT8jdhz20UIUuKv+S6 /dev/loop0 /usr/cryptfs
        fsck -t jfs -f /dev/loop0
        if [ $? != 0 ]; then
            # free up loop device.
            losetup -d /dev/loop0
            echo ">> could not filesystem check (fsck) device.  bad password?"
            exit 1
        fi

        # fsck was ok, so mount it.
        mount /dev/loop0 /glftpd

        echo ""
        echo ">> FSCKing all drives......"
        echo ""

        echo ""
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S kq6JN+am17wtpmlTs1ZnYW5hidpsyjw2vztuGtUbP17prvzV4svBfMRCHloW /dev/loop1 /dev/md0
        fsck -t jfs -f /dev/loop1
        mount /dev/loop1 /glftpd/site

        echo ""
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S WmkkkDBwjP6U/Z7uLdMlCloq2+PFn+naPmtVEJ/qu2r4IQxFDWZ5fha8n/W4 /dev/loop2 /dev/hdi1
        fsck -t jfs -f /dev/loop2
        mount /dev/loop2 /glftpd/site/games

        echo ""
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S Gjg2VcwA1wm3In7PoZQEm4V3MX/Peq0fOKkwtUgxgUOX/o4HwVKMVCqlpJ5x /dev/loop4 /dev/hdj1
        fsck -t jfs -f /dev/loop4
        mount /dev/loop4 /glftpd/site/movies/vcd

        echo ""
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S Jnyc9A9EvEYAf7WhWfvlb7oOfOtvmz7qJwuD+WFbFImLzb91E4OHhdPXCN39 /dev/loop3 /dev/hdc1
        fsck -t jfs -f /dev/loop3
        mount /dev/loop3 /glftpd/site/movies/svcd

        echo ""
        echo ""
        echo $myPass | losetup -e AES256 -p 0 -S fQGTFlgcbubwO1vXldcshXOuyGlgFF+y5Kq7VxwFv+UMRy7c92RU8qDJki2u /dev/loop5 /dev/hdk1
        fsck -t jfs -f /dev/loop5
        mount /dev/loop5 /glftpd/site/console

        echo ""
        echo ""
        fsck -t jfs -f /dev/hdl1
        mount /dev/hdl1 /glftpd/site/incoming

        # What services need to be started...?
        /glftpd/mysql/bin/safe_mysqld --user=mysql >/dev/null &
        if [ ! -f /var/run/crond.pid ]; then
                crond
                echo `pidof crond` > /var/run/crond.pid
        else
                killall -HUP crond
        fi

        if [ ! -f /var/run/syslogd.pid ]; then
                syslogd -m 60
                # Program makes its own pid.
        else
                killall -HUP syslogd
        fi


        # Start glftpd.
        killall -HUP inetd
    ;;

    stop)

        # Any graceful terminations before we 'kill -9' open files?
        /glftpd/mysql/bin/mysqladmin -u root --password=m00mycow shutdown >/dev/null
        if [ -r /var/run/crond.pid ]; then
                kill -9 `cat /var/run/crond.pid`
                rm -f /var/run/crond.pid
        fi
        if [ -r /var/run/syslogd.pid ]; then
                kill -9 `cat /var/run/syslogd.pid`
                rm -f /var/run/syslogd.pid
        fi
 
        # Use lsof (LiSt Open Files) to kill any processes keeping our
        # devices busy so we can unmount them next.
        IFS='
'
        for i in `lsof +D /glftpd | grep -v PID | awk '{print $1, $2}' | uniq`; do
            echo "killing open file: $i"
            kill -9 `echo $i | awk '{print $2}'`
        done
 
        # Unmount disks.
        umount /glftpd/site/movies/svcd
        umount /glftpd/site/movies/vcd
        umount /glftpd/site/console
        umount /glftpd/site/games
        umount /glftpd/site/incoming
        umount /glftpd/site
        umount /glftpd
 
        # Free up the loop devs.
        losetup -d /dev/loop5
        losetup -d /dev/loop4
        losetup -d /dev/loop3
        losetup -d /dev/loop2
        losetup -d /dev/loop1
        losetup -d /dev/loop0
    ;;
 
    *)
        echo "wrong syntax: $0 {start|stop}"
        exit 1
    ;;
esac
 
exit 0
