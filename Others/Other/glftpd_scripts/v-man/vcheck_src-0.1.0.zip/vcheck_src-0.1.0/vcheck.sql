DROP DATABASE IF EXISTS vcheck;
CREATE DATABASE vcheck;
USE vcheck;

grant all privileges on vcheck.* to vcheck@localhost identified by 'kcehcv99' with grant option;
grant all privileges on vcheck.* to vcheck@127.0.0.1 identified by 'kcehcv99' with grant option;

create table Releases (
  releaseId INT UNSIGNED NOT NULL AUTO_INCREMENT,
  fullDir VARCHAR(255) NOT NULL,
  timeStamp DATETIME NOT NULL,
  PRIMARY KEY (releaseId)
);

create table ReleasesDetails (
  releaseId INT UNSIGNED NOT NULL,
  fileName VARCHAR(246) NOT NULL,
  fileSize INT UNSIGNED NOT NULL,
  averageSpeed INT UNSIGNED NOT NULL,
  userName VARCHAR(255) NOT NULL,
  groupName VARCHAR(255) NOT NULL,
  timeStamp DATETIME NOT NULL,
  PRIMARY KEY (releaseId, fileName)
);

create table IncompleteReleases (
  releaseId INT UNSIGNED NOT NULL,
  fileName VARCHAR(246) NOT NULL,
  PRIMARY KEY (releaseId, fileName)
);

create table Mp3Releases (
  releaseId INT UNSIGNED NOT NULL,
  mpeg TINYINT NOT NULL,
  layer TINYINT NOT NULL,
  bitrate SMALLINT NOT NULL,
  frequency MEDIUMINT NOT NULL,
  mode VARCHAR(15) NOT NULL,
  title VARCHAR(35) NOT NULL,
  artist VARCHAR(35) NOT NULL,
  album VARCHAR(35) NOT NULL,
  year SMALLINT NOT NULL,
  comment VARCHAR(35) NOT NULL,
  genre VARCHAR(32) NOT NULL,
  PRIMARY KEY (releaseId)
);

