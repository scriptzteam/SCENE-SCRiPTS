#!/bin/sh
#--make sure we have a decent PATH-- \
export PATH=$PATH:/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin \
#the next line restarts using tclsh \
exec tclsh8.3 "$0" "$@"
#change 'tclsh8.3' to the Tcl version you have installed: tclsh8.2, tclsh8.4, etc.


#
# Copyright (c) 1999-2001, ``vman'' (moopowah@yahoo.com)
# All rights reserved.  Please refer to the LICENSE file
# included in vCheck's package for more information, or
# the homepage http://vware.hypermart.net.
#


set revision "Jan/26/2001"
puts ".-------------------------------------------------------------------------------."
puts "| vCheck installation script revision $revision, by vman (moopowah@yahoo.com) |"
puts "`-------------------------------------------------------------------------------'"
puts "\n";

puts -nonewline "Where is glftpd installed (press ENTER for \"/glftpd\")?  "; flush stdout
set glftpdDir [gets stdin]
if {$glftpdDir == ""} {
	set glftpdDir "/glftpd"
}
puts -nonewline "Where is your ftpdata dir relative to $glftpdDir (press ENTER for \"/ftp-data\")?  "; flush stdout
set ftpdataDir [gets stdin]
if {$ftpdataDir == ""} {
	set ftpdataDir "/ftp-data"
}
puts -nonewline "Where is Tcl installed (press ENTER for \"/usr\")?  "; flush stdout
set tclDir [gets stdin]
if {$tclDir == ""} {
	set tclDir "/usr"
}
puts ""


###   Reserved Variables   ###########################################
set RequiredBins	"unzip zip ln sh"
set vcheck(PLATFORM)	"src"
set vcheck(REVISION)	"0.1.0"
set LibConfigFiles	"/etc/ld.so.conf $glftpdDir/etc/ld.so.conf"
set mysql(IP)		"127.0.0.1"
set mysql(PORT)		3306
######################################################################


#sanity checks
puts -nonewline "Sanity checks..."; flush stdout
if {[exec -- whoami] != "root"} {
  puts "You need to be root user to install vCheck"
  exit 1
}
if {[file tail [pwd]] != "vcheck_$vcheck(PLATFORM)-$vcheck(REVISION)"} {
  puts "You are not in vCheck's installation dir: vcheck_$vcheck(PLATFORM)-$vcheck(REVISION)/"
  exit 1
}
puts "OK"

#pre-setup
puts -nonewline "Creating dir structures..."; flush stdout
catch {file mkdir "$glftpdDir/usr/bin"}
catch {file mkdir "$glftpdDir/usr/lib/zoneinfo"}
catch {file mkdir "$glftpdDir/usr/local/bin"}
catch {file mkdir "$glftpdDir/usr/local/lib"}
puts "OK"

#--getting up-to-date shell binaries--
puts -nonewline "Copying required shell utilities..."; flush stdout
foreach copyMe $RequiredBins {
	set srcFile ""
	if {[catch {set srcFile [exec -- which $copyMe]}]} {
		puts -nonewline "MISSING($copyMe)..."
	} else {
		file copy -force -- [exec -- which $copyMe] "$glftpdDir/bin/"
	}
}
puts "OK"

#--setting up glftpd�s tmp dir--
puts -nonewline "Creating tmp dir..."; flush stdout
catch {file mkdir "$glftpdDir/tmp"}
exec -- chmod 1777 "$glftpdDir/tmp"
puts "OK"

#--deleting glftpd�s default race information--
puts -nonewline "Replacing glftpd's default race information..."; flush stdout
catch {file rename -force -- "$glftpdDir$ftpdataDir/text/show_totals.head" "$glftpdDir$ftpdataDir/text/show_totals.head.sav"}
catch {file rename -force -- "$glftpdDir$ftpdataDir/text/show_totals.head" "$glftpdDir$ftpdataDir/text/show_totals.body.sav"}
catch {file rename -force -- "$glftpdDir$ftpdataDir/text/show_totals.head" "$glftpdDir$ftpdataDir/text/show_totals.foot.sav"}
puts "OK"

#--copying over tcl--
puts -nonewline "Copying over Tcl..."; flush stdout
if {![file exists "$tclDir/lib/tcl[info tclversion]/init.tcl"]} {
	puts "Tcl is not installed, yet ur running a tcl script.  You probably set the path incorrectly (above)."
	exit 1
}
catch {file mkdir "$glftpdDir$tclDir/lib"}
catch {file mkdir "$glftpdDir$tclDir/bin"}
file copy -force -- "$tclDir/bin/tclsh[info tclversion]" "$glftpdDir$tclDir/bin/"
catch {exec -- ln -s "tclsh[info tclversion]" "$glftpdDir$tclDir/bin/tclsh"}
catch {exec -- ln -s "../$tclDir/bin/tclsh[info tclversion]" "$glftpdDir/bin/tclsh"}
catch {file delete -force -- "$glftpdDir/$tclDir/lib/tcl[info tclversion]"}
file copy -- "$tclDir/lib/tcl[info tclversion]" "$glftpdDir/$tclDir/lib/"
file copy -force -- "$tclDir/lib/tclConfig.sh" "$glftpdDir$tclDir/lib/"
catch {file copy -force "$tclDir/lib/libtcl[info tclversion].a" "$glftpdDir$tclDir/lib/"}
file copy -force "$tclDir/lib/libtcl[info tclversion].so" "$glftpdDir$tclDir/lib/"
file copy -force "$tclDir/lib/libtclstub[info tclversion].a" "$glftpdDir$tclDir/lib/"
catch {exec -- ln -s "libtcl[info tclversion].a" "$glftpdDir$tclDir/lib/libtcl.a"}
catch {exec -- ln -s "libtcl[info tclversion].so" "$glftpdDir$tclDir/lib/libtcl.so"}
catch {exec -- ln -s "libtclstub[info tclversion].a" "$glftpdDir$tclDir/lib/libtclstub.a"}
puts "OK"

#--install mysql--
puts ""
puts "Would you like to install MySQL on this machine right now?"
puts "You must provide the EXTRACTED dir from the SOURCE distribution"
puts "of MySQL found on http://www.mysql.com/downloads/mysql-3.23.html."
puts "Just go ahead and download it now; I'll wait for you. :-)"
puts -nonewline "Please enter the path to the source (press ENTER to skip):  "; flush stdout
set temp [gets stdin]
set mysqlDir ""
if {$temp != ""} {
	set mysqlDir "/usr/mysql"
	set origDir [pwd]
	cd $temp

	puts -nonewline "Adding user 'mysql' and group 'mysql' to system..."; flush stdout
	catch {exec -- groupadd mysql}
	catch {exec -- useradd -g mysql mysql}
	puts "OK"

	puts -nonewline "Configuring MySQL for compilation (error log in /tmp/mysql_configure_errors.log)..."; flush stdout
	file delete -force -- "/tmp/mysql_configure_errors.log"
	exec -- ./configure --prefix=$mysqlDir > /dev/null 2> /tmp/mysql_configure_errors.log
	file delete -force -- "/tmp/mysql_configure_errors.log"
	puts "OK"

	puts -nonewline "Compiling MySQL (this may take several minutes; error log in /tmp/mysql_make_errors.log)..."; flush stdout
	file delete -force -- "/tmp/mysql_make_errors.log"
	exec -- make > /dev/null 2> /tmp/mysql_make_errors.log
	file delete -force -- "/tmp/mysql_make_errors.log"
	puts "OK"

	puts -nonewline "Installing MySQL to $mysqlDir (error log in /tmp/mysql_install_errors.log)..."; flush stdout
	file delete -force -- "/tmp/mysql_install_errors.log"
	exec -- make install > /dev/null 2> /tmp/mysql_install_errors.log
	file delete -force -- "/tmp/mysql_install_errors.log"
	puts "OK"

	puts -nonewline "Creating MySQL database indexes..."; flush stdout
	catch {exec -- "scripts/mysql_install_db" 2>/dev/null}
	puts "OK"

	puts -nonewline "Setting MySQL file permissions..."; flush stdout
	exec -- chown -R mysql $mysqlDir
	exec -- chgrp -R mysql $mysqlDir
	puts "OK"

	puts -nonewline "Launching MySQL daemon into memory..."; flush stdout
	exec $mysqlDir/bin/safe_mysqld --user=mysql &
	puts "OK"

	cd $origDir
	unset origDir
} else {
	puts -nonewline "Where is MySQL installed (press ENTER for \"/usr/mysql\")?  "; flush stdout
	set mysqlDir [gets stdin]
	if {$mysqlDir == ""} {
		set mysqlDir "/usr/mysql"
	}
}

#--set password for mysql and login--
#--setting-up vcheck�s tables for mysql--
puts ""
puts -nonewline "Enter a password to set for MySQL's root user (press ENTER to skip):  "; flush stdout
set mysqlPass [gets stdin]
puts ""
if {$mysqlPass != ""} {
	exec -- $mysqlDir/bin/mysqladmin -u root password $mysqlPass
	puts "Your password was successfully set."
}
puts "Now we'll login to MySQL (it is assumed to be running on IP=$mysql(IP) PORT=$mysql(PORT))."
puts "Simply enter MySQL's root password when prompted in order to setup vCheck's database."
catch {exec -- $mysqlDir/bin/mysql -u root -p < vcheck.sql 2>@ stderr}
puts "vCheck's database was successfully created."

#--copying over mysql--
puts ""
puts -nonewline "Copying over MySQL libraries..."; flush stdout
catch {file delete -force -- "$glftpdDir$mysqlDir/lib/mysql"}
catch {file mkdir "$glftpdDir$mysqlDir/lib"}
file copy -- "$mysqlDir/lib/mysql" "$glftpdDir$mysqlDir/lib/"
puts "OK"

#--confirming correct file setup and general security--
puts -nonewline "Setting file permissions..."; flush stdout
exec -- chmod 0666 "$glftpdDir$ftpdataDir/logs/glftpd.log"
#
catch {file delete -- "$glftpdDir/dev/null"}
catch {file delete -- "$glftpdDir/dev/zero"}
#crw-rw-rw-   1 root     root       1,   3 May  5  1998 /dev/null
set temp [lrange [exec -- ls -l "/dev/null"] 4 5]
exec -- mknod "$glftpdDir/dev/null" c [string range [lindex $temp 0] 0 end-1] [lindex $temp 1]
exec -- chmod 0666 "$glftpdDir/dev/null"
set temp [lrange [exec -- ls -l "/dev/zero"] 4 5]
exec -- mknod "$glftpdDir/dev/zero" c [string range [lindex $temp 0] 0 end-1] [lindex $temp 1]
exec -- chmod 0666 "$glftpdDir/dev/zero"
puts "OK"
#
puts -nonewline "Copying over vCheck package..."; flush stdout
catch {file delete -force -- "$glftpdDir/bin/vcheck"}
file copy -- "bin/vcheck" "$glftpdDir/bin/"
catch {file mkdir "/bin/vcheck"}
file copy -force -- "bin/vcheck/dbLogin2.tcl" "/bin/vcheck/dbLogin.tcl"
foreach copyMe [glob "usr/lib/tcl8.3/*"] {
	file copy -force -- $copyMe "$glftpdDir$tclDir/lib/tcl[info tclversion]/"
	file copy -force -- $copyMe "$tclDir/lib/tcl[info tclversion]/"
}
file copy -force -- "usr/lib/libstdc++-2-libc6.1-1-2.9.0.so" "$glftpdDir/usr/lib/"
file copy -force -- "usr/lib/libstdc++-2-libc6.1-1-2.9.0.so" "/usr/lib/"
if {$tcl_platform(os) == "FreeBSD"} {
	file copy -force -- "usr/lib/sql_fbsd.so" "$glftpdDir/usr/lib/sql.so"
	file copy -force -- "usr/lib/sql_fbsd.so" "/usr/lib/sql.so"
} else {
	file copy -force -- "usr/lib/sql_lnx.so" "$glftpdDir/usr/lib/sql.so"
	file copy -force -- "usr/lib/sql_lnx.so" "/usr/lib/sql.so"
}
catch {exec -- ln -s "libstdc++-2-libc6.1-1-2.9.0.so" "$glftpdDir/usr/lib/libstdc++-libc6.1-1.so.2"}
catch {exec -- ln -s "libstdc++-2-libc6.1-1-2.9.0.so" "/usr/lib/libstdc++-libc6.1-1.so.2"}
exec -- chown -R root "$glftpdDir/bin"
if {$tcl_platform(os) == "FreeBSD"} {
	exec -- chgrp -R wheel "$glftpdDir/bin"
} else {
	exec -- chgrp -R root "$glftpdDir/bin"
}
exec -- chmod -R 0755 "$glftpdDir/bin"
#
if {[file exists /etc/localtime]} {
	file copy -force -- "/etc/localtime" "$glftpdDir/etc/"
	file copy -force -- "/etc/localtime" "$glftpdDir/usr/lib/zoneinfo/"
}
puts "OK"

puts -nonewline "Copying libraries required for sql module (sql.so)..."
proc copyLibs {binary} { global glftpdDir
	catch {exec -- ldd $binary} libs
	foreach {libname arrow libpath num} [join $libs] {
		if {$libname == "statically"} {
			continue
		}
		if {[file exists "$glftpdDir$libpath"]} {
			continue
		}
		catch {exec -- cp -Rp $libpath "$glftpdDir[file dirname $libpath]/"}
	}
}
copyLibs /usr/lib/sql.so
puts "OK"

#--updating library cache--
puts -nonewline "Updating library cache..."; flush stdout
foreach libConfigFile $LibConfigFiles {
	if {[catch {exec -- grep "$mysqlDir/lib/mysql" "$libConfigFile"}]} {
		set fout [open "$libConfigFile" a]
		puts $fout "$mysqlDir/lib/mysql"
		close $fout
	}
}
catch {exec -- ldconfig 2>@ stderr}
catch {exec -- ldconfig -r $glftpdDir 2>@ stderr}
puts "OK"

puts "\nPlease refer to the INSTALL file for further instructions.\n"

puts "Installation has successfully completed! :-)"

exit 0

