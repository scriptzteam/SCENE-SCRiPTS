/* 
** topdownloads-loganalyser by digitoxin
** 2001 digitoxin@digitoxin.dhs.org
** based on weekTop of pSi1
*/

#include <stdio.h>
#include <time.h>

#define	XFERLOG		"/glftpd/ftp-data/logs/xferlog"
#define	OUTFILE		"/dev/stdout"
#define	LINE_DELIMITER	'|'
#define MAXFILESLISTED	200
#define DEPTH		2

struct files {
	char name[150];
	unsigned long count;
	struct files *next;
};

FILE *file, *file2;
char space[] = "                                                          ";
struct files *head = NULL;

int UseLine(char *mode, char *day)
{
	if(*mode == 'o')
		return(1);
		
	/* for future use */
	return(0);
}


void markdepth (char* name, char* newname) 
{	
	int pos,notfound = 1,count = 0;
	pos = strlen (name);
	while (notfound) {
	if (name[--pos] =='/') count++;
	if ((count == DEPTH) || (pos==0)) notfound = 0;
	}
	strcpy (&newname[0], &name[pos]); 
}


struct files *FindFile(char *files)
{
	struct files *temp = head, *temp1;
	int found = 0;

	if(!temp) {
		/* create the head */
		head = temp = (struct files *)malloc(sizeof(struct files));
		strcpy(&(temp->name[0]), files);
		temp->count = 0;
		temp->next = NULL;
	}
	else {
		/* first try to find the name */
		while(temp && !found) {
			if(!strcmp(&(temp->name[0]), files))
				found = 1;
			else {
				temp1 = temp;
				temp = temp->next;
			}
		}

		if(!found) {
			/* we have to create a new entry */
			temp = (struct files *)malloc(sizeof(struct files));
			temp1->next = temp;
			strcpy(&(temp->name[0]), files);
			temp->count = 0;
			temp->next = NULL;
		}
	}

	return(temp);
}

void WriteLine(char *files, unsigned long count)
{

    fprintf(file, "%c %dx %c %s\n", LINE_DELIMITER, count, LINE_DELIMITER, &files[0]);
}

void ProcessXferLog(void)
{
	struct files *temp, *temp1, *temp2;
	char line[256], day[10], files[150], dummy[256], mode[5], cutfiles[150];
	int files_listed = 0, n, dummy_int;
	unsigned long size, max;

	/* read xferlog and build files-db */
	do {
		fgets(&line[0], 256, file);
		if(!feof(file)) {
			/* parse line */
			sscanf(&line[0], "%s %s %d %s %d %s %s %ld %s %s %s %s %s %s %s %s %s", &day[0], &dummy[0], &dummy_int, &dummy[0], &dummy_int, &dummy[0], &dummy[0], &size, &files[0], &dummy[0], &dummy[0], &mode[0], &dummy[0], &dummy[0], &dummy[0], &dummy[0], &dummy[0]);
			if(UseLine(&mode[0], &day[0])) {
				/* this line has a correct date, use it */
				markdepth (&files[0], &cutfiles[0]);
				temp = FindFile(&cutfiles[0]);
				temp->count += 1;
			}
		}
	} while(!feof(file));
	fclose(file);
	
	file = fopen ( OUTFILE, "w");
	
	temp = head;
	while(temp) {
		max = temp->count;
		temp2 = temp;
		temp1 = head;
		while(temp1) {
			if(temp1->count > max) {
				max = temp1->count;
				temp2 = temp1;
			}
			temp1 = temp1->next;
		}

		WriteLine(&(temp2->name[0]), temp2->count);
		temp2->count = 0;
		temp = temp->next;

		files_listed++;
		if(files_listed == MAXFILESLISTED)
			temp = NULL;
	}

	fclose(file);

	/* free files mem */
//	temp = head;
//	while(temp) {
//		temp1 = temp;
//		temp = temp->next;
//		free(temp1);
//	}
}

int main(void)
{
	if(file = fopen(XFERLOG, "r")) {
		ProcessXferLog();
		fclose(file);
		return 0;
	}
}

