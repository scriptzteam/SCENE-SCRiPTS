#!/bin/bash
#######################################################################
#---                                                               ---#
#--- Name:         rmrel.sh                                        ---#
#--- Version:      0.1                                             ---#
#--- Last Updated: 2002-12-05                                      ---#
#--- Author:       Jahangir  -  (C) 2002                           ---#
#--- Contact:      jahangir on EFNet or jahangir@x-mail.net        ---#
#--- Notes:        This script is for free use                     ---#
#---               You can use or modify it if you let the header  ---#
#---               information in it.                              ---#
#---                                                               ---#
#--- This script is used to delete single releases.                ---#
#--- The release will be deleteted from the MYSQL-DB and the       ---#
#--- releases-txt-files (releases-mp3.txt, all-releases-mp3,       ---#
#--- old_in_db.txt, old_crap.txt).                                 ---#
#--- The deleted release will be added to deleted.txt.             ---#
#---                                                               ---#
#--- Setup: - Place this script in your /glftpd/bin directory      ---#
#---           or somewhere in your path.                          ---#
#---        - Chmod rmrel.sh 755                                   ---#
#---        - Edit the section below to your needs                 ---#
#---                                                               ---#
#--- Usage: - Go to each dir which has releases in it              ---#
#---            cd /glftpd/site/MP3/Albums_A-M/Metallica/          ---#
#---         (if this is the dir where the release to be deleted   ---#
#---          is in)                                               ---#
#---             /glftpd/bin/rmrel.sh <releasename>                ---#
#---        - Watch the output of the script.                      ---#
#---        - If you have problems with the output, disable        ---#
#---          colors in the configuration section.                 ---#
#---                                                               ---#
#######################################################################
#######################################################################
#--- CONFIGURATION - Edit only here -----------------------------  ---#
#---                                                               ---#
db="mp3releases";           ### MYSQL-Database name                ---#
dbuser="root";              ### MYSQL-Database user                ---#
dbpass="dbadmin";           ### MYSQL-Database password            ---#
dbtable="releases";         ### MYSQL release-table                ---#
path="/glftpd/bin/";        ### Path to release-txt-files          ---#
releasetxt="releases-mp3.txt";# release-txt-file                   ---#
alltxt="all-releases-mp3.txt"; # all-releases-txt-file             ---#
oldindbtxt="old_in_db.txt"; ### txt-file (old rels now in DB)      ---#
oldcraptxt="old_crap.txt";  ### txt-file (rels without .message)   ---#
deletedtxt="deleted.txt";   ### txt-file (deleted releases)        ---#
tmpfile=".nuketmp.txt";     ### temporary file for copying         ---#
colored="yes";              ### colored output (yes/no)            ---#
#---                                                               ---#
#--- Please don't edit below ------------------------------------- ---#
#######################################################################

if [ "$1" = "" ]; then
   echo "------------------------------------------ ";
   echo "No Parameters given!";
   echo "Usage: site rmrel complete_releasename";
   echo "------------------------------------------ ";
   exit 0;
fi

# --- Farbe bei Ausgabe ---
if [ "$colored" = "yes" ]; then
b1="\033[1m"; b2="\033[0m"; ok1="\033[1m\E[34m"; ok2="\033[0m"; done1="\033[1m\E[32;47m"; no="\033[1m\E[31m";
else
b1=""; b2=""; ok1=""; ok2=""; done1=""; no="";
fi

# --- Aktuellen Pfad speichern (dir, in dem script gestartet wird) ---
actdir="$PWD";
# --- Releasedirname ---
deldir="$1";

echo -e "$ok1 Deleting Release from the Database-System $ok2";
echo -e "$ok1 and all txt-files in $storepath... $ok2";

# --- nur wenn $deldir auch ein Directory ist ---
if [ -e $deldir ]; then
     echo "-------------------------------------------------------------------------";
 # --- aus DB deleten ---
     echo "USE $db; DELETE FROM $dbtable WHERE releasename='$deldir'" | mysql -u "$dbuser" -p"$dbpass" ;
     echo -e "$ok1 OK $ok2 - $b1$n2$b2 deleted from MYSQL-DB $done1 done. $b2";

 # --- aus release-txt-file deleten ---
     cat $path$releasetxt | grep -v -e $deldir > $path$tmpfile;
     cp $path$tmpfile $path$releasetxt;
     cp /dev/null $path$tmpfile;
     echo -e "Release $deldir deleted from $b1$path$releasetxt$b2.";

 # --- aus all-releases-txt-file deleten ---
     cat $path$alltxt | grep -v -e $deldir > $path$tmpfile;
     cp $path$tmpfile $path$alltxt;
     cp /dev/null $path$tmpfile;
     echo -e "Release $deldir deleted from $b1$path$alltxt$b2.";

# --- aus old_in_db-txt-file deleten ---
     cat $path$oldindbtxt | grep -v -e $deldir > $path$tmpfile;
     cp $path$tmpfile $path$oldindbtxt;
     cp /dev/null $path$tmpfile;
     echo -e "Release $deldir deleted from $b1$path$oldindbtxt$b2.";

# --- aus old_crap-txt-file deleten ---
     cat $path$oldcraptxt | grep -v -e $deldir > $path$tmpfile;
     cp $path$tmpfile $path$oldcraptxt;
     cp /dev/null $path$tmpfile;
     echo -e "Release $deldir deleted from $b1$path$oldcraptxt$b2.";

# --- in deleted-txt-file kopieren ---
     echo $deldir >> $path$deletedtxt;

     echo "All deleting complete. done.";
     echo "-------------------------------------------------------------------------";
     exit 0;
   else
     echo -e "$no NO $b2 Releasedir - $b1$deldir$b2 does not exist in $PWD !";
     echo "-------------------------------------------------------------------------";
     exit 0;
  fi

exit 0;