#!/bin/bash
#
# xL-genrefind v1.1
#
# (C) 2003 xoLax

#Sections that might contain .imdb files
sections="divx vcd svcd"

#sitepath
sitepath="/glftpd/site/"

#What do you call your .imdb files?
imdbfile=".imdb"

#What do your .imdb look like?
#Trailing space on titlelook!
titlelook="Title........: "
#Trailing space on genrelook!
genrelook="Genre........: "
#NO trailing space on ratinglook!
ratinglook="User Rating..:"

#Default number of hits returned
maxhits="10"

#Enable userdefined number of hits?
userhits="YES"

#Max hits when userdefined
usermax="25"

## END OF CONFIG ##
###################
section="$sitepath$1/"

if [ "$1" == "" -o "$2" == "" -o "$3" == "" ]; then
  echo "Usage: !grfind <section> <genre> <imdbrating (x.x or x.x-x.x)> [min votes] [number of hits] [Opening year+]"
  echo "Genres are case sensitive and shall be spelled the same way as on IMDb"
  exit
fi
if [ "`echo $sections | grep -w -o $1`" == "" ]; then
  echo "$1 is not a valid section!"
  echo "Valid sections are: $sections"
  exit
fi
votes="$4"
if [ "$4" == "" ]; then
  votes="0"
fi
genre="$2"
rating="$3"
if [ "$5" != "" -a "$userhits" == "YES" ]; then
  if [ "$5" -le "$usermax" ]; then
    maxhits="$5"
  else
    maxhits="$usermax"
  fi
fi
year="$6"
if [ "$6" == "" ]; then
  year="0"
fi
if [ "`echo $rating | grep \-`" != "" ]; then
  export rating1=`echo $rating | sed s/"-"/" "/ | cut -d ' ' -f1`
  export rating1=`echo $rating1\*10\/1 | bc`
  export rating2=`echo $rating | sed s/"-"/" "/ | cut -d ' ' -f2`
  export rating2=`echo $rating2\*10\/1 | bc`
  interval="TRUE"
fi
export movies=`ls -1 $section | grep -v incomplete`
matches="0"
for each in $movies; do
  if [ "$matches" -ge "$maxhits" ]; then
    echo "Maximum number of hits ($maxhits) returned"
    exit
  fi
  if [ "`ls -la $section$each/ | grep -o -w $imdbfile`" == "" ]; then
    continue
  fi
  if [ "$genre" != "all" ]; then
    export imdbg=`cat $section$each/$imdbfile | grep "$genrelook" | grep -w -i $genre | sed s/"$genrelook"// | sed s/"$genre"/"$genre"/`
  else
    export imdbg=`cat $section$each/$imdbfile | grep "$genrelook" | sed s/"$genrelook"//`
  fi
  if [ "$imdbg" == "" ]; then
    continue
  fi
  export title=`cat $section$each/$imdbfile | grep $titlelook`
  export yearplace=`echo "$title" | tr -d '()' | wc -w`
  export imdby=`echo $title | tr -d '()' | cut -d ' ' -f$yearplace`
  if [ "$imdby" == "TV" -o "$imdby" == "mini" ]; then
    yearplace="$( expr "$yearplace" \- "1" )"
    export imdby=`echo $title | tr -d '()' | cut -d ' ' -f$yearplace`
  fi
  export imdby=`echo $imdby | tr -d '[:alpha:]' | tr -d '[=/=]'`
  if [ "$imdby" == "" ]; then
    continue
  fi
  export imdbr=`cat $section$each/$imdbfile | grep "$ratinglook" | sed s/"\/"/" "/ | awk '{print $3}'` 
  if [ "$imdbr" == "awaiting" -o "$imdbr" == "" ]; then
    continue
  fi
  export imdbv=`cat $section$each/$imdbfile | grep "$ratinglook" | sed s/","//g | tr -d '(' | awk '{print $4}'`
  export cimdbr=`echo $imdbr\*10\/1 | bc`
  if [ "$interval" == "TRUE" ]; then
    if [ "$cimdbr" -ge "$rating1" -a "$cimdbr" -le "$rating2" -a "$imdbv" -ge "$votes" -a "$imdby" -ge "$year" ]; then
      echo "$each - $imdby - $imdbr ("$imdbv"v) - $imdbg"
      matches="$( expr "$matches" \+ "1" )"
      continue
    else
      continue
    fi
  fi
  if [ "$rating" == "$imdbr" -a "$imdbv" -ge "$votes" -a "$imdby" -ge "$year" ]; then
    echo "$each - $imdby - $imdbr ("$votes"v) - $imdbg"
    matches="$( expr "$matches" \+ "1" )"
    continue
  else
    continue
  fi
done
echo "$matches hit(s) returned"




  
  

