# CONFIGURATION ----------------------------------------------------------.
#   `---------------------------------------------------------------------'

# Exact path to glftpd.conf.
GLCONF="/etc/glftpd.conf"

# Folder the script can have full write/read access to for temp files.
TMPFLDR="/glftpd/tmp"

# Exact path to Turranius's ftpwho binary.
TURFTPWHO="/glftpd/bin/tur-ftpwho"

# Exact path to User files directory.
USERDIR="/glftpd/ftp-data/users"

# Exact path to ncftpls binary.
NCFTPLS="/usr/local/bin/ncftpls"

# Users with these flags will not be kicked by the script.
SAFEFLAGS="1|4|7"

# Account for ncftpls to use to kick users.
GLUSER="username"

# Password for ncftpls account.
GLPASS="password"

# Address of glftpd server.
GLHOST="localhost"

# Port of glftpd server.
GLPORT="21"

#   .---------------------------------------------------------------------.
# CONFIGURATION END ------------------------------------------------------'

# check for glftpd.conf

if [ -r "$GLCONF" ]; then
    GLCONFEXIST="YES"
   else
  echo "Can not read $GLCONF. Check paths / chmod"
 exit 0
fi

if [ -z "$1" ]; then
  echo "USAGE : shutdown <1/0> [kick]"
  echo "specify '1' if you want to shutdown, '0' if you want to open"
 exit 0
fi

# convert "kick" to lowercase

KICKFORMAT="$( echo "$2" | tr '[:upper:]' '[:lower:]' )"

# check for tur-who

if [ "$KICKFORMAT" = "kick" ]; then
  KICK="TRUE"
fi

if [ "$KICK" = "TRUE" ]; then
  if [ -e "$TURFTPWHO" ]; then
    ALLTHERE="YES"
  else
    echo "You have decided to kick all users too, but I cant find $TURFTPWHO."
    echo "Check your setup!"
    exit 0
  fi
fi

# shutdown 1 or 0?

if [ "$1" = "1" ]; then
  SHUTDOWN="TRUE"
fi

if [ "$1" = "0" ]; then
  OPEN="TRUE"
fi

# set shutdown mode to 1 or 0
if [ "$SHUTDOWN" = "TRUE" ]; then
  cp -f $GLCONF $TMPFLDR/glftpd.conf.org
  sed '/^shutdown 0/s//shutdown 1/g' $GLCONF > $TMPFLDR/glftpd.conf.edt
   cp -f $TMPFLDR/glftpd.conf.edt $GLCONF
   rm -f $TMPFLDR/glftpd.conf.edt
  echo "Server shut down!"
fi

if [ "$OPEN" = "TRUE" ]; then
  cp -f $GLCONF $TMPFLDR/glftpd.conf.org
  sed '/^shutdown 1/s//shutdown 0/g' $GLCONF > $TMPFLDR/glftpd.conf.edt
   cp -f $TMPFLDR/glftpd.conf.edt $GLCONF
   rm -f $TMPFLDR/glftpd.conf.edt
  echo "Server opened!"
fi

# kick users?

if [ "$KICK" = "TRUE" ]; then
  for pid in `$TURFTPWHO | tr -d ' '`; do
    username="$( echo $pid | cut -d '^' -f1 )"
    pid="$( echo $pid | cut -d '^' -f2 )"
    if [ -z "$( grep "^FLAGS " $USERDIR/$username | egrep "$SAFEFLAGS" )" ]; then
      if [ "$UID" = "0" ]; then
         kill $pid
	echo "$username kicked!"
      else
        $NCFTPLS -u$GLUSER -p$GLPASS -P$GLPORT -Y"site kill $pid" ftp://$GLHOST 2> /dev/null > /dev/null
       echo "$username kicked!"
      fi
      echo "All Non-Exempt Users Kicked!"
    else
      echo "User $username is excluded. Wont kick."
    fi
  done
fi

exit 0
