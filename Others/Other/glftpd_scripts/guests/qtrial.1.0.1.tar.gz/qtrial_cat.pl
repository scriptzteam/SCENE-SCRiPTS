#!/usr/bin/perl
require("/glftpd/bin/qtrial_config.pl");
open(FILE,"<$botfile");
while(<FILE>) {
print $_;
}
close(FILE);
system("perl -e '' > $botfile");
