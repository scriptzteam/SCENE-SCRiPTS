#######################################
#       global informations           #
#######################################
#how many stat sections do u have:
$sections = "3";

$blod = "";
$ala = @ARGV[0];
$botfile = $glftpd."/glftpd/ftp-data/misc/botfile";
#where u have glftpd
$glftpd = "/glftpd/";
#define trialuser file:
$trialuserdir = $glftpd."/ftp-data/trial_users";

#trial size in MB
$mtu = 2000;

#time to do trial in days
$tte = 7;

#text trial:
$texttrial = $bold."-SITENAME-".$bold." [=TRiAL=] %user% trial will end in %time% day(s) He must up %toup% MB to end trial ($mtu MB/week).\n";
$textendtrial = $bold."-SITENAME-".$bold." [=TRiAL=] %user% pass trial ($mtu MB/week) He must waiting for delete trial.\n";
$textdonttrial = $bold."-SITENAME-".$bold." [=TRiAL=] %user% didn't pass trial ($mtu MB/week) He must waiting for delete.\n";
$textnouser = $bold."-SITENAME-".$bold." [=TRiAL=] user %user% not found.\n";
$textnotrial = $bold."-SITENAME-".$bold." [=TRiAL=] user %user% isnt on trial.\n";
$textdonttrialb = $bold."-SITENAME-".$bold." [=TRiAL=] %user% didnt pass trial ($mtu MB/week) and gain +6 flag right now \n";
$textendtrialb = $bold."-SITENAME-".$bold." [=TRiAL=] Yeah %user% passed trial ($mtu MB/week) and remove TRiAL flag right now.\n";
$textuserno = $bold."-SITENAME-".$bold." [=TRiAL=] Sorry u must give username.\n";
$textadduser = $bold."-SITENAME-".$bold." [=TRiAL=] User %user% added to TRiAL.\n";

######################################
#               Mysql                #
#       now must be disable          #
######################################
$use_mysql = "no";
$muser = "user";
$mpass = "pass";
$mhost = "host";
$mtable = "qtrial";



#####################################################
#dont change this
#####################################################
$mtu = $mtu*1024;