#!/usr/bin/perl
require("/glftpd/bin/qtrial_config.pl");
my ($user, $allup, $istrial, $userfile);
use Date::Calc;


$user = @ARGV[0];
if (!$user) {
$ls = `ls $glftpd/$trialuserdir/`;
$ls =~ s/\n/ /ig;
print $ls;
exit(1);
}
$userfile = $glftpd."/ftp-data/users/" . $user; 

open(USERFILE,"$userfile") || nouser("$textnouser",$user);
while(<USERFILE>) {
if ($_ =~ /^ALLUP (.*)/) {
$allup = $1;
} 

}
close(USERFILE);

@allup = split(' ',$allup);
$upped = 0;
for($i=0;$i<($sections*3);$i=$i+3) {
$upped = $upped+@allup[$i+1];
}
$trialfile = $glftpd."/ftp-data/trial_users/" . $user;
open(TRIALFILE,"$trialfile") || nouser($textnotrial,$user);;
@lines = <TRIALFILE>;
#       Delta_Days
#       $Dd = Delta_Days($year1,$month1,$day1,
#                        $year2,$month2,$day2);
$is[0] = `date +%Y`;
$is[1] = `date +%m`;
$is[2] = `date +%d`;
$roznica = Date::Calc::Delta_Days($lines[0],$lines[1],$lines[2],$is[0],$is[1],$is[2]);
$wasup = $lines[3];
close(TRIALFILE);
#
$upped = $upped-$wasup;
$dni = $tte-$roznica;
$danych = ($mtu-$upped)/1024;
$danych = sprintf("%.1f", $danych);

if ( $upped < $mtu ) {
if ($roznica <= $tte) {
$texttrialw = $texttrial;
$texttrialw =~ s/%user%/$user/ig;
$texttrialw =~ s/%time%/$dni/ig;
$texttrialw =~ s/%toup%/$danych/ig;
print $texttrialw;
#pozosstalo do upniecia...
} else {
$textdonttrialw = $textdonttrial;
$textdonttrialw =~ s/%user%/$user/ig;
$textdonttrialw =~ s/%time%/$dni/ig;
$textdonttrialw =~ s/%toup%/$danych/ig;
print $textdonttrialw;
}

} else {
$textendtrialw = $textendtrial;
$textendtrialw =~ s/%user%/$user/ig;
$textendtrialw =~ s/%time%/$dni/ig;
$textendtrialw =~ s/%toup%/$danych/ig;
print $textendtrialw;

}
sub nouser {
@_[0] =~ s/%user%/@_[1]/ig;
print @_[0];
exit(0);
}