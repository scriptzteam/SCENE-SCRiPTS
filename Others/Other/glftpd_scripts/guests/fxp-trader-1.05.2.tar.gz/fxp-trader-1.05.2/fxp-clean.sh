#!/bin/sh
VER=1.02
# Clean the avaible logs
# or from other Sites
# Version 1.02 by Xtreame

if [ -z $config ]; then
	config="`dirname $0`/fxp-trader.conf"
fi
if [ ! -r $config ]; then
	echo "Error. Can not read $config"
	exit 0
else
	. $config
fi

sed -e 's/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/127.0.0.1/g' $mslog > /ftp-data/logs/mslog
mv -f /ftp-data/logs/mslog $mslog
sed -e 's/\<FXP/REMOVE/' -e 's/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/127.0.0.1/g' $gllog > /ftp-data/logs/glftp.log
mv -f /ftp-data/logs/glftp.log $gllog
sed -e 's/[:][[:space:]][^\b].*\@[^\b].*[[:space:]][(]/: disabled@disabled (/g;s/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/disabled/g' $login > /ftp-data/logs/log.log
mv -f /ftp-data/logs/log.log $login	

exit 0
