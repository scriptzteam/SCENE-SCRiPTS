#!/bin/sh
VER=1.05.2
# A Script that shows the FXP to other Sites
# view the README for more Info�s
# Version 1.05.2 by Xtreame
# Note: Requires the following binaries: tac, grep, awk, echo

if [ -z $config ]; then
	config="`dirname $0`/fxp-trader.conf"
fi
if [ ! -r $config ]; then
	echo "Error. Can not read $config"
	exit 0
else
	. $config
fi

if [ "$gllog" ]; then
	if [ -w "$gllog" ]; then
		echo `date "+%a %b %e %T %Y"` "$@" >> $gllog
	else
		if [ "$gllog" ]; then
			echo "Can�t find $gllog, check your config"
		fi
  	fi
fi

if [ ! -f "$ms_log" ]; then
	echo "Can�t find $ms_log, check your path�s and syslog.conf"
	exit 0
fi

timein=`tac $login | grep -e "$USER" | grep -m1 "LOGIN" | awk '{print $2,$3,$4}'`
timems=`tac $ms_log | grep -m1 "$timein" | awk '{print $1,$2,$3}'`
gla=`tac $login | grep -e "$USER" | grep -m1 "LOGIN" | cut -d '(' -f2 | cut -d ')' -f1`
glb=`tac $ms_log | grep -e FindOUT | grep $gla | grep -m1 "LEN=" | cut -d '=' -f5 | cut -d 'L' -f1`
glc=`tac $ms_log | grep -e FindOUT | grep -m1 "LEN=" | cut -d '=' -f5 | cut -d 'L' -f1`
bc=`cat $bad | grep -e $glc | cut -d ' ' -f1`

if [ "$timein" = "$timems" ]; then
	if [ $bc ]; then
		echo `date "+%a %b %d %T %Y"` FXPBAD: \"$USER\" \"$GROUP\" \"$bc\" >> $gllog
	else
		if [ "$glb" = "$glc" ]; then
			echo `date "+%a %b %d %T %Y"` IGNORE: \"$USER\" \"$GROUP\" \"$glb\" >> $gllog
		else
			echo `date "+%a %b %d %T %Y"` FXPOUT: \"$USER\" \"$GROUP\" \"$glc\" >> $gllog
		fi
	fi
else
		echo `date "+%a %b %d %T %Y"` TIMEMS: \"$USER\" \"$GROUP\" \"$glc\" >> $gllog
fi
