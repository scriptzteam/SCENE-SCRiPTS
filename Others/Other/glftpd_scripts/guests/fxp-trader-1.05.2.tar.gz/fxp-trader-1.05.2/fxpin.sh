#!/bin/sh
VER=1.05.2
# A Script that shows the FXP from other Sites
# view the README for more Info�s
# Version 1.05.2 by Xtreame
# Note: Requires the following binaries: tac, grep, awk, echo


if [ -z $config ]; then
	config="`dirname $0`/fxp-trader.conf"
fi
if [ ! -r $config ]; then
	echo "Error. Can not read $config"
	exit 0
else
	. $config
fi

if [ "$gllog" ]; then
  if [ -w "$gllog" ]; then
    echo `date "+%a %b %e %T %Y"` "$@" >> $gllog
  else
      if [ "$gllog" ]; then
        echo "Can�t find $gllog, check your config"
      	if [ "$USER" = "root" ]; then
          chmod 666 $gllog
      	fi
     fi
  fi
fi

if [ ! -f "$ms_log" ]; then
	echo "Can�t find $ms_log, check your path�s and syslog.conf"
	exit 0
fi

in=`tac $ms_log | grep -e FindIN | grep -m1 SRC= | cut -d '=' -f5 | cut -d 'D' -f1`
bc=`cat $bad | grep -e $in | cut -d ' ' -f1`

if [ "$bc" ]; then
	echo `date "+%a %b %d %T %Y"` FXPBAD: \"$USER\" \"$GROUP\" \"$bc\" >> $gllog
else
	echo `date "+%a %b %d %T %Y"` FXPIN: \"$USER\" \"$GROUP\" \"$in\" >> $gllog
fi

exit 0
