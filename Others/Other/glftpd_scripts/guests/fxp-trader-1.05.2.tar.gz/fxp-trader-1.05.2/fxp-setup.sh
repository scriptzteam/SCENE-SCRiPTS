#!/bin/bash
VER=1.05.2
# A Script that shows the FXP to other Sites
# or from other Sites
# Version 1.05.2 by Xtreame
if [ -z $config ]; then
	config="`dirname $0`/fxp-trader.conf"
fi

proc_setup() {
	touch $config
	echo -e "VERSION=$VER" >> $config
	echo -e "\n" >> $config
	echo -e "##########################################" >> $config
	echo -e "###          FXP-Trader-Conf           ###" >> $config
	echo -e "###               Start                ###" >> $config
	echo -e "##########################################" >> $config
	echo -e "\n" >> $config
	echo -e "\nCreate now $config"
	echo -e "\n"
	until echo "$setflag" | grep -E "^[I-Z0]+$" > /dev/null; do
		echo "You can set a flag to monitored, that is recommend if you"
		echo "watch selected User. Or set nothing to watch all users"
		echo -en "Enter a flag if you watch selected Users [J-Z]: "
	read flag
	[ -z "$setflag" ] && setflag=0
		if [ "$setflag" = "0" ]; then
			echo -e "setflag=\""\" >> $config
		else
			echo -e "setflag=\"$flag"\" >> $config
		fi
	done
	setglservice=`cat /etc/services | grep -e glftpd | cut -d '/' -f1 | cut -d ' ' -f4`
	until echo "$setport" | grep -E "^[0-9]+$" > /dev/null && [ "$setport" -lt 65535 ]; do
		echo -en "glftpd is listen on [$setglservice]: "
	read setport
	[ -z "$setport" ] && setport=$setglservice
		echo -e "glport=\"$setport"\" >> $config
	done
	until [ -n "$setglroot" ]; do
		echo -n "Please enter the directory where glftpd is installed [/glftpd]: "
	read glroot
	[ -z "$setglroot" ] && setglroot="/glftpd"
	echo -e "glroot=\"$setglroot"\" >> $config
	echo -e "gllog=\"$setglroot/ftp-data/logs/glftpd.log"\" >> $config
	echo -e "login=\"$setglroot/ftp-data/logs/login.log"\" >> $config
	echo -e "ms_log=\"$setglroot/ftp-data/logs/messages"\" >> $config
	done
	until [ -n "$setglconf" ]; do
		echo -n "Where is glftpd.conf, normaly in [/etc/glftpd.conf]: "
	read setglconf
	[ -z "$setglconf" ] && setglconf="/etc"
	echo -e "glconf=\"$setglconf/glftpd.conf"\" >> $config
	done
	clear
	until [ -n "$setacport" ]; do
		echo "You should have at least 10 ports per user, so if you have 30"
		echo "users online, this range should be 300, i.e. active_ports"
		echo "13000-13300"
		echo -n "Set the active_ports, standard [20000-21000]: "
	read setacport
	[ -z "$setacport" ] && setacport="20000;21000"
	echo -e "acport=\"$setacport"\" >> $config
	done
	echo -e "\n"
	until [ -n "$setpport" ]; do
		echo "You should have at least 10 ports per user, so if you have 30 users"
		echo "online, this range should be 300, i.e. pasv_ports 2200-2300"
		echo -n "Set the passive_ports, standard [22000-23000]: "
	read setpport
	[ -z "$setpport" ] && setpport="22000;23000"
	echo -e "pport=\"$setpport"\" >> $config
	done
	echo -e "\n"
	if [ -w /etc/xinetd.d/glftpd ]; then
		iftcp=`cat /etc/xinetd.d/glftpd | grep protocol | awk '{print $3}'`
		if [ "$iftcp" ]; then
			echo -e "glx=\"/etc/xinetd.d/glftpd"\" >> $config
		else
			echo -e "We need xinetd and tcp loging, now abort the script"
			rm -f $config
			exit 0
		fi
	else
		echo -e "We need xinetd and tcp loging, now abort the script"
		rm -f $config
		exit 0
	fi
	echo -e "\nNow check the required binaries and config files"
	if [ -e /etc/syslog.conf ]; then
		echo -e "\nSearch syslog.conf\t\t\t\t\t\t[ OK ]"
		echo -e "syslog=\"/etc/syslog.conf"\" >> $config
	else
		wissysl=`whereis syslog.conf | cut -d ' ' -f2`
		if [ "$wissysl" ]; then
			echo -e "\nSearch syslog.conf\t\t\t\t\t\t[ OK ]"
			echo -e "syslog=\"$wissysl"\" >> $config
		else
			echo -e "\nSearch syslog.conf\t\t\t\t\t\t[ Failed ]"
			rm -f $config
			exit 0
		fi
	fi
	if [ -e /sbin/iptables ]; then
		echo -e "\nSearch IP-Tables\t\t\t\t\t\t[ OK ]"
		echo -e "ippath=\"/sbin/iptables"\" >> $config
	else
		wisipt=`whereis iptables | cut -d ' ' -f2`
		if [ "$wisipt" ]; then
			echo -e "\nSearch IP-Tables\t\t\t\t\t\t[ OK ]"
			echo -e "ippath=\"$wisipt"\" >> $config
		else
			echo -e "\nSearch IP-Tables\t\t\t\t\t\t[ Failed ]"
			echo -e "\nCheck your kernel or modify it, now abort the script"
			rm -f $config
			exit 0
		fi
	fi
	if [ -x $glroot/bin/tac ]; then
		echo -e "\nCheck tac in $glroot/bin\t\t\t\t\t\t[ OK ]"
	else
		wistac=`whereis tac | cut -d ' ' -f2`
		echo -e "\nSearch tac in your System"
		if [ "$wistac" ]; then
			cp -f $wistac $glroot/bin/
			chmod 755 $glroot/bin/tac
			echo -e "\nCopy tac and set chmod 755\t\t\t\t\t[ OK ]"
		else
			echo -e "\nSearch tac in your system\t\t\t\t\t[ Failed ]"
			rm -f $config
			exit 0
		fi
	fi
	if [ -x $glroot/bin/awk ]; then
		echo -e "\nSearch awk in $glroot/bin\t\t\t\t\t\t[ OK ]"
	else
		wisawk=`whereis awk | cut -d ' ' -f2`
		echo -e "\nSearch awk in your System"
		if [ "$wisawk" ]; then
			cp -f $wisawk $glroot/bin/
			chmod 755 $glroot/bin/awk
			echo -e "\nCopy awk and set chmod 755\t\t\t\t\t[ OK ]"
		else
			echo -e "\nSearch awk in your system\t\t\t\t\t[ Failed ]"
			rm -f $config
			exit 0
		fi
	fi
	if [ -x $glroot/bin/grep ]; then
		echo -e "\nSearch grep in $glroot/bin\t\t\t\t\t\t[ OK ]"
	else
		wisgrep=`whereis grep | cut -d ' ' -f2`
		echo -e "\nSearch grep in your System"
		if [ "$wisgrep" ]; then
			cp -f $wisgrep $glroot/bin/
			chmod 755 $glroot/bin/grep
			echo -e "\nCopy grep and set chmod 755\t\t\t\t\t[ OK ]"
		else
			echo -e "\nSearch grep in your system\t\t\t\t\t[ Failed ]"
			rm -f $config
			exit 0
		fi
	fi
	if [ -e /etc/cron.d/fxp-trader ]; then
		echo -e "\nCheck fxp-trader cron avaible\t\t\t\t\t[ OK ]"
	else
		touch /etc/cron.d/fxp-trader
		echo "0 0-23 * * * root $setglroot/bin/fxp-clean.sh" >> /etc/cron.d/fxp-trader
		echo -e "\nCreate cron entry\t\t\t\t\t\t[ OK ]"
	fi
	if [ -e $setglroot/ftp-data/misc/badip ]; then
		echo -e "\nBad IP file was found\t\t\t\t\t[ OK ]"
	else
		touch $setglroot/ftp-data/misc/badip && chmod 666 $setglroot/ftp-data/misc/badip
		echo -e "\nBad IP file create and chmod 666 was set\t\t\t\t[ OK ]"
		echo -e "bad=\"$setglroot/ftp-data/misc/badip"\" >> $config
	fi
	echo -e "Save the Bad IP file somewhere else, the file delete by stop the script"
}

proc_check() {
if [ -e $setglroot/bin/fxpin.sh -a -e $setglroot/bin/fxpout.sh -a -e $setglroot/bin/fxp-clean.sh ]; then
	echo -e "\nCheck fxpin.sh in $setglroot/bin\t\t\t\t\t\t[ OK ]"
	echo -e "\nCheck fxpout.sh in $setglroot/bin\t\t\t\t\t\t[ OK ]"
	echo -e "\nCheck fxp-clean.sh in $setglroot/bin\t\t\t\t\t[ OK ]"
else
	cp -f fxpin.sh $setglroot/bin/ && chmod 755 $setglroot/bin/fxpin.sh
	echo -e "\nCopy fxpin.sh and set chmod 755\t\t\t\t[ OK ]"
	cp -f fxpout.sh $setglroot/bin/ && chmod 755 $setglroot/bin/fxpout.sh
	echo -e "\nCopy fxpout.sh and set chmod 755\t\t\t\t[ OK ]"
	cp -f fxp-clean.sh $setglroot/bin/ && chmod 755 $setglroot/bin/fxp-clean.sh
	echo -e "\nCopy fxp-clean.sh and set chmod 755\t\t\t\t[ OK ]"
	cp -f $config $setglroot/bin/
	echo -e "\nCopy $config to $glroot/bin/\t\t\t\t[ OK ]"
fi
}

if [ ! -r $config ]; then
	proc_setup
	proc_check
	echo -e "\nConfig is done now type fxp-setup.sh start"
	exit 0
else
	. $config
fi

if [ -r $config ]; then
ckver=`cat $config | grep -e VERSION | cut -d '=' -f2`
	if [ "$VER" != "$ckver" ]; then
		rm -f $glroot/bin/fxp-in.sh
		rm -f $glroot/bin/fxp-out.sh
		rm -f $glroot/bin/fxp-clean.sh
		rm -f $glroot/bin/fxp-trader.conf
		sed -e /VERSION=${ckver}/c\VERSION=${VER} $config >> fxp-trader1.conf
		mv -f fxp-trader1.conf $config
		proc_check
		echo -e "\nUpdating your files done"
	fi
fi

###Code###

pport1=`echo $pport | cut -d ';' -f 1`
pport2=`echo $pport | cut -d ';' -f 2`
apport1=`echo $acport | cut -d ';' -f 1`
apport2=`echo $acport | cut -d ';' -f 2`

if [ "$USER" = "root" ]; then
	if [ ! -f "$ippath" ]; then
		echo "Can not find IP-Tables, check your config or modify your kernel"
		exit 0
	fi
	if [ ! -f "$glconf" ]; then
		echo "Can not find $glconf, check your paths"
		exit 0
	fi
	if [ ! -w "$glconf" ]; then
		echo "Error. Can not read and write $glconf"
		exit 0
	else
		inon=`cat $glconf | grep -e "^#cscript" | grep ".fxpin" | cut -d '"' -f2`
		outon=`cat $glconf | grep -e "^#cscript" | grep ".fxpout" | cut -d '"' -f2`
		inoff=`cat $glconf | grep -e "^cscript" | grep ".fxpin" | cut -d '"' -f2`
		outoff=`cat $glconf | grep -e "^cscript" | grep ".fxpout" | cut -d '"' -f2`
	fi
	case $1 in
		-h|-H|\-[hH][eE][lL][pP])
			echo "You can use start, stop or clean"
		;;
		-v|-V)
			echo "FXP-TRADER Version 1.05.2"
		;;
	esac
	if [ "$1" = "start" ]; then
		echo "Check cron and modify"
		if [ -e /etc/cron.d/fxp-trader ]; then
			sed -e 's/^#//g' /etc/cron.d/fxp-trader > /etc/cron.d/fxp-trader1
			mv -f /etc/cron.d/fxp-trader1 /etc/cron.d/fxp-trader
			echo -e "Modify is done"
		else
			echo -e "You have delete the fxp-trader cron entry, now stop the script"
			exit 0
		fi
		if [ ! -f "$glx" ]; then
			echo "Can not find xinetd"
			exit 0
		else
			echo "Modify xinetd entry, turn on logging of IPs and restart"
			sed 's/-o -X/-o/g' $glx > /etc/xinetd.d/glftp
			mv -f /etc/xinetd.d/glftp $glx
			/etc/rc.d/init.d/xinetd restart
		fi
		echo "Write IP-Tables"
		$ippath -A INPUT -p tcp -m tcp -m state --dport $apport1:$apport2 --tcp-flags SYN,ACK,FIN,RST,URG,PSH SYN,ACK --state ESTABLISHED -j LOG  --log-prefix=Find
		$ippath -A INPUT -p tcp -m tcp -m state --dport $glport --tcp-flags SYN,ACK,FIN,RST,URG,PSH ACK --state ESTABLISHED -j LOG --log-prefix=TIME
		$ippath -A OUTPUT -p tcp -m tcp -m state --sport $pport1:$pport2 --tcp-flags SYN,ACK,FIN,RST,URG,PSH SYN,ACK --state ESTABLISHED -j LOG  --log-prefix=FindOUT
		echo "Writing and restart Syslog-Daemon"
		sys=`cat $syslog | grep -e "^#kern.info" | cut -d '"' -f2`
		if [ "$sys" ]; then
			sed -e 's/^#kern.info/kern.info/g' -e 's/^*.info/#*.info/g' -e 's/^authpriv/#authpriv/g' $syslog > /etc/syslog1.conf
			mv -f /etc/syslog1.conf $syslog
		else
			sed -e 's/^*.info/#*.info/g' -e 's/^authpriv/#authpriv/g' $syslog > /etc/syslog1.conf
			mv -f /etc/syslog1.conf $syslog
			echo "kern.info $glroot/ftp-data/logs/messages" >> $syslog
		fi
		/etc/rc.d/init.d/syslog reload
		echo "Write and modify into $glconf"
		if [ "$inon" ]; then
			sed 's/^#cscript/cscript/g' $glconf > /etc/glfxp.conf
		elif [ "$outon" ]; then
			sed 's/^#cscript/cscript/g' $glconf > /etc/glfxp.conf
			mv -f /etc/glfxp.conf $glconf
		else
			echo "###FXP-INFO-SETUP###" >> $glconf
			echo "active_ports $apport1-$apport2" >> $glconf
			echo "pasv_ports $pport1-$pport2" >> $glconf
			echo "cscript STOR POST /bin/fxpin.sh $flag" >> $glconf
			echo "cscript STOR RETR /bin/fxpout.sh $flag" >> $glconf
		fi
		echo "All settings done, dont forget to stop the script"
	elif [ "$1" = "stop" ]; then
		if [ ! = "$glx" ]; then
			echo "Can not find xinetd"
			exit 0
		else
			echo "Modify xinetd entry, turn off logging of IPs and restart"
			sed 's/-o/-o -X/g' $glx > /etc/xinetd.d/glftp
			mv -f /etc/xinetd.d/glftp $glx
		fi
		/etc/rc.d/init.d/xinetd restart
		echo "Deleting IP-Tables"
		$ippath -D INPUT -p tcp -m tcp -m state --dport $apport1:$apport2 --tcp-flags SYN,ACK,FIN,RST,URG,PSH SYN,ACK --state ESTABLISHED -j LOG  --log-prefix=Find
		$ippath -D INPUT -p tcp -m tcp -m state --dport $glport --tcp-flags SYN,ACK,FIN,RST,URG,PSH ACK --state ESTABLISHED -j LOG --log-prefix=TIME
		$ippath -D OUTPUT -p tcp -m tcp -m state --sport $pport1:$pport2 --tcp-flags SYN,ACK,FIN,RST,URG,PSH SYN,ACK --state ESTABLISHED -j LOG  --log-prefix=FindOUT
		echo "Stop syslog in glftpd"
		sed -e 's/^kern.info/#kern.info/g' -e 's/^#*.info/*.info/g' -e 's/^#authpriv/authpriv/g' $syslog > /etc/syslog1.conf
		mv -f /etc/syslog1.conf $syslog
		/etc/rc.d/init.d/syslog reload
		echo "Deleting $ms_log and delete the IPs in $gllog and $login"
		rm -f $ms_log
		sed -e 's/\<FXP/REMOVE/' -e 's/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/127.0.0.1/g' $gllog > $glroot/ftp-data/logs/glftp.log
		mv -f $glroot/ftp-data/logs/glftp.log $gllog
		sed -e 's/[:][[:space:]][^\b].*\@[^\b].*[[:space:]][(]/: disabled@disabled (/g;s/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/disabled/g' $login > $glroot/ftp-data/logs/log.log
		mv -f $glroot/ftp-data/logs/log.log $login
		sed -e 's/^0/#0/g' /etc/cron.d/fxp-trader > /etc/cron.d/fxp-trader1
		mv -f /etc/cron.d/fxp-trader1 /etc/cron.d/fxp-trader
		echo "Modify $glconf"
		if [ "$inoff" ]; then
			sed 's/^cscript/#cscript/g' $glconf > /etc/glfxp.conf
		elif [ "$outoff" ]; then
			sed 's/^cscript/#cscript/g' $glconf > /etc/glfxp.conf
			mv -f /etc/glfxp.conf $glconf
		fi
		echo "Delete Bad IP file"
		rm -f $glroot/ftp-data/misc/badip
		echo "All settings are stopped"
	elif [ "$1" = "clean" ]; then
		echo -e "Cleaning the logs"
		sed -e 's/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/127.0.0.1/g' $mslog > $glroot/ftp-data/logs/mslog
		mv -f $glroot/ftp-data/logs/mslog $mslog
		sed -e 's/\<FXP/REMOVE/' -e 's/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/127.0.0.1/g' $gllog > $glroot/ftp-data/logs/glftp.log
		mv -f $glroot/ftp-data/logs/glftp.log $gllog
		sed -e 's/[:][[:space:]][^\b].*\@[^\b].*[[:space:]][(]/: disabled@disabled (/g;s/[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}\.[0-9]\{0,3\}/disabled/g' $login > /ftp-data/logs/log.log
		mv -f $glroot/ftp-data/logs/log.log $login
		echo -e "\nDone"
	else
		echo -e "\nYou can use start, stop or clean"
	fi
else
	echo "You are not root"
fi
