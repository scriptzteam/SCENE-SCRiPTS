#!/bin/bash 
VER=4.0
#
# site duel <user>
# site duel list
#
# configure for chrooted running and make sure /glftpd/tmp is writable.
# this isn't perfect and could be speeded up in another language but its 
# all ya getting from me :D feel free to modify the code i ran outta ideas :P
#
# INSTALL
# make sure the binaries (grep cat expr cut etc..) are in /glftpd/bin
# make sure your /ftp-data/users is writeable 666/777 which ever works best
# tar zxvf sd.tar.gz
# gcc -o /glftpd/bin/random.c random;chmod a+x /glftpd/bin/random
# cp duel.sh /glftpd/bin;chmod a+x /glftpd/bin/duel.sh
# add the usual crap to dZSbot.tcl i don't support anything else.
# 
# set msgtypes(DEFAULT) "SDUEL"
# set chanlist(SDUEL)   "$sitechan"
# set disable(SDUEL)    0
# set variables(SDUEL)  "%u1 %u2 %msg"
# set announce(SDUEL)   "(\002DUEL\002) - \[%u1 vs. %u2\] %msg"
# 
# and glftpd.conf
# 
# site_cmd        DUEL            EXEC    /bin/duel.sh
# custom-duel     !8 *
#
# BACKUP YOUR USERS BEFORE RUNNING THIS SCRIPT!
# BACKUP YOUR USERS BEFORE RUNNING THIS SCRIPT!
# BACKUP YOUR USERS BEFORE RUNNING THIS SCRIPT!
# the script has been tested but just to be safe...
#
# ��������������������������������������������������������������
#
# config start.. (configure for chrooted (/glftpd) running)

SNAME="SITE"				;#sitename (plain, no fancy shit)
THEME="RROULETTE"			;#select your announce theme (VIKING/RROULETTE)
CF=2000					;#creds in MB to be able to duel (1000 = 1GB)
DUELERS="/tmp/duels"			;#relative to rootpath (make sure u create + chmod 777!)
DATAPATH="/ftp-data"			;#relative to rootpath
USRPATH="/ftp-data/users"		;#user path. (make sure u chmod it!)
LOGFILE="/ftp-data/logs/glftpd.log"	;#relative to rootpath

# * gadmins can add users and pump them for creds or change there ratio so they don't *
# * lose creds so i recommend setting below to 0 *

AZERO=0                                 ;#allow users to get under 0 credits on when losing? 0=no 1=yes
ALEECH=0				;#allow users on leech to play? 0=no 1=yes

# config end..
#
# ��������������������������������������������������������������
echo ".--------------------------------------------------------------."
/bin/printf "%-1s %-60s %s\n" "|" "$SNAME Duel v$VER" "|"
echo "\`--------------------------------------------------------------'"
case $1 in
	[lL][iI][sS][tT])
	duels=`ls $DUELERS|awk -F"." '{print $1 " has challenged " $2 " to a duel"}'`;
	if [ "$duels" = "" ]; then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "No current duels" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	else
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Current duels:" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	echo ""
	echo "$duels"
	echo ""
	fi
exit 0
esac
[ -z "$1" ] && {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Usage 'site duel list'" "|"
	/bin/printf "%-1s %-60s %s\n" "|" "      'site duel <username>'" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
exit 0
}
[ -w "$DUELERS" ] || {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Error: $DUELERS is not writable go bug a sysop!" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
exit 2
}
[ -w "$USRPATH" ] || {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Error: $USRPATH is not writable go bug a sysop!" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
exit 2
}
[ -w "$LOGFILE" ] || {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Error: $LOGFILE is not writable go bug a sysop!" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
exit 2
}
[ -f "$DATAPATH/users/$1" ] || {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Error: User '$1' doesn't exist." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
exit 2
}
CRED=`cat $DATAPATH/users/$USER|grep "^CREDITS"|awk '{print $2}'`
RATiO=`cat $DATAPATH/users/$USER|grep "^RATIO"|awk '{print $2}'`
WCRED=`cat $DATAPATH/users/$1|grep "^CREDITS"|awk '{print $2}'`
WRATiO=`cat $DATAPATH/users/$1|grep "^RATIO"|awk '{print $2}'`
CCRED=`expr $CF \* 1024`
[ "$USER" = "$1" ] && {
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "You wanna duel yourself huh!?" "|"
	/bin/printf "%-1s %-60s %s\n" "|" "........go play with the buses." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 wants to duel with himself, dumbass....\"" >> "$LOGFILE"
exit 1
}
if [ -f "$DUELERS/$1.$USER" ]; then
	LO=`exec /bin/random 0 100`
	HM=`exec /bin/random 0 20`
	NN="$HM"
	if [ `expr $WCRED - $CCRED` -lt 0 ] && [ $AZERO = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry the user who challenged u no longer has enough credits." "|"
	/bin/printf "%-1s %-60s %s\n" "|" "duel terminated...." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	rm -f $DUELERS/$1.$USER
	exit 0
	fi
	if [ $WRATiO = 0 ] && [ $ALEECH = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry, the user that challenged u has been given leech." "|"
	/bin/printf "%-1s %-60s %s\n" "|" "Leech users arn't allowed to duel." "|"
	/bin/printf "%-1s %-60s %s\n" "|" "duel terminated..." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	rm -f $DUELERS/$1.$USER
	exit 0
	fi
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Accepting $1's challenge...." "|" 
	echo "\`---------------------------------------------------[Pentagon]-'"
	if [ $NN = 0 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 realizes he bought his plastic halloween sword by accident!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 can't pull his sword out of the sheath!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 wonders whether that all was worth it and... <click>... boring :Q\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 jerks the trigger and... BANG!... \002$1\002 ended his life.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 1 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 lance pierces through \002$USER\002's shield and knocks him to the ground!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 stands over \002$USER\002's body and...SLICE!....chops his head off in one.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 pulls the trigger slowy... <click>... jammy twat!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 thinks his luck has just ended and... BANG!... \002$USER\002 will be reborn as little worm in China.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 2 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002's horse see's a hot donkey and sends him flying!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"The horse goes mad...STAMP! \002$1\002 is no more.....\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002\'s body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 says \`may the force be with me\`... <click>.... sigh..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 holds his lucky charm.... BANG! pfft lucky charm my arse..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 3 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 pulls out a gun and shoots \002$USER\002 in the face!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 falls to the ground....PHUD!.....\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002's hands are shaking so much the trigger pulls itself... <click>...lucky cunt!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 thinks nothing can go wrong ...BANG hes one dead motherfucker..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 4 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 goes karate on \002$USER\002's face!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 opens wide and takes a chuck out of \002$1\002's mid section with his metal teeth!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 wants to blow his own brains out ... <click> tuff shit\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002's fingers slip on the trigger, BANG... blows his brains all over the floor!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 5 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002's lance kills \002$USER\002's horse which sends him flying!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002's horse falls to the ground on top of him!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's squashed body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 says fuckit!... <click>.... :S\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 prays for a barrel of blanks... BANG! muhahahah..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 6 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 reaches into \002$1\002's chest and rips out his beating heart!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 starts twitching...EEK...UH..PHUD!....he falls to the ground.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 thinks its the end... <click>....jammy sod!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 feels the shit in his pants building up, pulls the trigger, BANG ... blows a 3 inch hole in his face!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 7 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002's sword rips through \002$USER\002's midsection and his bowels ooze out!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 starts twitching...EEK...UH..PHUD!....he falls to the ground.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 wants to end it.. <click>...tuff shit!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 looks at the siteops and pulls... BANG!..*tehehehee* :)\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 8 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 finds a double barrel automatic shotgun.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 starts firing..BANG! \002$1\002's chest ooze's out!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 prays for a +6, pulls the trigger .... <click> the lucky cunt escapes a cleanup once again!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 laughs in the face of death... BANG! his face ooze's off the wall...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 9 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 realizes he bought his plastic halloween sword by accident!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 can't pull his sword out of the sheath!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 spins the barrel and pulls hard.... <click>.. now do it again...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 takes a chance with two bullets left... BANG! ...muhahaha\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 10 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 reaches for his sword!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 swings wildly and decapitates \002$USER\002!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 gets a hard one on and... <click>... :->\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 prays for mercy... BANG!... oops...!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 11 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 takes a quick swing at \002$1\002 slicing his midsection open...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 prays to the siteops and... <click>... phew!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 is shitting himself, but pulls the trigger anyway.... BANG! ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 12 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 pulls a gun out and shoots at \002$1\002 twice to the rib section..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blocks the bullets with his shield and decapitates \002$USER\002 with his sword!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 wonders why this is happening to him... <click>.. :O\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 starts to cry screaming MUMMY!!.... BANG!... muhahaha!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 13 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 runs from \002$USER\002 cause he has a bigger sword ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 throws a spear into \002$1\002's back!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 puts the gun in his mouth and pulls the trigger... <click>... ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 is totally excited and... BANG!... =//\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 14 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 thinks it isn't worth all the fighting and thrusts his sword into his chest!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 isn't a pussa and just pulls hard... <click>... ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 dont waste no time, pulls the trigger hard, BANG!...his brains ooze off the light socket...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 15 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002's horse trips on some wood sending him flying!...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 slices \002$1\002's head off....\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 is shitting himself, but pulls the trigger anyway ... <click> :>\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 pulls back the hammer and puts the gun to his head.... BANG!.. cya!.. \"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 16 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 throws a spear into \002$USER\002's horses midsection.\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 falls to the ground breaking his spine!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 would prefer to run away but... <click>... ;)\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 spins the chamber... BANG!... :(\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 17 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 throws his spear at \002$1\002 hitting him in the heart!..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 gives his luck a chance and... <click>... nothing happens...\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 wonders whether that all was worth it and... BANG!... :Q\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 18 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 trys to pull out his lance but it seems stuck!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 throws two daggers at \002$USER\002 both piercing an eyeball each!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 prays to the siteops and... <click>... phew!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 is crapping himself.. BANG!.... :O\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 19 ];then
	WINNER=$USER
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 sneaks up behind \002$1\002 and stabs him with his sword!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 loots \002$CF\MB\002 from \002$1\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 has piss rolling down his leg, pulls the trigger ... <click>..clean yourself up boy! ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 wonders why he never lost his virginity... BANG!...poor bastard!..\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 blew his fucking brains all over the wall, \002$USER\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $NN = 20 ];then
	WINNER=$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 mounts his steed and accepts \002$1\002's challenge, let the tournement begin!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002's horse trips on a rock and sends him flying!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$1\002 takes advantage of this and sends his horse to STOMP! on \002$USER\002\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 loots \002$CF\MB\002 from \002$USER\002's body.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"Get ready for Russian Roulette!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$1\002 thinks he's in the zone and pulls the trigger with confidence ... <click> ://\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 *sigh* pulls the trigger.. BANG!....ekk!\"" >> "$LOGFILE"
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 blew his fucking brains all over the wall, \002$1\002 laughs his ass off and runs away with \002$CF\MB\002 of creds.\"" >> "$LOGFILE"
	fi
	fi
	if [ $WINNER = $USER ];then
	LO=`grep "^CREDITS" $USRPATH/$USER|awk '{print $2}'`
	cat $USRPATH/$USER|grep -v "^CREDITS" >> $DUELERS/$USER.temp
	OL=`expr $CRED + $CCRED`
	echo "CREDITS $OL" >> $DUELERS/$USER.temp
	rm -f $USRPATH/$USER
	mv -f $DUELERS/$USER.temp $USRPATH/$USER
	PO=`grep "^CREDITS" $USRPATH/$1|awk '{print $2}'`
	cat $USRPATH/$1|grep -v "^CREDITS" >> $DUELERS/$1.temp
	OP=`expr $WCRED - $CCRED`
	echo "CREDITS $OP" >> $DUELERS/$1.temp
	rm -f $USRPATH/$1
	mv -f $DUELERS/$1.temp $USRPATH/$1
	else
	LO=`grep "^CREDITS" $USRPATH/$1|awk '{print $2}'`
	cat $USRPATH/$1|grep -v "^CREDITS" >> $DUELERS/$1.temp
	OL=`expr $WCRED + $CCRED`
	echo "CREDITS $OL" >> $DUELERS/$1.temp
	rm -f $USRPATH/$1
	mv -f $DUELERS/$1.temp $USRPATH/$1
	PO=`grep "^CREDITS" $USRPATH/$USER|awk '{print $2}'`
	cat $USRPATH/$USER|grep -v "^CREDITS" >> $DUELERS/$USER.temp
	OP=`expr $CRED - $CCRED`
	echo "CREDITS $OP" >> $DUELERS/$USER.temp
	rm -f $USRPATH/$USER
	mv -f $DUELERS/$USER.temp $USRPATH/$USER
	rm -f $DUELERS/$1.$USER >/dev/null 2>&1
	exit 0
	fi
	else
	if [ $RATiO = 0 ] && [ $ALEECH = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry, not allowed to duel on leech accounts." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	exit 0
	fi
	if [ `expr $CRED - $CCRED` -lt "0" ] && [ $AZERO = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry u don't have enough credits to duel." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	exit 0
	fi
	if [ `expr $WCRED - $CCRED` -lt 0 ] && [ $AZERO = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry but '$1' dosn't have enough credits to duel." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	exit 0
	fi
	if [ $WRATiO = 0 ] && [ $ALEECH = 0 ];then
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "Sorry but '$1' has a leech account." "|"
	/bin/printf "%-1s %-60s %s\n" "|" "Users on leech arn't allowed to duel.." "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	exit 0
	fi
	echo "|                                                              |"
	/bin/printf "%-1s %-60s %s\n" "|" "$1 has been challenged to a duel!" "|"
	echo "\`---------------------------------------------------[Pentagon]-'"
	touch $DUELERS/$USER.$1
	if [ $THEME = "VIKING" ];then
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$USER\" \"$1\" \"\002$USER\002 sharpens his sword and challenges \002$1\002 to a duel.\"" >> "$LOGFILE"
	else
	echo "$(date +'%a %b %d %T %Y') SDUEL: \"$1\" \"$USER\" \"\002$USER\002 challenges \002$1\002 to a game of russian roulette!\"" >> "$LOGFILE"
	fi
exit 0
fi
