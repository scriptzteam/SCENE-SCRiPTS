#!/usr/bin/perl

# ----------------------------------------------------------------------------------
#   iono-affils.pl v1.0
#
#   outputs an affil list based off contents of a "group/affils" directory in which
#   group/pre dirs are sub-directories (so isn't suitable for all sites, designed
#   for single affiled section sites, eg mp3)
#
#   args: none.
# ----------------------------------------------------------------------------------

# path to your group dir
my $groupdir = "/glftpd/site/groups";


# array with directories to exclude from output, add what you want here, or
# comment it out completely.
@excluded[0] = "STAFF";
#@excluded[1] = "etc";
#@excluded[2] = "etc...";

my $header = "[SITE-AFFILS] ";	# leave a space at the end

#########################################################################################
my $msg, $count = 0;

$msg = $header;

opendir(DIR, $groupdir) || die "ERROR: Can't Opendir \"$groupdir\" ('$!'),  check configuration!\n";

while (defined($group = readdir(DIR))) {
        ($msg .= "$group ", $count++) unless (($group eq ".") || ($group eq "..") || (groupmatch($group) == 1));
}

$msg .= "($count Groups)";

print "$msg\n";

# sub-proc to match current group with excluded groups
sub groupmatch {
        foreach $exgrp (@excluded) {
                return 1 unless ($exgrp ne $group);
        }
        return 0;
}

