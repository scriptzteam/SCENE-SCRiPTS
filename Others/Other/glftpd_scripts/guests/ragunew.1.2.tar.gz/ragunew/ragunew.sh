#!/bin/bash
###########################################################################
# IRCNEW 1.0 by ragusallad
#
# Nifty script that will ouput the newest
# dirs of stated sections into an irc-channel
#
# INC		tag of incomplete dirs, so we won't show them
# GROUPDIR	The dir of your PRE-groups, so we won't show the PREdir
# SECTIONS	Your sections, name:where it's located relativ to siteroot
#
###########################################################################

INC="(incomplete)"
GROUPDIR="PRE"
SITENAME="RES"
SITEROOT="/glftpd/site/"
today="$( date +%m%d )"
SECTIONS="
apps:Apps/ISO
games:Games/ISO
divx:DivX
svcd:SVCD
vcd:VCD
dox:Games/DOX
0day:Apps/0day/$today
"

if [ "$1" = "" ]; then
for SECTION in $SECTIONS; do
    SEC="$(echo $SECTION | cut -d':' -f1)"
    if [ "$SEC2" ]; then
	SEC2="$SEC2 $SEC"
    else
	SEC2="$SEC"
    fi
done
    echo "Usage: !resnew, available sections = $SEC2"
fi

for each in $SECTIONS; do
    SECTION="$(echo $each | cut -d':' -f1)"
    DIR="$(echo $each | cut -d':' -f2)"
    if [ "$( echo $SECTION | grep -wi "$1")" ]; then
	new="$( ls -t $SITEROOT$DIR | grep -v $INC | grep -v $GROUPDIR | head -n5 )"
        echo "5 Newest $SECTION"
        echo "$new"
        exit 0
    fi
done
