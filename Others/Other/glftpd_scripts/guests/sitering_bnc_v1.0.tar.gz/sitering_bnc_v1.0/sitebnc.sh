#!/bin/bash

# LOGIN TO THE SiTES! (Need to work on all sites)
LOGiN="sitebot"

# PASS TO THE SiTES! (Need to work on all sites)
PASS="he3333"

# HOW LONG TO TRY TO CONNECT TO SiTE!
TiMEOUT="10"

# WHERE YOU GOT BNCTEST.SH LOCATED
BNCTEST="/glftpd/bin/bnctest.sh"

# WHERE YOU GOT NCFTPLS LOCATED
NCFTPLS="/usr/bin/ncftpls"

# WHERE TO STORE THE BNC STATUS LOG FiLE
BNCLOGFiLE="/glftpd/ftp-data/logs/bnc.log"

# ENTER ALL YOUR SiTES iN THE RiNG DOWN HERE
# EXAMPLE
# SiTENAME HOST PORT SECTiONS

BNCIP="
aag aag.mine.nu 929 MP3,DVDr
aga aga.mine.nu 992 SVCD,DiVX,XBOX,PS2,GAMES,DOX
gga gaa.mine.nu 299 0day"

# DONT TOUCH BELOWE!
rm $BNCLOGFiLE
SiTEIP="none"
SiTE="none"
PORT="none"
SECTiON="none"
for ARGS in $BNCIP;do
	if [ $SiTE == "none" ]
	then
		SiTE=$ARGS
	fi

	if [ $SiTEIP == "none" ]
	then
		if [ $SiTE == $ARGS ]
		then
			SUXX="TRUE"
		else
			SiTEIP=$ARGS
		fi
	fi

	if [ $PORT == "none" ]
	then
		if [ $SiTE == $ARGS ]
		then
			SUXX="TRUE"
		else
			if [ $SiTEIP == $ARGS ]
			then
				SUXX="TRUE"
			else
				PORT=$ARGS
				SECTiON="next"
			fi
		fi
	fi

	if [ $PORT == $ARGS ]
	then 
		SUXX="TRUE"
	else
        	if [ $SECTiON == "next" ]
		then
			SECTiON=$ARGS
			STATUS=`$BNCTEST $NCFTPLS $LOGiN $PASS $PORT $TiMEOUT $SiTEIP`
			echo $SiTE $SiTEIP:$PORT $STATUS $SECTiON>> $BNCLOGFiLE
			SiTEIP="none"
			SiTE="none"
			PORT="none"
			SECTiON="none"
		fi
	fi
done
