# Where your glftpd is installed
glftpddir="/glftpd"

# The site name
sitename="[-dds-]"

# Where the glftpd.log is located
logfile="/glftpd/ftp-data/logs/glftpd.log"

### No need to edit belowe ###
release=`cat $logfile |grep $1|grep -m1 NEWDIR|cut -d '"' -f2`
if [ "$release" ]
then
mkdir $glftpddir$release/$sitename" - Approved by "$2" - "$sitename
chmod 0777 $glftpddir$release/$sitename" - Approved by "$2" - "$sitename
echo "[APPROVE] $1 was approved by $2"
else
echo "[APPROVE] $2.. Could not find the release!"
fi
