#!/bin/bash

                         ##                     ##
                        ##  nukereq 1.0 by ugly  ##
                         ##                     ##


sitename="-MYNAME-"        # replace this with the name of your site
root="/jail/glftpd"        # full glftpd root path
delall="YES"               # allow all users to delete a nuke request in the
                           # public channel?


### END CONFIG ###


### AUTO-DETECT ENVIRONMENT ###

if [ ! -d "$root" ];
  then
    nfile="/ftp-data/misc/nukerequests"
    delall="YES"
  else
    nfile=""$root"/ftp-data/misc/nukerequests"
fi

if [ ! -w "$nfile" ];
  then
    echo ""$nfile" isn't writable or doesn't exist!"
    exit 0
fi

### END ###

case "$1" in
  help*)
    if [ -d "$root" ]; then
      if [ "$delall" = "NO" ]; then
        echo ""$sitename" [NUKEREQ] + Make or list nuke requests.  Add nuke syntax: !nukereq <rel> <reason>.  List nuke requests syntax: !nukereqls."
        exit 0
      else
        echo ""$sitename" [NUKEREQ] + Make, delete, or list nuke requests.  Add nuke request syntax: !nukereq <rel> <reason>.  Delete nukereq syntax: !nukereq del <#>.  Delete all nukereqs syntax: !nukereq clean.  List nuke requests syntax: !nukereqls."
      fi
    else
      echo "Syntax: SITE NUKEREQ [ help | list | clean | del <#> | <release> <reason> ]: Make, delete, or list nuke requests."
    fi
    exit 0
  ;;
  del*)
    if [ "$delall" = "NO" ]; 
      then
        echo ""$sitename" [NUKEREQ] + ERROR: You do not have permission to delete a nuke request!"
        exit 0
       else
         if [ "$2" = "" ]; then
           echo ""$sitename" [NUKEREQ] + ERROR: You did not enter a nuke request number."
	   exit 0
         fi
	 delnum=`echo "$2" | sed -e 's/[^[:digit:]]//g'`
	 if [ "$delnum" = "" ] || [ "$delnum" -eq 0 ];
	   then
	     echo ""$sitename" [NUKEREQ] + ERROR: Invalid nuke request number."
	     exit 0
	 fi
	 if [ "$delnum" -lt 10 ];
	   then
	     delnum="0"$delnum""
	 fi
	 if [ `grep -c "" "$nfile"` -lt "$delnum" ];
	   then
	     echo ""$sitename" [NUKEREQ] + ERROR: Nuke request #"$delnum" does not exist in the database."
	     exit 0
	   else
	     delrel=`cat "$nfile" | head -n "$delnum" | tail -1 | awk '{printf $3}'`
             tmp_file=`cat "$nfile"`
             echo "$tmp_file" | grep -v "$delrel" > "$nfile"
	     echo ""$sitename" [NUKEREQ] + "$delrel" removed from nuke request database."
	 fi
     fi
     exit 0
  ;;
  list)
    if [ -d "$root" ];
      then
        cat "$root"/ftp-data/misc/nukerequests.head
	cat "$nfile" | nl -n rz -w 2 -p | awk '{print "#"$0}' | tr '\t' ' '
        cat "$root"/ftp-data/misc/nukerequests.foot
      else
        cat /ftp-data/misc/nukerequests.head
	cat "$nfile" | nl -n rz -w 2 -p | awk '{print "#"$0}' | tr '\t' ' '
	cat /ftp-data/misc/nukerequests.foot
    fi
    exit 0
  ;;
  clean)
    echo -n > "$nfile"
    exit 0
  ;;
esac

### ADD NUKEREQ LINES ###

if [ "$1" = "" ]; then
  echo ""$sitename" [NUKEREQ] + Make or list nuke requests.  Add nuke syntax: !nukereq <rel> <reason>.  List nuke requests syntax: !nukereqls."
  exit 0
fi

if [ "$2" = "" ]; then
  echo ""$sitename" [NUKEREQ] + You didn't enter a nuke reason!"
  exit 0
fi

date=`date "+%m%d"`

### ADD NUKE AND ANNOUNCE ###

if [ -d "$root" ];
  then
    echo ""$date"  "$3"  "$1"  "$2"" >> "$nfile"
  else
    reason=`echo "$@" | sed -e "s/$1//g"`
    echo ""$date"  "$USER"  "$1""  "$reason" >> "$nfile"
fi

echo ""$sitename" [NUKEREQ] + Nuke request added to database."

exit 0
