#!/bin/sh
# fulhack (C) vip3r@i386.net / wh3e@hugbox.net 
#####

# The quota to use.
QUOTA=5000

# Where is the userfiles located
USERDIR=/glftpd/ftp-data/users/

# The name of your trial group
TRiAL="TRiAL"

# Groups to ignore from passed.

IGNOREG="
Friends
SiTEtech
SiTEOP
fBX
TRiAL
"
#### DONT EDIT BELOW! ####
USERFILE=$USERDIR$1
export EXIST=`ls -1 $USERDIR | grep -w $1`
if [ "$EXIST" == "" ]
then
 echo $1' is not a valid username.'
 exit
fi

GROUP=`cat $USERFILE|head -21|tail -1|awk '{print $2}'`

UPLOAD=`cat $USERFILE|head -16|tail -1|awk '{print $3}'`
let UPLOAD=$UPLOAD/1024
if [ "$GROUP" == "$TRiAL" ]
then
        echo $1'@'$GROUP'. You are on trial so check that instead.'
        exit
fi

if [[ $IGNOREG == *$GROUP* ]]
then
        echo $1'@'$GROUP'. '$GROUP' dont need to pass quota. But '$1' have uploaded: '$UPLOAD'Mb this month.'
        exit
fi
if [ "$UPLOAD" -ge "$QUOTA" ]
then
	MESSAGE=$1'@'$GROUP' have passed the monthly quota! '$UPLOAD'Mb/'$QUOTA'Mb.'
else
	MESSAGE=$1'@'$GROUP' have not passed the monthly quota! '$UPLOAD'Mb/'$QUOTA'Mb.'
fi
echo $MESSAGE
