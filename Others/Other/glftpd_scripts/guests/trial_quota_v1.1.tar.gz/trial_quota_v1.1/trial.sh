#!/bin/sh
# fulhack (C) vip3r@i386.net / wh3e@hugbox.net 
#####

# Where is your userdir located
USERDIR=/glftpd/ftp-data/users/

# Amount you want to use for quota. (Mb)
TRiALQ=2000

# Path to your passwd file
PASSWDFILE=/glftpd/etc/passwd

# Name on the trial group
TRIALG=TRiAL


###DONT EDIT UNDER THIS ####

USERFILE=$USERDIR$1
export EXIST=`ls -1 $USERDIR | grep -w $1`

if [ "$EXIST" == "" ]
then
	echo $1' is not a valid username.'
	exit
fi
GROUP=`cat $USERFILE|head -21|tail -1|awk '{print $2}'`
if [ "$GROUP" == "$TRIALG" ]
then
	UPLOAD=`cat $USERFILE|head -10|tail -1|awk '{print $3}'`
	let UPLOAD=$UPLOAD/1024

        if [ "$UPLOAD" -ge "$TRiALQ" ]
        then
		MESSAGE=$1'@'$GROUP' have passed his TRiAL! '$UPLOAD'Mb/'$TRiALQ'Mb.'
        else
		MESSAGE=$1'@'$GROUP' have not passed his TRiAL! '$UPLOAD'Mb/'$TRiALQ'Mb.'
        fi
        PASSWD=`cat $PASSWDFILE|grep $1:`
	echo $MESSAGE'|'$PASSWD
else
	echo $1' is not on TRiAL. Try the quota command.'
fi
