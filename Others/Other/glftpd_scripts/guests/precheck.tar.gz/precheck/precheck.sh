#!/bin/sh
# Version 0.1 by Teqno
#
# Configure 
glpath=/glftpd/ftp-data/logs/glftpd.log
log=/glftpd/ftp-data/logs/precheck.log
# End of Config
#
# Don't change anything below this line
################################################
if [ "$1" = "" ] ; then
echo "You need to specify a group"
else
cat $glpath | grep PRE: | grep -n -i $1 > $log
echo "The group $1 have preed a total of `cat -n $log | tail -n 1 | awk -F '[ \t]+' '{print $2}'` times since 28th December 2004"
echo "Last Pre : " `cat $log | tail -n 1 | awk -F '[ /]+' '{print $2}''{print $3}''{print $5}'`
echo "Time :  " `cat $log | tail -n 1 | awk -F '[ /]+' '{print $4}'`
echo "Pre : " `cat $log | tail -n 1 | awk -F '[ :]+' '{print $10}'`
cat /dev/null > $log
fi
#EOF