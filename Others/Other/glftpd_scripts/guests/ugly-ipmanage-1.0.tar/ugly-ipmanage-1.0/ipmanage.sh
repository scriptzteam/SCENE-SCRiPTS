#!/bin/bash

                         ##                      ##
                        ##  ipmanage 1.0 by ugly  ##
                         ##                      ##


siteop="myuser"                           # user to be used for logging into the
                                          # site for adding, deleting, and
                                          # listing IPs

siteop_pass="mypasssword"                 # password for the above user

ftp_host="127.0.0.1"                      # site IP
ftp_port="1337"                           # site port

lftp_path="/usr/local/bin/lftp"           # path to 'lftp' - 'ncftp3' will work
                                          # as well, but 'ftp' will NOT

passwd_file="/glftpd/etc/passwd"          # site's glftpd passwd file
passchk_bin="/glftpd/bin/passchk"         # passchk binary - used for
                                          # authentication 

user_path="/glftpd/ftp-data/users/"       # directory containing your userfiles

deny_users=( sitebot user1 user2 )        # space separated list of usernames
                                          # that are not allowed to use this
                                          # script (good place for bot 
                                          # usernames, etc.)

email_db="/glftpd/ftp-data/misc/email.db" # file used for storing users' email
                                          # addresses
encrypted_db=YES                          # set to "YES" if your email db is
                                          # encrypted
encrypted_cipher="aes256"                 # set the cipher that your db is
                                          # encrypted with - see 'openssl enc ?'
                                          # for a list of ciphers
keystore="/glftpd/ftp-data/keystore/key"  # file to store passkey for encrypted
                                          # email db - should be a TEMPORARY
                                          # location such as a memory-disk

ip_db="/glftpd/ftp-data/misc/ip/"         # directory to store users' temp key
                                          # files

max_key_age="24"                          # number of hours before a key expires

sendmail_bin="/usr/local/sbin/sendmail"   # path to your sendmail binary


### END CONFIG ###


version=1.0

# DATE BIN
if [ `uname` = "Linux" ];
  then
    date_bin=`which date`
  else
    date_bin="/usr/local/bin/gdate"
fi
if [ ! -f "$date_bin" ]; then
  echo "*BSD users: this script requires the 'gdate' binary that comes with"
  echo "            sh-utils or coreutils (found in your ports tree)"
  exit 0
fi

# encryption configured but no cipher specified and/or no key stored
if [ "$encrypted_db" = YES ]; then 
  if [ -z "$encrypted_cipher" ]; then
    echo "Email database configured as encrypted, but no cipher specified!"
    exit 0
  fi
  if [ ! -f "$keystore" ] || [ -z `cat "$keystore"` ]; then
    echo "No key stored for decrypting the email database!"
    exit 0
  fi
fi


# DB CHECKS
if [ ! -w "$email_db" ] || [ ! -w "$ip_db" ]; then
  echo "Bad permissions or non-existant email or ip database(s)."
  exit 0
fi 

# EXPIRED KEY CLEANUP
anyexist=`ls "$ip_db"`
if [ ! -z "$anyexist" ]; then
  for i in "$ip_db"/*; do
    basename=`basename "$i"`
    gnu_age=`$date_bin -r "$i" +%s`
    gnu_current=`$date_bin --date "-$max_key_age hours" +%s`
    max_age=$(( $max_key_age * 3600 ))
    age_sec=$(( $gnu_current - $gnu_age ))
    if [ $age_sec -gt $max_age ]; then
      rm "$i"
    fi
  done
fi

# KEY AUTHENTICATION

if [ "$1" = "keyip" ] && [ -f "$ip_db"/"$2" ] && [ ! -z $3 ];
  then
    stored_key=`cat "$ip_db"/"$2" | awk '{print $1}'`
    action=`cat "$ip_db"/"$2" | awk '{print $2}'`
    stored_ips=`cat "$ip_db"/"$2" | sed -e "s/$stored_key //" -e "s/$action //"`
    if [ $3 = "$stored_key" ]; 
      then
        if [ $action = list ]; then
          list_output=`cat "$user_path"/"$2" | grep -E "^IP " | awk '{print $2}' | tr '\n' ' '`
          echo "IPs: "$list_output""
          rm "$ip_db"/"$2"
          exit 0
        fi
        echo "site "$action"ip "$2" "$stored_ips"" | \
        "$lftp_path" ftp://"$siteop":"$siteop_pass"@"$ftp_host":"$ftp_port" | sed -e 's/^200 //g' -e 's/^200- //g'
        rm "$ip_db"/"$2"
        exit 0
      else
        echo "Invalid key!  Does not match stored value."
        exit 0
     fi
fi

# ARGUMENT CHECKS

# keyip specified incorrectly or key expired
if [ "$1" = "keyip" ]; then
  echo "Syntax error or key has expired!  Syntax: !keyip <user> <key>"
  exit 0
fi

# too few args
if [ $# -lt 3 ]; then
  echo "Syntax: !ip add|del|list <user> <pass> [<ident@ip1> <ident@ip2> ... ]"
  exit 0
fi

# add or del was specified with too few args
if [ $# -lt 4 ] && [[ $1 = "add" || $1 = "del" ]]; then
  echo "Syntax: !ip add|del|list <user> <pass> [<ident@ip1> <ident@ip2> ...]"
  exit 0
fi

# list, add, and del weren't specified as first arg
if [[ $1 != list && $1 != add && $1 != del ]] || [ $# -eq 0 ]; then
  echo "Syntax: !ip add|del|list <user> <pass> [<ident@ip1> <ident@ip2> ...]"
  exit 0
fi

# user doesn't exist
if [ ! -f "$user_path"/$2 ]; then
  echo "Invalid username!"
  exit 0
fi

# user on deny list
on_list=`echo ${deny_users[@]} | grep -E "(^|\b)$2($|\b)"`
if [ ! -z "$on_list" ]; then
  echo "Username is on deny list!"
  exit 0
fi

# user already has 10 IPs added, or is adding too many IPs
if [ $1 != list ];
  then
    num_ips=`grep -Ec "^IP " "$user_path"/$2`

    num_ips_add=$(( $# - 3 ))
    total_ips=$(( $num_ips_add + $num_ips ))

    if [ $num_ips -eq 10 ]; then
      echo "10 IPs have already been added to this account!"
      exit 0
    fi

    if [ $total_ips -gt 10 ]; then
      echo "Attempting to add too many IPs! (current = $num_ips, adding = $num_ips_add, total = $total_ips, max = 10)"
      exit 0
    fi
fi

# IP/host portion of ident@ip script contains invalid characters
if [ `uname` = Linux ];
  then
    seq=`which seq`
  else
    seq="/usr/local/bin/gseq"
fi 
for i in `$seq 4 $#`; do
  badarg=`echo ${!i} | sed -e 's/.*@//g' | grep -E "[^A-Za-z\@0-9\.\*_-]"`
  if [ ! -z ${badarg} ]; then
    num=$(( $i - 3 ))
    echo "IP/host #$num is not in proper ident@ip format! (${!i})"
    exit 0
  fi
done

# AUTHENTICATION
match=`$passchk_bin $2 $3 $passwd_file`

if [ "$match" != "MATCH" ]; then
  echo "Authentication error!  Password doesn't match."
  exit 0
fi

# SET KEY VALUE
key=$RANDOM 

# MAIL KEY
if [ "$encrypted_db" = YES ];
  then
    email=`openssl enc -$encrypted_cipher -salt -d -in "$email_db" -pass \
           file:"$keystore" | grep -E "^$2\b" | awk '{print $2}'`
  else
    email=`grep -E "^$2\b" "$email_db" | awk '{print $2}'`
fi
if [ -z "$email" ]; then
  echo "Nowhere to send key!  An email address has not been set for $2.  Use 'site email <email@address>' from the site, and then try again."
  exit 0
fi

echo -e "To: "$email"\nFrom: no@reply.org (site keygen)\nSubject: site key\nDo not reply to this email.  You are receiving this automated message\nbecause you or someone with your username/password has attempted to\nadd, delete, or list your current IPs on this site.  To confirm this,\nplease enter the following from IRC:\n\n/msg <sitebot> !keyip $2 $key\n\nIf you do not enter this command within $max_key_age hours, the key will expire.\n\n--ipmanage $version" | "$sendmail_bin"

echo "Key has been emailed."

# ADD TO IP_DB
if [ -f "$ip_db"/"$2" ]; then
  rm "$ip_db"/"$2"
fi

output=`echo $@ | sed -e "s/$2 //" -e "s/$3 //"`
echo "$key $output" >> "$ip_db"/"$2"

exit 0
