#!/bin/bash
############################################################
#approve.sh 2.0 by ragusallad                              #
#Look below for important changes                          #
############################################################
SITENAME="XXX"                 #Change this to your sitename
SITEDIR="/glftpd/site/"        #This is where you have your sitefolder

#Correctly spelled sections needed here
SECTIONS="
DivX
SVCD
"
NUMFOLDERS="2"                 #How many SECTIONs is there above?

#########################################################################
#End of config, don't touch below, or your cat will be castrated etc etc#
#########################################################################

FOUND="NO"

if [ "$1" = "" ]; then
    echo "Usage: !approve <release>"
    exit 0
else

    while [ "$NUMFOLDERS" != "0" ]
    do
	for stuff in $SECTIONS; do
	    folders="$( echo $stuff | awk '{print $1}' )"
    
	    if [ -d $SITEDIR$folders/$1 ]; then
		touch $SITEDIR$folders/$1/[Approved_by_$2]
		echo "-$SITENAME- [APPROVE] + Approved in $folders : $1 by $2"
		FOUND="YES"
		let "NUMFOLDERS -= 1"
	    else
		let "NUMFOLDERS -= 1"
	    fi

    done
    done

if [ $FOUND = "NO" ]; then
    echo "No release named like that"
    exit 0
fi
fi
exit 0
