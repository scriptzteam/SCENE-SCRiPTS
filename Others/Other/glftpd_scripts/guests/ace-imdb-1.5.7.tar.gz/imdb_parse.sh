#!/bin/bash

log="/ftp-data/logs/glftpd.log"

date=`date +"%a %b %d %H:%M:%S %Y"`
fname="$@"

case "$PWD/" in 
/site/GROUPS/*) 
exit 0; 
;; 
esac 



case $fname in
 *.[nN][fF][oO])
  link=`grep -i imdb $fname | tr ' ' '\n' | sed -n /[hH][tT][tT][pP]:[/][/].*[iI][mM][dD][bB]/p | tail -1` 
  if [ ! -z "$link" ] && [ -e "$log" ] ; then
   echo "$date IMDB: \"$PWD\" \"$link\"" >> $log
  fi
  link=`grep -i allocine $fname | tr ' ' '\n' | sed -n /[hH][tT][tT][pP]:[/][/].*[.][aA][lL][lL][oO][cC][iI][nN][eE].*/p | head -n 1`
  if [ ! -z "$link" ] && [ -e "$log" ] ; then
   echo "$date ALLOCINE: \"$PWD\" \"$link\"" >> $log
  fi
 ;;
esac
