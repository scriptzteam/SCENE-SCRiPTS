#!/bin/sh

# The quota to use.
QUOTA=5000

# Where is the userfiles located
USERDIR=/glftpd/ftp-data/users/

# The name of your trial group
TRiAL="TRiAL"

# Groups to ignore from passed.

IGNOREG="
Friends
SiTEtech
SiTEOP
fBX
Owners
LiGHT
"

# Location of your passwd
PASSWD=/glftpd/etc/passwd

# Change this for your own needs. FEB for 29 days in 2004.
JAN=31
FEB=29
MAR=31
APR=30
MAY=31
JUN=30
JUL=31
AUG=31
SEP=30
OCT=31
NOV=30
DEC=31

#### DONT EDIT BELOW! ####
USERFILE=$USERDIR$1
export EXIST=`ls -1 $USERDIR | grep -w $1`
if [ "$EXIST" == "" ]
then
 echo $1' is not a valid username.'
 exit
fi
GROUP=`cat $USERFILE|head -21|tail -1|awk '{print $2}'`
UPLOAD=`cat $USERFILE|head -16|tail -1|awk '{print $3}'`
let UPLOAD=$UPLOAD/1024

#####
DAY=`date|cut -d ' ' -f3`
MONTH=`date|cut -d ' ' -f2`

if [ $MONTH == "Jan" ]
then
        MONTH="01"
        MDAYS=$JAN
fi
if [ $MONTH == "Feb" ]
then
        MONTH="02"
        MDAYS=$FEB
fi
if [ $MONTH == "Mar" ]
then
        MONTH="03"
        MDAYS=$MAR
fi
if [ $MONTH == "Apr" ]
then
        MONTH="04"
        MDAYS=$APR
fi
if [ $MONTH == "May" ]
then
        MONTH="05"
        MDAYS=$MAY
fi
if [ $MONTH == "Jun" ]
then
        MONTH="06"
        MDAYS=$JUN
fi
if [ $MONTH == "Jul" ]
then
        MONTH="07"
        MDAYS=$JUL
fi
if [ $MONTH == "Aug" ]
then
        MONTH="08"
        MDAYS=$AUG
fi
if [ $MONTH == "Sep" ]
then
        MONTH="09"
        MDAYS=$SEP
fi
if [ $MONTH == "Oct" ]
then
        MONTH="10"
        MDAYS=$OCT
fi
if [ $MONTH == "Nov" ]
then
        MONTH="11"
        MDAYS=$NOV
fi
if [ $MONTH == "Dec" ]
then
        MONTH="12"
        MDAYS=$DEC
fi
YEAR=`date|cut -d ' ' -f6`
ADDM=`cat $PASSWD|grep $1:|cut -d ':' -f5|cut -d '-' -f1`
ADDYEAR=`cat $PASSWD|grep $1:|cut -d ':' -f5|cut -d '-' -f3`
ADDYEAR=20$ADDYEAR
#####
if [ "$GROUP" == "$TRiAL" ]
then
        echo $1'@'$GROUP'. You are on trial so check that instead.'

        exit
fi

if [[ $IGNOREG == *$GROUP* ]]
then
        echo $1'@'$GROUP'. '$GROUP' dont need to pass quota. But '$1' have uploaded: '$UPLOAD'Mb this month.'
        exit
fi
if [ "$ADDM" == "$MONTH" ]
then
        echo $1'@'$GROUP'. Not beed added for the hole month. quota starts next month.'
        exit
fi

if [ "$UPLOAD" -ge "$QUOTA" ]
then
	MESSAGE=$1'@'$GROUP' have passed the monthly quota! '$UPLOAD'Mb/'$QUOTA'Mb.'
else
	MESSAGE=$1'@'$GROUP' have not passed the monthly quota! '$UPLOAD'Mb/'$QUOTA'Mb.'
fi
echo $MESSAGE
