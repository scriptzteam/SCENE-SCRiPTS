#!/bin/sh

# Where is the user files located.
USERDIR=/glftpd/ftp-data/users/

# How many / is it in your USERDIR variable example. /glftpd/ftp-data/users/) is 4.
USERSLASH=4

# Amount to use in trial. (Mb)
QUOTA=5000

# Groups to not list in passed /failed
IGNOREG="
TRiAL
SiTEOP
SiTEtech
Friends
Owners
"
# Users to not list in passed / failed
IGNOREU="
glftpd
sitebot
default.user
"
#### DONT EDIT BELOW THIS LINE ####
COMMAND=$1
PASSED=passed
FAILED=failed
let USERSLASH=$USERSLASH+1
for x in $USERDIR*
do
	CHECK=TRUE
	GROUP=`cat $x|head -21|tail -1|awk '{print $2}'`
	USER=`echo $x| cut -d "/" -f $USERSLASH`
	UPLOAD=`cat $x|head -16|tail -1|awk '{print $3}'`
	if [[ $IGNOREU == *$USER* ]]
	then
		CHECK=FALSE
	fi
        if [[ $IGNOREG == *$GROUP* ]]
        then
                CHECK=FALSE
        fi

	let UPLOAD=$UPLOAD/1024
	if [ "$CHECK" == "TRUE" ]
	then
	        if [ "$UPLOAD" -ge "$QUOTA" ]
		then 
			if [ "$PASSED" == "$COMMAND" ]
			then
				echo $USER'@'$GROUP' UPLOADED:'$UPLOAD'Mb.'
			fi
		else
			if [ "$FAILED" == "$COMMAND" ]
			then
        	        	echo $USER'@'$GROUP' UPLOADED:'$UPLOAD'Mb.'
			fi
		fi
	fi
done
