#!/bin/sh

###################################################################
#   (newdate.sh) MP3/0DAY Auto Date Creator v1.2.1 by kulgan      #
#             							  #
#    CRONTAB Entry:						  #
#    0 24 * * * root /glftpd/bin/newdate.sh >> /dev/null 2>&1	  #
#    								  #
#    Instructions:						  #
#    								  #
#  1. Put this file in your bin for glftpd (/glftpd/bin/ usually) #
#  2. Set variables for your glftpd system                        #
#  3. Make the file executable by doing chmod +x newdate.sh.      #
#  4. Add crontab entry, and let it run. :)			  #
#  5. To zipscript-c add:					  #
#     -> To set msgtypes(DEFAULT) add KULSCRIPT                   # 
#     -> set chanlist(KULSCRIPT) "#chan"			  #
#     -> set disable(KULSCRIPT) 0 				  #
#     -> set variables(KULSCRIPT) "%msg"			  #
#     -> set announce(KULSCRIPT) "%msg"				  #
#								  #
#								  #
#  CHANGELOG:							  #
#								  #
#  2004-10-11: - Forgot to add the Crontab entry for prev rls     #
#	       - Adjusted some of the code that wasn't needed     #
#								  #
#  2004-10-04: - Created choice to have either mp3/0day creation  #
#              - Editable output for both mp3/0day                # 
#								  #
#  2004-10-03: - Start of the script, only allowing mp3           #
#								  #
###################################################################

VER=1.2.1

##### ENABLE 0DAY/MP3 DIR CREATION (YES=1/NO=0) #####

ENABLE_MP3=1
ENABLE_0DAY=0

MP3OUTPUT="Newday $TODAY for MP3 created..."
0DAYOUTPUT="Newday $TODAY for 0DAY created..."

##### SCRIPT SETTINGS (ALTER THESE TO YOUR LIKING) #####

TODAY=`date +%m%d`
YESTERDAY=`date --date '1 days ago' +%m%d`
GLROOT=/glftpd/site
GLLOG=/glftpd/ftp-data/logs/glftpd.log
MP3DIR=$GLROOT/mp3
0DAYDIR=$GLROOT/0day
0DAYLINK=0day_yesterday
0DAYOLDLINK=0day_yesterday
MP3LINK=mp3_today
MP3OLDLINK=mp3_yesterday

##### DO NOT ALTER BEYOND THIS LINE UNLESS YOU KNOW WHAT YOUR DOING #####

if [ $ENABLE_MP3 != 0 ]; then

  if [ ! -e $MP3DIR/$YESTERDAY ]; then

     mkdir $MP3DIR/$YESTERDAY

  fi 

  if [ ! -e $MP3DIR/$TODAY ]; then
   
     mkdir $MP3DIR/$TODAY

  fi

  chmod 777 $MP3DIR/$TODAY
  chmod 755 $MP3DIR/$YESTERDAY

  cd $GLROOT

  rm -rf $MP3LINK
  rm -rf $MP3OLDLINK

  ln -s $MP3DIR/$TODAY $MP3LINK
  ln -s $MP3DIR/$YESTERDAY $MP3OLDLINK

  echo `date "+%a %b %e %T %Y"` KULSCRIPT: $MP3OUTPUT >> $GLLOG

fi

if [ $ENABLE_0DAY != 0 ]; then

  if [ ! -e $0DAYDIR/$YESTERDAY ]; then

     mkdir $0DAYDIR/$YESTERDAY

  fi

  if [ ! -e $0DAYDIR/$TODAY ]; then

     mkdir $0DAYDIR/$TODAY

  fi

  chmod 777 $0DAYDIR/$TODAY
  chmod 755 $0DAYDIR/$YESTERDAY

  cd $GLROOT

  rm -rf $0DAYLINK
  rm -rf $0DAYOLDLINK

  ln -s $0DAYDIR/$TODAY $0DAYLINK
  ln -s $0DAYDIR/$YESTERDAY $0DAYOLDLINK

  echo `date "+%a %b %e %T %Y"` KULSCRIPT: $0DAYOUTPUT >> $GLLOG

fi
