#!/bin/bash
#
# xL-credinfo v1.0.1
#
# (C) 2003 xoLax

#Path to your userdir
USERDIR="/glftpd/ftp-data/users/"

#Affils
affils="GROUP1 GROUP2 GROUP3"

## END OF CONFIG ##

if [ "$1" != "all" -a "$1" != "normal" ]; then
  echo "[CREDINFO] Usage: !credinfo all/normal"
  exit
fi
numusers="0"
totcreds="0"
mostcreds="0"
secondcreds="0"
thirdcreds="0"
blah="(Affils excluded)"
export USERS=`ls -1 $USERDIR | grep -v default.user | grep -v glftpd`
if [ "$1" == "all" ]; then
  affils=""
  blah=""
fi
for each in $USERS; do
  export ratio=`grep -w -m1 RATIO $USERDIR$each | cut -d ' ' -f2`
  export group=`grep -w -m1 GROUP $USERDIR$each | cut -d ' ' -f2`
  if [ "$ratio" = "3" -a "`echo $affils | grep -w $group`" == "" ]; then
    numusers="$( expr "$numusers" \+ "1" )"
    export credits=`grep -w -m1 CREDITS $USERDIR$each | cut -d ' ' -f2`
    credits="$( expr "$credits" \/ "1024" )"
    totcreds="$( expr "$totcreds" \+ "$credits" )"
    if [ "$credits" -gt "$mostcreds" ]; then
      third="$second"
      second="$richest"
      thirdcreds="$secondcreds"
      secondcreds="$mostcreds"
      richest="$each/$group ($credits MB)"
      mostcreds="$credits"
      continue
    fi
    if [ "$credits" -gt "$secondcreds" ]; then
      third="$second"
      thirdcreds="$secondcreds"
      second="$each/$group ($credits MB)"
      secondcreds="$credits"
      continue
    fi
    if [ "$credits" -gt "$thirdcreds" ]; then
      third="$each/$group ($credits MB)"
      thirdcreds="$credits"
      continue
    fi
  else
   continue
  fi   
done
export avgcreds=`echo "scale=2;($totcreds / $numusers) / 1024" | bc`
export totcreds=`echo "scale=2;$totcreds / 1024" | bc`

echo "[CREDINFO] Users with 1:3 ratio: $numusers $blah"
echo "[CREDINFO] Total amount of credits: $totcreds GB"
echo "[CREDINFO] Average amount of credits: $avgcreds GB/user"
echo "[CREDINFO] Credits Top3:"
echo "[CREDINFO] 1 - $richest"
echo "[CREDINFO] 2 - $second"
echo "[CREDINFO] 3 - $third"

## EOF ##
