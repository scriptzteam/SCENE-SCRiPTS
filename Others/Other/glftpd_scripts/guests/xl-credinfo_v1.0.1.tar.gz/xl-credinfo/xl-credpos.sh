#!/bin/bash
#
# xL-credpos v1.0.1
#
# (C) 2003 xoLax

#Path to your userdir
USERDIR="/glftpd/ftp-data/users/"

#Affils
affils="GROUP1 GROUP2 GROUP3"

## END OF CONFIG ##

if [ "$1" != "all" -a "$1" != "normal" ]; then
  echo "[CREDINFO] Usage: !credpos <all/normal> <user>"
  exit
fi
if [ "$2" == "" ]; then
  echo "[CREDINFO] Usage: !credpos <all/normal> <user>"
  exit
fi
export EXIST=`ls -1 $USERDIR | grep -w $2`
if [ "$EXIST" == "" ]; then
  echo "[CREDINFO] User $2 not found"
  exit
fi
numusers="1"
userpos="1"
blah="(Affils excluded)"
export USERS=`ls -1 $USERDIR | grep -v default.user | grep -v glftpd | grep -v $1`
if [ "$1" == "all" ]; then
  affils=""
  blah=""
fi
export cgroup=`grep -w -m1 GROUP $USERDIR$2 | cut -d ' ' -f2`
export cratio=`grep -w -m1 RATIO $USERDIR$2 | cut -d ' ' -f2`
if [ "$cratio" != "3" ]; then
  echo "[CREDINFO] $2/$cgroup does not have 1:3 ratio!"
  exit
fi
if [ "`echo $affils | grep -w $cgroup`" != "" ]; then
  echo "[CREDINFO] $2/$cgroup is in an affiliated group. Try !credpos all $2"
  exit
fi
export ccredits=`grep -w -m1 CREDITS $USERDIR$2 | cut -d ' ' -f2`
for each in $USERS; do
  export ratio=`grep -w -m1 RATIO $USERDIR$each | cut -d ' ' -f2`
  export group=`grep -w -m1 GROUP $USERDIR$each | cut -d ' ' -f2`
  if [ "$ratio" = "3" -a "`echo $affils | grep -w $group`" == "" ]; then
    numusers="$( expr "$numusers" \+ "1" )"
    export credits=`grep -w -m1 CREDITS $USERDIR$each | cut -d ' ' -f2`
    if [ "$credits" -gt "$ccredits" ]; then
      userpos="$( expr "$userpos" \+ "1" )"
    fi
  fi   
done
if [ "$userpos" -lt "10" ]; then
userpos="0$userpos"
fi
export ccredits=`echo "scale=1;$ccredits/1024" | bc`
echo "[CREDINFO] $2/$cgroup is #$userpos out of $numusers with $ccredits MB $blah"

## EOF ##
