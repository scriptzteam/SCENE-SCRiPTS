#!/bin/sh

# Where is the ftp bin located
ftp=/bin/ftp

# The sitebot login at the site.
login=sitebot

# The site bot password
pass=passss

# The sites host
host=213.114.22.22

#the sites port
port=9922

# Where is the user files located.
USERDIR=/glftpd/ftp-data/users/

# Where should I make the log?
LOGDIR=/glftpd/ftp-data/logs/stats/

# How many / is it in your USERDIR variable example. /glftpd/ftp-data/users/) is 4.
USERSLASH=4

# Amount to use in trial. (Mb)
QUOTA=5000

# Auto deluser that fails quota? (TRUE/FALSE)
USERDEL="FALSE"

# Location of your passwd
PASSWD=/glftpd/etc/passwd

# Groups to not list in passed /failed
IGNOREG="
TRiAL
SiTEOP
SiTEtech
Friends
"
# Users to not list in passed / failed
IGNOREU="
glftpd
sitebot
default.user
"

# Change this for your own needs. FEB for 29 days in 2004.
JAN=31
FEB=29
MAR=31
APR=30
MAY=31
JUN=30
JUL=31
AUG=31
SEP=30
OCT=31
NOV=30
DEC=31




#### DONT EDIT BELOW THIS LINE ####
let USERSLASH=$USERSLASH+1
LOGNAMEFAILED=$LOGDIR`date|cut -d ' ' -f2`"-Quota.FAILED.log"
LOGNAMEPASSED=$LOGDIR`date|cut -d ' ' -f2`"-Quota.PASSED.log"
LOGNAMESKIPPED=$LOGDIR`date|cut -d ' ' -f2`"-Quota.SKIPPED.log"
if [ -e "$LOGNAMESKIPPED" ]
then
mv $LOGNAMESKIPPED $LOGNAMESKIPPED.yesterday
fi
if [ -e "$LOGNAMEPASSED" ]
then
mv $LOGNAMEPASSED $LOGNAMEPASSED.yesterday
fi
if [ -e "$LOGNAMEFAILED" ]
then
mv $LOGNAMEFAILED $LOGNAMEFAILED.yesterday
fi

touch $LOGNAMEFAILED
touch $LOGNAMEPASSED
touch $LOGNAMESKIPPED
COMMAND="user $login $pass"
DAY=`date|cut -d ' ' -f2`
MONTH=`date|cut -d ' ' -f3`

if [ $MONTH == "Jan" ]
then
	MONTH="01"
	MDAYS=$JAN
fi
if [ $MONTH == "Feb" ]
then
	MONTH="02"
	MDAYS=$FEB
fi
if [ $MONTH == "Mar" ]
then
	MONTH="03"
	MDAYS=$MAR
fi
if [ $MONTH == "Apr" ]
then
	MONTH="04"
	MDAYS=$APR
fi
if [ $MONTH == "May" ]
then
	MONTH="05"
	MDAYS=$MAY
fi
if [ $MONTH == "Jun" ]
then
	MONTH="06"
	MDAYS=$JUN
fi
if [ $MONTH == "Jul" ]
then
	MONTH="07"
	MDAYS=$JUL
fi
if [ $MONTH == "Aug" ]
then
        MONTH="08"
	MDAYS=$AUG
fi
if [ $MONTH == "Sep" ]
then
        MONTH="09"
	MDAYS=$SEP
fi
if [ $MONTH == "Oct" ]
then
        MONTH="10"
	MDAYS=$OCT
fi
if [ $MONTH == "Nov" ]
then
        MONTH="11"
	MDAYS=$NOV
fi
if [ $MONTH == "Dec" ]
then
        MONTH="12"
	MDAYS=$DEC
fi



YEAR=`date|cut -d ' ' -f6`
for x in $USERDIR*
do
	CHECK=TRUE
	GROUP=`cat $x|head -21|tail -1|awk '{print $2}'`
	USER=`echo $x| cut -d "/" -f $USERSLASH`
	ADDM=`cat $PASSWD|grep $USER:|cut -d ':' -f5|cut -d '-' -f1`
	ADDYEAR=`cat $PASSWD|grep $USER:|cut -d ':' -f5|cut -d '-' -f3`
	ADDYEAR=20$ADDYEAR
	UPLOAD=`cat $x|head -16|tail -1|awk '{print $3}'`
	if [[ $IGNOREU == *$USER* ]]
	then
		CHECK=FALSE
	fi
        if [[ $IGNOREG == *$GROUP* ]]
        then
                CHECK=FALSE
        fi
	if [ $ADDYEAR == $YEAR ]
	then
		if [ $ADDM == $MONTH ]
		then
			CHECK=FALSE
		fi
	fi
	let UPLOAD=$UPLOAD/1024
	if [ "$CHECK" == "TRUE" ]
	then
	        if [ "$UPLOAD" -ge "$QUOTA" ]
		then 
		echo  $USER'|'$GROUP'|'$UPLOAD  >> $LOGNAMEPASSED
		else
			echo  $USER'|'$GROUP'|'$UPLOAD  >> $LOGNAMEFAILED
			if [ "$USERDEL" == "TRUE" ]
			then
				COMMAND=$COMMAND"\nsite userdel "$USER
			fi
		fi
	else
	echo  $USER'|'$GROUP'|'$UPLOAD  >> $LOGNAMESKIPPED
	fi
done
if [ "$DAYS" == "$MDAY" ] 
then
	if [ "$USERDEL" == "TRUE" ]
	then
		RESULT=`echo -e $COMMAND | $ftp -vn $host $port`
	fi
fi
