#!/bin/sh

# Log file for trial script
TRiALLOG="/glftpd/ftp-data/logs/trial"

# Where is the user files located.
USERDIR=/glftpd/ftp-data/users/

# How many / is it in your USERDIR variable example. /glftpd/ftp-data/users/) is 4.
USERSLASH=4

# Where the password file located.
PASSWDFILE="/glftpd/etc/passwd"

# Name of trial group
TRiALGROUP="TRiAL"

# Amount to use in trial. (Mb)
TRiALQ=2000

#### DONT EDIT BELOW THIS LINE ####

echo "" > $TRiALLOG
let USERSLASH=$USERSLASH+1
for x in $USERDIR*
do
	GROUP=`cat $x|head -21|tail -1|awk '{print $2}'`
	if [ "$GROUP" == "$TRiALGROUP" ]
	then
		UPLOAD=`cat $x|head -10|tail -1|awk '{print $3}'`
		let UPLOAD=$UPLOAD/1024
                if [ "$UPLOAD" -ge "$TRiALQ" ]
                then
                STATUS="PASSED"
                else
                STATUS="FAILED"
                fi
		USER=`echo $x| cut -d "/" -f $USERSLASH`
                PASSWD=`cat $PASSWDFILE|grep $USER:`
		echo $USER'@'$GROUP' UPLOADED:'$UPLOAD'Mb TRiALQUOTA:2000Mb User status:'$STATUS'|'$PASSWD >> /glftpd/ftp-data/logs/trial
	fi
done
