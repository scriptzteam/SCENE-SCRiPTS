<?php

#configure these

$loop = 2;
$url='movie.php';
$debug=FALSE;
$playmovie="/usr/bin/playmovie";

#done configuration

$temp = $_SERVER["REMOTE_ADDR"];
if ( substr($temp,0,3) != "192" ) {
 echo "You are not allowed to be here, go away";
 exit;
}
$path=$_GET["file"];
if ( $path == NULL ) {
	$path = '/';
}
else { $path = str_replace('%20',' ',$path); }
$path = addslashes($path);
$isDIR = is_dir($path);
if ( $isDIR ) {
	if ($handle = opendir($path)) {
		while (false !== ($file = readdir($handle))) {
			if ( $file == "." || $file == ".." ) { continue; }
			$link = $path . addslashes($file);
			if ( is_dir($link) ) { $link = $link . '/'; }
			$link = str_replace(' ','%20',$link);
			echo "<a href=" . $url . "?file=$link>$file</a><br>";
		}
    	closedir($handle);
	}
}
else {
	if ( is_file($path) ) {
        $temp = dirname($path);
		if ($handle = opendir($temp)) {
            $num_of_file = 2;
			if ( $debug ) { echo "path = $path<br>"; }
			$files = array ($path);
	        while ( false !== ( $file = readdir($handle))) {
				$nextfile = str_replace("part1","part".$num_of_file,basename($path));
				if ( $debug ) { echo "fullpath = $fullpath<br>"; }
				$fullpath = $temp."/".$nextfile;
				if ( $fullpath == $path ) { continue; }
				if ( is_file($fullpath)) {
					$files = array_pad ($files, $num_of_file, $fullpath);
					$num_of_file = $num_of_file + 1;
                }
			}
			closedir($handle);
		}
		$output = $playmovie." ".$loop;
		$counter = 0;
		echo "Playing this playlist $loop times.<br>";
		while( true ) {
			if ( $files[$counter] == NULL ) { break; }
			$output = $output.' "'.$files[$counter].'"';
			echo "Playing file ".$files[$counter]."<br>";
			$counter = $counter + 1;
		}
		
		system($output." > /dev/null &");
	}
}
?>
