#!/bin/bash
################################################################
# xL-glbackup v0.1                                             #
#							       #	
# (C) 2003, xoLax (xolax@home.se)			       #
#                                                              # 
# * copy this file to your glftpd/bin dir and chmod a+x	       #
# * edit your crontab and add:				       #
# 45 23 * * *     /glftpd/bin/xl-glbackup.sh > /dev/null 2>&1  #
# * edit the config below 	                 	       # 
# * create the destination dir				       #	
################################################################

# Path to your glftpd user dir
userdir="/glftpd/ftp-data/users/"

# Path to your glftpd misc dir
miscdir="/glftpd/ftp-data/misc/"

# Path to your glftpd bin dir
bindir="/glftpd/bin/"

# Path to your glftpd etc dir
etcdir="/glftpd/etc/"

# Where is your glftpd.conf located?
glconf="/etc/glftpd.conf"

# Where is your zipscript config located?
zsconf="/root/project-zs/zipscript/conf/zsconfig.h"

# Path to your sitebot's script dir
botdir="/glftpd/sitebot/scripts/"

# Where is your sitebot config located?
botconf="/glftpd/sitebot/xl.conf"

# Where is your sitebot's userfile config located?
botusers="/glftpd/sitebot/users"

# Sitename?
sitename="My1337Site"

# Where shall the script put the tar.gz files?
destdir="/glftpd/site/incoming1/groups/STAFF/xl-glbackup"

# Maximum number of backup files before deleting the oldest?
maxfiles="25"

#chmod the tar.gz to what when done?
modtar="400"

## END OF CONFIG ##

d=$(date +%F)
export oldest=`ls -1t $destdir | grep -n $sitename. | grep $maxfiles: | sed s/$maxfiles://`
while [ "$oldest" != "" ]; do
rm $destdir/$oldest
export oldest=`ls -1t $destdir | grep -n $sitename. | grep $maxfiles: | sed s/$maxfiles://`
done
makedir=$destdir/$sitename.$d
mkdir $makedir
tar -cf $destdir/$sitename.$d/users.$d.tar $userdir  > /dev/null 2>&1
tar -cf $destdir/$sitename.$d/misc.$d.tar $miscdir  > /dev/null 2>&1
tar -cf $destdir/$sitename.$d/bin.$d.tar $bindir  > /dev/null 2>&1
tar -cf $destdir/$sitename.$d/etc.$d.tar $etcdir  > /dev/null 2>&1
tar -cf $destdir/$sitename.$d/bot.$d.tar $botdir  > /dev/null 2>&1
gzip $destdir/$sitename.$d/users.$d.tar  > /dev/null 2>&1
gzip $destdir/$sitename.$d/misc.$d.tar  > /dev/null 2>&1
gzip $destdir/$sitename.$d/bin.$d.tar  > /dev/null 2>&1
gzip $destdir/$sitename.$d/etc.$d.tar  > /dev/null 2>&1
gzip $destdir/$sitename.$d/bot.$d.tar  > /dev/null 2>&1
cp $glconf $destdir/$sitename.$d/ 
cp $zsconf $destdir/$sitename.$d/
cp $botconf $destdir/$sitename.$d/
cp $botusers $destdir/$sitename.$d/
cd $destdir/
tar -cf $sitename.$d.tar $sitename.$d/
gzip $sitename.$d.tar
chmod $modtar $sitename.$d.tar.gz
rm -rf $destdir/$sitename.$d/
