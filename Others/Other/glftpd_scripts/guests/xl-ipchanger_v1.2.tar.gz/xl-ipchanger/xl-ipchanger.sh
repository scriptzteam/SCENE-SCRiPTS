#!/bin/sh

#xL-ipchanger v1.2

#(C) 2003 xoLax 

#put this file in /glftpd/bin/ and chmod a+x

log="/glftpd/ftp-data/logs/xl-ipchanger.log"
#You need to create this file and chmod it 777 or something :)

user="/glftpd/ftp-data/users/$2"
#The path were you have the user files

tmp="/glftpd/ftp-data/logs/xl-ipchanger.tmp"
#This file will be created and deleted everytime the script runs
#Make sure the bot has correct permissions in this dir

###END OF CONFIG###

username=$2
ip=$3
nick=$4
host=$5

touch $tmp
echo $3 >> $tmp
export ident=`grep -o -i -m 1 @ $tmp`
rm $tmp

#Add ip and log the action
if [ "$ident" == "@" ]; then
  if [ "$1" = "ADDIP" ]; then
  echo ADDIP: `/bin/date '+%a %b %d %X %Y'` -"$4""($5)" added "$3" to user "$2" >> "$log"
  echo IP "$3" >> "$user"
  fi
fi

#Delete ip and log the action
if [ "$ident" == "@" ]; then
  if [ "$1" = "DELIP" ]; then
  echo DELIP: `/bin/date '+%a %b %d %X %Y'` -"$4""($5)" deleted "$3" from user "$2" >> "$log"
  grep -v $3 $user > $user.tmp
  mv $user.tmp $user
  fi
fi

#List ip's for user

if [ "$1" = "LISTIP" ]; then
grep IP $user 
#echo bajs
fi

#Output the 10 last ipadds 
if [ "$1" = "IPADDS" ]; then
tail -n 10 /glftpd/ftp-data/logs/xl-ipchanger.log
fi
