#!/bin/bash
#
# Top stats (irc) v. 1.1 by pexi  
# ------------------------------- 
# -[Purpose]-
# Output to irc, users (including their rank) with most credits, 
# users most nuked,biggest leechers, best uploaders (allup) and times logged in (nerd-o-meter ;) )
# when triggered in irc. ie !top leech 5 will show top 5 list of leechers.
# Supports a "ranking system" ie. !top rank pexi 
# will show users rank in all 3 sections (creds,nukes,leech(alldn)) 
 
# -[Installation and usage]-
# place px-topstat.sh in your glftpd bin dir. And .tcl in your eggdrops scripts dir. 
# edit px-topstat.sh and px-topstat.tcl
# add source scripts/px-topstat.tcl in your eggdrop.conf and rehash bot
# type !top (or whatever you configured it to be, !top is default) in sitechan.

# -[Contact]- 
# irc: pexi @ efnet 
# email: me@pexi.net 
# Please report bugs,ideas, anything

# -[Updates]-
# V. 1.1,
# Added top uploaders and the nerd-o-meter

# -[Todo]-
# Optimize the script. It's a little heavy right now

# -[CONFIGURE]- #

# This defines how big the top list can be. (Number of users)
# ie if you set this to 10 you can see top lists from 1-10 but not over.
max=10
# Trigger in irc
cmdtop=!top
# Glftpd users path
glusers=/glftpd/ftp-data/users
# Tmp folder
tmp=/tmp
# Do you want to output top creds as Gigs or MB?
# Enter gigs for gigs mb for megabytes (only for top creds and top leech lists!)
output=gigs

# -[ CONFIGURE DONE ]- #
# DONT touch anything below!

if [ -z $1 ];then
echo "Stats script by pexi"
echo "Valid commands are $cmdtop nukes x $cmdtop creds x $cmdtop leech x $cmdtop upload x $cmdtop nerds x $cmdtop rank username"
exit
fi
if [ -z $2 ];then
echo "Stats script by pexi"
echo "Valid commands are $cmdtop nukes x $cmdtop creds x $cmdtop leech x $cmdtop upload x $cmdtop nerds x $cmdtop rank username."
exit
fi
if [ "$1" = "creds" ] && [ "$2" -gt "$max" ] ;then
echo "Please choose something below $max"
exit
fi
if [ $output = "gigs" ];then
number=1024000
else
number=1024
fi
if [ -e $tmp/topstat.tmp ];then
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi

# Makes the file with needed information for creds top & creds rank
credsdb ()
{
for user in `ls -1 $glusers`; do
usercred=`cat $glusers/$user |grep CREDITS | gawk  '{ print $2 }'`
usercred2="`echo "scale=2; $usercred / $number"|bc`"
echo $user:with:$usercred2:$output"!" >> $tmp/topstat.tmp
done
sort -n -r -t: -k 3 -o $tmp/topstat2.tmp $tmp/topstat.tmp
rm $tmp/topstat.tmp
count=1
for i in `cat $tmp/topstat2.tmp| gawk '{ print $1 }'`
do
echo "$count"." $i" >> $tmp/topstat.tmp
let "count = $count + 1"
done
}

# Echo top cred stats
let "max2 = $max +1"
if [ $1 = "creds" ] &&  [ $2 -lt $max2 ];then
credsdb
echo "People with most creds (top $2)"
echo "`cat $tmp/topstat.tmp |grep -m $2 ""| tr : " "`"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
# Echo users creds & rank

if [ ! -z $2 ] && [ $1 = "rank" ];then
if [ ! -e $glusers/$2 ];then
echo "$2 does not exist"
exit
else
credsdb
place="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $1 }'`"
creds="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $4 }'`"
echo "Cred stats: $2 is ranked $place with $creds $output"!""
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
fi

# Top nuke part
# Almost the same function as before:
nukesdb ()
{
for user in `ls -1 $glusers`; do
nukes="`cat $glusers/$user |grep NUKE | gawk  '{ print $4 }'`"
echo $user:with:$nukes:MB"!" >> $tmp/topstat.tmp
done
sort -n -r -t: -k 3 -o $tmp/topstat2.tmp $tmp/topstat.tmp
rm $tmp/topstat.tmp
count=1
for i in `cat $tmp/topstat2.tmp| gawk '{ print $1 }'`;do
echo "$count"." $i" >> $tmp/topstat.tmp
let "count = $count + 1"
done
}

let "max2 = $max +1"
if [ $1 = "nukes" ] &&  [ $2 -lt $max2 ];then
nukesdb
echo "Most nuked people (top $2)"
echo "`cat $tmp/topstat.tmp |grep -m $2 ""| tr : " "`"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi

if [ ! -z $2 ] && [ $1 = "rank" ];then
if [ ! -e $glusers/$2 ];then
echo "$2 does not exist"
exit
else
nukesdb
place="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $1 }'`"
nuke="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $4 }'`"
echo "Nuke stats: $2 is ranked $place with $nuke MB"!""
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
fi 

# Leech part
leechdb ()
{
for user in `ls -1 $glusers`; do
down=`cat $glusers/$user |grep ALLDN | gawk  '{ print $3 }'`
down2="`echo "scale=2; $down / $number"|bc`"
echo $user:with:$down2:$output"!" >> $tmp/topstat.tmp
done
sort -n -r -t: -k 3 -o $tmp/topstat2.tmp $tmp/topstat.tmp
rm $tmp/topstat.tmp
count=1
for i in `cat $tmp/topstat2.tmp| gawk '{ print $1 }'`;do
echo "$count"." $i" >> $tmp/topstat.tmp
let "count = $count + 1"
done
}
let "max2 = $max +1"
if [ $1 = "leech" ] &&  [ $2 -lt $max2 ];then
leechdb
echo "The biggest and fattest leechers (top $2)"
echo "`cat $tmp/topstat.tmp |grep -m $2 ""| tr : " "`"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi

if [ ! -z $2 ] && [ $1 = "rank" ];then
if [ ! -e $glusers/$2 ];then
echo "$2 does not exist"
exit
else
leechdb
place="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $1 }'`"
leech="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $4 }'`"
echo "Leech stats: $2 is ranked $place with $leech $output"!""
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
fi
# Upload stats

uploadb ()
{
for user in `ls -1 $glusers`; do
ul=`cat $glusers/$user |grep ALLUP | gawk  '{ print $3 }'`
ul2="`echo "scale=2; $ul / $number"|bc`"
echo $user:with:$ul2:$output"!" >> $tmp/topstat.tmp
done
sort -n -r -t: -k 3 -o $tmp/topstat2.tmp $tmp/topstat.tmp
rm $tmp/topstat.tmp
count=1
for i in `cat $tmp/topstat2.tmp| gawk '{ print $1 }'`;do
echo "$count"." $i" >> $tmp/topstat.tmp
let "count = $count + 1"
done
}
let "max2 = $max +1"
if [ $1 = "upload" ] &&  [ $2 -lt $max2 ];then
uploadb
echo "Top uploaders (allup) (top $2)"
echo "`cat $tmp/topstat.tmp |grep -m $2 ""| tr : " "`"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi

if [ ! -z $2 ] && [ $1 = "rank" ];then
if [ ! -e $glusers/$2 ];then
echo "$2 does not exist"
exit
else
uploadb
place="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $1 }'`"
ul="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $4 }'`"
echo "Upload stats: $2 is ranked $place with $ul $output"!""
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
fi
nerdb ()
{
for user in `ls -1 $glusers`; do
nerd=`cat $glusers/$user |grep TIME" " | gawk  '{ print $2 }'`
echo $user:with:$nerd:logins"!" >> $tmp/topstat.tmp
done
sort -n -r -t: -k 3 -o $tmp/topstat2.tmp $tmp/topstat.tmp
rm $tmp/topstat.tmp
count=1
for i in `cat $tmp/topstat2.tmp| gawk '{ print $1 }'`;do
echo "$count"." $i" >> $tmp/topstat.tmp
let "count = $count + 1"
done
}
let "max2 = $max +1"
if [ $1 = "nerds" ] &&  [ $2 -lt $max2 ];then
nerdb
echo "Top nerds list. Dont have anything better to do? (top $2)"
echo "`cat $tmp/topstat.tmp |grep -m $2 ""| tr : " "`"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi

if [ ! -z $2 ] && [ $1 = "rank" ];then
if [ ! -e $glusers/$2 ];then
echo "$2 does not exist"
exit
else
nerdb
place="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $1 }'`"
nerdp="`cat $tmp/topstat.tmp |grep $2: | tr : " "| gawk '{ print $4 }'`"
echo "Nerd-o-meter: $2 is ranked $place with $nerdp logins"
rm $tmp/topstat.tmp
rm $tmp/topstat2.tmp
fi
fi
