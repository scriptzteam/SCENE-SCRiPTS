/* Modification of Captain's ftpwho by iono.
 * NOTE: passwd file location is hardcoded, but isn't hard to change if you have any sort of brain.
 *
 * Exit codes:
 * 2 - No users online (also prints "0" before it exits)
 * 3 - SHMAT (Shared Memory Attach) Failed
 * 4 - SHMDT (Shared Memory Detatch) Failed
 * 0 - no problems, execution as usual
 *
 * Action codes:
 * 0 - Idle ( >5 secs from last command)
 * 1 - Active ( Setting up xfer / browsing....less than 5secs from last command)
 * 2 - Uploading
 * 3 - Downloading
 *
 * OLD FORMAT: "uid;username;action;filename;host;currentdir;groupid;speed(k/s);idletime;tagline"
 *
 * NEW FORMAT: "action;username;primgroup;uid;command;currentdir;filename;speed(kB/s);idletime;tagline;host"
 * Last line is total bw stats.....
 * NEW FORMAT: "uploads;uploadspeed(kB/s);downloads;downloadspeed(kB/s);totalxfers;totalspeed(kB/s);idlers;activeusers;totalusers"
 * 
 * CHANGES: Different output order, and outputs group as name rather than GID. status is now integer
 *          rather than a string. Changed a few statements aswell.	
 *          
 * GID To Group Name code by Zio.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

/* Stealing the datatype from ftpwho.c, mine obviously has to look the same anyway */
struct USER {
  char   tagline[64];
  char   username[24];
  char   status[256];
  char   host[256];
  char   currentdir[256]; // it is uncertain if this will ALWAYS contain a filename if you're up or downloading but it seems to, altho sometimes it doesn't
  long   groupid;
  time_t login_time;
  struct timeval tstart;   
  unsigned long bytes_xfer; 
  pid_t  procid;
};

//default ipc-key for glftpd
static key_t key = 0x0000DEAD; 
static int numUsers = 0;
static struct USER *users;
//this needs to be here to contain the stats for the shm segment
static struct shmid_ds ipcbuf; 
static char groupfilepath[255], primgroup[255];

/* Convert GID to group name using the 'group' file [ by Zio ] */
int gid_to_group(char *groupname, long *groupid) {
   FILE *fp;
   int found = 0, size = 0;
   char temp[255], temp2[255], temp3[255];
   if((fp = fopen("/glftpd/etc/group", "r")) == NULL) {
      return 1;
   }
   sprintf(temp3, "%ld", ((*groupid / 100) * 100));
   while (fgets(temp, (sizeof temp / sizeof temp[0]) - 1, fp) != NULL &&
         found == 0) {
      char *p;
      p = strchr(strchr(temp, ':') + 1, ':') + 1;
      size = (strlen(p) - 1) - (strlen(strchr(p, ':') + 1));
      strncpy(temp2, p, size);
      temp2[size] = '\0';
      if (strcmp(temp2, temp3) == 0) {
         size = (strlen(temp) - 1) - (strlen(strchr(temp, ':') + 1));
         sprintf(temp2, "%s", "\0");
         strncpy(temp2, temp, size);
         temp2[size] = '\0';
         sprintf(groupname, "%s", temp2);
         found++;
      }
   }
   fclose(fp);
   return 0;
}


int main(int argc, char *argv[]) {
	
	int rv;
	int shmid;
	/* Connect to the start of the datasegment (it'll already be created, therefore we don't need a size of permissions
	 * If it is NOT already created, that means that there are nore users online
	 */
    if ((shmid = shmget(key, 0,0)) == -1) {
		//0 users online
		printf("0");
        //exit with a value higher than 0, error, trigger on this if you want
		exit(2);
    }
	// do I really need the typecast for the -1 comparison?
	users = (struct USER *)shmat(shmid, 0, SHM_RDONLY);
	if (users == (struct USER *)(-1)) {
		perror("3-shmat Failed");
		exit(3);
	}
	//get the length of what's in shared memory to  fnd out how many users we have by dividing the datablock with the size of the USER struct
	shmctl( shmid, IPC_STAT, &ipcbuf);
	numUsers = ipcbuf.shm_segsz / sizeof(struct USER);
	//pass commandline arguments to the function to determine what to present (TODO)
	rv = presentInformation();
	/* detach from the segment: */
    if (shmdt(users) == -1) {
        perror("4-shmdt failed");
        exit(4);
    }
	return rv;
}
/*
 * Stole this very quickly from the original, will write my own soon, but I need this one for testing
 * and it's not pid you fuck-ass, it's uid, or possible oid, ad the original array was named online
 */
static double calcTime(int uid) {
	struct timeval tstop;
	double delta, rate;
	if (users[uid].bytes_xfer < 1) {
		return 0;
	}
	gettimeofday(&tstop, (struct timezone *)0 );
	delta = ((tstop.tv_sec*10.)+(tstop.tv_usec/100000.)) - ((users[uid].tstart.tv_sec*10.)+(users[uid].tstart.tv_usec/100000.));
	delta = delta/10.;
	rate = ((users[uid].bytes_xfer / 1024.0) / (delta));
	if (!rate) rate++;
	return (double)(rate);
}
/*
 * this goes over the data in the users array, and prints it according to the format
 * TODO: Accept arguments to determine what to present
 */
int presentInformation() {
	int i;
	int j;
	char filename[260], command[255];
	int action;
	double u_spd = 0, d_spd = 0, t_spd = 0, speed = 0;
	int u_xfers = 0, d_xfers = 0, t_xfers = 0, i_slots = 0, a_slots = 0, t_logins = 0;

	for (i = 0; i < numUsers; i++) {
		int idletime = time(NULL) - users[i].tstart.tv_sec;
		// the only interesting users are the ones who have a real pid and who are logged in properly
		if ((users[i].procid != 0) && strcmp(users[i].username, "-NEW-") != 0) {
			/* get group name from gid */
			gid_to_group(primgroup, &users[i].groupid);
			/* copy status into command string */
			strcpy(command, users[i].status);
			/* remove newline from command string */
			j = strlen(command);
			if (!isprint(command[j-2])) {
				command[j-2] = '\0';
			} else if (!isprint(command[j-1])) {
				command[j-1] = '\0';
			}
			speed = calcTime(i);
			if (!strncasecmp(users[i].status, "APPE", 4) || !strncasecmp(users[i].status, "STOR", 4)) {
				/* Upload */
				//assign "upload" (3) to the action type
				action = 3;
				//copy the filename without the APPE or STOR to the, well, "filename" string
				strcpy(filename, command+5);
				u_spd += speed;
				u_xfers++;
			} else if (!strncasecmp(command, "RETR", 4)) {
				/* Download */
				//assign "download" (2) to the action type
				action = 2;
				//copy the filename without the RETR to the, well, "filename" string
				strcpy(filename, command+5);
				d_spd += speed;
				d_xfers++;
			} else if(idletime > 5 && users[i].bytes_xfer == 0) {
				/* Idle */
				//assign "idle" (0) to the action type
				action = 0;
				strcpy(filename, "0"); //there needs to be something here to keep output standard
				i_slots++;
			} else {
				/* Active */
				//assign "active" (1) to the action type
				action = 1;
				strcpy(filename, "0"); // there needs to be something here to keep output standard
				a_slots++;
			}
			printf("%d;%d;%s;%s;%s;%s;%s;%.1f;%d;%s;%s\n",
							action,
							users[i].procid,
							users[i].username,
							primgroup,
							command,
							filename,
							users[i].currentdir,
							calcTime(i),
							idletime,
							users[i].tagline,
							users[i].host);
		}
	}
	t_xfers = u_xfers + d_xfers;
	t_spd = u_spd + d_spd;
	t_logins = u_xfers + d_xfers + i_slots + a_slots;

	//output total bandwidth
	// >> uploads;uploadspeed(kB/s);downloads;downloadspeed(kB/s);totalxfers;totalspeed(kB/s);idlers;activeusers;totalusers
	printf("%d;%.1f;%d;%.1f;%d;%.1f;%d;%d;%d\n", u_xfers, u_spd, d_xfers, d_spd, t_xfers, t_spd, i_slots, a_slots, t_logins);
	return 0;
}
