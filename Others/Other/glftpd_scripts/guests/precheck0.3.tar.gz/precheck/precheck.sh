#!/bin/sh
VER=0.3
#####################
# Precheck by Teqno #
#####################
# Version 0.3
# 
# Removed the hard coded "preed a total of .... times since"
# replaced it with a check of the logfile
#
#
# Version 0.2
#
# Added the feature to show the last 5 releases
# of a group.
# Some cosmetic changes as well ;D
#
# Version 0.1
#
# *Initial Release
#
# Configure 
glpath=/glftpd/ftp-data/logs/glftpd.log
log=/glftpd/ftp-data/logs/precheck.log
# End of Config
#
# Dont change anything below this line
################################################
if [ "$1" = "" ] ; then
echo "You need to specify a group"
else
cat $glpath | grep PRE: | grep -n -i $1 > $log
echo "The group $1 have preed a total of `cat -n $log | tail -n1 | awk -F '[ \t]+' '{print $2}'` times since "`cat $glpath | head -n2 | tail -n1 | awk -F '[ :]+' '{print $2}''{print $3}''{print $7}'`
echo
echo "Last Pre : " `cat $log | tail -n 1 | awk -F '[ /]+' '{print $2}''{print $3}''{print $5}'`
echo "Time :  " `cat $log | tail -n 1 | awk -F '[ /]+' '{print $4}'`
echo "Pre : " `cat $log | tail -n 1 | awk -F '[ :]+' '{print $10}'`
echo
echo "Last 5 Releases are :"
cat $log | tail -n 5 | awk -F '[ :]+' '{print $10}'
cat /dev/null > $log
fi
#EOF