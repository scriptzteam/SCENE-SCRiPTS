#!/bin/bash

##########################################################
# Cozmic GLTools v0.1                                    # 
# !idle !dl !ul !seen                                    #
# Hope you have some use of it =)                        #
# You need to have tur-ftpwho installed for this to work #
##########################################################

BOLD="" 
COL="14"
COLE=""
SITENAME="xXx" 
FTPWHO=/glftpd/bin/tur-ftpwho
USERSTAT=/glftpd/bin/userstat
VERS=0.1

ULTOT=`$FTPWHO |grep Up|wc -l|tr -d " "`
UL=`$FTPWHO |grep Up|tr -d "|"|awk -F^ '{print "user: " $1, "file: " $5, "speed: " $4, "kb/s" }'`
DLTOT=`$FTPWHO |grep Dn|wc -l|tr -d " "`
DL=`$FTPWHO |grep Dn|awk -F^ '{print "user: " $1, "file: " $5, "speed: " $4, "kb/s" }'`
TOTIDLE=`$FTPWHO |grep Idle|wc -l|tr -d " "`
IDLE=`$FTPWHO |grep Idle|awk -F^ '{print "user: " $1, "path: " $4, "idle: " $6 }'`
USER=`$USERSTAT $2 |grep LASTON|awk '{ print "last seen " $2 " " $3 }'`

# No need to change stuff below

case "$1" in
        -ul)
		if [ "$UL" = "" ] ;
		then
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/UL + No active uploads"
		else
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/UL + Current uploads (tot: $ULTOT)"
        	echo "$UL"
		fi
                ;;
        -dl)
		if [ "$DL" = "" ] ;
		then
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/DL + No active downloads"
		else
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/DL + Current downloads (tot: $DLTOT)"
		echo "$DL"
		fi
                ;;
        -idle)
		if [ "$IDLE" = "" ] ;
		then
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/IDLE + No idlers, wh00t :)"
		else
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/IDLE + Idlers (tot: $TOTIDLE):"
        	echo "$IDLE"
		fi
                ;;
        -seen)
		if [ "$2" = "" ] ;
		then
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/SEEN + specify a user to check too."
		fi
		if [ "$USER" = "" ] ;
		then
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/SEEN + hmm, dunno that punkass"
		else
        	echo "$BOLD$COL$SITENAME$COLE$BOLD/SEEN + $2 $USER ago"
		fi
		;;
        *)
		echo ""
		echo "GLTools $VERS, Syntax: -dl -ul -idle -seen"
esac
