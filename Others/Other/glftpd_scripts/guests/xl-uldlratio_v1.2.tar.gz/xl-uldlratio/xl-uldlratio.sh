#!/bin/sh
#
# xL-uldlratio v1.2
#
# (C) 2003 xoLax

#Where is your userdir located?
USERDIR="/glftpd/ftp-data/users/"

#Show UL/DL Ratio? (YES/NO)
SHOWRATIO="YES"

#Show Credits and Ratio? (YES/NO) 
CREDRATIO="NO"

#Show tagline? (YES/NO)
SHOWTAG="YES"

#Show nukestatus on alstats? (YES/NO)
NUKES="YES"

#Sitename?
SITENAME="xL"

## Don't edit below unless you want to change the comments ##

STATSBIN="/glftpd/bin/stats"

if [ "$2" == "" ]; then
  echo "Usage: !alstats/!mnstats/!wkstats/!daystats <user> ..:xL-uldlratio v1.2:.."
  exit 0
fi

USER=$2

export EXIST=`ls -1 $USERDIR | grep -w $USER`

if [ "$EXIST" == "" ]; then
echo "User $USER not found"
exit
fi

export GROUP=`grep -w -m 1 GROUP $USERDIR$USER | cut -d ' ' -f2`

export TAGLINE=`grep -w TAGLINE $USERDIR$USER | cut -d ' ' --fields=2,3,4,5,6,7,8,9,10`

export RATIO=`grep -w RATIO $USERDIR$USER | cut -d ' ' -f2` 
if [ "$RATIO" == "0" ]; then
RATIO="Unlimited"
fi
if [ "$RATIO" == "3" ]; then
RATIO="1:3"
fi

export CREDITS=`grep -w CREDITS $USERDIR$USER | cut -d ' ' -f2`
export CREDITSMB=`echo "scale=1;$CREDITS/1024" | bc`

export MBNUKES=`grep -w NUKE $USERDIR$USER | cut -d ' ' -f4`
export NUMNUKES=`grep -w NUKE $USERDIR$USER | cut -d ' ' -f3`

COMMENT=""


## ALRATIO ##

if [ "$1" == "ALRATIO" ]; then

ALDNDATA="$( $STATSBIN -d -a -x 500 | grep "\[..\]\ $USER\ " )"

ALDNPOS="$( echo "$ALDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$ALDNPOS" | grep ".."`" ]; then
  ALDNPOS=0$ALDNPOS
fi
if [ "$ALDNPOS" == "0" ]; then
  ALDNDATA="$( $STATSBIN -d -a -x 500 | grep "\[...\]\ $USER\ " )"
  ALDNPOS="$( echo "$ALDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$ALDNPOS" == "" ]; then
    ALDNPOS="N/A"
  fi
fi

ALUPDATA="$( $STATSBIN -u -a -x 500 | grep "\[..\]\ $USER\ " )"

ALUPPOS="$( echo "$ALUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$ALUPPOS" | grep ".."`" ]; then
  ALUPPOS=0$ALUPPOS
fi
if [ "$ALUPPOS" == "0" ]; then
  ALUPDATA="$( $STATSBIN -u -a -x 500 | grep "\[...\]\ $USER\ " )"
  ALUPPOS="$( echo "$ALUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$ALUPPOS" == "" ]; then
    ALUPPOS="N/A"
  fi
fi

export ALUP=`grep -n "" $USERDIR$USER | grep 10: | cut -d ' ' -f3`

ALUP="$( expr "$ALUP" \/ "1024" )"

export ALDN=`grep -n "" $USERDIR$USER | grep 11: | cut -d ' ' -f3`

ALDN="$( expr "$ALDN" \/ "1024" )"

if [ "$ALDN" == "0" -a "$ALUP" != "0" ]; then
  echo "All Time stats for $USER/$GROUP:"
  echo "Upload: $ALUP MB ..:.. Download: $ALDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: iNFiNiTE (The ultimate user!)"
fi
  echo "AlUp: #$ALUPPOS ..:.. AlDn: #$ALDNPOS"
if [ "$NUKES" == "YES" ]; then
  echo "NUKES: $NUMNUKES ($MBNUKES MB)"
fi
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$ALUP" == "0" -a "$ALDN" != "0" ]; then
  echo "All Time stats for $USER/$GROUP:"
  echo "Upload: $ALUP MB ..:.. Download: $ALDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Ever heard about uploading?!)"
fi
  echo "AlUp: #$ALUPPOS ..:.. AlDn: #$ALDNPOS"
if [ "$NUKES" == "YES" ]; then
  echo "NUKES: $NUMNUKES ($MBNUKES MB)"
fi
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$ALUP" == "0" -a "$ALDN" == "0" ]; then
  echo "All Time stats for $USER/$GROUP:"
  echo "Upload: $ALUP MB ..:.. Download: $ALDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Hey! Still alive?)"
fi
  echo "AlUp: #$ALUPPOS ..:.. AlDn: #$ALDNPOS"
if [ "$NUKES" == "YES" ]; then
  echo "NUKES: $NUMNUKES ($MBNUKES MB)"
fi
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

export ALRATIO=`echo "scale=2;$ALUP/$ALDN" | bc`
export ALPERCENT=`echo "scale=2;$ALUP*100" | bc`
export ALCOMPARE=`echo "scale=0;$ALPERCENT/$ALDN" | bc`

if [ $ALCOMPARE -lt "100" -a $ALCOMPARE != "0" ];then
   ALRATIO=0$ALRATIO
fi

if [ $ALCOMPARE -lt "5" ];then
  COMMENT="Stop abusing the site!"
fi
if [ $ALCOMPARE -gt "5" ];then
  COMMENT="Ever heard the word CONTRIBUTING?!"
fi
if [ $ALCOMPARE -gt "25" ];then
  COMMENT="Everyone can't be the best"
fi
if [ $ALCOMPARE -gt "40" ];then
  COMMENT="Bah! Just an average guy"
fi
if [ $ALCOMPARE -gt "50" ];then
  COMMENT="Now we're talking!"
fi
if [ $ALCOMPARE == "33" ];then
  COMMENT="Wow! right on the ratio spot"
fi
if [ $ALCOMPARE -gt "75" ];then
  COMMENT="Getting closer to the l337 1.0 ratio :P "
fi
if [ $ALCOMPARE -gt "100" ];then
  COMMENT="One of the best!"
fi
if [ $ALCOMPARE -gt "150" ];then
  COMMENT="Are you for real?!"
fi

echo "All Time stats for $USER/$GROUP:"
echo "Upload: $ALUP MB ..:.. Download: $ALDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
echo "UL/DL Ratio: $ALRATIO ($COMMENT)"
fi
echo "AlUp: #$ALUPPOS ..:.. AlDn: #$ALDNPOS"
if [ "$NUKES" == "YES" ]; then
  echo "NUKES: $NUMNUKES ($MBNUKES MB)"
fi
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi


## MNRATIO ##

if [ "$1" == "MNRATIO" ]; then

MNDNDATA="$( $STATSBIN -d -m -x 500 | grep "\[..\]\ $USER\ " )"

MNDNPOS="$( echo "$MNDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$MNDNPOS" | grep ".."`" ]; then
  MNDNPOS=0$MNDNPOS
fi

if [ "$MNDNPOS" == "0" ]; then
  MNDNDATA="$( $STATSBIN -d -m -x 500 | grep "\[...\]\ $USER\ " )"
  MNDNPOS="$( echo "$MNDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$MNDNPOS" == "" ]; then
    MNDNPOS="N/A"
  fi
fi

MNUPDATA="$( $STATSBIN -u -m -x 500 | grep "\[..\]\ $USER\ " )"

MNUPPOS="$( echo "$MNUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$MNUPPOS" | grep ".."`" ]; then
  MNUPPOS=0$MNUPPOS
fi
if [ "$MNUPPOS" == "0" ]; then
  MNUPDATA="$( $STATSBIN -u -m -x 500 | grep "\[...\]\ $USER\ " )"
  MNUPPOS="$( echo "$MNUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$MNUPPOS" == "" ]; then
    MNUPPOS="N/A"
  fi
fi

export MNUP=`grep -n "" $USERDIR$USER | grep 16: | cut -d ' ' -f3`

MNUP="$( expr "$MNUP" \/ "1024" )"

export MNDN=`grep -n "" $USERDIR$USER | grep 17: | cut -d ' ' -f3`

MNDN="$( expr "$MNDN" \/ "1024" )"

if [ "$MNDN" == "0" -a "$MNUP" != "0" ]; then
  echo "Month stats for $USER/$GROUP:"
  echo "Upload: $MNUP MB ..:.. Download: $MNDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: iNFiNiTE (The ultimate user!)"
fi
  echo "MnUp: #$MNUPPOS ..:.. MnDn: #$MNDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$MNUP" == "0" -a "$MNDN" != "0" ]; then
  echo "Month stats for $USER/$GROUP:"
  echo "Upload: $MNUP MB ..:.. Download: $MNDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Extreme Leecher!)"
fi
  echo "MnUp: #$MNUPPOS ..:.. MnDn: #$MNDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$MNUP" == "0" -a "$MNDN" == "0" ]; then
  echo "Month stats for $USER/$GROUP:"
  echo "Upload: $MNUP MB ..:.. Download: $MNDN MB"
  echo "UL/DL Ratio: 0.00 (Hey! Still alive?)"
  echo "MnUp: #$MNUPPOS ..:.. MnDn: #$MNDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi


export MNRATIO=`echo "scale=2;$MNUP/$MNDN" | bc`
export MNPERCENT=`echo "scale=2;$MNUP*100" | bc`
export MNCOMPARE=`echo "scale=0;$MNPERCENT/$MNDN" | bc`

if [ $MNCOMPARE -lt "100" -a $MNCOMPARE != "0" ];then
   MNRATIO=0$MNRATIO
fi

if [ $MNCOMPARE -lt "9" ];then
  COMMENT="When was the last time you raced?!"
fi
if [ $MNCOMPARE -lt "1" ];then
  COMMENT="Extreme leecher!"
fi
if [ $MNCOMPARE -gt "9" ];then
  COMMENT="'Get a life' means 'race more on $SITENAME'"
fi
if [ $MNCOMPARE -gt "25" ];then
  COMMENT="Prepare for the worst"
fi
if [ $MNCOMPARE -gt "40" ];then
  COMMENT="Not too bad, but it could be better"
fi
if [ $MNCOMPARE -gt "50" ];then
  COMMENT="Now we're talking!"
fi
if [ $MNCOMPARE == "33" ];then
  COMMENT="Wow! right on the ratio spot"
fi
if [ $MNCOMPARE -gt "75" ];then
  COMMENT="Keep it up!"
fi
if [ $MNCOMPARE -gt "100" ];then
  COMMENT="One of the best!"
fi

echo "Month stats for $USER/$GROUP:"
echo "Upload: $MNUP MB ..:.. Download: $MNDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
echo "UL/DL Ratio: $MNRATIO ($COMMENT)"
fi
echo "MnUp: #$MNUPPOS ..:.. MnDn: #$MNDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi


## WKRATIO ##

if [ "$1" == "WKRATIO" ]; then

WKDNDATA="$( $STATSBIN -d -w -x 500 | grep "\[..\]\ $USER\ " )"

WKDNPOS="$( echo "$WKDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$WKDNPOS" | grep ".."`" ]; then
  WKDNPOS=0$WKDNPOS
fi
if [ "$WKDNPOS" == "0" ]; then
  WKDNDATA="$( $STATSBIN -d -w -x 500 | grep "\[...\]\ $USER\ " )"
  WKDNPOS="$( echo "$WKDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$WKDNPOS" == "" ]; then
    WKDNPOS="N/A"
  fi
fi

WKUPDATA="$( $STATSBIN -u -w -x 500 | grep "\[..\]\ $USER\ " )"

WKUPPOS="$( echo "$WKUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$WKUPPOS" | grep ".."`" ]; then
  WKUPPOS=0$WKUPPOS
fi
if [ "$WKUPPOS" == "0" ]; then
  WKUPDATA="$( $STATSBIN -u -w -x 500 | grep "\[...\]\ $USER\ " )"
  WKUPPOS="$( echo "$WKUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$WKUPPOS" == "" ]; then
    WKUPPOS="N/A"
  fi
fi

export WKUP=`grep -n "" $USERDIR$USER | grep 12: | cut -d ' ' -f3`

WKUP="$( expr "$WKUP" \/ "1024" )"

export WKDN=`grep -n "" $USERDIR$USER | grep 13: | cut -d ' ' -f3`

WKDN="$( expr "$WKDN" \/ "1024" )"

if [ "$WKDN" == "0" -a "$WKUP" != "0" ]; then
  echo "Week stats for $USER/$GROUP:"
  echo "Upload: $WKUP MB ..:.. Download: $WKDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: iNFiNiTE (The ultimate user!)"
fi
  echo "WkUp: #$WKUPPOS ..:.. WkDn: #$WKDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$WKUP" == "0" -a "$WKDN" != "0" ]; then
  echo "Week stats for $USER/$GROUP:"
  echo "Upload: $WKUP MB ..:.. Download: $WKDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Extreme Leecher!)"
fi
  echo "WkUp: #$WKUPPOS ..:.. WkDn: #$WKDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

if [ "$WKUP" == "0" -a "$WKDN" == "0" ]; then
  echo "Week stats for $USER/$GROUP:"
  echo "Upload: $WKUP MB ..:.. Download: $WKDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (On vacation?)"
fi
  echo "WkUp: #$WKUPPOS ..:.. WkDn: #$WKDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
  echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
  exit
fi

export WKRATIO=`echo "scale=2;$WKUP/$WKDN" | bc`
export WKPERCENT=`echo "scale=2;$WKUP*100" | bc`
export WKCOMPARE=`echo "scale=0;$WKPERCENT/$WKDN" | bc`

if [ $WKCOMPARE -lt "100" -a $WKCOMPARE != "0" ];then
   MNRATIO=0$MNRATIO
fi
if [ $WKCOMPARE -lt "10" -o $WKCOMPARE == "10" ];then
  COMMENT="Having a bad week huh?!!"
fi
if [ $WKCOMPARE -lt "1" ];then
  COMMENT="Extreme leecher!"
fi
if [ $WKCOMPARE -gt "10" ];then
  COMMENT="At least you upload"
fi
if [ $WKCOMPARE -gt "25" ];then
  COMMENT="We thought we could trust you :/ "
fi
if [ $WKCOMPARE -gt "40" ];then
  COMMENT="Not too bad, but it could be better"
fi
if [ $WKCOMPARE -gt "50" ];then
  COMMENT="Now we're talking!"
fi
if [ $WKCOMPARE == "33" ];then
  COMMENT="Wow! right on the ratio spot"
fi
if [ $WKCOMPARE -gt "75" ];then
  COMMENT="This could be a good week!"
fi
if [ $WKCOMPARE -gt "100" ];then
  COMMENT="This is why we like you"
fi

echo "Week stats for $USER/$GROUP:"
echo "Upload: $WKUP MB ..:.. Download: $WKDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
echo "UL/DL Ratio: $WKRATIO ($COMMENT)"
fi
echo "WkUp: #$WKUPPOS ..:.. WkDn: #$WKDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: $CREDITSMB MB ..:.. Ratio: $RATIO"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi


## DAYRATIO ##

if [ "$1" == "DAYRATIO" ]; then

DAYDNDATA="$( $STATSBIN -d -t -x 500 | grep "\[..\]\ $USER\ " )"

DAYDNPOS="$( echo "$DAYDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$DAYDNPOS" | grep ".."`" ]; then
  DAYDNPOS=0$DAYDNPOS
fi
if [ "$DAYDNPOS" == "0" ]; then
  DAYDNDATA="$( $STATSBIN -d -t -x 500 | grep "\[...\]\ $USER\ " )"
  DAYDNPOS="$( echo "$DAYDNDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$DAYDNPOS" == "" ]; then
    DAYDNPOS="N/A"
  fi
fi

DAYUPDATA="$( $STATSBIN -u -t -x 500 | grep "\[..\]\ $USER\ " )"

DAYUPPOS="$( echo "$DAYUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$DAYUPPOS" | grep ".."`" ]; then
  DAYUPPOS=0$DAYUPPOS
fi
if [ "$DAYUPPOS" == "0" ]; then
  DAYUPDATA="$( $STATSBIN -u -t -x 500 | grep "\[...\]\ $USER\ " )"
  DAYUPPOS="$( echo "$DAYUPDATA" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$DAYUPPOS" == "" ]; then
    DAYUPPOS="N/A"
  fi
fi


export DAYUP=`grep -n "" $USERDIR$USER | grep 14: | cut -d ' ' -f3`

DAYUP="$( expr "$DAYUP" \/ "1024" )"

export DAYDN=`grep -n "" $USERDIR$USER | grep 15: | cut -d ' ' -f3`

DAYDN="$( expr "$DAYDN" \/ "1024" )"

if [ "$DAYDN" == "0" -a "$DAYUP" != "0" ]; then
  echo "Day stats for $USER/$GROUP:"
  echo "Upload: $DAYUP MB ..:.. Download: $DAYDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: iNFiNiTE (The ultimate user!)"
fi
  echo "DayUp: #$DAYUPPOS ..:.. DayDn: #$DAYDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: ^B$CREDITSMB^B MB ..:.. Ratio: ^B$RATIO^B"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi

if [ "$DAYUP" == "0" -a "$DAYDN" != "0" ]; then
  echo "Day stats for $USER/$GROUP:"
  echo "Upload: $DAYUP MB ..:.. Download: $DAYDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Extreme Leecher!)"
fi
  echo "DayUp: #$DAYUPPOS ..:.. DayDn: #$DAYDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: ^B$CREDITSMB^B MB ..:.. Ratio: ^B$RATIO^B"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi

if [ "$DAYUP" == "0" -a "$DAYDN" == "0" ]; then
  echo "Day stats for $USER/$GROUP:"
  echo "Upload: $DAYUP MB ..:.. Download: $DAYDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
  echo "UL/DL Ratio: 0.00 (Having a day off huh?!)"
fi
  echo "DayUp: #$DAYUPPOS ..:.. DayDn: #$DAYDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: ^B$CREDITSMB^B MB ..:.. Ratio: ^B$RATIO^B"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
exit
fi


export DAYRATIO=`echo "scale=2;$DAYUP/$DAYDN" | bc`
export DAYPERCENT=`echo "scale=2;$DAYUP*100" | bc`
export DAYCOMPARE=`echo "scale=0;$DAYPERCENT/$DAYDN" | bc`

if [ $DAYCOMPARE -lt "100" -a $DAYCOMPARE != "0" ];then
   DAYRATIO=0$DAYRATIO
fi
if [ $DAYCOMPARE -lt "10" -o $DAYCOMPARE == "10" ];then
  COMMENT="May the devil take you by the end of this day!"
fi
if [ $DAYCOMPARE -lt "1" ];then
  COMMENT="Extreme leecher!"
fi
if [ $DAYCOMPARE -gt "10" ];then
  COMMENT="At least you upload"
fi
if [ $DAYCOMPARE -gt "25" ];then
  COMMENT="Like stealing bandwidth huh?!"
fi
if [ $DAYCOMPARE -gt "40" ];then
  COMMENT="Not too bad, but it could be better"
fi
if [ $DAYCOMPARE -gt "50" ];then
  COMMENT="Now we're talking!"
fi
if [ $DAYCOMPARE == "33" ];then
  COMMENT="Wow! right on the ratio spot"
fi
if [ $DAYCOMPARE -gt "75" ];then
  COMMENT="Good day! :P "
fi
if [ $DAYCOMPARE -gt "100" ];then
  COMMENT="Whoa!!"
fi
if [ $DAYCOMPARE -gt "400" ];then
  COMMENT="Keep that for a month and I'll be your slave"
fi


echo "Day stats for $USER/$GROUP:"
echo "Upload: $DAYUP MB ..:.. Download: $DAYDN MB"
if [ "$SHOWRATIO" == "YES" ]; then
echo "UL/DL Ratio: $DAYRATIO ($COMMENT)"
fi
echo "DayUp: #$DAYUPPOS ..:.. DayDn: #$DAYDNPOS"
if [ "$CREDRATIO" == "YES" ]; then
echo "Credits: ^B$CREDITSMB^B MB ..:.. Ratio: ^B$RATIO^B"
fi
if [ "$SHOWTAG" == "YES" ]; then
  echo "$USER says: $TAGLINE"
fi
fi


