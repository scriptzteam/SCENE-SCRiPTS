#!/bin/sh

###################################################################
#   (kpre.sh) KPRE Adder v0.1 by kulgan                           #
#             							  #
#    								  #
#    Instructions:						  #
#    								  #
#  1. Put this file in your bin for glftpd (/glftpd/bin/ usually) #
#  2. Set variables for your glftpd system                        #
#  3. Make the file executable by doing chmod +x kpre.sh.         #
#								  #
#								  #
#  CHANGELOG:							  #
#								  #
#  2004-10-06: - Initial Release; Delete function will be made    #
###################################################################

VER=0.1


GLCONF="/home/kulgan/sh_prg/glftpd.conf"
PRECONF="/home/kulgan/sh_prg/pre.cfg"
GLROOT="/glftpd"
PREDIRS="/site/groups"


if [ "$1" = "add" ]; then

   if [ "$2" = "" ]; then

      echo "You Need a Group Name"

   else
   
      if [ "$3" = "" ]; then

         echo "You need to put sections"
  
      else
    
         if [ ! -e $GLROOT$PREDIRS/$2 ]; then
    
            echo "privpath $PREDIRS/$2            1 =$2" >> $GLCONF
            MULTIGRP=`grep "privpath.* 1 =STAFF" $GLCONF`    
            sed "/privpath.* 1 =STAFF/d" $GLCONF > $GLCONF.tmp; cat $GLCONF.tmp > $GLCONF
	    rm -rf $GLCONF.tmp
 
            echo "$MULTIGRP =$2" >> $GLCONF

            mkdir $GLROOT$PREDIRS/$2; chmod 777 $GLROOT$PREDIRS/$2

            echo "[Affil] $2 added to affil list. Ask for a pre test :)"
    
            GROUP=` echo $4|tr ',' '|'`
            echo "group.$2.allow=$GROUP" >> $PRECONF
            PREPATH="group.$2.dir=$PREDIRS/$2"
    
            #for each in ` echo $4|tr ',' ' '`;do
            #   PREPATH=$PREPATH$PREDIRS/$each/$group$2\|
            #   echo $PREPATH 
            #done
            #PREPATH=`echo $PREPATH | sed 's/|$//'`
            
	    echo $PREPATH >> $PRECONF
            echo "group.$2.chown.user=$2" >> $PRECONF
	    echo "group.$2.chown.group=$2" >> $PRECONF
            echo "group.$2.ratio=0" >> $PRECONF
            echo "group.$2.def_sec=$3" >> $PRECONF
	
            echo "" >> $PRECONF
            
    
        else

           echo "$2 pre dir exists"

        fi
     fi
  fi

elif [ "$1" = "del" ]; then

   if [ "$2" = "" ]; then
 
      echo "You need to supply a group"
 
   fi

   

else
  
  echo "Usage: !affil <add/del> <group> <default section> <section1,section2,section3,...>"
fi
             
