#!/bin/sh

###################################################################
#   (kpre.sh) KPRE Adder v1.0 by kulgan                           #
#             							  #
#    								  #
#    Instructions:						  #
#    								  #
#  1. Put this file in your bin for glftpd (/glftpd/bin/ usually) #
#  2. Set variables for your glftpd system                        #
#  3. Make the file executable by doing chmod +x kpre.sh.         #
#								  #
#								  #
#  CHANGELOG:							  #
#								  #
#  2004-12-08: - Added Delete Function (thx loxley for ur help)   #
#  2004-10-06: - Initial Release; Delete function will be made    #
###################################################################

VER=1.0


GLCONF="/etc/glftpd.conf"
TMPCONF="/glftpd/tmp/glftpd.conf"
PRECONF="/glftpd/etc/pre.cfg"
TMPRECONF="/glftpd/tmp/pre.cfg"
GLROOT="/glftpd"
PREDIRS="/site/GROUPS"

if [ "$1" = "add" ]; then

   if [ "$2" = "" ]; then

      echo "You Need a Group Name"

   else
   
      if [ "$3" = "" ]; then

         echo "You need to put sections"
  
      else
    
         if [ ! -e $GLROOT$PREDIRS/$2 ]; then
    
            echo "privpath $PREDIRS/$2            1 =$2 !*" >> $GLCONF
            MULTIGRP=`grep "privpath.* 1 =STAFF" $GLCONF | sed -e 's/ !\*//g'`    
            sed "/privpath.* 1 =STAFF/d" $GLCONF > $TMPCONF.tmp; cat $TMPCONF.tmp > $GLCONF
	    rm -rf $TMPCONF.tmp
 	
            echo "$MULTIGRP =$2 !*" >> $GLCONF

            mkdir $GLROOT$PREDIRS/$2; chmod 777 $GLROOT$PREDIRS/$2

            echo "[Affil] $2 added to affil list. Ask for a pre test :)"
    
            GROUP=` echo $4|tr ',' '|'`
            echo "group.$2.allow=$GROUP" >> $PRECONF
            PREPATH="group.$2.dir=$PREDIRS/$2"
            
	    echo $PREPATH >> $PRECONF
            echo "group.$2.chown.user=$2" >> $PRECONF
	    echo "group.$2.chown.group=$2" >> $PRECONF
            echo "group.$2.ratio=0" >> $PRECONF
            echo "group.$2.def_sec=$3" >> $PRECONF
	
            echo "" >> $PRECONF
            
    
        else

           echo "$2 pre dir exists"

        fi
     fi
  fi

elif [ "$1" = "del" ]; then

   if [ "$2" = "" ]; then
 
      echo "You need to supply a group"
 
   else

      if [ -e $GLROOT$PREDIRS/$2 ]; then

	sed "/privpath.*\/$2/d" $GLCONF | sed -e 's/ ='${2}'//g' > $TMPCONF.tmp; cat $TMPCONF.tmp > $GLCONF
	sed "/group.$2.*/d" $PRECONF > $TMPRECONF.tmp; cat $TMPRECONF.tmp > $PRECONF
	rm -rf $GLROOT$PREDIRS/$2

	echo "[Affil] $2 deleted from affil list."

   else

	echo "[Affil] $2 Could Not Be Found"
	
   fi
fi
else
  
  echo "Usage: !affil <add/del> <group> <default section> <section1,section2,section3,...>"
fi
          
