#!/bin/bash
##############################################################
#request script 1.1 by ragusallad                            #
#Just change 'REQDIR' and 'SITENAME' below and you're all set#
##############################################################

REQDIR="/glftpd/site/Requests"
SITENAME="XXX"

if [ "$1" = "" ]; then
    echo "Use it correctly"
    exit 0
else

if [ "$1" = "add" ]; then

    if [ "$2" = "" ]; then
    echo "Specify a request... Usage: !req <release>"
    exit 0
    else
	ALREADYTHERE="$( ls $REQDIR | grep $2 )"
	if [ "$ALREADYTHERE" = "" ]; then
        mkdir $REQDIR/$2-$3
        echo "-$SITENAME- [REQ] + New Request: $2 by $3"
        else
        echo "Already a requests named like that, try to rephrase"
        exit 0
        fi
    fi

else
if [ "$1" = "del" ]; then

    if [ "$2" = "" ]; then
	echo "Specify a request to delete... Usage: !delreq <release>"
	exit 0
    else
	ALREADYTHERE="$( ls $REQDIR | grep $2 )"
	if [ "$ALREADYTHERE" != "" ]; then
        rm -fr $REQDIR/$ALREADYTHERE
	echo "-$SITENAME- [REQ] - Deleted Request: $ALREADYTHERE"
        else
        echo "No request named like that, try to rephrase"
        exit 0
	fi
    fi
fi
fi
fi
exit 0