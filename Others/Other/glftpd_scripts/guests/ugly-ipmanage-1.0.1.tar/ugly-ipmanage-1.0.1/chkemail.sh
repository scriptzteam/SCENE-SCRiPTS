#!/bin/bash

email_db="/ftp-data/misc/email.db"   # path to email database
encrypted_db=YES
encrypted_cipher="aes256"
keystore="/ftp-data/misc/keystore/key"

# case insensitive list of users, flags, or groups that will not be forced to
# set an email address - you can just comment out any of them if you don't to
# exempt a certain type (flags, users, or groups)
exempt_users=( user1 user2 )
exempt_flags=( 1 A )
exempt_groups=( SiTEOPS mygroup2 )

## END CONFIG ###

if [ "$encrypted_db" = YES ];
  then
    e_output=`openssl enc -$encrypted_cipher -salt -d -in "$email_db" -pass \
              file:"$keystore"`
  else
    e_output=`cat "$email_db"`
fi

set=`echo "$e_output" | grep -E "^$USER\b"`
if [ ! -z "$set" ]; then
  exit 0
fi

# EXEMPTIONS
if [ ! -z ${exempt_groups[0]} ]; then
  egroup=`echo ${exempt_groups[@]} | grep -i $GROUP`
fi
if [ ! -z ${exempt_users[0]} ]; then
  euser=`echo ${exempt_groups[@]} | grep -i $USER`
fi
if [ ! -z ${exempt_flags[0]} ];
  then
    for i in "${exempt_flags[@]}"; do
      eflag=`echo "$FLAGS" | grep -i "$i"`
      if [ ! -z $eflag ]; then
        exit 0
      fi
    done
fi
  
if [ ! -z $egroup ] || [ ! -z $euser ]; then
  exit 0
fi

echo -e "500*** Email address not set!  Use: site email <email@address> ***\r"
exit 1
