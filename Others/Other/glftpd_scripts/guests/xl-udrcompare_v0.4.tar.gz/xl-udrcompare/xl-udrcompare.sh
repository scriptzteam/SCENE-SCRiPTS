#!/bin/bash
#
# xL-udrcompare v0.4
#
# (C) 2003 xoLax

#Path to your user dir
USERDIR="/glftpd/ftp-data/users/"

#Don't check users who uploaded less than <ULIMIT> MB. (0 to disable)
ALULIMIT="5120" ## ALL TIME
MNULIMIT="2048" ## MONTH
WKULIMIT="256"  ## WEEK
DAYULIMIT="64" ## DAY

## END OF CONFIG ##

if [ "$1" == "" ]; then
echo "Display the top 5 UL/DL Ratios. Usage !altopratio, !mntopratio, !wktopratio, !daytopratio."
exit
fi
export USERS=`ls -1 $USERDIR`
fifthr="0"
fourthr="0"
thirdr="0"
secondr="0"
firstr="0"
fifthu="N/A"
fourthu="N/A"
thirdu="N/A"
secondu="N/A"
firstu="N/A"

if [ "$1" == "ALL" ]; then
  blah1="10"
  blah2="11"
  ULIMIT=$ALULIMIT
  header="All Time Top5 UL/DL Ratios" 
fi
if [ "$1" == "MONTH" ]; then
  blah1="16"
  blah2="17"
  ULIMIT=$MNULIMIT
  header="Month Top5 UL/DL Ratios"
fi
if [ "$1" == "WEEK" ]; then
  blah1="12"
  blah2="13"
  ULIMIT=$WKULIMIT
  header="Week Top5 UL/DL Ratios"
fi
if [ "$1" == "DAY" ]; then
  blah1="14"
  blah2="15"
  ULIMIT=$DAYULIMIT
  header="Day Top5 UL/DL Ratios"
fi
if [ "$2" != "" ]; then
  ULIMIT="`echo $2 | tr -d '[:alpha:]'`"
fi
echo "$header (Users with UL>$ULIMITMB)"
for each in $USERS; do
  export GROUP=`grep -w -m 1 GROUP $USERDIR$each | cut -d ' ' -f2`
  export ALUP=`grep -n "" $USERDIR$each | grep $blah1: | cut -d ' ' -f3`
  export UNUM=`echo $ALUP | tr -d '[:alpha:]'`
  if [ "$UNUM" != "$ALUP" -o "$ALUP" == "" ]; then
  continue
  fi
  ALUP="$( expr "$ALUP" \/ "1024" )"
  export ALDN=`grep -n "" $USERDIR$each | grep $blah2: | cut -d ' ' -f3`
  export DNUM=`echo $ALDN | tr -d '[:alpha:]'`
  if [ "$DNUM" != "$ALDN" -o "$ALDN" == "" ]; then
  continue
  fi
  ALDN="$( expr "$ALDN" \/ "1024" )"
  if [ "$ALDN" != "0" -a "$ALUP" != "0" -a "$ALUP" -gt "$ULIMIT" ]; then
    export RATIO=`echo "scale=2;$ALUP/$ALDN" | bc`
    export COMPARE=`echo "$RATIO * 10000 / 100" | bc`
    if [ "$COMPARE" -lt "100" ]; then
      RATIO="0$RATIO"
    fi
    if [ "$COMPARE" != "0" ]; then
      if [ "$COMPARE" -gt "$firstr" ]; then
        fifthr="$fourthr"
        fifthu="$fourthu"
        fourthr="$thirdr"
        fourthu="$thirdu"
        thirdr="$secondr"
        thirdu="$secondu"
        secondr="$firstr"
        secondu="$firstu"
        firstr="$COMPARE"
        firstu="$each/$GROUP .:. UL/DL Ratio: $RATIO ($ALUPMB/$ALDNMB)"
        continue
      fi
      if [ "$COMPARE" -gt "$secondr" ]; then
        fifthr="$fourthr"
        fifthu="$fourthu"
        fourthr="$thirdr"
        fourthu="$thirdu"
        thirdr="$secondr"
        thirdu="$secondu"
        secondr="$COMPARE"
        secondu="$each/$GROUP .:. UL/DL Ratio: $RATIO ($ALUPMB/$ALDNMB)"
        continue
      fi
      if [ "$COMPARE" -gt "$thirdr" ]; then
        fifthr="$fourthr"
        fifthu="$fourthu"
        fourthr="$thirdr"
        fourthu="$thirdu"
        thirdr="$COMPARE"
        thirdu="$each/$GROUP .:. UL/DL Ratio: $RATIO ($ALUPMB/$ALDNMB)"
        continue
      fi
      if [ "$COMPARE" -gt "$fourthr" ]; then
        fifthr="$fourthr"
        fifthu="$fourthu"
        fourthr="$COMPARE"
        fourthu="$each/$GROUP .:. UL/DL Ratio: $RATIO ($ALUPMB/$ALDNMB)"
        continue
      fi
      if [ "$COMPARE" -gt "$fifthr" ]; then
        fifthr="$COMPARE"
        fifthu="$each/$GROUP .:. UL/DL Ratio: $RATIO ($ALUPMB/$ALDNMB)"
      fi
    fi
  fi
unset USER
done

echo "1 - $firstu"
echo "2 - $secondu"
echo "3 - $thirdu"
echo "4 - $fourthu"
echo "5 - $fifthu"
## EOF ## 
