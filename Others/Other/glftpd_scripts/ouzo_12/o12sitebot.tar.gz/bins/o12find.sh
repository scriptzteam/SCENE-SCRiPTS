#!/bin/sh
short=0
args="$1"
dirs=/glftpd/bin

# Check for short switch.
if [ "$args" == "-s" ] ; then
   short=1; shift
fi

# Check if input is already an imdb number.
case $1 in
   [0-9][0-9][0-9][0-9][0-9][0-9][0-9])
      imdbnr="$1"
      if [ ! -z $imdbnr ] ; then
         lynx -dump -width=200 -nolist "http://207.171.168.20/Details?$imdbnr" > "Details_$imdbnr"
         lynx -dump -width=200 -nolist "http://207.171.168.20/Business?$imdbnr" > "Business_$imdbnr"
         if [ $short == 1 ] ; then
            $dirs/o12info -s "Details_$imdbnr" "Business_$imdbnr"
         else
            $dirs/o12info "Details_$imdbnr" "Business_$imdbnr"
         fi
         rm Details_$imdbnr
         rm Business_$imdbnr
      fi
      exit 0
      ;;
esac

# Treat input as a query.
args="$1"; shift
while [ ! -z $1 ] ; do
   args="$args+$1"; shift
done

lynx -source -width=200 -hiddenlinks=ignore "http://207.171.168.20/Find?$args" > "Find_2"
lynx -dump -width=200 -nolist -force_html Find_2 > "Find_1"


url=`$dirs/o12find Find_1 Find_2`
if [ `echo "$url" | grep -c "Exact hit"` != 0 ] ; then
   imdbnr=`echo "$url" | cut -d" " -f3`;
   if [ ! -z $imdbnr ] ; then
      lynx -dump -width=200 -nolist "http://207.171.168.20/Details?$imdbnr" > "Details_$imdbnr"
      lynx -dump -width=200 -nolist "http://207.171.168.20/Business?$imdbnr" > "Business_$imdbnr"
      if [ $short == 1 ] ; then
         $dirs/o12info -s "Details_$imdbnr" "Business_$imdbnr"
      else
         $dirs/o12info "Details_$imdbnr" "Business_$imdbnr"
      fi
      rm Details_$imdbnr
      rm Business_$imdbnr
      rm Find_1
      rm Find_2
   fi
else
   echo "$url"
   rm Find_1
   rm Find_2
fi
