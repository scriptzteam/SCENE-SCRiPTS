#!/bin/sh

# You probably only need to change this path:
BNCPATH=/home/leetdude/multibnc

BNCBIN=multibnc
BNCPID=multibnc.pid

cd $BNCPATH
if test -r $BNCPATH/$BNCPID 
then
     MULTIPID=$(cat $BNCPATH/$BNCPID)
     if $(kill -CHLD $MULTIPID >/dev/null 2>&1)
     then
        echo "MULTI-BNC is still running..."
        exit 0
     fi
     rm -f $BNCPATH/$BNCPID
fi

echo "Starting MULTI-BNC..."
echo " "

if test -x $BNCBIN 
then
   $BNCPATH/$BNCBIN
   exit 0
fi

echo "Could not restart MULTI-BNC: $BNCPATH/$BNCBIN is not executable!"
exit 1

