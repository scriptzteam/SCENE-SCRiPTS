Topic: FreeBSD patch for foo-tools
Author: Friend of packager
Packager: Sicko
Copyright: No

Tanesha has made a package with some really useful glftpd utilities, available at http://www.tanesha.net/projects/

Unfortunately it seems the development have stopped, the sourcefiles are quite Linuxified and will not compile on a FreeBSD box. 
Here is a patch for it :) Only tested on FreeBSD 4.5 STABLE so no guarantees. 

Usage:
--start--
mkdir foo
cd foo
tar xvfz foo-tools-latest.tar.gz
cp /path/to/foo-tools-freebsd.patch .
patch -p1 < foo-tools-freebsd.patch
gmake
--end--

Both patch and gmake should run without any errors.

-Enjoy!
