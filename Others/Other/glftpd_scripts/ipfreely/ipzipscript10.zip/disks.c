/* MODIFIED by MagicaL
   many thanks to Usurper, But I modified the output to 'none' if it couldn't count
   number of disks, and i use FILE_ID.DIZ instead of the message file */

/* Disks finder (file_id.diz analyzer) by Usurper
   4 July 1999, version 1.1 (now supports LND releases)
   I started with evilution's code for up.c but I totally
   changed and enhanced it so I doubt you'll find much resemblence
   Nevertheless he deserves some credit :}

   Just run this program in a release dir (best use it with my disks.csh script */ 

/* Output: -1 if .message not found, 0 if disk number not found, or number of disks otherwise.
   Please report problems to theusurper@geocities.com */

#include <string.h>
#include <stdio.h>

FILE *fp;

void try_new_format(char *buff) {   /* the new ## x 2.88 format (LND) */
  char number[3];
  int num = 0;

    if (*(buff-1) == ' ' && *(buff+1) == ' ') {
       if (isdigit(*(buff-2)) || *(buff-2) == 'o' || *(buff-2) == 'O')
         number[1] = *(buff-2);
       else
	 return;
       if (isdigit(*(buff-3)) || *(buff-3) == 'o' || *(buff-3) == 'O')
         number[0] = *(buff-3);
       else
         number[0] = '0';
       number[2] = '\0';
       if (number[0] == 'o' || number[0] == 'O') /* some "leet" mofos use o's instead of 0's */
         number[0] = '0'; 
       if (number[1] == 'o' || number[1] == 'O') 
         number[1] = '0'; 
       num = atoi(number);
       if (!num) return;
       printf("%d\n", num);
       fclose(fp);
       exit(num);
    } /* if */
}

void fucking_fallen_format(char *buff) {    /* Fallen has another new invention */
  char number[3];
  int num = 0;

    if (*(buff-2) != '(' || !isdigit(*(buff-3)) || *(buff+3) != ')' ||
       !isdigit(*(buff-4)) && *(buff-4) != 'o' ) {
      buff++;
      return;
    } 
    if (*(buff-4) == 'o')
      number[0] = '0';
    else
      number[0] = *(buff-4);
    if (*(buff-3) == 'o')
      number[1] = '0';
    else
      number[1] = *(buff-3);
    number[2] = '\0';
    num = atoi(number);
    if (!num) return;
    printf("%d\n", num);
    fclose(fp);
    exit(num);
}

void try_old_format(char *linestart, char *buff) {  /* the old xx/## format */
  char number[3];
  int num = 0;

    if (*(buff-3) != ' ' && *(buff-2) != ' ' &&    /* so we don't match Win95/98 */
        *(buff-3) != '[' && *(buff-2) != '[' &&    /* most releases */
        *(buff-3) != '(' && *(buff-2) != '(' &&    /* GLOW and such */
        *(buff-3) != '|' && *(buff-2) != '|' &&    /* FCN */
        *(buff-3) != ':' &&    /* core releases */
        buff-3 >= linestart ) {   /* in case disk number starts at beginning of line */
      buff++;
      return;
    }
    if (isdigit(*++buff) || *buff == 'o' || *buff == 'O')
      number[0] = *buff;
    else
      return;
    if (isdigit(*++buff) || *buff == 'o' || *buff == 'O')
      number[1] = *buff;
    else {
      number[1] = '\0';
      buff--;
    }
    number[2] = '\0';
    if (isalpha(*++buff) || isdigit(*buff) || *buff == '/') {
      buff += 4;
      return;  /* if this is not the end (as in dates)*/
    }
    if (number[0] == 'o' || number[0] == 'O') /* some "leet" mofos use o's instead of 0's */
      number[0] = '0';
    if (number[1] == 'o' || number[1] == 'O')
      number[1] = '0';
    num = atoi(number);
    if (!num) return;
    printf("%d\n", num);
    fclose(fp);
    exit(num);
}


int main ( void ) {
  int x = 0, num = 0;
  char *buff;
  char number[3];
  char line[200];
  
  if((fp = fopen("FILE_ID.DIZ", "r")) == NULL) {
    printf("\n");
    return -1;
  }
  
  while(!feof(fp)) {
     buff = fgets(line, sizeof(line), fp);
     if (buff == NULL) {
       printf("\n");
       fclose(fp);
       return 0;
     }
     while(*buff != '\0') {
       if ( *buff == '/' || *buff == '\\')   /* second case is for TRPS releases */
         try_old_format(line,buff);
       else if ( *buff == 'x' || *buff == '*')   /* new format, ## x 2.88 */
         try_new_format(buff);
       else if ( *buff == '.' )   /* as in 01(1.44) */
	 fucking_fallen_format(buff);
       buff++;
     } /* nested while */
  } /* while */
  fclose(fp);
  printf("\n");
  return 0;
}

