#!/bin/sh
#	Frontend for ip_wkly.sh
#	Run this script from your crontab
#
glbin="/iP/bin"
users=`cat $glbin/ip_wkly.users`
for x in $users
do
user=`echo $x|cut -d":" -f1`
$glbin/ip_wkly.sh $user
done
 
