#!/bin/sh
#	Enchanced Weekly Allotment Script v0.1
#	(NOTE: For sites with only ONE Stat Section, must be run as ROOT!!)
#
#	This script allows users who support the site accumulate credit, while disallowing
#	leechers only from accumulating credit.
#
#	
#		by: ip
#		comments: ipfreely@home.com
#	HOWTO: This part of the script should be run once a week.
#
#	$1 = USER
#

gluserdir="/iP/ftp-data/users" #Path to users dir
glbin="/iP/bin" #Path to bin
glpasswd="/iP/etc/passwd"
username="$1"
	if `test -f $gluserdir/$username`;then
	   glUID=`grep "$1" $glpasswd|cut -d":" -f3`
           wkupFILES=`grep "WKUP" $gluserdir/$username|cut -d" " -f2`
	   if `test $wkupFILES -gt 0`;then
	      allow=`cat ip_wkly.users|grep "$1"|cut -d: -f2`
	      ratio=`grep "RATIO" $gluserdir/$username|cut -d" " -f2`
	      wkupKB=`grep "WKUP" $gluserdir/$username|cut -d" " -f3`
              wkdnKB=`grep "WKDN" $gluserdir/$username|cut -d" " -f3`
	      if `test $wkupKB -gt $wkdnKB`;then
		accum=`expr $wkupKB - $wkdnKB`
	      else
	        accum=0
	      fi
	      give=`expr $accum + $allow`
	      echo "$0 - Giving $username $give KB"
	      credln=`cat $gluserdir/$username|grep -n "CREDIT"|cut -d":" -f1`
	      head -`expr $credln - 1` $gluserdir/$username > $gluserdir/$username.new
	      echo "CREDITS $give" >> $gluserdir/$username.new
	      length=`wc -l $gluserdir/$username|cut -b6-|cut -d" " -f1`
	      tail -`expr $length - $credln` $gluserdir/$username >> $gluserdir/$username.new  
	      mv $gluserdir/$username.new $gluserdir/$username
	      chown $glUID $gluserdir/$username	      
	   else
	      echo "$0 - $username = LEECHER"
              credln=`cat $gluserdir/$username|grep -n "CREDIT"|cut -d":" -f1`
              head -`expr $credln - 1` $gluserdir/$username > $gluserdir/$username.new
              echo "CREDITS $give" >> $gluserdir/$username.new
              length=`wc -l $gluserdir/$username|cut -b6-|cut -d" " -f1`
              tail -`expr $length - $credln` $gluserdir/$username >> $gluserdir/$username.new
              mv $gluserdir/$username.new $gluserdir/$username    
              chown $glUID $gluserdir/$username
	   fi
	else
		echo "$0 - $username ... DOES NOT EXIST"
	fi
