#!/bin/sh -x
#
#	iP Dirscript v1.3 (November 07.2001)
# 	by: ip@#glftpd
#	e-mail: ipfreelyinpublic@hotmail.com
#	www: www.chimera-coding.com
#
#	Requires: grep test
#
# $1 = Name of directory.
# $2 = Actual path the directory is stored in
# $PWD = Current Path.
# NOTE: Do not use echo for cases that return 0, only use it for cases that return 1
# or some ftp clients will lock up (this is the same problem as with dupescript)
#
#
# EXIT codes..
# 0 - Good: 
# 1 - Bad:
###CONFIG
# Site name short
SNS="ToB"
##Directory where your incoming dir is
incomingdir="/site/incoming"
###Directory for pre grps and other u may wanna omit
predirs="/site/incoming/private"
### Banned Languages, OS, GROUPS
banned="German Sweedish Italian Solaris French JGT JADE"
####NUKE TYPE
NUKESTL="[NUKED]-"
###END CONFIG
if `test `echo $PWD|grep -q $predirs``;then
     echo "($SNS) Omiting Check For Directory ($SNS)"
     exit 0;
fi

for x in $banned
do
	Match=`echo $1|grep -i "$x"`
	if `test "$Match" = "$1"`;then
		echo "($SNS) $x Releases Not Allowed ($SNS)"
		exit 2;
	fi
done

Day=`ls $incomingdir`
for y in $Day
do
	if `test -d $incomingdir/$y/$1 -o -d $incomingdir/$y/$NUKESTL$1`;then
	echo "($SNS) DUPE from $y ... DENIED ($SNS)"
	exit 2;
	fi
done

if `test `echo $1|grep -q "-"``;then
	TMP="y"
else
	echo "($SNS) Imporper Release Format ... Denied ($SNS)"
	exit 2;
fi
exit 0;
