#!/usr/bin/perl

## Settings
# glftpd root dir
$gldir = "/glftpd";
# FooPre logfile name
$fooprelog = "foo-pre.log";
# How many prees to show?
$precount = "5";

#### :)

open PRELOG, "< $gldir/ftp-data/logs/$fooprelog" or die "Cant open $fooprelog!\n";
@prelog = <PRELOG>;
close PRELOG;

$prees = 1;
$count = 0;
$count2 = 1;
@prelog = reverse(@prelog);

while ($#prelog >= $count) {
	if ($prelog[$count] =~ /START: (.*) (.*) (.*)/) {
		$user = $1;
		$release = $2;
		$section = $3;

		if ($prelog[$count2] =~ /GROUP: (.*) (.*)/) {
			$path = $1;
			$group = $2;
			$prereleases[$prees] = "$user\@$group prereleased: $release in $section";
			$prees++;
		};
	};
	$count++;
	$count2++;
}

print "$precount newest prereleases:\n";
$count = 1;
while ($count <= $precount) {
	print "($count) $prereleases[$count]\n";
	$count++;
};
