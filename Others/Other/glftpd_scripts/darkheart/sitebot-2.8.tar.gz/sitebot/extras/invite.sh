#!/bin/sh

# Site Invite v0.1 by DaRKHeaRT

# ; start of config section
chan=#king
# ; end of config section

if [ $1 ] ; then
        echo "Inviting $1 to $chan"
	echo `date "+%a %b %d %T %Y"` INVITE: $1 $USER $GROUP >> /ftp-data/logs/glftpd.log
else
        echo "USAGE: site invite <nick>"
fi
