// AUTO NUKE COMPARE PROGRAM (Not Case Sensitive)  By BLiNKY
#include <string.h>
#include <stdio.h>

#define MAXLINE 80

int main (int argc, char *argv[]) {
  FILE *fp;
 
  char dirname[255];
  char string[MAXLINE];
  char temp[MAXLINE];
  char match[MAXLINE];
  int i;
  int found = 0;
  match[0] = '\0';  
  if (argc == 1){
      printf("USEAGE: %s <dirname>\n", argv[0]);
          return 0;
		}
            
//
// Change the path to point to your /glftpd/ftp-data/logs/dupelog
//
  if((fp = fopen("/glftpd/ftp-data/logs/dupelog", "r")) == NULL) {
    printf("Can'nt open DUPELOG\n");
    return 0;
						}
 strcpy(dirname, argv[1]);
for(i=0; i<strlen(dirname); i++) dirname[i] = toupper(dirname[i]);
while(fgets(string, MAXLINE, fp) != NULL) {
 for(i=7; i<strlen(string); i++) temp[i-7] = toupper(string[i]);
temp[i-8] = '\0';

if (strcmp(temp,dirname) == 0 && found != 1) { 
for(i=0; i<6; i++) match[i] = string[i];
found = 1;
match[i] = '\0';
			       }
//printf("%s", temp);
//return 0;		       }
					  }
  fclose(fp);
for(i=0; i<6; i++) temp[i] = string[i];
temp[i] = '\0';
if ( match == NULL ) { return 0; }
if (strcmp(match,temp) == 0 ) { return 0; }
if (strcmp(match,temp) != 0 ) { printf("%s",match); }
// printf("DEBUG: match = %s  last = %s",match,temp);
  return 0;
				  }