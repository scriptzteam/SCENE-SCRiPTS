#!/bin/sh  -x
# MagicaLs Newday Script + dh output lines.
# v1.0

# set this to your glftpd site dir
glftpdsitedir1=/glftpd/site/MP3/
glftpdsitedir2=/glftpd/site/Rip/Games/
glftpdsitedir3=/glftpd/site/Rip/Utils/

dhdir1=/glftpd/site/MP3/today
dhdir2=/glftpd/site/Rip/Games/today
dhdir3=/glftpd/site/Rip/Utils/today

# set this line below to your sites incoming directory
ftpincoming1=Incoming/

# owner of glftpd (usually root)
glftpdowner=root
archive=yes
copyinsteadofmove=no
oldarchive=Old/

# set the next line to 'yes' and set a path for your today link
todaylink=yes
todaylinkname=today
todaylocation=
# leave as blank to default to yer site dir

# it is safe to not modify below this line

date=`date +%m%d`
date2=`date --date '4 days ago' +%m%d`

#date to move

cp -r $glftpdsitedir1$ftpincoming1$date2 $glftpdsitedir1$oldarchive
cp -r $glftpdsitedir2$ftpincoming1$date2 $glftpdsitedir2$oldarchive
cp -r $glftpdsitedir3$ftpincoming1$date2 $glftpdsitedir3$oldarchive
rm -fr $glftpdsitedir1$ftpincoming1$date2
rm -fr $glftpdsitedir2$ftpincoming1$date2
rm -fr $glftpdsitedir3$ftpincoming1$date2

# Create new days

mkdir -m 777 $glftpdsitedir1$ftpincoming1$date
mkdir -m 777 $glftpdsitedir2$ftpincoming1$date
mkdir -m 777 $glftpdsitedir3$ftpincoming1$date
chown $glftpdowner $glftpdsitedir1$ftpincoming1$date
chown $glftpdowner $glftpdsitedir2$ftpincoming1$date
chown $glftpdowner $glftpdsitedir3$ftpincoming1$date

# GLFTPD Output lines by DH..

DATE=`date +%m%d`
OLDDATE=`date --date '1 days ago' +%m%d`
TOTALRELEASE=`ls $dhdir1 | wc -w | awk '{print $1}'`
TOTALSIZE=`du $dhdir1 -m -s -L | awk '{print $1}'`
echo `date "+%a %b %d %T %Y"` NEWDAY: $OLDDATE $DATE $TOTALRELEASE $TOTALSIZE >> /glftpd/ftp-data/logs/glftpd.log

DATE=`date +%m%d`
OLDDATE=`date --date '1 days ago' +%m%d`
TOTALRELEASE=`ls $dhdir2 | wc -w | awk '{print $1}'`
TOTALSIZE=`du $dhdir2 -m -s -L | awk '{print $1}'`
echo `date "+%a %b %d %T %Y"` NEWDAY: $OLDDATE $DATE $TOTALRELEASE $TOTALSIZE >> /glftpd/ftp-data/logs/glftpd.log

DATE=`date +%m%d`
OLDDATE=`date --date '1 days ago' +%m%d`
TOTALRELEASE=`ls $dhdir3 | wc -w | awk '{print $1}'`
TOTALSIZE=`du $dhdir3 -m -s -L | awk '{print $1}'`
echo `date "+%a %b %d %T %Y"` NEWDAY: $OLDDATE $DATE $TOTALRELEASE $TOTALSIZE >> /glftpd/ftp-data/logs/glftpd.log

# Create today link

if [ "$todaylink" = "yes" ]; then
cd $glftpdsitedir1
rm -f $todaylocation$todaylinkname
ln -s $ftpincoming1$date $todaylocation$todaylinkname
chown $glftpdowner $todaylocation$todaylinkname

cd $glftpdsitedir2
rm -f $todaylocation$todaylinkname
ln -s $ftpincoming1$date $todaylocation$todaylinkname
chown $glftpdowner $todaylocation$todaylinkname

cd $glftpdsitedir3
rm -f $todaylocation$todaylinkname
ln -s $ftpincoming1$date $todaylocation$todaylinkname
chown $glftpdowner $todaylocation$todaylinkname
fi
