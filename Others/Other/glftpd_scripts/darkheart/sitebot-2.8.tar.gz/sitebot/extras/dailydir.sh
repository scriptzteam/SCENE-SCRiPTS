#!/bin/bash

# dailydir.sh script by DaRKHeaRT.

gllog=`echo /glftpd/ftp-data/logs/glftpd.log`
glbase=`echo /glftpd/site`
DATE=`date +%m%d`
OLDDATE=`date --date '1 days ago' +%m%d`
OLD=`date --date '2 days ago' +%m%d`
cd $glbase

### 0day ###

todaylink=`echo today`
glpath=`echo 0day/incoming`
chmod 555 ./$glpath/$OLD
mkdir -m 777 ./$glpath/$DATE
rm -f $todaylink
ln -sf ./$glpath/$DATE $todaylink
TOTALRELEASE=`ls ./$glpath/$OLDDATE | wc -w | awk '{print $1}'`
TOTALSIZE=`du ./$glpath/$OLDDATE -m -s -L | awk '{print $1}'`
echo `date "+%a %b %d %T %Y"` NEWDAY: $glpath $OLDDATE $DATE $TOTALRELEASE $TOTALSIZE >> $gllog

### mp3 ###

todaylink=`echo mp3today`
glpath=`echo mp3/incoming`
chmod 555 ./$glpath/$OLD
mkdir -m 777 ./$glpath/$DATE
rm -f $todaylink
ln -sf ./$glpath/$DATE $todaylink
TOTALRELEASE=`ls ./$glpath/$OLDDATE | wc -w | awk '{print $1}'`
TOTALSIZE=`du ./$glpath/$OLDDATE -m -s -L | awk '{print $1}'`
echo `date "+%a %b %d %T %Y"` NEWDAY: $glpath $OLDDATE $DATE $TOTALRELEASE $TOTALSIZE >> $gllog