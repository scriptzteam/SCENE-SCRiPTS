/* -------------------------------------------------------------------------
 * jstats - Used by jehsom's zipscript to store & get race stats
 * Copyright (C) 2000 jehsom@jehsom.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * -------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <pwd.h>
#include <grp.h>
#include <limits.h>
#include <ctype.h>
#include <time.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "js.h"

/* Array of pointers to file structs, each holding info on one file */
static struct file *data[MAXFILES];
/* Number of files we have info on */
static unsigned int numFiles=0;
/* Array of pointers to totals structs, to store calc'd totals info */
static struct total *totals[MAXTOTALS];
/* Number of totals records we have */
static unsigned int numTotals=0;
/* File containing the data for the files in the rls */
static char dataFileName[PATH_MAX];
/* Global variable to hold the current dir, so it doesn't
   have to be retrieved multiple times */
static char cwd[PATH_MAX];
/* Points to argv[0] so it can be accessed from other functions */
static char *progname=NULL;
/* Pointer to strcmp function -- changes depending on case sensitivity */
static int (*mystrcmp)(const char*,const char*)=strcmp;

/* Some option variables */
static int include_unverified=0;
static int verbose=0;
static int precision=2;

/* CRC lookup table */
unsigned long crc32_table[256] = {  0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA,
0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3, 0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E,
0x97D2D988, 0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91, 0x1DB71064, 0x6AB020F2,
0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7, 0x136C9856,
0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 0x3C03E4D1, 0x4B04D447, 0xD20D85FD,
0xA50AB56B, 0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75,
0xDCD60DCF, 0xABD13D59, 0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5,
0x56B3C423, 0xCFBA9599, 0xB8BDA50F, 0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924,
0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D, 0x76DC4190, 0x01DB7106, 0x98D220BC,
0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433, 0x7807C9A2, 0x0F00F934,
0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01, 0x6B6B51F4,
0x1C6C6162, 0x856530D8, 0xF262004E, 0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3,
0xFBD44C65, 0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7,
0xA4D1C46D, 0xD3D6F4FB, 0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 0x44042D73,
0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9, 0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086,
0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F, 0x5EDEF90E, 0x29D9C998, 0xB0D09822,
0xC7D7A8B4, 0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD, 0xEDB88320, 0x9ABFB3B6,
0x03B6E20C, 0x74B1D29A, 0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683, 0xE3630B12,
0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB, 0x196C3671,
0x6E6B06E7, 0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 0xF9B9DF6F, 0x8EBEEFF9,
0x17B7BE43, 0x60B08ED5, 0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1,
0xA6BC5767, 0x3FB506DD, 0x48B2364B, 0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60,
0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79, 0xCB61B38C, 0xBC66831A, 0x256FD2A0,
0x5268E236, 0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F, 0xC5BA3BBE, 0xB2BD0B28,
0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D, 0x9B64C2B0,
0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7,
0x0BDBDF21, 0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B,
0x6FB077E1, 0x18B74777, 0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF,
0xF862AE69, 0x616BFFD3, 0x166CCF45, 0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2,
0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB, 0xAED16A4A, 0xD9D65ADC, 0x40DF0B66,
0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9, 0xBDBDF21C, 0xCABAC28A,
0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF, 0xB3667A2E,
0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D};


struct total *getTotalsFor( const char *who, totalType type ){
	int i=0;
	for( i=0; i<numTotals; i++ )
		if( (totals[i]->type == type) && (type == overallTotal || mystrcmp(totals[i]->who, who) == 0) )
			return totals[i];
	return NULL;
}	

struct file *getDataFor( const char *fileName ){
	int i=0;
	if( fileName == NULL ) return NULL;
	for( i=0; i<numFiles; i++ )
		if( mystrcmp(data[i]->name,fileName) == 0 ) return data[i];
	return NULL;
}	

int getRank( const char *name, totalType op ){
	struct total *info=NULL;
	if( (info=getTotalsFor(name, op)) != 0 ) return info->rank;
	return 0;
}

char **atRank( int rank, totalType type ){
	char **names;
	int i=0;
	int j=0;
	int curr=0;
	
	if( (names=malloc(numTotals*sizeof(char*))) == NULL ) return NULL;
	
	for( i=0; i<numTotals; i++ ){
		if( totals[i]->type == type ){
			curr++;
			if( curr == rank || (rank<0 && curr>-rank) ){
				names[j++]=totals[i]->who;
			}
		}
	}
	names[j]=NULL;
	return names;
}

char *getNameFromRank( int rank, totalType op ){
	int i=0;
	for( i=0; i<numTotals; i++ ){
		if( totals[i]->type == op && totals[i]->rank == rank ) return totals[i]->who;
	}
	return NULL;
}	

char **getFilenames( const char *name, totalType op ){
	int i=0;
	int j=0;
	char **names;
	if( (names=malloc(sizeof(char*) * (numFiles+1))) == NULL ) return NULL;
	for( i=0; i<numFiles; i++ ){
		if( (op == userTotal && mystrcmp(name, data[i]->user) == 0) ||
		    (op == groupTotal && mystrcmp(name, data[i]->group) == 0) ||
			(op == fileTotal && mystrcmp(name, data[i]->name) == 0) ||
			(op == overallTotal) ) {
			names[j++]=data[i]->name;
		}	
	}
	names[j]=NULL;
	return names;
}	

int getNumFiles( const char *name, totalType op ){
	struct total *info=NULL;
	if( (info=getTotalsFor(name, op)) != 0 ) return info->totFiles;
	return 0;
}

int getNumRacers( totalType type ){
	int i;
	int rc=0;
	for( i=0; i<numTotals; i++ ){
		if( totals[i]->type == type ) rc++;
	}
	return rc;
}

time_t getModTime( const char *name, totalType op ){
	int i=0;
	unsigned long rc=0;
	struct file *fileInfo=NULL;
	
	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) != 0 ) rc=fileInfo->mtime;
			break;
		case userTotal: case groupTotal: case overallTotal:
			for( i=0; i<numFiles; i++ ){
				if(((op==overallTotal) ||
					(op==userTotal && mystrcmp(name,data[i]->user) == 0) ||
					(op==groupTotal && mystrcmp(name,data[i]->group) == 0)) &&
					(data[i]->mtime > rc) ){
						rc=data[i]->mtime;
				}
			}
			break;
		default:
			rc=0;
			break;
	}
	return (time_t)rc;
}

char *getPrettyModTime( const char *name, totalType op ){
	time_t tmp;
	tmp=getModTime(name, op);
	return asctime(localtime(&tmp));
}


time_t getStartTime( const char *name, totalType op ){
	int i=0;
	unsigned long rc=0;
	struct file *fileInfo=NULL;

	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) != 0 ) rc=fileInfo->mtime-fileInfo->secs;
			break;
		case userTotal: case groupTotal: case overallTotal:
			rc=ULONG_MAX;
			for( i=0; i<numFiles; i++ ){
				if(((op==overallTotal) || 
					(op==userTotal && mystrcmp(name, data[i]->user) == 0) ||
					(op==groupTotal && mystrcmp(name, data[i]->group) == 0)) &&
					(data[i]->mtime-data[i]->secs < rc) ){
						rc=data[i]->mtime-data[i]->secs;
				}
			}
			if( rc==ULONG_MAX ) rc=0;
			break;
		default:
			rc=0;
			break;
	}
	return (time_t)rc;
}

char *getPrettyStartTime( const char *name, totalType op ){
	time_t tmp;
	tmp=getStartTime(name, op);
	return asctime(localtime(&tmp));
}

int getDuration( const char *name, totalType op ){
	return getModTime(name, op) - getStartTime(name, op);
}

float getUploadTime( const char *name, totalType op ){
	struct total *totalInfo=NULL;
	struct file  *fileInfo=NULL;
	float time=0.0;

	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) != 0 ) time=fileInfo->secs;
			break;
		case userTotal: case groupTotal: case overallTotal:
			if( (totalInfo=getTotalsFor(name,op)) ) time=totalInfo->totTime;
			break;
		default:
			break;
	}		
	return time;
}

unsigned long getBytes( const char *name, totalType op ){
	struct total *totalInfo=NULL;
	struct file *fileInfo=NULL;
	unsigned long bytes=0;
	
	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) ) bytes=fileInfo->size;
			break;
		case userTotal: case groupTotal: case overallTotal:
			if( (totalInfo=getTotalsFor(name,op)) ) bytes=totalInfo->totBytes;
			break;
		default:
			break;
	}
	return bytes;
}

float getSpeed( const char *name, totalType op ){
	struct total *totalInfo=NULL;
	struct file *fileInfo=NULL;
	float speed=0.0;
	
	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) ) speed=fileInfo->size/fileInfo->secs/1024;
			break;
		case userTotal: case groupTotal: case overallTotal:
			if( (totalInfo=getTotalsFor(name,op)) ) speed=totalInfo->totBytes/totalInfo->totTime/1024;
			break;
		default:
			break;
	}
	return speed;	
}

float getPercent( const char *name, totalType op ){
	struct total *totalInfo=NULL;
	struct file *fileInfo=NULL;
	float percent=0.0;
	
	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) ) percent=fileInfo->size/totals[0]->totBytes*100;
			break;
		case userTotal: case groupTotal: case overallTotal:
			if( (totalInfo=getTotalsFor(name,op)) ) percent=totalInfo->percent;
			break;
		default:
			break;
	}
	return percent;
}

char **getGroups( const char *name, totalType op ){
	struct file *fileInfo=NULL;
	char **groups;
	int i=0;
	int j=0;

	if( (groups=malloc(sizeof(char*) * (numTotals+1))) == NULL ) return NULL;

	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor(name)) ) groups[j++]=fileInfo->group;
			break;
		case userTotal:
			for( i=0; i<numFiles; i++ )
				if( mystrcmp(data[i]->user, name) == 0 ) {
					groups[j++]=data[i]->group;
					break;
				}
			break;
		case overallTotal:
			for( i=1; i<numTotals; i++ )
				if( totals[i]->type == groupTotal ) groups[j++]=totals[i]->who;
			break;
		case groupTotal:
			for( i=1; i<numTotals; i++ )
				if( totals[i]->type == groupTotal && mystrcmp(totals[i]->who,name) == 0 )
					groups[j++]=totals[i]->who;
			break;
		default:
			break;
	}
	groups[j]=NULL;
	return groups;
}

char **getUsers( const char *name, opType op ){
	struct total *totalInfo=NULL;
	struct file *fileInfo=NULL;
	char **users;
	int i=0;
	int j=0;

	if( (users=malloc(sizeof(char*) * (numTotals+1))) == NULL ) return NULL;

	switch( op ){
		case fileTotal:
			if( (fileInfo=getDataFor( name )) ) users[j++]=fileInfo->user;
			break;
		case groupTotal:
			for( i=0; i<numFiles; i++ ){
				if( (totalInfo=getTotalsFor(data[i]->user, userTotal)) ){
					if( totalInfo->flag ) continue;
					totalInfo->flag=1;
					if(mystrcmp(data[i]->group, name) == 0) users[j++]=data[i]->user;
				}
			}
			break;
		case overallTotal:
			for( i=1; i<numTotals; i++ ) 
				if( totals[i]->type == userTotal ) users[j++]=totals[i]->who;
			break;
		case userTotal:
			for( i=1; i<numTotals; i++ )
				if( totals[i]->type == userTotal && mystrcmp(totals[i]->who,name) == 0 )
					users[j++]=totals[i]->who;
			break;
		default:
			break;
	}
	users[j]=NULL;
	return users;
}

unsigned long getCrc( const char *fileName ){
	struct file *fileInfo=NULL;
	if( (fileInfo=getDataFor(fileName)) ) return fileInfo->crc;
	return 0;
}

fileStatus getStatus( const char *fileName ){
	struct file *fileInfo=NULL;
	if( (fileInfo=getDataFor(fileName)) ) return fileInfo->status;
	return unverified;
}

int markFile( const char *fileName, fileStatus status ){
	struct file *fileInfo;
	if( fileName == NULL ){
		int i;
		for( i=0; i<numFiles; i++ ) data[i]->status=status;
		return 0;
	} else if ( (fileInfo=getDataFor(fileName)) ){
		fileInfo->status=status;
		return 0;
	} else {
		return 1;
	}
}

void delFileStats( const char *fileName ){
	int i=0;
	int j=0;
	for( i=0; i<numFiles; i++ ){
		if( fileName == NULL || mystrcmp( fileName, data[i]->name ) == 0 ){
			free( data[i]->name );
			free( data[i]->user );
			free( data[i]->group );
			free( data[i] );
			/* data[i]=NULL; */
			for( j=i+1; j<numFiles; j++ ){
				data[j-1]=data[j];
				/*data[j]=NULL; */
			}
			numFiles--; i--;
		}	
	}
	return;
}


void wipeStale( void ){
	int i=0;
	for( i=0; i<numFiles; i++ ){
		if( access( data[i]->name, F_OK ) == 0 ) continue;
		free( data[i]->name );
		data[i]->name=NULL; /* NULL indicates deleted record */
	}
	return;
}	


/* calc_crc32()
 * 
 * Based on the calc_crc32.c code. Thanks to the author!
 * RETURN VALUES:
 #	0: Success
 *	1: File read error
 *	2: Memory allocation error
 */
int calc_crc32( const char *fname, unsigned long *crc ) {
	FILE *in;           /* input file */
	unsigned char *buf; /* pointer to the input buffer */
	size_t i, j;        /* buffer positions*/
	int k;              /* generic integer */

	/* open file */
	if((in = fopen(fname, "rb")) == NULL) return 1;
	/* allocate buffer */
	if( (buf=malloc(32766)) == NULL){
		fclose(in);
		return 2;
	}
	*crc = 0xFFFFFFFF; /* preconditioning sets non zero value */
	/* loop through the file and calculate CRC */
	while( (i=fread(buf, 1, 32766, in)) != 0 ){
		for(j=0; j<i; j++){
			k=(*crc ^ buf[j]) & 0x000000FFL;
			*crc=((*crc >> 8) & 0x00FFFFFFL) ^ crc32_table[k];
		}
	}
	fclose(in);
	*crc=~(*crc); /* postconditioning */
    return 0;
}

/* static int addFileData( const char *fileName );
 *
 * Stats the specified file and stores its info into a new
 * entry into the data[] array.
 * RETURN VALUES:
 *  0: Success
 *  1: Unable to stat file
 *  2: Unable to malloc()
 *  3: Error obtaining file CRC (Probably couldn't read file)
 */
int addFileData( const char *fileName ){
	int i=0;
	int j=0;
	int gid=0;
	struct group *grpInfo=NULL;
	struct passwd *usrInfo=NULL;
	struct stat fileData;
	char *cp=NULL;

	delFileStats( fileName ); /* Remove any existing stats for a file of this name */

	i=numFiles;
	if( stat(fileName, &fileData) == -1 ) return 1; /* Stat file */
	if( (data[i]=malloc(sizeof(struct file))) == NULL ) return 2; /* Make room */
	if( (data[i]->name=(char*)strdup(fileName)) == NULL ) return 2; /* Store name */
	if( (cp=getenv(CRC_VAR)) == NULL ){
		if( calc_crc32( fileName, &data[i]->crc ) != 0 ) return 3;
	} else {
		/* Verify that CRC is valid */
		for( j=0; cp[j] != '\0'; j++ ){
			cp[j]=toupper(cp[j]);
			if( (cp[j] >= '0' && cp[j] <= '9') ||
				(cp[j] >= 'A' && cp[j] <= 'F') )
				continue;
		}
		/* If we have what appears to be a valid crc, convert to
		 * an unsigned long and store to data[i]->crc */
		if( cp[j] == '\0' ) data[i]->crc=strtoul( cp, NULL, 16 );
		/* If our CRC is 0, glftpd didn't pass it to us, so calc it */
		if( data[i]->crc == 0 && calc_crc32( fileName, &data[i]->crc ) != 0 ) return 3;
	}
	/* Get the user's info */
	if( (usrInfo=getpwuid(fileData.st_uid)) == NULL ){
		if( (data[i]->user=malloc(12)) == NULL ) return 2;
		(void)sprintf( data[i]->user, "%d", fileData.st_uid );
	} else {
		/* Store username */
		if( (data[i]->user=(char*)strdup( usrInfo->pw_name )) == NULL ) return 2;
	}
	/* Fix glftpd's stupid gid download count */
	gid=100 * (int)(fileData.st_gid/100);
	/* Get the group's info */
	if( (grpInfo=getgrgid(gid)) == NULL ){
		if( (data[i]->group=malloc(12)) == NULL ) return 2;
		(void)sprintf( data[i]->group, "%d", fileData.st_gid );
	} else {
		/* Store groupname */
		if( (data[i]->group=(char*)strdup( grpInfo->gr_name )) == NULL ) return 2;
	}
	/* Store filesize */
	data[i]->size=fileData.st_size;
	/* Get the value of the SPEED_VAR from the environment */
	if( (cp=getenv(SPEED_VAR)) == NULL || *cp == '0' ) cp=DEFAULT_SPEED;
	/* Store upload duration */
	data[i]->secs=(float)data[i]->size/strtol(cp,NULL,0)/1024;
	/* Store mtime */
	data[i]->mtime=fileData.st_mtime;
	/* The file hasn't verified yet, so put 0 in this field */
	data[i]->status=unverified;

	numFiles++;
	return 0;
	
}	

/* static int pmkdir( char *path );
 *
 * Makes a directory and its parents. Returns
 *  0 on success, or -1 on failure.
 */
int pmkdir( const char *newpath ){
	char path[PATH_MAX];
	char tmp;
	int pos=0;
	int rc=0;

	(void)strcpy( path, newpath );
	for( pos=0; path[pos]; pos++ ){
		if( (path[pos] == '/' && path[pos+1] != '/') || path[pos+1] == '\0' ){
			tmp=path[pos+1];
			path[pos+1]='\0';
			rc=mkdir( path, 0777 );
			path[pos+1]=tmp;
		}
	}
	return rc;
}

/* static int validataNfoDir( char *rlsPath );
 *
 * Validates that NFODIR is valid and that the specific
 * stats dir for this release is present and accessible.
 * Also sets the global dataFileName variable.
 */
int validateNfoDir( const char *rlsPath ){
	char *nfoDir=NULL;
	
	(void)umask(0);
	
	if( (nfoDir=getenv(NFODIR_VAR)) == NULL ){
		errno=EINVAL;
		return 1;
	}
	if( access(nfoDir, F_OK) == -1 && pmkdir(nfoDir) == -1 ){
		errno=ENOENT;
		return 1;
	}
	if( access(nfoDir, R_OK|W_OK|X_OK) == -1 && chmod(nfoDir, 
		S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IWGRP|S_IXGRP|S_IROTH|S_IWOTH|S_IXOTH) == -1 ){
		errno=EACCES;
		return 1;
	}	
	/* For now, only put the PATH to the datafile into dataFileName */
	(void)strcpy(dataFileName, nfoDir);
	(void)strcat(dataFileName, rlsPath);
	/* Check accessibility of the path */
	if( access(dataFileName, F_OK)==-1 && pmkdir(dataFileName)==-1 ){
		errno=EPERM;
		return 1;
	}
	(void)strcat(dataFileName, "/" );
	(void)strcat(dataFileName, DATFILE );
	return 0;
}

/* static int addTotalRecord( char *who, totalType type );
 *
 * Creates a new entry in the totals[] array, and copies the
 *  "who" string into the "who" entry of the new struct.
 */
int addTotalsRecord( const char *who, totalType type ){
	if( (totals[numTotals]=malloc(sizeof(struct total))) == NULL ) return 1;
	if( (totals[numTotals]->who=(char*)strdup(who)) == NULL ) return 1;
	totals[numTotals]->type=type;
	totals[numTotals]->totFiles=0;
	totals[numTotals]->totBytes=0;
	totals[numTotals]->totTime=0.0;
	totals[numTotals]->avgSpeed=0;
	totals[numTotals]->percent=0;
	totals[numTotals]->rank=0;
	totals[numTotals]->flag=0;
	numTotals++;
	return 0;
}	

/* static int totSort( const void *totA, const void *totB );
 *
 * Takes two parameters that are each a pointer to a struct total.
 * For use with qsort() to allow the array of totals to be sorted.
 */
int totSort( const void *totA, const void *totB ){
	struct total *totalA=*((struct total**)totA);
	struct total *totalB=*((struct total**)totB);
	
	if( totalA->type < totalB->type ) {
		return -1;
	} else if( totalA->type > totalB->type ){
		return 1;
	} else {
		if( totalA->totBytes < totalB->totBytes ){
			return 1;
		} else if( totalA->totBytes > totalB->totBytes ){
			return -1;
		} else {
			return 0;
		}
	}
}

/* static void calcTotals( void );
 *
 * Calculates all the totals, puts it into totals[] 
 */
void calcTotals( void ){
	int i=0;
	int j=0;

	/* The 0th struct of the totals array is reserved
	   for OVERALL totals, as opposed to per-user/group */
	numTotals=0;
	addTotalsRecord( "All Users", overallTotal );

	/* Iterate through each file record */
	for( i=0; i<numFiles; i++ ){
		/* Exclude unverified files if toggle is set */
		if( !include_unverified && data[i]->status == unverified ) continue;
		/* Update the overall stats */
		totals[0]->totFiles++;
		totals[0]->totBytes += data[i]->size;
		totals[0]->totTime += data[i]->secs;
			if( totals[0]->totTime == 0 ) totals[0]->totTime++;
		totals[0]->avgSpeed = (totals[0]->totBytes/1024)/totals[0]->totTime;
		
		/* Update the stats for the individual user */
		for( j=0; j<numTotals; j++ ){
			if( ( totals[j]->type == userTotal ) &&
				( mystrcmp(totals[j]->who, data[i]->user) == 0 ) ){
				break;
			}
		}	
		if( j == numTotals ) addTotalsRecord( data[i]->user, userTotal );
		totals[j]->totFiles++;
		totals[j]->totBytes += data[i]->size;
		totals[j]->totTime += data[i]->secs;
			if( totals[j]->totTime == 0 ) totals[j]->totTime++;
		totals[j]->avgSpeed = (totals[j]->totBytes/1024)/totals[j]->totTime;

		/* Update the stats for the file's group */
		for( j=0; j<numTotals; j++ ){
			if( ( totals[j]->type == groupTotal ) &&
				( mystrcmp(totals[j]->who, data[i]->group) == 0 ) ){
				break;
			}
		}	
		if( j == numTotals ) addTotalsRecord( data[i]->group, groupTotal );
		totals[j]->totFiles++;
		totals[j]->totBytes += data[i]->size;
		totals[j]->totTime += data[i]->secs;
			if( totals[j]->totTime == 0 ) totals[j]->totTime++;
		totals[j]->avgSpeed = (totals[j]->totBytes/1024)/totals[j]->totTime;
	}

	qsort( totals, numTotals, sizeof(struct totals*), totSort );

	if( numTotals > 1 ){
		for( i=1; totals[i]->type != groupTotal; i++ ){
			totals[i]->rank=i;
		}
		for( j=i; j<numTotals; j++ ){
			totals[j]->rank=(j-i+1);
		}	
	}			
	for( j=0; j<numTotals; j++ ){
		totals[j]->percent=(float)totals[j]->totBytes/totals[0]->totBytes * 100;
	}	
	
	return;
}


/* static int nextTok( char **lineptr );
 *
 * Modifis *lineptr to point to the next field on a line of
 *  null-delimited fields. If it can't find a next field, it
 *  returns 1, otherwise it returns 0.
 * I would have used strchr() for this, except that it would stop
 *  at the end of each field thinking it was the end of the string :)
 */
int nextTok( char **lineptr ){
	while( **lineptr && **lineptr != '\n' ) (*lineptr)++;
	if( **lineptr == '\n' ) return 1;
	(*lineptr)++;
	return 0;
}


/* static void readStats( void );
 * 
 * This function reads the specified file
 * and places its contents into data[] 
 */
int readStats( void ){
	char *line=NULL;
	char *linebuf=NULL;
	FILE *fp=NULL;

	numFiles=0;

	if( (fp=fopen( dataFileName, "r" )) == NULL ){
		if( ((fp=fopen( dataFileName, "w" )) == NULL ) ||
			((fp=freopen( dataFileName, "r", fp )) == NULL)) {
			(void)fclose(fp);
			return 1;
		}	
	}
	/* Allocate space for a line buffer */
	if( (linebuf=malloc(MAXLINELEN)) == NULL ) return 1;
	/* Read input line by line */
	while( fgets( linebuf, MAXLINELEN, fp ) ){
		line=linebuf;
		
		/* If line had to be truncated, place \n before end */
		line[MAXLINELEN-2]='\n';
		
		if( (data[numFiles]=malloc(sizeof(struct file))) == NULL ||
		    (data[numFiles]->name=malloc( MAXLINELEN )) == NULL ||
			(data[numFiles]->user=malloc( MAXNAMELEN )) == NULL ||
			(data[numFiles]->group=malloc( MAXNAMELEN )) == NULL ) {
				(void)fclose(fp);
				return 1;
		}		
		(void)strcpy( data[numFiles]->name, line );

		/* Get CRC */
		if( nextTok( &line ) != 0 ) continue;
		data[numFiles]->crc=strtoul( line, NULL, 0 );
		
		/* Get Username */
		if( nextTok( &line ) != 0 ) continue;
		(void)strncpy( data[numFiles]->user, line, MAXNAMELEN );
		data[numFiles]->user[MAXNAMELEN]='\0';
	
		/* Group name */
		if( nextTok( &line ) != 0 ) continue;
		(void)strncpy( data[numFiles]->group, line, MAXNAMELEN );
		data[numFiles]->group[MAXNAMELEN]='\0';
		
		/* Filesize */
		if( nextTok( &line ) != 0 ) continue;
		data[numFiles]->size=strtoul( line, NULL, 0 );

		/* transfer time */
		if( nextTok( &line ) != 0 ) continue;
		data[numFiles]->secs=strtod( line, NULL );

		/* File's modification time (epoch time) */
		if( nextTok( &line ) != 0 ) continue;
		data[numFiles]->mtime=strtoul( line, NULL, 0 );

		/* status boolean (0/1) */
		if( nextTok( &line ) != 0 ) continue;
		data[numFiles]->status=strtol( line, NULL, 0 );
		if( data[numFiles]->status != unverified && data[numFiles]->status != verified ){
			data[numFiles]->status = unverified;
		}	
		
		if( data[numFiles]->status == unverified && !include_unverified ){
			free(data[numFiles]->user);
			free(data[numFiles]->name);
			free(data[numFiles]->group);
			free(data[numFiles]);
		} else {
			numFiles++;
		}	
	}
	(void)fclose(fp);
	return 0;
}

/* static void writeStats( void );
 * 
 * This function takes the data[] array
 * and writes it out to  the specified file 
 */
int writeStats( void ){
	FILE *fp;
	int i=0;
	
	if( (fp=fopen( dataFileName, "w" )) == NULL ) return 1;
	for( i=0; i<numFiles; i++ ){
		/* A null name pointer indicates deletion of the record */
		if( data[i]->name == NULL ) continue;
		(void)fprintf( fp, "%s%c%lu%c%s%c%s%c%u%c%f%c%lu%c%d%c\n",
			data[i]->name, '\0', data[i]->crc,  '\0', data[i]->user,  '\0', data[i]->group,  '\0', 
			data[i]->size, '\0', data[i]->secs, '\0', data[i]->mtime, '\0', data[i]->status, '\0' );
	}
	(void)fclose(fp);
	return 0;
}

void raceTable( void ){
	printf( ",----------------------------------------------------------.\n"
	        "|RNK / Racer/Group        / Size (KB) / #F /    %%%%   / K/s  |\n"
	        "|---|--------------------|-----------|----|--------|-------|\n" );
	if( getNumFiles( NULL, overallTotal ) == 0 ){
		printf( "| ? |      No race info! |   Unknown | ?? |  ??.?? |  ???? |\n" );
	} else {
		char **names;
		names=getUsers( NULL, overallTotal );
		while( *names ){
            char useratgroup[19];
            strncpy(useratgroup, *names, 18);
            strncat(useratgroup, "@", 18-strlen(useratgroup));
            strncat(useratgroup, *getGroups(*names, userTotal), 18-strlen(useratgroup));
            useratgroup[19]='\0';
			printf( "| %d | %18s | %9lu | %2d | %6.2f | %5.0f |\n",
				getRank( *names, userTotal ), useratgroup,
				getBytes( *names, userTotal)/1024, getNumFiles( *names, userTotal ), 
				getPercent( *names, userTotal), getSpeed( *names, userTotal )  );
			names++;
		}
	    printf( "|---|--------------------|-----------|----|--------|-------|\n" );
		names=getGroups( NULL, overallTotal );
		while( *names ){
			printf( "| %d | %18s | %9lu | %2d | %6.2f | %4.0f |\n",
				getRank(*names, groupTotal), *names,
				getBytes(*names, groupTotal)/1024, getNumFiles(*names, groupTotal),
				getPercent(*names, groupTotal), getSpeed(*names, groupTotal) );
			names++;
		}	
	}
	printf( "`---+--------------------+-----------+----+--------+-------'\n" );

}

void printVars( void ){
	int i=0;
	char **names=NULL;
    int totbytes;
    char usr_name_list[1024]={'\0'};
    char usr_group_list[1024]={'\0'};
    char usr_kbps_list[1024]={'\0'};
    char usr_bytes_list[1024]={'\0'};
    char usr_kb_list[1024]={'\0'};
    char usr_mb_list[1024]={'\0'};
    char usr_numfiles_list[1024]={'\0'};
    char usr_percent_list[1024]={'\0'};
    char grp_name_list[1024]={'\0'};
    char grp_kbps_list[1024]={'\0'};
    char grp_bytes_list[1024]={'\0'};
    char grp_kb_list[1024]={'\0'};
    char grp_mb_list[1024]={'\0'};
    char grp_numfiles_list[1024]={'\0'};
    char grp_percent_list[1024]={'\0'};

    totbytes=getBytes(NULL,overallTotal);

	if( (names=getUsers( NULL, overallTotal) ) ){
		for( i=0; names[i]; i++ ){
			printf( "usr%d_name='%s'\n", i+1, names[i] );
            sprintf(strchr(usr_name_list, '\0'), "%s%s", (*usr_name_list?" ":""), names[i] );
			printf( "usr%d_group='%s'\n", i+1, *getGroups( names[i], userTotal ) );
            sprintf(strchr(usr_group_list, '\0'), "%s%s", (*usr_group_list?" ":""),
                *getGroups( names[i], userTotal ) );
			printf( "usr%d_kbps='%.*f'\n", i+1, precision, getSpeed( names[i], userTotal ) );
            sprintf(strchr(usr_kbps_list, '\0'), "%s%.*f", (*usr_kbps_list?" ":""),
                precision, getSpeed(names[i],userTotal) ); 
			printf( "usr%d_bytes='%lu'\n", i+1, getBytes(names[i],userTotal) );
            sprintf(strchr(usr_bytes_list, '\0'), "%s%lu", (*usr_bytes_list?" ":""),
                getBytes(names[i],userTotal) );
			printf( "usr%d_kb='%.*f'\n", i+1, precision, (float)getBytes(names[i],userTotal)/1024 );
            sprintf(strchr(usr_kb_list, '\0'), "%s%.*f", (*usr_kb_list?" ":""),
                precision, (float)getBytes(names[i],userTotal)/1024 );
			printf( "usr%d_mb='%.*f'\n", i+1, precision, (float)getBytes(names[i],userTotal)/1048576 );
            sprintf(strchr(usr_mb_list, '\0'), "%s%.*f", (*usr_mb_list?" ":""),
                precision, (float)getBytes(names[i],userTotal)/1048576 );
			printf( "usr%d_numfiles='%d'\n", i+1, getNumFiles(names[i],userTotal) );
            sprintf(strchr(usr_numfiles_list, '\0'), "%s%d", (*usr_numfiles_list?" ":""), 
                getNumFiles(names[i],userTotal) );
			printf( "usr%d_percent='%.*f'\n", i+1, precision, (float)100*getBytes(names[i],userTotal)/totbytes );
            sprintf(strchr(usr_percent_list, '\0'), "%s%.*f", (*usr_percent_list?" ":""),
                precision, (float)100*getBytes(names[i],userTotal)/totbytes );
		}
        printf( "usr_name_list='%s'\n", usr_name_list );
        printf( "usr_group_list='%s'\n", usr_group_list );
        printf( "usr_kbps_list='%s'\n", usr_kbps_list );
        printf( "usr_bytes_list='%s'\n", usr_bytes_list );
        printf( "usr_kb_list='%s'\n", usr_kb_list );
        printf( "usr_mb_list='%s'\n", usr_mb_list );
        printf( "usr_numfiles_list='%s'\n", usr_numfiles_list );
        printf( "usr_percent_list='%s'\n", usr_percent_list);
	}
	if( (names=getGroups(NULL, overallTotal)) ){
		for( i=0; names[i]; i++ ){
			printf( "grp%d_name='%s'\n", i+1, names[i] );
            sprintf(strchr(grp_name_list, '\0'), "%s%s", (*grp_name_list?" ":""), names[i] );
			printf( "grp%d_kbps='%.*f'\n", i+1, precision, getSpeed(names[i],groupTotal) );
            sprintf(strchr(grp_kbps_list, '\0'), "%s%.*f", (*grp_kbps_list?" ":""),
                precision, getSpeed(names[i],groupTotal) ); 
			printf( "grp%d_bytes='%lu'\n", i+1, getBytes(names[i],groupTotal) );
            sprintf(strchr(grp_bytes_list, '\0'), "%s%lu", (*grp_bytes_list?" ":""),
                getBytes(names[i],groupTotal) );
			printf( "grp%d_kb='%.*f'\n", i+1, precision, (float)getBytes(names[i],groupTotal)/1024 );
            sprintf(strchr(grp_kb_list, '\0'), "%s%.*f", (*grp_kb_list?" ":""),
                precision, (float)getBytes(names[i],groupTotal)/1024 );
			printf( "grp%d_mb='%.*f'\n", i+1, precision, (float)getBytes(names[i],groupTotal)/1048576 );
            sprintf(strchr(grp_mb_list, '\0'), "%s%.*f", (*grp_mb_list?" ":""),
                precision, (float)getBytes(names[i],groupTotal)/1048576 );
			printf( "grp%d_numfiles='%d'\n", i+1, getNumFiles(names[i],groupTotal) );
            sprintf(strchr(grp_numfiles_list, '\0'), "%s%d", (*grp_numfiles_list?" ":""), 
                getNumFiles(names[i],groupTotal) );
			printf( "grp%d_percent='%.*f'\n", i+1, precision, (float)100*getBytes(names[i],groupTotal)/totbytes );
            sprintf(strchr(grp_percent_list, '\0'), "%s%.*f", (*grp_percent_list?" ":""),
                precision, (float)100*getBytes(names[i],groupTotal)/totbytes );
		}
        printf( "grp_name_list='%s'\n", grp_name_list );
        printf( "grp_kbps_list='%s'\n", grp_kbps_list );
        printf( "grp_bytes_list='%s'\n", grp_bytes_list );
        printf( "grp_kb_list='%s'\n", grp_kb_list );
        printf( "grp_mb_list='%s'\n", grp_mb_list );
        printf( "grp_numfiles_list='%s'\n", grp_numfiles_list );
        printf( "grp_percent_list='%s'\n", grp_percent_list);
	}

	printf( "rls_bytes='%lu'\n", getBytes(NULL,overallTotal) );
	printf( "rls_kb='%.*f'\n", precision, (float)getBytes(NULL,overallTotal)/1024 );
	printf( "rls_mb='%.*f'\n", precision, (float)getBytes(NULL,overallTotal)/1048576 );
	printf( "rls_kbps='%.*f'\n", precision, getSpeed(NULL,overallTotal) );
	printf( "rls_numfiles='%d'\n", getNumFiles(NULL,overallTotal) );
	printf( "rls_numusers='%d'\n", getNumRacers(userTotal) );
	printf( "rls_numgroups='%d'\n", getNumRacers(groupTotal) );
	i=getDuration(NULL, overallTotal);
	printf( "rls_racelen='%02d:%02d'\n", i/60, i%60 );
	printf( "rls_racesecs='%d'\n", i );

	return;
}
		

	

#ifndef ZIPSCRIPT

/* int main( int argc, char *argv[] );
 * 
 * Processes commandline arguments and calls appropriate functions.
 */
int main( int argc, char *argv[] ){
	int rc=0;
	int opt=0;
	int writeOp=0;
	int n=0;
	char finalOp='\0';
	char *name=NULL;
	totalType type=overallTotal;
	extern char *optarg;
	extern int optind;

	/* Store the name of the program for use in error msgs */
	progname=argv[0];
	
	/* Get the current working directory */
	if( getcwd( cwd, PATH_MAX ) == NULL ){
		(void)fprintf( stderr, "Could not getcwd() (Directory permissions problem?).\n" );
		return EXIT_FAILURE;
	}
	/* Adjust umask so files are world readable/writable */
	(void)umask( 0 );
	/* If NFODIR is invalid or unset, exit. */
	if( validateNfoDir( cwd ) ){
		fprintf( stderr, "Your NFODIR is invalid. Exiting.\n" );
		return EXIT_FAILURE;
	}

	/* Get commandline options */
	while((opt=getopt(argc, argv, "LAVviIf:ou:g:rcFdtsmbkpGUCnNMTqa:0:1:x:Pw:W:")) != -1){
		switch( opt ){
			/* Invalid options */
			case '?': case ':':
				return EXIT_FAILURE;
			case 'q':
				include_unverified=1;
				/* fallthrough */
			case 'r': case 'c': case 'F': case 'd': case 'n': case 'T':
			case 's': case 't': case 'b': case 'k': case 'N': case 'V':
			case 'p': case 'G': case 'U': case 'C': case 'm': case 'M':
			case 'L':
				if( finalOp == 0 ) finalOp=opt;
				break;
			case 'w': case 'W':
				if( finalOp == 0 ){
					n=strtol(optarg, NULL, 0);
					finalOp=opt;
				}
				break;
			case 'a': case '0': case '1': case 'x': 
				if( strcmp(optarg,".") == 0 ){
					name=NULL;
				} else {
					name=(char*)strdup(optarg);
				}
				/* Intentional Fallthrough */
			case 'P':
				if( finalOp == 0 ){
					writeOp=1;
					include_unverified=1;
					finalOp=opt;
				}	
				break;
			case 'f':
				if( (name=(char*)strdup(optarg)) == NULL ){
					(void)fprintf( stderr, "Could not strdup filename.\n" );
					return EXIT_FAILURE;
				}
				type=fileTotal;
				include_unverified=1;
				break;
			case 'u': case 'g':
				if( (name=(char*)strdup(optarg)) == NULL ){
					(void)fprintf( stderr, "Could not strdup grp/user name.\n" );
					return EXIT_FAILURE;
				}
				type=(opt=='u'?userTotal:groupTotal);
				break;
			case 'o':
				type=overallTotal;
				break;
			case 'A':
				include_unverified=1;
				break;
			case 'v':
				verbose=1;
				break;
			case 'I':
				precision=0;
				break;
			case 'i':
				mystrcmp=strcasecmp;
				break;
			default:
				(void)fprintf( stderr, "Fell through to default\n" );
				break;
		}
	}
	/* Check for no operand */
	if( finalOp == 0 ){
		(void)fprintf( stderr, "Must specify an operation flag.\n" );
		return EXIT_FAILURE;
	}
	
	readStats();
	calcTotals();
	switch( finalOp ){
		char **names;
		case 'r':
			printf( "%d\n", getRank( name, type ) );
			break;
		case 'c':
			printf( "%d\n", getNumFiles( name, type ) );
			break;
		case 'n': case 'N':
			printf( "%d\n", getNumRacers( finalOp=='n'?userTotal:groupTotal ) );
			break;
		case 'F':
			names=getFilenames( name, type );
			while( *names ){
				printf( "%s%s", *names, (verbose?" ":"\n") );
				names++;
			}
			if(verbose) printf("\n");
			break;
		case 'd':
			if(verbose){
				n=getDuration( name, type );
				printf( "%d:%02d:%02d\n", n/3600, n%3600/60, n%60 );
			} else {
				printf( "%d\n", getDuration( name, type ) );
			}
			break;
		case 't':
			if(verbose){
				n=getUploadTime( name, type );
				printf( "%d:%02d:%02d\n", n/3600, n%3600/60, n%60 );
			} else {
				printf( "%.*f\n", precision, getUploadTime( name, type ) );
			}
			break;
		case 's':
			if(verbose){
				printf( "%s", getPrettyStartTime( name, type ) );
			} else {
				printf( "%lu\n", getStartTime( name, type ) );
			}
			break;
		case 'm':
			if(verbose){
				printf( "%s", getPrettyModTime( name, type ) );
			} else {
				printf( "%lu\n", getModTime( name, type ) );
			}
			break;
		case 'b':
			if(verbose)
				printf( "%lu\n", getBytes( name, type ) / 1024 );
			else
				printf( "%lu\n", getBytes( name, type ) );
			break;
		case 'M':
			printf( "%.*f\n", precision, (float)getBytes( name, type ) / 1048576 );
			break;
		case 'k':
			printf( "%.*f\n", precision, getSpeed( name, type ) );
			break;
		case 'p':
			printf( "%.*f\n", precision, getPercent( name, type ) );
			break;
		case 'G':
			names=getGroups( name, type );
			while( *names ){
				printf( "%s%s", *names, (verbose?" ":"\n") );
				names++;
			}
			if(verbose) printf("\n");
			break;
		case 'U':
			names=getUsers( name, type );
			while( *names ){
				printf( "%s%s", *names, (verbose?" ":"\n") );
				names++;
			}
			if(verbose) printf("\n");
			break;
		case 'C':
			names=getFilenames( name, type );
			while( *names ){
				if( verbose ){
					printf( "%s %08lX\n", *names, getCrc(*names) );
				} else {
					printf( "%08lX\n", getCrc(*names) );
				}
				names++;
			}	
			break;
		case 'q':
			if(type==fileTotal){
				rc=!getStatus(name);
				if(verbose) printf( "%d\n", !rc );
			} else {
				names=getFilenames( name, type );
				if(names==NULL || *names==NULL){
					rc=1;
				} else {
					while( *names ){
						printf( "%d %s\n", getStatus(*names), *names );
						names++;
					}
				}	
			}
			break;
		case 'a':
			if( name == NULL ){
				DIR *dp;
				struct dirent *entry;
				struct stat file;
				dp=opendir( cwd );
				while( (entry=readdir(dp)) ){
					/* Don't add if already exists */
					if( getDataFor(entry->d_name) ) continue;
					/* Don't add if it's a dot-file */
					if( *(entry->d_name) == '.' ) continue;
					/* Don't add if can't stat file */
					if( stat(entry->d_name, &file) == -1 ) continue;
					/* Don't add if it's not a regular file */
					if( !S_ISREG( file.st_mode ) ) continue;
                    /* Don't add file if it's 0 bytes */
                    if( file.st_size == 0 ) continue;
					if(verbose)
						printf( "Adding data for file %s . . . ", entry->d_name );
					rc=(rc|addFileData(entry->d_name));
					if(verbose)
						printf( "Done!\n" );
				}
				closedir( dp );
			} else {
				rc=addFileData( name );
			}
			break;
		case '0':
			rc=markFile( name, unverified );
			break;
		case '1':
			rc=markFile( name, verified );
			break;
		case 'x':
			delFileStats( name );
			break;
		case 'P':
			wipeStale();
			break;
		case 'w': case 'W':
			names=atRank( n, (finalOp=='w'?userTotal:groupTotal) );
			if( names && *names ){
				while( *names ){
					printf( "%s%s", *names, (verbose && *(names+1)?" ":"\n") );
					names++;
				}
			} else if( verbose ){
				printf( "none\n" );
			}	
			break;
		case 'T':
			raceTable();
			break;
		case 'L':
			printVars();
			break;
		case 'V':
			/* Intentionally do nothing */
			break;
		default:
			break;
	}
	/* if( verbose ) printTotals(); */
	if( writeOp ) writeStats();

	return (rc==0?EXIT_SUCCESS:EXIT_FAILURE);
}
#endif
