/* -------------------------------------------------------------------------
 * jstats - Used by jehsom's zipscript to store & get race stats
 * Copyright (C) 2000 jehsom@jehsom.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * -------------------------------------------------------------------------
 */


/* Maximum files in a rls */
#define MAXFILES 10000 /* You can set this really high */
/* Max # of users + groups ever to race in a rls */
#define MAXTOTALS 1000 /* You can set this really high */
#define DATFILE "filestats.dat"
/* Maximum length of line to read from DATFILE */
#define MAXLINELEN 500
/* Maximum length for a user/group name plus terminating null */
#define MAXNAMELEN 50
/* The names of environment vars containing various data */
#define NFODIR_VAR "NFODIR"
#define SPEED_VAR "SPEED"
#define CRC_VAR "crc_in"
/* The default speed to use if $SPEED isn't set */
#define DEFAULT_SPEED "50"
#ifndef PATH_MAX
#define PATH_MAX 4096
#endif


typedef enum fileStatus {
	unverified = 0,
	verified = 1
} fileStatus;

struct file {
    char *name;
    unsigned long crc;
    char *user;
    char *group;
    unsigned int size;
	float secs;
	unsigned long mtime;
    fileStatus status;
};

typedef enum opType {
    noOp,
    fileOp,
    userOp,
	groupOp,
    overallOp
} opType;

typedef enum totalType {
	overallTotal = 0,
	userTotal = 1,
	groupTotal = 2,
	fileTotal = 3
} totalType;

struct total {
	totalType type;
	char *who;
	int totFiles;
	float totBytes;
	float totTime;
	float avgSpeed;
	float percent;
	int rank;
	int flag;
};

struct total *getTotalsFor( const char *who, totalType type );
struct file *getDataFor( const char *fileName );
int getRank( const char *name, totalType op );
char **atRank( int rank, totalType type );
char *getNameFromRank( int rank, totalType op );
char **getFilenames( const char *name, totalType op );
int getNumFiles( const char *name, totalType op );
int getNumRacers( totalType type );
time_t getModTime( const char *name, totalType op );
char *getPrettyModTime( const char *name, totalType op );
time_t getStartTime( const char *name, totalType op );
char *getPrettyStartTime( const char *name, totalType op );
int getDuration( const char *name, totalType op );
float getUploadTime( const char *name, totalType op );
unsigned long getBytes( const char *name, totalType op );
float getSpeed( const char *name, totalType op );
float getPercent( const char *name, totalType op );
char **getGroups( const char *name, totalType op );
char **getUsers( const char *name, opType op );
unsigned long getCrc( const char *fileName );
fileStatus getStatus( const char *fileName );
int markFile( const char *fileName, fileStatus status );
void delFileStats( const char *fileName );
void wipeStale( void );
int calc_crc32( const char *fname, unsigned long *crc ) ;
int addFileData( const char *fileName );
int pmkdir( const char *newpath );
int validateNfoDir( const char *rlsPath );
int addTotalsRecord( const char *who, totalType type );
int totSort( const void *totA, const void *totB );
void calcTotals( void );
int nextTok( char **lineptr );
int readStats( void );
int writeStats( void );
void raceTable( void );
