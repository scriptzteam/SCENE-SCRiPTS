/** undupe2 - Remove a file from specified dupefile
 ** Original code by evilution @ efnet
 ** Simplified & Modified by jehsom
 ** - Added ability to specify dupefile
 ** - Made the prog return >0 on error, for script use.
 ** User needs write access to the dupefile's directory!
 ** 03-09-00
 **/

#include <strings.h>
#include <stdio.h>
#include <sys/time.h>
#include <errno.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

struct dupefile
{
  char filename[256];
  time_t timeup;
  char uploader[25];
};

int
main (int argc, char *argv[])
{
  // Declaring variables
  FILE *fp, *fp2;
  char dupename[1024], datapath[1024], data2[1024], dupefile[1024];
  time_t timeinfo = time (NULL);
  struct dupefile buffer;

  // Check for proper syntax
  if (argc < 2) {
	 printf ("Usage: %s file_to_undupe dupefile\n", argv[0]);
	 return 1;
  }

  // Command line parsing
  strcpy (dupename, argv[1]);
  strcpy (dupefile, argv[2]);

  // This is my kludge to update the file. Just write a new one. Copy it over the old

  printf ("Clearing DUPEFILE of %s \n", argv[1]);
  sprintf (data2, "%s2", dupefile);

  // Opening the data files
  printf ("%s\n", dupefile);
  if ((fp = fopen (dupefile, "r+b")) == NULL) {
	 printf ("Unable to open dupefile\n");
	 return 1;
  }
  if ((fp2 = fopen (data2, "w+b")) == NULL)
    return 1;

  // While the file is still open
  while (!feof (fp)) {
	 if (fread (&buffer, sizeof (struct dupefile), 1, fp) < 1)
	   break;
	 // If we found the file, delete it
	 if (strcmp (buffer.filename, dupename) == 0) {
		fflush (fp);
		printf ("Dupe! Clearing!!\n");
	 }
	 // if not, write it to the new file
	 if (strcmp (buffer.filename, dupename) != 0)
	   if (fwrite (&buffer, sizeof (struct dupefile), 1, fp2) < 1)
		break;
    }

  fclose (fp);
  fclose (fp2);
  // My HUGE kludge that works quite well. 
  // Read in the old data file, write to a new data file. 
  // After everything is done, and sucessful. Move the new one over the old one.
  // Hey, it works.
  if (rename (data2, dupefile) != 0) {
    printf ("Error renaming new dupefile\n");
    return 1;
  }
  printf ("\n");
  return 0;
}
