/* -------------------------------------------------------------------------
 * progressbar - Used by jehsom's zipscript to display a progress meter
 * Copyright (C) 2000 jehsom@jehsom.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * -------------------------------------------------------------------------
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int main( int argc, char *argv[] ){
	int present=0;
	int total=0;
	int missing=0;
	char *bar=NULL;
	int i=0;
	int verbose=0;

	if( argc < 3 ){
		fprintf( stderr, "Usage: %s disks_present total_disks\n"
		                 "  Produces a %%-complete progressbar\n",
						 argv[0] );
		return 1;
	}

	if( argv[3] && strcmp( argv[3], "-v" ) == 0 ) verbose=1;

	present=atoi( argv[1] );
	total=atoi( argv[2] );
	missing=total-present;

	if( total == 0 ){
		printf( "[----Unknown----]%s\n", (verbose?" (??%) : ??/?? files present":"") );
		return 0;
	}
	
	if( (total < present) || (present < 0) || (total < 0) ){
		printf( "[-----Error-----]%s\n", (verbose?" (??%) : ??/?? files present":"") );
		return 0;
	}

	if( (bar=malloc(2*total+1)) == NULL ){
		fprintf( stderr, "Could not malloc.\n" );
		return 1;
	}

	*bar='\0';

	for( i=0; i<present; i++ ){
		bar=strcat( bar, (total>25?"#":"##") );
	}
	for( i=0; i<missing; i++ ){
		bar=strcat( bar, (total>25?"-":"--") );
	}	

	if(verbose)
		printf( "[%s] (%.2f%%) : %d/%d files present\n", bar, 
			(float)100*present/total, present, total );
	else
		printf( "[%s]\n", bar );

	return 0;
}	
