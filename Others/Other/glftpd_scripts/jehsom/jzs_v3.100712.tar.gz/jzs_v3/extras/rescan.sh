#!/bin/bash
# rescan.sh ver 3.0
# Implement as SITE RESCAN in glftpd.conf with the following lines:
#   site_cmd RESCAN EXEC /bin/rescan.sh
#   custom-rescan *
# Copy this script to /glftpd/bin:
#   chmod 755 rescan.sh
#   cp rescan.sh /glftpd/bin
# Re-login and you're set!


bindir=/bin

[ -n "$1" ] && { cd "$1" || exit 1; }

. $bindir/jzipscript.conf || {
	echo "Could not find config file. Exiting."
	exit 1
}

allow_null_glob_expansion="1"
shopt -s nullglob 2>/dev/null

export NFODIR
js -V || exit 1

rm -f [fF][iI][lL][eE]_[iI][dD].[dD][iI][zZ]

js -P
js -0 .

set -- *.[nN][fF][oO] *

while [ -n "$1" ]; do
	[ -f "$1" ] || { shift; continue; }
    case "$1" in 
        *.[nN][fF][oO]) 
            case " $done_nfos " in
                *" $1 "*)
                    shift
                    continue
                    ;;
                *)
                    done_nfos="$done_nfos $1"
                    ;;
            esac    
            ;; 
        *)
            ;;
    esac
	case "$1" in *.[sS][fF][vV])
		keepgoing=0
		for i; do
			case $i in
				*.[sS][fF][vV])
					;;
				*)
					keepgoing=1
					;;
			esac
		done
		[ $keepgoing = "1" ] && {
			set "$@" "$1"
			shift
			continue
		}
		;; 
	esac
	export SPEED="$(js -kIf "$1")"
	js -x "$1"
	echo -e "\nChecking file $1 . . .\n"
	$bindir/jzipscript "$1" "$PWD" "00000000" 2>/dev/null
	[ "$?" -eq 2 ] && {
		echo "Deleting file $1."
		rm -f "$1"
	}
	shift
done	
