#!/bin/bash
# Jehsom's clean script, version 1.1.4
#
# When implemented as a custom site command (such as SITE CLEAN), this
#  script can be executed from the incoming dir, where all the incomplete 
#  warnings are in the .message, and it will remove any stale warnings 
#  that are still around after a rls has been nuked or deleted.
#
# Requires the following programs in /glftpd/bin: bash
#
# $1 can be used to specify that the script should operate in a dif-
# ferent directory than the current working directory. It's optional.
#
# Configuration Options are set in jzipscript.conf. This should be
#  located under <rootpath/bin. If not, change the path below.
#
# Changes:
# 1.1.1 - Changed script to match behavior of zipscript, in that 0-byte
#         .message files are removed.
# 1.1.2 - Checked for existence of .message before doing anything
# 1.1.3 - Fixed problem with change made in 1.1.2 :)
# 1.1.4 - Fixed an *other* problem with 1.1.2...

CONFIG="/bin/jzipscript.conf"

umask 000

[ -n "$1" ] && cd "$1"  # $1 is operating directory. Optional.

source $CONFIG || {
	echo "Could not locate the zipscript config file."
	exit 1
}	

{ [ -w $MSGFILE ] || [ ! -e "$MSGFILE" -a -w "$(dirname "$MSGFILE")" ]; } || {
	echo "Cannot write $MSGFILE. Exiting."
	exit 1
}

for i in *; do
    { [ -L "$i" ] && [ ! -d "$i" ]; } && rm -f -- "$i"
done    

msgs="$(cat $MSGFILE 2>/dev/null)"

echo "$msgs" | while read warning; do
	for dir in *; do
		case $warning in 
			*$dir*)
				echo "$warning"
				;;
			*)
				;;
		esac
	done
done > "$MSGFILE"

[ ! -s "$MSGFILE" ] && rm -f "$MSGFILE"
# Packed Fri Dec 15 16:02:28 EST 2000
