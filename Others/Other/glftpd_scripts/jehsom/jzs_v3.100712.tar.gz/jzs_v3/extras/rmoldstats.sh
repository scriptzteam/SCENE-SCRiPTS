#!/bin/bash

# Put this script in your glftpd bin directory, and execute it
# from root's crontab as follows:
#	30 4 * * *	/usr/sbin/chroot /glftpd /bin/rmoldstats.sh
# Replace /glftpd with your glftpd rootpath, of course.

# List your incoming dirs relative to your rootpath. If you use
#   dated dirs, you should set this to the directory containing
#   all the dated dirs. This list is space-delimited.
INCOMING_DIRS="/site/Incoming /site/Incoming/*_Pre_Dir"

# How many days old should the stats dirs be before I delete them?
DAYSOLD=7

# Where can I find your zipscript config? Relative to rootpath.
# This should be correct for 99% of configurations.
ZSCONFIG="/bin/jzipscript.conf"

##################################
#### DO NOT MODIFY BELOW HERE ####
##################################

. $ZSCONFIG 2>/dev/null || {
	echo "Could not read the specified zipscript config file."
	exit 1
}

cd $NFODIR 2>/dev/null || {
	echo "Could not change to NFODIR specified in $ZSCONFIG."
	exit 1
}

for dir in $INCOMING_DIRS; do (
	cd .$dir 2>/dev/null || {
		echo "No stats dir for incoming dir $dir."
		exit 1
	}
	find . -maxdepth 1 -mtime +$DAYSOLD -exec rm -rf {} \;
); done


# Packed Fri Dec 15 16:02:28 EST 2000
