#!/usr/bin/perl
## newPost
## 
## Togheter with pscript.tcl this script can post
## the 10 newest releases from the site.

$gldir = "/glftpd";

## Sections
## ALL is for all sections
@sections = ('ALL', 'MP3', 'ISO');

##########################[ Thats all, now watch the magic ]##

if ($ARGV[0] or $ARGV[1]) {
	if ($ARGV[0] ne "-nolog") {
		foreach $section (@sections) {
			if ($section eq $ARGV[0]) {
				print "Showing newest dirs for section: $section\n";
				$match = 1;
				&doStats($section);
			}
		}
	}
	foreach $section (@sections) {
        	if ($section eq $ARGV[1]) {
			print "Showing newest dirs for section: $section\n";
                	$match = 1;
			&doStats($section);
                }
        }
	if (!$match) {
		print "$ARGV[1] is a invalid section\n";
		print "Valid sections are:";
		foreach $section (@sections) {print " $section";};
		print "\n";
	}
}

sub doStats {
my($arg) = @_;
print "\n";
open GLOG, "< $gldir/ftp-data/logs/glftpd.log" or die "Cant open your glftpd.log file!\n";
@gllog = <GLOG>;
close GLOG;
$cnt = 0;
foreach $thing (@gllog) {
	if ($thing =~ /NEWDIR:/) {
		@things = split(/ /, $thing);
		$uload = $things[6];
		$uload =~ /(.*)\/(.*)$/;
		$uload = $2;
		$uload =~ s/\"//g;
		$racer = $things[7]."\@".$things[8];
		$racer =~ s/\"//g;
		$dire = $things[6];
		$dire =~ s/\"//g;
		$dire =~ s/\/site\///;
		if ($arg eq "ALL") {
                        $news[$cnt] = "$dire!!!$racer!!!$things[2]$things[1]";
                        $cnt++;
		} elsif ($dire =~ /$arg/) {
			$news[$cnt] = "$dire!!!$racer!!!$things[2]$things[1]";
			$cnt++;
		}
	}
}

reverse(@news);
$counter = 1;
$cnu = $#news;
$date = scalar localtime(time);
$log = "$date NEWDIRS";
while ($counter < 6) {
	($dir, $racer, $update) = split(/!!!/, $news[$cnu]);
	$log .= " \"$dir\" \"$racer\" \"$update\"";
	print "$counter: \002$dir\002 by $racer [$update]\n";
	$counter++;
	$cnu--;
};
print "Valid sections are:";
foreach $section (@sections) {print " $section";};
print "\n";

if ($ARGV[0] ne "-nolog") {
open LOG, ">> $gldir/ftp-data/logs/glftpd.log" or die "Cant open glftpd.log!\n";
print LOG "$log\n";
close LOG;
print "$log\n";
};
};
