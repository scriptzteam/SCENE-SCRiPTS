#!/usr/bin/perl
#
# Version 0.2
# Released under GNU GPL
#
# If you are intending to use the glftpd chrooted function, you MUST
# have youre sorted dir in the same dir as youre mp3 dir. (See example)
#
# // PnG
###############
# Directories #
$glftpddir = "/glftpd/";
$archivedir = "/glftpd/site/MP3-ARCHIVE";
$sorteddir = "/glftpd/site/MP3-Sorted";

############
# Settings ###
#### Set this to false if you dont want me to add mp3s to
#### glftpd dupelog. Ill check if the album is there of course
$addtodupedb = "true";
#### Make links so they will work in glftpds chrooted envoirenment
$forglftd = "true";

## Creating folders
if (!opendir(DIR, "$sorteddir/genres")) {system ("mkdir $sorteddir/genres")};
if (!opendir(DIR, "$sorteddir/year")) {system ("mkdir $sorteddir/year")};
if (!opendir(DIR, "$sorteddir/artist")) {system ("mkdir $sorteddir/artist")};
## Resetting vars
$newcnt = 0;
$dupecnt = 0;
$dupecheck = "0";
## Finding time
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$mon = $mon + 1;
$year =~ s/1//;
if ($mon =~ /^\d$/) {$mon =~ s/^/0/};
if ($mday =~ /^\d$/) {$mday =~ s/^/0/};
$today = "$mon$mday$year";


use File::Find;
use MP3::Info;

$File::Find::dont_use_nlink = 1;

if ($forglftd eq "true") {print "- Linking for glftpd\n"} else {print "- Linking for shell\n"};
if ($addtodupedb eq "true") {print "- Adding dupes to dupelog\n"} else {print "- Not adding to dupelog\n\n"};
print "working...\n";

open LOG, "> mp3sort.log";
find(\&Wanted, $archivedir);
close LOG;

sub Wanted {
	if ($_ =~ /(.*)\.mp3$/) {
	## Searching if this folder has been scanned before
	foreach $thing (@folders) {if ($thing eq $File::Find::dir) {$dupe = 1}};

		if ($dupe != 1) {
			## Finding full path to mp3
			$file = $File::Find::name;
			$oldir = $File::Find::dir;
			## Reading its id3
			my $mp3 = new MP3::Info $file;
			print LOG "scanning: $file";
			
			## Grabbing ID3 info
			$Genre = $mp3->genre;
			$Year = $mp3->year;
			$Artist = $mp3->artist;
			print LOG " :: $Genre :: $Year :: $Artist \n";

			## Making genres
			if ($Genre) {
			$Genre =~ s/\s/_/g;
			$Genre =~ s/&/n/g;
			if (opendir(DIR, "$sorteddir/genres/$Genre")) {} else {print "( genre )Creating $Genre\n"; system("mkdir $sorteddir/genres/$Genre"); print LOG "Created genredir ($Genre)\n"};
			
			$linkdir = $File::Find::dir;
			$linkdir =~ s/CD(\d)//i;
			
			if ($forglftd eq "true") {	
				$linkdir =~ s/\/glftpd\/site/..\/..\/../;
                                $dirr = $oldir."/";
                                $dirr =~ /(.*)\/(.*)\/$/;
                                $dirr = $2;
				$dirr =~ s/CD(\d)$//i;
				$command = "ln -sf $linkdir $sorteddir/genres/$Genre/$dirr";
			} else {
				$command = "ln -sf $linkdir $sorteddir/genres/$Genre";
			};

			$command =~ s/\(/\\(/g;
			$command =~ s/\)/\\)/g;
			$command =~ s/&/\\&/g;
			$command =~ s/'/\\'/g;
			system($command);
			print LOG "made: $command\n";
			};


			## Making Years
			if ($Year and $Year =~ /\d\d\d\d/) {
			if (opendir(DIR, "$sorteddir/year/$Year")) {} else {print "( year )Creating $Year\n"; system("mkdir $sorteddir/year/$Year"); print LOG "Created year dir ($year)\n"};
			$linkdir = $File::Find::dir;
                        $linkdir =~ s/CD(\d)//i;
			
                        if ($forglftd eq "true") {
                                 $linkdir =~ s/\/glftpd\/site/..\/..\/../;
                                 $dirr = $oldir."/";
                                 $dirr =~ /(.*)\/(.*)\/$/;
                                 $dirr = $2;
				 $dirr =~ s/CD(\d)$//i;
                                 $command = "ln -sf $linkdir $sorteddir/year/$Year/$dirr";
                        } else {
                                $command = "ln -sf $linkdir $sorteddir/year/$Year";
                        };
			
                        $command =~ s/\(/\\(/g;
                        $command =~ s/\)/\\)/g;
                        $command =~ s/&/\\&/g;
			$command =~ s/'/\\'/g;
			system($command);
			print LOG "made: $command\n";
			};

			## Making Artist
			if ($Artist) {
			$Artist =~ /^(.)/;
			$letter = $1;
			if (opendir(DIR, "$sorteddir/artist/$letter")) {} else {print "( artist )Creating $letter\n"; system("mkdir $sorteddir/artist/$letter"); print LOG "Created artistdir ($Artist)\n"};
                        
			$linkdir = $File::Find::dir;
                        $linkdir =~ s/CD(\d)//i;

                        if ($forglftd eq "true") {
                                $linkdir =~ s/\/glftpd\/site/..\/..\/../;
                                $dirr = $oldir."/";
                                $dirr =~ /(.*)\/(.*)\/$/;
                                $dirr = $2;
				$dirr =~ s/CD(\d)$//i;
                                $command = "ln -sf $linkdir $sorteddir/artist/$letter/$dirr";
                        } else {
                                $command = "ln -sf $linkdir $sorteddir/artist/$letter";
                        };			

                        $command =~ s/\(/\\(/g;
                        $command =~ s/\)/\\)/g;
                        $command =~ s/&/\\&/g;
			$command =~ s/'/\\'/g;
			system($command);
			print LOG "made $command\n";

			## Adding to dupedb
			if ($addtodupedb eq "true") {
				open DUPELOG, "< $glftpddir/ftp-data/logs/dupelog" or die "Cant open dupelog!\n";
                                 $dirr = $oldir."/";
                                 $dirr =~ /(.*)\/(.*)\/$/;
                                 $dirr = $2;
				 $dupeck = 0;
				while (<DUPELOG>) {
					($date, $rel) = split(/ /);
					$rel =~ s/\n//;
					$rel =~ s/\r//;
					if ($rel eq $dirr) {
						$dupeck = "1";
						$dupecnt++;
					};
				};
				if ($dupeck != 1) {
					open DUPELOG, ">> $glftpddir/ftp-data/logs/dupelog" or die "Cant open dupelog! ($glftpddir/ftp-data/logs/dupelog)\n";
					print DUPELOG "$today $dirr\n";
					close DUPELOG;
					print LOG "Added to dupelog: $today $dirr\n";
					$newcnt++;
				};
				$dupecheck = "0";
				close DUPELOG;
				};
			};			

			$cnt = $#folders + 1;
			$folders[$cnt] = "$oldir";
		};
			$dupe = 0;
	};
};

$cnt = $#folders + 1;
print "\nScanned $cnt folder(s)\n";
print "Found: $dupecnt dupes\n";
print "Added: $newcnt to dupelog\n";
print "Please check mp3sort.log for details\n";
