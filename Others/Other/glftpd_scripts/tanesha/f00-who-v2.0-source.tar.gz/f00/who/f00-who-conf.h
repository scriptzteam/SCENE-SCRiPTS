
#define CONFIGFILE "/ftp-data/misc/f00-who.conf"

// copyright text for binary version  (ps; Doplgnger sux)
#define COPYRIGHT "ell-Tkl.u1-3#+`*#Wbmfpkb#Wfbn"

struct config_t {
	char textfiles[5][300];
	char sitedir[300];
	char gldir[300];

	char hiddendirsfile[300];
	int hiddenstyle;
	int showowngrp;
	char hiddenstring[300];
	struct strlist *hidden;
        struct strlist *hideusers;
   
	long ipckey;
	float speedmultiply;

	char transtext[2][300];
};

int read_config(char *fn, struct config_t *cfg, char *p, int is_chroot);

