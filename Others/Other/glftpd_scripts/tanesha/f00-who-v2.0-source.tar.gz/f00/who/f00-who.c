/*
 *
 * f00-who v2.0.1 (c) tanesha team.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/param.h>
#include <grp.h>
#include <glob.h>
#include "../lib/common.h"
#include "../lib/strlist.h"
#include "../lib/missing.h"
#include "../lib/macro.h"
#include "f00-who-conf.h"

struct ONLINE {
	char tagline[64];
	char username[24];
	char status[256];
	char host[256];
	char currentdir[256];
	long groupid;
	time_t login_time;
	struct timeval tstart;
	unsigned long bytes_xfer;
	pid_t procid;
};

struct ul_dir {
	char path[500];
	struct comp_list *comp;
	int uploaders;

	struct ul_dir *next;
};


struct o_users {
	int hidden;
	int shmpos;
	char filename[500];
	float speed;

	// some variables specific to races.
	struct ul_dir *uploading;

	struct o_users *next;
};

static struct ONLINE *online;
static int dl=0;
static int ul=0;
static double dlspeed=0;
static double ulspeed=0;
static int shmid;
static struct shmid_ds ipcbuf;
int num_idle=0;

static void quit();
static double calc_time();

int o_userscount(struct o_users *l) {
	if (l)
		return 1 + o_userscount(l->next);
	else
		return 0;
}

struct ul_dir *find_uldir(struct ul_dir *l, char *p) {
	struct ul_dir *t;
	char dir[500], *tt;
	
	strcpy(dir, p);
	if (tt = strrchr(dir, '/'))
		*tt = 0;
	
	for (t = l; t; t = t->next)
		if (!strcmp(t->path, dir))
			break;
	
	return t;
}

struct ul_dir *add_uldir(struct ul_dir *l, char *p) {
	struct ul_dir *t = (struct ul_dir*)malloc(sizeof(struct ul_dir));
	struct strlist *m = NULL;
	char dir[500], *tt;
	
	strcpy(dir, p);
	if (tt = strrchr(dir, '/'))
		*tt = 0;
	
	strcpy(t->path, dir);
	m = mis_getsfv(dir);
	
	if (m)
		t->comp = is_complete(dir, NULL, m);
	else
		t->comp = NULL;
	
	t->uploaders = 1;
	t->next = l;
	
	return t;
}

static char *trim(char *str) {
	char *ibuf;
	char *obuf;
	
	if (str) {
		for (ibuf=obuf=str;*ibuf;) {
			while (*ibuf&&(isspace(*ibuf)))
				ibuf++;
			if (*ibuf&&(obuf!=str))
				*(obuf++)=' ';
			while (*ibuf&&(!isspace(*ibuf)))
				*(obuf++)=*(ibuf++);
		}
		*obuf='\0';
	}
	return(str);
}

char *makeage(time_t t) {
	time_t age=time(0);
	char *buf=(char*)malloc(1024);
	time_t days=0,hours=0,mins=0,secs=0;
	
	if (t>=age)
		sprintf(buf,"0");
	else {
		age-=t;
		days=age/(3600*24);
		age-=days*3600*24;
		hours=age/3600;
		age-=hours*3600;
		mins=age/60;
		secs=age-(mins*60);

		if (days)
			sprintf(buf,"%dd %dh",days,hours);
		else if (hours)
			sprintf(buf,"%dh %dm",hours,mins);
		else
			sprintf(buf,"%dm %ds",mins,secs);
	}
	
	
	return buf;
}

int makepercent(char *r,long now,long total) {
	int percent,i;
	
	strcpy(r,"[");
	percent=(10*now)/total;
	
	for (i=0;(i<percent)&&(i<10);i++)
		strcat(r,"#");
	for (i=percent;i<10;i++)
		strcat(r,":");
	
	strcat(r,"]");

	return 1;
}

int makedlstat(char *r,char *fn,long now) {
	struct stat st;
	int downloads;
	
	if (stat(fn,&st)==-1)
		sprintf(r,"[??????????] got: %.1f Mb",
			now/(1024*1024));
	else {
		makepercent(r,now,st.st_size);
		downloads=st.st_gid%100;
		
		sprintf(r,"%s downloads: %d",r,downloads+1);
	}

	return 1;
}

int makeulstat(char *r, struct ul_dir *d, long now) {
	struct stat st;
	struct strlist *m=NULL;
	struct comp_list *comp=NULL;
	long tid,rarsize;

	if (d) {
		rarsize=comp_rarsize(d->comp);
		
		if (rarsize!=0)
			makepercent(r, now, rarsize);
		else
			sprintf(r, "[??????????]");
		
		sprintf(r,"%s race: %d(+%d) of %d",
				r, count_complete(d->comp),
				d->uploaders,
				count_total(d->comp));
	} else
		sprintf(r,"[??????????] put: %.1f Mb",(float)now/(1024*1024));
}

int finddir(char *r,char *dir) {
	char buf[300];
	int i;
	
	if (strlen(dir)>28) {
		strcpy(buf,dir+(strlen(dir)-28));
		for (i=0;i<3;i++)
			buf[i]='.';
	} else
		strcpy(buf, dir);
	
	sprintf(r,"dir: %s",buf);
}

struct o_users *get_online(int slots, int ppid, struct config_t *cfg, int gid) {
	int secret, i, j;
	struct o_users *l = NULL, *tl;
	struct strlist *ttl;
	struct ul_dir *races = NULL, *traces;
	char *tmp;
	float tmpspeed;
	
	for (i = 0; i < slots; i++) {
		if (online[i].procid == 0)
			continue;

		secret = 0;
		ttl = cfg->hidden;
		while (ttl) {
			if ((!strncasecmp(online[i].currentdir,
							  ttl->line, strlen(ttl->line))) &&
			    (online[i].procid!=ppid))
				secret=1;
			
			ttl=ttl->next;
		}
		ttl = str_search(cfg->hideusers, online[i].username);
		if (!secret && ttl)
			secret = 1;
		
		if (secret && cfg->showowngrp && (online[i].groupid == gid))
			secret = 0;

		if (secret && (cfg->hiddenstyle == 2))
			continue;
		
		tl = (struct o_users*)malloc(sizeof(struct o_users));
		tl->hidden = secret;
		tl->shmpos = i;
		tl->uploading = NULL;
		
		if ((!strncasecmp(online[i].status,"STOR", 4) ||
			 !strncasecmp(online[i].status,"APPE",4)) &&
			(online[i].bytes_xfer != 0)) {
			
			strncpy(tl->filename,
					online[i].status + 5,
					sizeof(tl->filename));
			
			j = strlen(tl->filename);
			
			if (!isprint(tl->filename[j - 2]))
				tl->filename[j - 2]='\0';
			else if (!isprint(tl->filename[j - 1]))
				tl->filename[j - 1] = '\0';
			if (tmp=(char*)strrchr(tl->filename,'/'))
				strcpy(tl->filename, tmp + 1);
			
			traces = find_uldir(races, online[i].currentdir);
			if (traces) {
				traces->uploaders++;
				tl->uploading = traces;
			} else {
				races = add_uldir(races,
								  online[i].currentdir);
				tl->uploading = races;
			}
			
			tl->speed = calc_time(i);
			tl->speed *= cfg->speedmultiply;
			ulspeed += tl->speed;
			ul++;
		}
		else if (!strncasecmp(online[i].status,"RETR",4) &&
				 (online[i].bytes_xfer != 0)) {
			
			strncpy(tl->filename,
					online[i].status + 5,
					sizeof(tl->filename));
			
			j = strlen(tl->filename);
			
			if (!isprint(tl->filename[j - 2]))
				tl->filename[j - 2]='\0';
			else if (!isprint(tl->filename[j - 1]))
				tl->filename[j - 1] = '\0';
			if (tmp=(char*)strrchr(tl->filename,'/'))
				strcpy(tl->filename, tmp + 1);
			
			tl->speed = calc_time(i);
			tl->speed *= cfg->speedmultiply;
			dlspeed += tl->speed;
			dl++;
		} else
			num_idle++;
		
		tl->next = l;
		l = tl;
	}
	
	return l;
}

void show_users(int ppid, struct config_t *cfg, struct o_users *o) {
	char statbuf[500],buf[2048];
	char pidbuf[10];
	char *tmp,grpbuf[50],extstat[100];
	struct group *grp;
	struct strlist *tl;
	struct o_users *to;
	char flag;
	struct macro_list *ml, *rep;
	char *body;
	struct ul_dir *up;
	int c = 1;

	body = readfile(cfg->textfiles[1]);

	for (to = o; to; to = to->next) {
		rep = NULL; ml = NULL;
		extstat[0] = 0;
		statbuf[0] = 0;

		/* uploading */
		if (!strncasecmp(online[to->shmpos].status, "STOR", 4) ||
			!strncasecmp(online[to->shmpos].status,"APPE",4)) {
			if (online[to->shmpos].bytes_xfer==0)
				goto do_idle;
			
			if (to->hidden && (cfg->hiddenstyle == 1))
				strcpy(to->filename, cfg->hiddenstring);
			
			ml = NULL;
			ml = ml_addstring(ml, "FILE", to->filename);
			ml = ml_addfloat(ml, "SPEED", to->speed);
			ml = ml_addfloat(ml, "KB", (float)online[to->shmpos].bytes_xfer / 1024);
			
			strcpy(statbuf, ml_replacebuf(ml, cfg->transtext[1]));
			
			ml_free(ml);
			
			makeulstat((char*)&extstat,
					   to->uploading,
					   online[to->shmpos].bytes_xfer);
		}
		/* Downloading */
		else if (!strncasecmp(online[to->shmpos].status,"RETR",4)) {
			// jump at once, not to end up showing RETR filename
			// on hidden dirs.
			if (online[to->shmpos].bytes_xfer==0)
				goto do_idle;
			
			if (to->hidden && (cfg->hiddenstyle == 1))
				strcpy(to->filename, cfg->hiddenstring);
			
			makedlstat((char*)&extstat,
					   online[to->shmpos].currentdir,
					   online[to->shmpos].bytes_xfer);
			
			ml = ml_addstring(NULL, "FILE", to->filename);
			ml = ml_addfloat(ml, "SPEED", to->speed);
			ml = ml_addfloat(ml, "KB", (double)online[to->shmpos].bytes_xfer / 1024);
			
			strcpy(statbuf, ml_replacebuf(ml, cfg->transtext[0]));
			
			ml_free(ml);
			
			/* Idling */
		} else if (time(NULL)-online[to->shmpos].tstart.tv_sec>5) {
		do_idle:
			sprintf(statbuf,"Idling For %s",
					makeage(online[to->shmpos].tstart.tv_sec));
		} else if (!strncasecmp(online[to->shmpos].status,"SITE who",8)) {
			sprintf(statbuf,"Checking who are online");
		} else if (!strncasecmp(online[to->shmpos].status,"PORT",4)) {
			sprintf(statbuf, "Opening DataConn");
		} else if (!strncasecmp(online[to->shmpos].status,"PASV",4)) {
			sprintf(statbuf, "Opening Passive DataConn");
		} else {
			/* Doing something else... */
			sprintf(statbuf,"%s",online[to->shmpos].status);
			trim(statbuf);

			
		}
		
		if (to->hidden && (cfg->hiddenstyle == 1) && (extstat[0] == 0))
			sprintf(extstat, "dir: %s", cfg->hiddenstring);
		else if (extstat[0] == 0)
			finddir((char*)&extstat,
					online[to->shmpos].currentdir +
					strlen(cfg->sitedir));
		
		
		if (online[to->shmpos].procid == ppid)
			rep = ml_addchar(NULL, "FLAG", '*');
		else
			rep = ml_addchar(NULL, "FLAG", ' ');
		
		grp = getgrgid(online[to->shmpos].groupid);
		if (grp)
			strcpy(grpbuf, grp->gr_name);
		else
			sprintf(grpbuf,"(%d)",online[to->shmpos].groupid);
		
		rep = ml_addstring(rep, "GROUP", grpbuf);
		rep = ml_addstring(rep, "USER", online[to->shmpos].username);
		rep = ml_addstring(rep, "TAGLINE", online[to->shmpos].tagline);
		rep = ml_addstring(rep, "ACTION", statbuf);
		rep = ml_addstring(rep, "EXTACTION", extstat);
		rep = ml_addstring(rep, "ONLINE",
						   makeage(online[to->shmpos].login_time));
		rep = ml_addint(rep, "NUM", c++);
		
		if (body)
			printf(ml_replacebuf(rep, body));
		
		ml_free(rep);
	}
}


int main(int argc, char *argv[]) {
	int online_now,online_max,pid_parent,i,showhidden=0;
	struct config_t cfg;
	struct macro_list *hdr;
	char tmpbuf[300];
	char *head, *foot;
	struct o_users *u_on;

	// read the config.
	if (!read_config(CONFIGFILE, &cfg, (argc > 1) ? argv[1] : NULL, 1)) {
		printf("Couldnt read config: %s!\n", CONFIGFILE);
		exit(1);
	}

	if ((shmid=shmget((key_t)cfg.ipckey,0,0))==-1) {
		printf("No one online? (Prolly means siteop has setup wrong ipckey in f00-who.conf)\n");
		exit(1);
	}

	if ((online=(struct ONLINE*)shmat(shmid,NULL,SHM_RDONLY))==(struct ONLINE*)-1) {
		printf("Error: (SHMAT) Failed!\n");
		exit(1);
	}

	shmctl(shmid,IPC_STAT,&ipcbuf);
	online_max=ipcbuf.shm_segsz/sizeof(struct ONLINE);
	pid_parent=getppid();

	head = readfile(cfg.textfiles[0]);
	foot = readfile(cfg.textfiles[2]);

	u_on = get_online(online_max, pid_parent, &cfg, getgid());

	hdr = NULL;
	hdr = ml_addint(hdr, "DLRS", dl);
	hdr = ml_addint(hdr, "ULRS", ul);
	hdr = ml_addint(hdr, "TRANSFERS", dl + ul);
	hdr = ml_addint(hdr, "IDLE", num_idle);
	hdr = ml_addfloat(hdr, "DLSPEED", dlspeed);
	hdr = ml_addfloat(hdr, "ULSPEED", ulspeed);
	hdr = ml_addfloat(hdr, "TOTALSPEED", ulspeed + dlspeed);
	hdr = ml_addint(hdr, "ONLINE", o_userscount(u_on));
	hdr = ml_addint(hdr, "MAXONLINE", online_max);

	if (head)
		printf(ml_replacebuf(hdr, head));

	show_users(pid_parent, &cfg, u_on);

	if (foot)
		printf(ml_replacebuf(hdr, foot));

	ml_free(hdr);

#ifdef BINARYVERSION
	strcpy(tmpbuf, COPYRIGHT);
	head = (char*)&tmpbuf;
	while (*head)
		*(head++) ^= 3;
	printf("%73.73s\n", tmpbuf);
#endif

	quit(0);
}

static double calc_time(int pid) {
	struct timeval tstop;
	double delta,rate;

	if (online[pid].bytes_xfer<1)
		return 0;
	gettimeofday(&tstop,(struct timezone *)0);
	delta=((tstop.tv_sec*10.)+(tstop.tv_usec/100000.))-
		((online[pid].tstart.tv_sec*10.)+(online[pid].tstart.tv_usec/100000.));
	delta=delta/10.;
	rate=((online[pid].bytes_xfer/1024.0)/(delta));
	if (!rate) rate++;
	return (double)(rate);
}

static void quit(int exit_status) {
	shmctl(shmid,IPC_STAT,&ipcbuf);
	if (ipcbuf.shm_nattch<=1) {
		shmctl(shmid,IPC_RMID,0);
	}
	shmdt(0);
	exit(exit_status);
}




