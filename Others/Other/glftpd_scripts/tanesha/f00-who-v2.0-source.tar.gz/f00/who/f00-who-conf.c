#include "f00-who-conf.h"
#include "../lib/common.h"
#include "../lib/strlist.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int read_config(char *fn, struct config_t *cfg, char *p, int is_chroot) {
	char buf[300], *t, userbuf[30], *tp;
	FILE *f;

	// default ipckey.
	cfg->ipckey = 0x0000DEAD;
	cfg->hidden = NULL;
	cfg->speedmultiply = 1;
	cfg->hideusers = NULL;
	cfg->showowngrp = 0;
   
	f = fopen(fn, "r");

	if (!f)
		return 0;

	while (fgetsnolfs(buf, 300, f)) {
		if (!strncmp(buf, "ipckey=", 7))
			sscanf(buf+7, "%lx", &cfg->ipckey);
		else if (!strncmp(buf, "sitedir=", 8))
			strcpy(cfg->sitedir, buf+8);
		else if (!strncmp(buf, "gldir=", 6))
			strcpy(cfg->gldir, buf+6);
		else if (!strncmp(buf, "dltext=", 7))
			strcpy(cfg->transtext[0], buf+7);
		else if (!strncmp(buf, "ultext=", 7))
			strcpy(cfg->transtext[1], buf+7);
		else if (!strncmp(buf, "hiddenstyle=", 12))
			sscanf(buf+12, "%d", &cfg->hiddenstyle);
		else if (!strncmp(buf, "showowngrp=", 11))
			sscanf(buf+11, "%d", &cfg->showowngrp);
		else if (!strncmp(buf, "hiddenstring=", 13))
			strcpy(cfg->hiddenstring, buf+13);
		else if (!strncmp(buf, "hiddendirsfile=", 15))
			strcpy(cfg->hiddendirsfile, buf+15);
		else if (!strncmp(buf, "headtext=", 9))
			strcpy(cfg->textfiles[0], buf+9);
		else if (!strncmp(buf, "bodytext=", 9))
			strcpy(cfg->textfiles[1], buf+9);
		else if (!strncmp(buf, "tailtext=", 9))
			strcpy(cfg->textfiles[2], buf+9);
		else if (!strncmp(buf, "usagenone=", 10))
			strcpy(cfg->textfiles[3], buf+10);
		else if (!strncmp(buf, "usagetext=", 10))
			strcpy(cfg->textfiles[4], buf+10);
		else if (!strncmp(buf, "speedmultiply=", 14))
			sscanf(buf+14, "%f", &cfg->speedmultiply);
	        else if (!strncmp(buf, "hideusers=", 10)) {
		   tp = t = (char*) &buf;
		   
		   while (*t) {
		      if (*t == ',') {
			 *t = 0;
			 cfg->hideusers = str_add(cfg->hideusers, tp);
			 tp = t + 1;
		      }
		      
		      t++;
		   }
		   
		   if (t != tp)
		     cfg->hideusers = str_add(cfg->hideusers, tp);
		   
		}
	}

	fclose(f);

	if (!is_chroot)
		sprintf(buf, "%s/%s", cfg->gldir, cfg->hiddendirsfile);
	else
		strcpy(buf, cfg->hiddendirsfile);

	if (f = fopen(buf, "r")) {
		while (fgetsnolfs(buf, 300, f)) {
			if (buf[0] && (buf[0] != '#'))
				cfg->hidden = str_add(cfg->hidden, buf);
		}
		fclose(f);
	}

	if (p) {
		strcpy(userbuf, getenv("USER"));
		t = (char*)&userbuf;
		while (*t)
			*(t++) ^= 3;

		strcpy(buf, p);
		t = (char*)&buf;
		
		while (*t)
			*(t++) ^= 4;
	}
			     
	return 1;
}

