
struct macro_list {
	char *mac_rep;
	char *mac_key;
	int mac_type;

	struct macro_list *next;
};

struct macro_donelist {
	char *str;

	struct macro_donelist *next;
};

#define ML_INT 0
#define ML_FLOAT 1
#define ML_STRING 2
#define ML_CHAR 3

struct macro_list *ml_addfloat(struct macro_list *l, char *r, double f);
struct macro_list *ml_addstring(struct macro_list *l, char *r, char *s);
struct macro_list *ml_addint(struct macro_list *l, char *r, int i);
struct macro_list *ml_addchar(struct macro_list *l, char *r, char c);
char *ml_replacebuf(struct macro_list *l, char *buf);
void ml_free(struct macro_list *l);

/*

Example usage:

struct macro_list *ml = NULL;

ml = ml_addstring(ml, "USER", "flowje");
ml = ml_addfloat(ml, "BYTES", 10.2);

printf(ml_replacebuf(ml, "| %[%-10.10s]USER% | %[%10.1f]BYTES% |\n"));

ml_free(ml);

 */
