#include "taneshadb.h"
#include "missing.h"
#include <sys/types.h>
#include <sys/stat.h>

void taneshadb_writestart(FILE *f) {
	struct tanesha_db db;

	strcpy(db.username, "TANESHA");
	strcpy(db.filename, "RACESTART");
	db.speed = time(0);

	fwrite(&db, sizeof(db), 1, f);
}


FILE *taneshadb_openw(char *path) {
	FILE *f;
	char buf[300];
	struct stat st;
	int newfile = 0;

	sprintf(buf, "%s/%s", path, SECRETFILE);

	if (stat(buf, &st) == -1)
		newfile = 1;

	f = fopen(buf, "ab");
	if (newfile)
		taneshadb_writestart(f);

	return f;
}

FILE *taneshadb_openr(char *path, long *start) {
	FILE *f;
	char buf[300];
	struct tanesha_db db;

	sprintf(buf, "%s/%s", path, SECRETFILE);
	*start = 0;

	if (f = fopen(buf, "rb")) {
		if (fread(&db, sizeof(db), 1, f))
			*start = db.speed;

		return f;
	} else
		return NULL;
}

void taneshadb_close(FILE *f) {
	if (f)
		fclose(f);
}

void taneshadb_addfile(char *p, char *u, char *f, long sp) {
	FILE *db;
	struct tanesha_db e;

	strcpy(e.username, u);
	strcpy(e.filename, f);
	e.speed = sp;
	e.end = time(0);

	db = taneshadb_openw(p);

	fwrite(&e, sizeof(e), 1, db);

	taneshadb_close(db);
}
