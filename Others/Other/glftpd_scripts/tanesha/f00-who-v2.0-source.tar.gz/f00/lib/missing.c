#include "missing.h"
#include "strlist.h"
#include "common.h"
#include "taneshadb.h"
#include <stdio.h>
#include <stdlib.h>
#include <glob.h>
#include <sys/types.h>
#include <sys/stat.h>

int mis_setracestart(char *dir) {
	char buf[300];
	FILE *mf;

	mf = taneshadb_openw(dir);
	taneshadb_close(mf);

	/*
	sprintf(buf,"%s/%s",dir,SECRETFILE);
	if (mf=fopen(buf,"w")) {
		fchmod(fileno(mf), 0666);
		sprintf(buf, "%s%lu\n", SECRETTAG, time(0));
		fputs(buf,mf);
		fclose(mf);
	} else
		return 0;
	*/

	return 1;
}

long mis_getracestart(char *dir) {
	char buf[300];
	FILE *mf;
	long tid;

	mf = taneshadb_openr(dir, &tid);
	taneshadb_close(mf);

	/*
	sprintf(buf,"%s/%s",dir,SECRETFILE);
	if ((mf=fopen(buf,"r"))!=NULL) {
		while (fgetsnolfs(buf,300,mf))
			if (!strncmp(buf,SECRETTAG,strlen(SECRETTAG))) {
				tid=atol((char*)&buf+strlen(SECRETTAG));
				break;
			}
		fclose(mf);
	}
	*/

	return tid;
}

struct strlist *mis_getcomplete(char *dir, struct strlist *sfv,
				struct mis_complete *c) {
	DIR *dh;
	struct dirent *dent;
	struct strlist *l=NULL;
	char buf[300];
	struct stat st;

	if (!(dh=opendir(dir)))
		return NULL;

	while (dent=readdir(dh)) {
		sprintf(buf,"%s/%s", dir, dent->d_name);

		if (stat(buf,&st) == -1)
			continue;

		// file being uploaded.
		if (!((st.st_mode & UPLOADING) > 0))
			continue;

		if (str_search(sfv, lower(dent->d_name))) {
			l=str_add(l, lower(dent->d_name));

			c->bytes+=st.st_size;
		}

	}
	closedir(dh);

	return l;
}

struct strlist *mis_getsfv(char *dir) {
	FILE *sfv;
	glob_t glbuf;
	char buf[300],*t;
	struct strlist *l=NULL;

	sprintf(buf,"%s/*.sfv",dir);
	glob(buf,0,0,&glbuf);

	if (!glbuf.gl_pathc)
		return NULL;

	if (sfv=fopen(glbuf.gl_pathv[0],"r")) {
		while (fgetsnolfs(buf,300,sfv)) {
			if (buf[0]!=';') {
				t=(char*)&buf;
				while (*t)
					if (*t==' ') {
						*t=0;
						l=str_add(l,(char*)lower(buf));
					} else
						t++;
			}
		}
		fclose(sfv);
	} else
		return NULL;

	return l;
}

int count_complete(struct comp_list *l) {
	if (l && l->complete)
		return 1+count_complete(l->next);
	else if (l)
		return 0+count_complete(l->next);
	else
		return 0;
}

int count_total(struct comp_list *l) {
	if (l)
		return 1+count_total(l->next);
	else
		return 0;
}

int comp_close(struct comp_list *l) {
	struct comp_list *t;

	while (l) {
		t=l;
		l=l->next;
		free(t);
	}

	return 1;
}

float count_size(struct comp_list *l) {
	if (l)
		return l->info.st_size+count_size(l->next);
	else
		return 0;
}

long comp_rarsize(struct comp_list *l) {
	struct comp_list *t=l;
	long biggest=0;

	while (t) {
		if (t->complete && (t->info.st_size > biggest))
			biggest=t->info.st_size;
		t=t->next;
	}

	return biggest;
}

void add_to_race(char *dir, char *fn) {
	long speed;
	char username[20], *strspeed;

	strspeed = getenv("SPEED");
	if (strspeed)
		speed = atol(strspeed);
	else
		speed = 0;

	strcpy(username, getenv("USER"));

	taneshadb_addfile(dir, username, fn, speed);
}

struct comp_list *is_complete(char *dir, char *fn, struct strlist *sfv) {
	struct comp_list *l=NULL,*tmp;
	struct strlist *tsfv=sfv;
	char buf[300], tfn[300];
	struct stat st;

	// add fn to racedb.
	if (fn != NULL)
		add_to_race(dir, fn);

	while (tsfv) {
		strcpy(tfn, (char*)lower(tsfv->line));

		tmp=(struct comp_list*)malloc(sizeof(struct comp_list));
		strcpy(tmp->file, tfn);

		sprintf(buf,"%s/%s", dir, tfn);

		if (stat(buf,&st) == -1) {
			tmp->complete=0;

		// if being uploaded.
		} else if (((st.st_mode & UPLOADING) > 0) &&
			   ((fn==NULL) || strcmp(tfn, fn))) {

			memcpy(&tmp->info, &st, sizeof(struct stat));
			tmp->complete=0;
		} else {
			memcpy(&tmp->info, &st, sizeof(struct stat));
			tmp->complete=1;
		}

		tmp->next=l;
		l=tmp;

		tsfv=tsfv->next;
	}

	return l;
}

