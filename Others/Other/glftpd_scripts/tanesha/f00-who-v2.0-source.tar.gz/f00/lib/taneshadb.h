#include <stdio.h>

struct tanesha_db {
	char username[20];
	char filename[300];
	long speed, end;
};

#define SECRETFILE ".tanesha"

void taneshadb_writestart(FILE *f);
FILE *taneshadb_openw(char *path);
FILE *taneshadb_openr(char *path, long *start);
void taneshadb_close(FILE *f);
void taneshadb_addfile(char *p, char *u, char *f, long sp);

