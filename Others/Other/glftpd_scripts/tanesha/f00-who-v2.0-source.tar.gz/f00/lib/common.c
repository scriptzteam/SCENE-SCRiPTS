#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "common.h"

char *lower(char *s) {
	int i;

	for (i=0;i<strlen(s);i++)
		s[i]=tolower(s[i]);

	return s;
}

char *fgetsnolfs(char *buf, int n, FILE *fh) {
        char *in;
        char *tmp;

        in=fgets(buf,n,fh);
        if (!in) return 0;
        tmp=buf;
        while (*tmp) {
                if ((*tmp==10)||(*tmp==13)) {
                        *tmp=0;
                        break;
                }
                tmp++;
        }
        return in;
}

int fileexists(char *f) {
	struct stat st;

	return (stat(f,&st)!=-1);
}

int replace(char *b, char *n, char *r) {
	char *t, *save;
	int i=0;

	while (t=strstr(b, n)) {
		save=(char*)malloc(strlen(t)-strlen(n)+1);
		strcpy(save, t+strlen(n));
		*t=0;
		strcat(b, r);
		strcat(b, save);
		free(save);
		i++;
	}
}

int ishiddendir(char *p) {
	int hidden=0;
	FILE *hf;
	char tmpfile[300];

	// check if the dir is in the list of hiddendirs.
	if (hf=fopen(HIDDENDIRFILE,"r")) {
		while (fgetsnolfs(tmpfile,300,hf))
			if (tmpfile[0] &&
			    !strncasecmp(tmpfile, p, strlen(tmpfile)))
				hidden=1;
		fclose(hf);
	}

	return hidden;
}

int get_dirs(char *d, char *p, char *r) {
	char *t, *t2;
	char buf[300];

	strcpy(buf, d);
	t=strrchr(buf, '/');
	if (!t) {
		strcpy(r, buf);
		strcpy(p, "??");
		return 0;
	} else
		t++;

	if (!strncasecmp(t, "cd", 2) ||
		 !strncasecmp(t, "disc", 4) ||
		 !strncasecmp(t, "sample", 6) ||
		 !strncasecmp(t, "cover", 5)) {

		*(t-1)=0;
		t2=strrchr(buf, '/')+1;
		*(t-1)='/';
		t=t2;
	}

	*(t-1)=0;
	t2=strrchr(buf, '/')+1;

	strcpy(p, t2);
	strcpy(r, t);

	return 1;
}

char *make_percent(int complete, int total, int size) {
	char *r=(char*)malloc(size+1);
	int percent, i;

	*r=0;
	if (total==0) {
		while (strlen(r) < size)
			strcat(r, ":");
	} else {
		percent=(size*complete)/total;

		for (i=0;(i<percent)&&(i<size);i++)
			strcat(r, "#");
		for (i=percent;i<size;i++)
			strcat(r, ":");
	}

	return r;
}

char *readfile(char *fn) {
	FILE *f;
	char buf[1024], nbuf[10240], *b;
	long s;

	f = fopen(fn, "r");
	if (!f)
		return NULL;

	nbuf[0] = 0;
	while (fgetsnolfs(buf, 1024, f)) {
		strcat(nbuf, buf);
		strcat(nbuf, "\n");
	}
	fclose(f);

	b = (char*)malloc(strlen(nbuf)+1);
	strcpy(b, nbuf);

	return b;
}
