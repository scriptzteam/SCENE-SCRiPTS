#include <time.h>
#include <sys/types.h>
#include <dirent.h>
#include <glob.h>
#include <sys/stat.h>

// name of the secretfile we use.
#define SECRETFILE ".tanesha"

// tag in the secretfile to identify where to get the race-start date.
// #define SECRETTAG "; f00 tools-v1 C tanesha, racestart="

// which perms files being uploaded currently has.
#define UPLOADING S_IXUSR

struct mis_complete {
	long bytes;
};

struct comp_list {
	char file[300];
	struct stat info;
	int complete;

	struct comp_list *next;
};

int mis_setracestart(char *dir);
long mis_getracestart(char *dir);
struct strlist *mis_getcomplete(char *dir, struct strlist *sfv,
				struct mis_complete *c);
struct strlist *mis_getsfv(char *dir);
int count_complete(struct comp_list *l);
int count_total(struct comp_list *l);
int comp_close(struct comp_list *l);
float count_size(struct comp_list *l);
struct comp_list *is_complete(char *dir, char *fn, struct strlist *sfv);
long comp_rarsize(struct comp_list *l);









