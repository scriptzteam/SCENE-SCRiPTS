
struct strlist {
	char line[300];
	struct strlist *next;
};

long str_count(struct strlist *l);
struct strlist *str_search(struct strlist *l, char *s);
struct strlist *str_add(struct strlist *l, char *s);
void str_close(struct strlist *l);

