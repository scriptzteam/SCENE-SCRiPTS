#include "strlist.h"
#include <stdlib.h>

long str_count(struct strlist *l) {
	if (l)
		return 1+str_count(l->next);
	else
		return 0;
}

struct strlist *str_search(struct strlist *l, char *s) {
	struct strlist *t=l;

	while (t) {
		if (!strcmp(s, t->line))
			break;

		t=t->next;
	}

	return t;
}

struct strlist *str_add(struct strlist *l, char *s) {
	struct strlist *t=(struct strlist *)malloc(sizeof(struct strlist));

	strcpy(t->line,s);
	t->next=l;

	return t;
}

void str_close(struct strlist *l) {
	struct strlist *t;

	while (l) {
		t=l;
		l=l->next;
		free(t);
	}
}
