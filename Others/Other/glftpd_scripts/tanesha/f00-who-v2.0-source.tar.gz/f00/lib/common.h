#include <stdio.h>

#define HIDDENDIRFILE "/ftp-data/misc/f00-hiddendirs.txt"

int get_dirs(char *d, char *p, char *r);
int ishiddendir(char *p);
char *lower(char *s);
char *fgetsnolfs(char *buf, int n, FILE *fh);
int fileexists(char *f);
int replace(char *b, char *n, char *r);
char *make_percent(int complete, int total, int size);
char *readfile(char *fn);

