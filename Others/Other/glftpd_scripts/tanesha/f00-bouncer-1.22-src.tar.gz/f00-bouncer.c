/*
 *  Some attempt at rewriting the java bouncer in c, monday night when i came
 *  home from pleasent evening wif Malene - i blame Trax for no sex ;]
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <time.h>

#define VERSION "1.22"

// uncomment this if you dont want the welcome msg from bouncer.
#define WELCOMEMSG "220-## foo.Bnc v%s (c) tanesha team ##\r\n"
#define MSG "220-## %-30.30s ##\r\n"

struct cycleip {
     struct sockaddr_in sockname;
     long is_available;

     struct cycleip *next;
};

struct threadlist {
     int clientsocket;
     int serversocket;

     struct sockaddr_in clientname;
     struct sockaddr_in servername;

     fd_set fd_active_read, fd_read, fd_active_send, fd_send;
     char clientbuf[2048], serverbuf[2048];
};

int servsock;
int servport = 2021;
struct threadlist *this;
char errbuf[300];

void connect_timeout(int d) {
     char buf[300];

     sprintf(buf, MSG, errbuf);
     bnc_send(this->clientsocket, buf, strlen(buf));
     close(this->clientsocket);

     exit(0);
}


int init_sockaddr(struct sockaddr_in *name,
				  const char *hostname,
				  unsigned short int port) {

     struct hostent *hostinfo;

     name->sin_family = AF_INET;
     name->sin_port = htons(port);
	 
     if (inet_aton(hostname, &name->sin_addr) != 0) {
		  // do noopje ;D
		  
     } else {
		  hostinfo = gethostbyname(hostname);
		  
		  if (hostinfo == NULL) return 0;
		  
		  name->sin_addr = *(struct in_addr*)hostinfo->h_addr;
     }
	 
     return 1;
}

int make_socket(unsigned short int port, char *ip) {
     int sock;
     struct sockaddr_in name;
	 
     // create socket.
     sock = socket (PF_INET, SOCK_STREAM, 0);
     if (sock < 0) {
		  printf("* error creating listen socket !\n");
		  exit(1);
     }

	 if (*ip != 0)
		  init_sockaddr(&name, ip, port);
	 else {
		  name.sin_family = AF_INET;
		  name.sin_port = htons (port);
		  name.sin_addr.s_addr = htonl (INADDR_ANY);
	 }

	 // bind socket.
     if (bind (sock, (struct sockaddr *) &name, sizeof (name)) < 0) {
		  printf("* error binding listen socket !\n");
		  exit(1);
     }
	 
     return sock;
}

struct cycleip *read_config(char *cfgfile, int *localport,
							int *localqueue, char *pidfile,
							struct sockaddr_in *fakeserv,
							int *timeout, char *bindip) {
     struct cycleip *t = NULL, *tt;
     FILE *f;
     char buf[300], ta[300];
     int tp;
	 
     f = fopen(cfgfile, "r");
	 
     if (!f)
		  return NULL;
	 
     while (fgets(buf, 300, f)) {
		  // add an remote ip to list.
		  if (!strncasecmp(buf, "remote=", 7)) {
			   sscanf(buf, "remote=%d,%s", &tp, ta);
			   tt = (struct cycleip*)malloc(sizeof(struct cycleip));
			   if (init_sockaddr(&tt->sockname, ta, tp)) {
					tt->next = t;
					t = tt;
			   }
			   
			   // set the local port 
		  } else if (!strncasecmp(buf, "localport=", 10))
			   *localport = atoi(buf+10);
		  else if (!strncasecmp(buf, "localqueue=", 11))
			   *localqueue = atoi(buf+11);
		  else if (!strncasecmp(buf, "timeout=", 8))
			   sscanf(buf, "timeout=%d", timeout);
		  else if (!strncasecmp(buf, "pidfile=", 8))
			   sscanf(buf, "pidfile=%s", pidfile);
		  else if (!strncasecmp(buf, "fakeserver=", 11)) {
			   sscanf(buf, "fakeserver=%d,%s", &tp, ta);
			   init_sockaddr(fakeserv, ta, tp);
		  }
		  else if (!strncasecmp(buf, "localip=", 8))
			   strcpy(bindip, buf + 8);
     }
	 
     fclose(f);
	 
     // make the ip list cyclic.
     tt = t;
     while (tt && tt->next)
		  tt = tt->next;
     tt->next = t;
	 
     return t;
}

void show_config(struct cycleip *l, int port) {
     struct cycleip *t = l->next;
	 
     printf("\n* foo.Bnc-v%s (c) tanesha team, configuration:\n\n\t+ local port -> %d\n", VERSION, port);
	 
     while (t && (t != l)) {
		  printf("\t+ remote host -> %s:%d\n",
				 inet_ntoa(t->sockname.sin_addr),
				 ntohs(t->sockname.sin_port));
		  
		  t = t->next;
     }
	 
     if (t) {
		  printf("\t+ remote host -> %s:%d\n",
				 inet_ntoa(t->sockname.sin_addr),
				 ntohs(t->sockname.sin_port));
     }
}

char *find_ident(struct sockaddr_in *client) {
     char *buf = (char*)malloc(500);
     char ident[300], *tmp, *ttmp, buff[500], bufn[500];
     int identsock, nbytes, sel;
     struct sockaddr_in identname;
     FILE *identfd;
     struct hostent *hostname;
	 
     strcpy(bufn, inet_ntoa(client->sin_addr));
     sprintf(buff, "ip-%s", bufn);
	 
     hostname = gethostbyaddr((char*)&client->sin_addr, sizeof(struct in_addr), AF_INET);
	 
     if (hostname != 0)
          sprintf(buff, hostname->h_name);
	 

	if (strchr(buff, '@') != NULL)
		sprintf(buff, "hacker-%s", bufn);

	if (strchr(buff, '*') != NULL)
		sprintf(buff, "hacker-%s", bufn);

     sprintf(buf, "*@%s:%s", bufn, buff);
	 
     identsock = socket (PF_INET, SOCK_STREAM, 0);
     if (identsock < 0)
          return buf;
	 
     identfd = fdopen(identsock, "r+");
     if (identfd == 0)
          return buf;
	 
     init_sockaddr(&identname,
                   (char*)inet_ntoa(client->sin_addr),
                   113);
	 
     if (connect(fileno(identfd), (struct sockaddr *) &identname,
                 sizeof(identname)) < 0)
          return buf;
	 
     fprintf(identfd, "%u, %u\r\n",
             ntohs(client->sin_port),
             servport);
     fflush(identfd);
	 
     if (fgets(ident, 300, identfd) == 0)
          return buf;
	 
     fclose(identfd);
	 
     if (strstr(ident, "ERROR"))
          return buf;
	 
     tmp = strrchr(ident, ':');
	 
     if (!tmp)
          return buf;
	 
     tmp++;
	 
     while (*tmp == ' ')
          tmp++;
	 
     ttmp = tmp;
	 
     while (*tmp) {
          if ((*tmp == ' ') || (*tmp == '\n') || (*tmp == '\r'))
               *tmp = 0;
          else
               tmp++;
     }

	if (strchr(ttmp, '@') != NULL)
		sprintf("hacked-ident@%s:%s", bufn, buff);
	else if (strchr(ttmp, '*') != NULL)
		sprintf("hacked-ident@%s:%s", bufn, buff);
	else
     		sprintf(buf, "%s@%s:%s", ttmp, bufn, buff);
	 
     return buf;
}

char *nolfs(char *b) {
     char *t;
	 
     t = b;
	 
     while (*t) {
		  if ((*t==10)||(*t==13)) {
			   *t=0;
			   break;
		  }
     }
	 
     return b;
}

int bnc_send(int fd, char *str, int len) {
     int nleft, nwritten;
	 
     nleft = len;
	 
     while (nleft > 0) {
		  nwritten = write(fd, str, nleft);
		  if (nwritten <= 0)
			   return nwritten;
		  
		  nleft -= nwritten;
		  str += nwritten;
     }
	 
     return (len-nleft);
}

int bnc_read(int fd, char *str, int len) {
     int nbytes;
	 
     nbytes = read(fd, str, len);
	 
     return nbytes;
}

void bnc_close(struct threadlist *self) {
     close(self->clientsocket);
     close(self->serversocket);
}

void *bouncer(struct threadlist *self, struct sockaddr_in *fakename, int timeout) {
     char *ident;
     char idntbuf[1024], *chead, *ctail, *shead, *stail;
     int i, cpos = 0, spos = 0, sel, num, datasend, isfake = 0;
	 
     strcpy(errbuf, "Timeout finding ident");
     this = self;
     signal(SIGALRM, (void*)connect_timeout);
     alarm(timeout);
	 
#ifdef WELCOMEMSG
	sprintf(idntbuf, WELCOMEMSG, VERSION);
     bnc_send(self->clientsocket, idntbuf, strlen(idntbuf));
#endif
	 
     ident = find_ident(&self->clientname);
	 
 RESTART:
	 
     strcpy(errbuf, "Timeout connecting to remote");
	 
     datasend = 0;
     self->serversocket = socket (PF_INET, SOCK_STREAM, 0);
     if (self->serversocket < 0) {
		  bnc_close(self);
		  return;
     }
	 
     if (connect(self->serversocket, (struct sockaddr *) &self->servername,
				 sizeof(self->servername)) < 0) {
		  sprintf(idntbuf, MSG, "Error connecting to remote");
		  bnc_send(self->clientsocket, idntbuf, strlen(idntbuf));
		  
		  bnc_close(self);
		  return;
     }
	 
     signal(SIGALRM, SIG_IGN);
	 
     if (!isfake) {
		  sprintf(idntbuf, "IDNT %s\n", ident);
		  bnc_send(self->serversocket,
				   idntbuf,
				   strlen(idntbuf));
     }
	 
     // register the filedescriptors.
     FD_ZERO(&self->fd_active_read);
     FD_SET(self->clientsocket, &self->fd_active_read);
     FD_SET(self->serversocket, &self->fd_active_read);
	 
     self->clientbuf[0] = 0;
     self->serverbuf[0] = 0;
	 
     while (1) {
		  self->fd_read = self->fd_active_read;
		  
		  sel = select(FD_SETSIZE, &self->fd_read, NULL,
					   NULL, NULL);
		  
		  if (sel <= 0)
			   continue;
		  
		  if (FD_ISSET(self->serversocket, &self->fd_read)) {
			   
			   if ((cpos = bnc_read(self->serversocket, self->serverbuf, 2048)) <= 0) {
					if (!datasend) {
						 close(self->serversocket);
						 
						 memcpy(&self->servername, fakename,
								sizeof(struct sockaddr_in));
						 isfake = 1;
						 
						 goto RESTART;
					} else {
						 bnc_close(self);
						 return;
					}
			   }
			   
			   if (bnc_send(self->clientsocket, self->serverbuf, cpos) <= 0) {
					bnc_close(self);
					return;
			   }

			   datasend = 1;
			   
		  } else if (FD_ISSET(self->clientsocket, &self->fd_read)) {
			   
			   if ((spos = bnc_read(self->clientsocket, self->clientbuf, 2048)) <= 0) {
					bnc_close(self);
					return;
			   }
			   
			   if (bnc_send(self->serversocket, self->clientbuf, spos) <= 0) {
					bnc_close(self);
					return;
			   }
			   
		  }
		  
     }
}


int main(int argc, char *argv[]) {
     struct cycleip *remotes;
     struct threadlist tt;
     struct sockaddr_in clientname, fakename;
     char buf[300];
	 char bindip[30];
     int localqueue = 3;
     int consock, s_size, pid, timeout = 30;
     FILE *pidfile;
	 struct sigaction sa;
     //pthread_mut_t *l_mut = (pthread_mut_t*)malloc(sizeof(pthread_mut_t));
	 
     if (argc < 2) {
		  printf("syntax; f00-bouncer <configfile>\n");
		  exit(1);
     }

	 bindip[0] = 0;
	 
     remotes = read_config(argv[1], &servport, &localqueue, buf, &fakename,
						   &timeout, bindip);
	 
     show_config(remotes, servport);

     servsock = make_socket(servport, bindip);
	 
     if (listen(servsock, localqueue) < 0) {
		  printf("* error listening to socket !\n");
		  exit(1);
     }
	 
     pid = fork();
     if (pid < 0) {
		  printf("* error forking into background !\n");
		  exit(1);
     } else if (pid > 0) {
		  pidfile = fopen(buf, "w");
		  fprintf(pidfile, "%d\n", pid);
		  fclose(pidfile);
		  
		  printf("\n* forked into background -->> pid %d\n\n", pid);
		  
		  exit(0);
     }


	 sa.sa_handler = SIG_IGN;
#ifdef SA_NOCLDWAIT
	 sa.sa_flags = SA_NOCLDWAIT;
#else
	 sa.sa_flags = 0;
#endif
	 sigemptyset(&sa.sa_mask);
	 sigaction(SIGCHLD, &sa, NULL);
	 
     s_size = sizeof(clientname);
     while (consock = accept(servsock,
							 (struct sockaddr*)&clientname, &s_size)) {
		  // set client adresses.
		  tt.clientsocket = consock;
		  memcpy(&tt.clientname, &clientname, sizeof(clientname));
		  
		  // give server-adress, and cycle onto next.
		  memcpy(&tt.servername, &remotes->sockname, sizeof(remotes->sockname));
		  remotes = remotes->next;
		  
		  // start the thread.
		  pid = fork();
		  if (pid < 0) {
			   sprintf(buf, MSG, "Error forking");
			   bnc_send(consock, buf, strlen(buf));
			   
		  } else if (pid == 0) {
			   bouncer(&tt, &fakename, timeout);
			   
			   exit(0);
		  }
		  
		  close(consock);
     }
	 
     close(servsock);
	 
     return 0;
}

