/*
 * Tanesha Team! $Id: nukes.h,v 1.3 2002/03/07 12:17:29 flower Exp $
 */
#ifndef _nukes_h
#define _nukes_h

#define NUKES_NUKELOG "/ftp-data/logs/nukelog"

#define NUKES_SITEROOT "/fk"

#define DELIM " -----------|-------------------------------------------|---------------\n"

#define HEAD "                           ________ 
                           \\       \\       _______________
    _____         _____ ____\\___    \\_____/__   _        /___
  _/     \\ ______/____  \\       \\  _       _/_  /       /  __)_________
 (_______\\\\          _)__________)__\\_________)_ ______/________       )
 ---------\\_________/--------------------------(__/-----,-----(_______/
  nuker.time| dir.nukees                                | reason
 ===========|===========================================|===============
"

#define TAIL "    foo nukes v2.o (c) tanesha / 'site nukes help' for help.\n"

#endif
