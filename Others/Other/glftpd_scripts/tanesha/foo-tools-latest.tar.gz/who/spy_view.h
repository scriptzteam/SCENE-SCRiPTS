

#ifndef _spy_view_h
#define _spy_view_h


#define USERINFO_SIZE 3
#define STATUS_SIZE 4

#define REFRESH_USEC 1000*500

/*
 * Initialize the spy view.
 */
void spy_view_init(int max);


#endif
