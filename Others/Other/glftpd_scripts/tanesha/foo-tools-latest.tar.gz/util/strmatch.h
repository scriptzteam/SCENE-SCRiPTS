
#ifndef _strmatch_h
#define _strmatch_h

/*
 * Returns 1 if string matches pattern.
 */
int strmatch_filename(char *pattern, char *string);


#endif

