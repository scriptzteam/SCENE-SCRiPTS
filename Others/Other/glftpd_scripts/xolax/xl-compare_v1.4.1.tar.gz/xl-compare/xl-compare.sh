#!/bin/bash
#
# xl-compare v1.4.1
#
#(C) 2004 xoLax, xolax@glftpd.at


#glftpd 2.00 or newer? (if 1.32 or older set this to FALSE, else TRUE)
GLV2="TRUE"

#Path to glftpd.conf
glconf="/etc/glftpd.conf"

#Where are your userfiles located?
userdir="/jail/glftpd/ftp-data/users/"

#Where is your passwd file located?
passwdfile="/jail/glftpd/etc/passwd"

# Where is the glftpd stats binary located?
statsbin="/jail/glftpd/bin/stats"

# Where is glftpd.log located?
gllog="/jail/glftpd/ftp-data/logs/glftpd.log"

#Compare race starts? (Not working for site rings..yet :P)
comprace="YES"

#This is what's going to start all output lines
look="[COMPARE]"

#Sitename
sitename="my1337site"

## END OF CONFIG ##

if [ "$1" == "" ]; then
  echo "$look Usage: !compare <user1> <user2>"
  exit
fi
if [ "$2" == "" ]; then
  echo "$look It takes two to tango..."
  exit
fi
if [ "$1" == "$2" ]; then
  echo "It's a draw Einstein..."
  exit
fi

export exist1=`ls -1 $userdir | grep -w $1`
export exist2=`ls -1 $userdir | grep -w $2`
if [ "$exist1" == "" -o "$exist2" == "" ]; then
  echo "$3 You aint got no class, im case sensitive! ;)"
  exit 0
fi

if [ "$GLV2" == "TRUE" ]; then
  AUPOS="12:"
  ADPOS="13:"
  WUPOS="14:"
  MUPOS="18:"
elif [ "$GLV2" == "FALSE" ]; then
  AUPOS="10:"
  ADPOS="11:"
  WUPOS="12:"
  MUPOS="16:"
else
  echo "You have to specify your glftpd version!"
  exit 0
fi


# Get info about the first user

time1="0"
export added1=`grep -w $1 $passwdfile | sed s/":"/" "/g | awk '{print $5}' | sed s/"-"/" "/g`
export u1d1=`echo "$added1" | cut -d ' ' -f1`
export u1d2=`echo "$added1" | cut -d ' ' -f2`
export u1d3=`echo "$added1" | cut -d ' ' -f3`
export days1=`date --date=""$u1d3-$u1d1-$u1d2 +"%j" | bc`
while [ "`echo "$u1d3" | bc`" -lt "`date +%y | bc`" ]; do
  export time1=`echo "365-$days1" | bc`
  days1="0"
  export u1d3=`echo "$u1d3+1" | bc`
done
if [ "`echo "$added1" | cut -d ' ' -f3 | bc`" == "`date +%y | bc`" ]; then
  export time1=`date +%j"-"$days1 | bc`
else
  export time1=`date +%j"+"$time1 | bc`
fi
if [ "$time1" == "0" ]; then
  time1="1"
fi
export alup1=`grep -n "" $userdir$1 | grep $AUPOS | cut -d ' ' -f3`
alup1="$( expr "$alup1" \/ "1024" )"
export aldn1=`grep -n "" $userdir$1 | grep $ADPOS | cut -d ' ' -f3`
aldn1="$( expr "$aldn1" \/ "1024" )"
export mnup1=`grep -n "" $userdir$1 | grep $MUPOS | cut -d ' ' -f3`
mnup1="$( expr "$mnup1" \/ "1024" )"
export wkup1=`grep -n "" $userdir$1 | grep $WUPOS | cut -d ' ' -f3`
wkup1="$( expr "$wkup1" \/ "1024" )"
export nukes1=`grep -w NUKE $userdir$1 | cut -d ' ' -f3`
if [ "$aldn1" != "0" ]; then
  export uldl1=`echo "scale=2;$alup1/$aldn1" | bc`
  export uldl1c=`echo "$uldl1*100/1" | bc`
  if [ "$uldl1c" -lt "100" ]; then
    uldl1=0$uldl1
  fi
  if [ "$uldl1" == "00" ]; then
    uldl1="0.00"
  fi
else
  uldl1="infinite"
  uldl1c="100000000"
fi
export avgmb1=`echo "scale=2;$alup1/$time1" | bc`
export avgmb1c=`echo "$avgmb1*100/1" | bc`
if [ "$avgmb1c" -lt "100" ]; then
  avgmb1=0$avgmb1
fi
if [ "$avgmb1" == "00" ]; then
  avgmb1="0.00"
fi
mnupdata1="$( $statsbin -r $glconf -u -m -x 500 | grep "\[..\]\ $1\ " )"
mnuppos1="$( echo "$mnupdata1" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$mnuppos1" | grep ".."`" ]; then
  mnuppos1=0$mnuppos1
fi
if [ "$mnuppos1" == "0" ]; then
  mnupdata1="$( $statsbin -r $glconf -u -m -x 500 | grep "\[...\]\ $1\ " )"
  mnuppos1="$( echo "$mnupdata1" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$mnuppos1" == "" ]; then
    mnuppos1="N/A"
  fi
fi
wkupdata1="$( $statsbin -r $glconf -u -w -x 500 | grep "\[..\]\ $1\ " )"
wkuppos1="$( echo "$wkupdata1" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$wkuppos1" | grep ".."`" ]; then
  wkuppos1=0$wkuppos1
fi
if [ "$wkuppos1" == "0" ]; then
  wkupdata1="$( $statsbin -r $glconf -u -w -x 500 | grep "\[...\]\ $1\ " )"
  wkuppos1="$( echo "$wkupdata1" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$wkuppos1" == "" ]; then
    wkuppos1="N/A"
  fi
fi

if [ "$comprace" == "YES" ]; then
  export numrel1=`grep "\"$1\"" $gllog | grep NEWDIR: | grep -iv \/[Ss][Aa][Mm][Pp][Ll][Ee] | grep -iv \/[Tt][Ee][Ss][Tt] | grep -iv [Cc][Dd][1-9] | grep -iv \/[Ee][Xx][Tt][Rr][Aa][Ss] | grep -iv \/[Rr][Ee][Qq][Uu][Ee][Ss][Tt] | grep -iv \/[Cc][Oo][Vv][Ee][Rr] | grep -iv [Dd][Ii][Ss][Cc][1-9] | grep -iv \/[Mm][Pp]3 | grep -iv \/0[Dd][Aa][Yy] | grep -iv [Ss][Uu][Bb][Ss] | grep "\/site\/" | grep -n "" | tail -n 1 | sed s/":"/" : "/ | cut -d ' ' -f1`
  if [ "$numrel1" == "" ]; then
    numrel1="0"
  fi
fi


# Get info about the second user

time2="0"
export added2=`grep -w $2 $passwdfile | sed s/":"/" "/g | awk '{print $5}' | sed s/"-"/" "/g`
export u2d1=`echo "$added2" | cut -d ' ' -f1`
export u2d2=`echo "$added2" | cut -d ' ' -f2`
export u2d3=`echo "$added2" | cut -d ' ' -f3`
export days2=`date --date=""$u2d3-$u2d1-$u2d2 +"%j" | bc`
while [ "`echo "$u2d3" | bc`" -lt "`date +%y | bc`" ]; do
  export time2=`echo "365-$days2" | bc`
  days2="0"
  export u2d3=`echo "$u2d3+1" | bc`
done
if [ "`echo "$added2" | cut -d ' ' -f3 | bc`" == "`date +%y | bc`" ]; then
  export time2=`date +%j"-"$days2 | bc`
else
  export time2=`date +%j"+"$time2 | bc`
fi
if [ "$time2" == "0" ]; then
  time2="1"
fi
export alup2=`grep -n "" $userdir$2 | grep $AUPOS | cut -d ' ' -f3`
alup2="$( expr "$alup2" \/ "1024" )"
export aldn2=`grep -n "" $userdir$2 | grep $ADPOS | cut -d ' ' -f3`
aldn2="$( expr "$aldn2" \/ "1024" )"
export mnup2=`grep -n "" $userdir$2 | grep $MUPOS | cut -d ' ' -f3`
mnup2="$( expr "$mnup2" \/ "1024" )"
export wkup2=`grep -n "" $userdir$2 | grep $WUPOS | cut -d ' ' -f3`
wkup2="$( expr "$wkup2" \/ "1024" )"
export nukes2=`grep -w NUKE $userdir$2 | cut -d ' ' -f3`
if [ "$aldn2" != "0" ]; then
  export uldl2=`echo "scale=2;$alup2/$aldn2" | bc`
  export uldl2c=`echo "$uldl2*100/1" | bc`
  if [ "$uldl2c" -lt "100" ]; then
    uldl2=0$uldl2
  fi
  if [ "$uldl2" == "00" ]; then
    uldl2="0.00"
  fi
else
  uldl2="infinite"
  uldl2c="100000000"
fi
export avgmb2=`echo "scale=2;$alup2/$time2" | bc`
export avgmb2c=`echo "$avgmb2*100/1" | bc`
if [ "$avgmb2c" -lt "100" ]; then
  avgmb2=0$avgmb2
fi
if [ "$avgmb2" == "00" ]; then
  avgmb2="0.00"
fi
mnupdata2="$( $statsbin -r $glconf -u -m -x 500 | grep "\[..\]\ $2\ " )"
mnuppos2="$( echo "$mnupdata2" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$mnuppos2" | grep ".."`" ]; then
  mnuppos2=0$mnuppos2
fi
if [ "$mnuppos2" == "0" ]; then
  mnupdata2="$( $statsbin -r $glconf -u -m -x 500 | grep "\[...\]\ $2\ " )"
  mnuppos2="$( echo "$mnupdata2" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$mnuppos2" == "" ]; then
    mnuppos2="N/A"
  fi
fi
wkupdata2="$( $statsbin -r $glconf -u -w -x 500 | grep "\[..\]\ $2\ " )"
wkuppos2="$( echo "$wkupdata2" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
if [ -z "`echo "$wkuppos2" | grep ".."`" ]; then
  wkuppos2=0$wkuppos2
fi
if [ "$wkuppos2" == "0" ]; then
  wkupdata2="$( $statsbin -r $glconf -u -w -x 500 | grep "\[...\]\ $2\ " )"
  wkuppos2="$( echo "$wkupdata2" | cut -d ' ' -f1 | tr -d '[' | tr -d ']' )"
  if [ "$wkuppos2" == "" ]; then
    wkuppos2="N/A"
  fi
fi

if [ "$comprace" == "YES" ]; then
  export numrel2=`grep "\"$2\"" $gllog | grep NEWDIR: | grep -iv \/[Ss][Aa][Mm][Pp][Ll][Ee] | grep -iv \/[Tt][Ee][Ss][Tt] | grep -iv [Cc][Dd][1-9] | grep -iv \/[Ee][Xx][Tt][Rr][Aa][Ss] | grep -iv \/[Rr][Ee][Qq][Uu][Ee][Ss][Tt] | grep -iv \/[Cc][Oo][Vv][Ee][Rr] | grep -iv [Dd][Ii][Ss][Cc][1-9] | grep -iv \/[Mm][Pp]3 | grep -iv \/0[Dd][Aa][Yy] | grep -iv [Ss][Uu][Bb][Ss] | grep "\/site\/" | grep -n "" | tail -n 1 | sed s/":"/" : "/ | cut -d ' ' -f1`
  if [ "$numrel2" == "" ]; then
    numrel2="0"
  fi
fi


export group1=`grep GROUP $userdir$1 | head -n1 | cut -d ' ' -f2`
export group2=`grep GROUP $userdir$2 | head -n1 | cut -d ' ' -f2`

# Start the competition

echo "$look $sitename presents: $1/$group1 vs $2/$group2"

player1="0"
player2="0"

# Round 1 - UL/DL Ratio

if [ "$uldl1c" -gt "$uldl2c" ]; then
  wr1="$1"
  player1="$( expr "$player1" + "1" )"
fi
if [ "$uldl2c" -gt "$uldl1c" ]; then
  wr1="$2"
  player2="$( expr "$player2" + "1" )"
fi
if [ "$uldl1c" == "$uldl2c" ]; then
  wr1="None"
fi

# Round 2 - MB Upload/Day
if [ "$avgmb1c" -gt "$avgmb2c" ]; then
  wr2="$1"
  player1="$( expr "$player1" + "2" )"
fi
if [ "$avgmb2c" -gt "$avgmb1c" ]; then
  wr2="$2"
  player2="$( expr "$player2" + "2" )"
fi
if [ "$avgmb1c" == "$avgmb2c" ]; then
  wr2="None"
fi

# Round 3 - MnUp

if [ "$mnup1" -gt "$mnup2" ]; then
  wr3="$1"
  player1="$( expr "$player1" + "2" )"
fi
if [ "$mnup2" -gt "$mnup1" ]; then
  wr3="$2"
  player2="$( expr "$player2" + "2" )"
fi
if [ "$mnup1" == "$mnup2" ]; then
  wr3="None"
fi

# Round 4 - WkUp

if [ "$wkup1" -gt "$wkup2" ]; then
  wr4="$1"
  player1="$( expr "$player1" + "2" )"
fi
if [ "$wkup2" -gt "$wkup1" ]; then
  wr4="$2"
  player2="$( expr "$player2" + "2" )"
fi
if [ "$wkup1" == "$wkup2" ]; then
  wr4="None"
fi

# Round 5 - Nukes

if [ "$nukes1" -lt "$nukes2" ]; then
  wr5="$1"
  player1="$( expr "$player1" + "1" )"
fi
if [ "$nukes2" -lt "$nukes1" ]; then
  wr5="$2"
  player2="$( expr "$player2" + "1" )"
fi
if [ "$nukes1" == "$nukes2" ]; then
  wr5="None"
fi

# Round 6 - RaceStarts

if [ "$comprace" == "YES" ]; then
  if [ "$numrel1" -gt "$numrel2" ]; then
    wr6="$1"
    player1="$( expr "$player1" + "1" )"
  fi
  if [ "$numrel2" -gt "$numrel1" ]; then
    wr6="$2"
    player2="$( expr "$player2" + "1" )"
  fi
  if [ "$numrel1" == "$numrel2" ]; then
    wr6="None"
  fi
fi

echo "$look Round 1 - UL/DL Ratio: [ $uldl1 ] vs [ $uldl2 ] - 1 point to $wr1"
echo "$look Round 2 - UL/DAY: [ $avgmb1MB for $time1 days ] vs [ $avgmb2MB for $time2 days ] - 2 points to $wr2"
echo "$look Round 3 - MnUp: [ $mnup1MB @ #$mnuppos1 ] vs [ $mnup2MB @ #$mnuppos2 ] - 2 points to $wr3"
echo "$look Round 4 - WkUp: [ $wkup1MB @ #$wkuppos1 ] vs [ $wkup2MB @ #$wkuppos2 ] - 2 points to $wr4"
echo "$look Round 5 - NUKES: [ $nukes1N ] vs [ $nukes2N ] - 1 point to $wr5" 
if [ "$comprace" == "YES" ]; then
  echo "$look Round 6 - RaceStarts: [ $numrel1 Races ] vs [ $numrel2 Races ] - 1 point to $wr6" 
fi
if [ "$player1" -gt "$player2" ]; then
  winner="The winner is $1/$group1 by $player1 to $player2.!"
fi
if [ "$player2" -gt "$player1" ]; then
  winner="The winner is $2/$group2 by $player2 to $player1!"
fi
if [ "$player1" == "$player2" ]; then
  winner="Oh my god! They are equal! It's $player1 to $player2. A draw!"
fi
echo "$look $winner"
  
  



