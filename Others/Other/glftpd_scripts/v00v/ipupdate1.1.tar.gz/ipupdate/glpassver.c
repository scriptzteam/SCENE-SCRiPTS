/********************************************************************/
/* Glftpd password verifier by Usurper, December 2000 version 1.0   */
/* --- Added support for ipupdate.cgi by gagging printf             */
/* --- \oo a.k.a. v00v, November 2001                               */
/*                                                                  */
/* Update passwdpath if needed, copy this over original glpassver.c */
/* in glpassver dir that you downloaded, and run "make".            */
/* copy compiled glpassver binary to /glftpd/bin directory          */
/********************************************************************/

char *passwdpath = "/glftpd/etc/passwd";

#include <stdio.h>

extern char *crypt();

int main (int argc, char *argv[]) {
	char *encrypted, pass[30], username[30], *boo;
	char buff[BUFSIZ], encpass[30], found=0;
	FILE *pw;
	
	if (argc < 3) {
	  return 1;
	}
	strcpy(username, argv[1]);
	strcpy(pass, argv[2]);

	pw = fopen(passwdpath, "r");
	if (pw == NULL) {
	  return 1;
	}
	while (fgets(buff, sizeof(buff), pw) != NULL) {
	  if (strncmp(buff, username, strlen(username)) == 0) {
	    strncpy(encpass, strchr(buff, ':') +1, sizeof(encpass));
	    boo = (char *)strchr(encpass, ':');
	    if (boo) *boo = '\0';	 
        found++;
	    break;
	  }
	}
	fclose(pw);
	if (!found) {
	  return 1;
	}
	encrypted = crypt(pass, encpass);
	if (strcmp(encrypted, encpass) != 0) {
	  return 1;
	}
	return 0;
}
