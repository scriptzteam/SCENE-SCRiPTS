#!/bin/bash
# Simple Script to Install the Quota Tool (FRS)
#
# Glftpd root dir
rootpath="/opt/glftpd"
# User dir
glusers="/ftp-data/users/"
#
# Set also your site dir
site="/site/"
#
# Put here your Glftpd configuration file :)
gletc="/opt/glftpd/etc/glftpd.conf"

echo "Doing a brief Dir Cheking..."
if [ -d ${rootpath} ]; then
	echo "Rootpath OK..."
else
	exit 1
fi

if [ -d "${rootpath}${glusers}" ]; then
	echo "User path dir OK..."
else
	exit 1
fi

if [ -d "${rootpath}${site}" ]; then
	echo "User site dir OK..."
else
	exit 1
fi

if [ -e "${gletc}" ]; then
	echo "Glftpd configuration is ok!"
else
	exit 1
fi

duvar="`which du`"

if [ -n $duvar ]; then
	cp $duvar ${rootpath}"/bin/"
else
	echo "I can't locate the binary - du -. Please copy it in ${rootpath}/bin/ "
fi

echo "Copying Main Binary file..."
cp ./quota.sh ${rootpath}"/bin/"
chmod oau+x ${rootpath}"/bin/quota.sh"

echo "Making DB Quota file..."
touch ${rootpath}"/etc/quotadb"

echo "Adding custom quota line in $gletc"
echo "# Line added by Quota Tool (FRS), if you don't use my script anymore, remove them!" >> $gletc
echo -e "site_cmd QUOTA\tEXEC\t/bin/quota.sh" >> $gletc
echo -e "custom-quota\t!8 *" $gletc
echo "All done."
