#!/bin/bash
#
# Quota for Glftpd by FRSoldier
# An util for "Glftpd's Web tools" (next will come the complete pack)
#
# Before use this script you have to know:
# - In my server a normal user has only a '+3' flag 
# - it's coded to work as 'web user check quota dir'
# - Set your users ratio to 0!
#
# How to use it
# - Simply run 'quota-setup.sh' 
# - go in your $glftpdpath/etc/ and edit your quotadb file as follow:
# Syntax    username:quotabyte
# Example:  vixen:1000000
#	    vixen3:NOQUOTA
#
# Quota.sh will run every time when the user type 'site quota' (for example to 
# enable his uploading permission, if his quota is regular).
# But you can also add an entry in your crontab, for example you could run it
# every 3 or 6 hours.
#
# Why did I write this script ?
# Glftpd is one of the best ftpd with many features. So I started to use it as 
# ftpd for a web server. Here I need only to check user quota, and block upload.
# I don't need to use Credit or ratio, so I use this script.
#
# History - Greets
# 22/01/2003: first coding and testing
# 23/01/2003: ending of the coding, doing some tests
# 24/01/2003: Thanks Zio for your hints
# 26/01/2003: Added an arg user check and 'site quota'; Bug fixing
# 27/01/2003: Packing, last tests, fixes.
#
# TODO
# - Made a custom tool to write/read a cdb database where store users with quota (soon!)
#
# For bug or comments you find me in Efnet as FRSoldier
#
# Coded and tested with Glftpd 1.28 (of course on Slackware!)
#
version="Glftpd Quota 0.65"
# Of Course set your Rootpath (leave empty if you are running quota.sh only for the users!)
rootpath=""
#
# Extra Rootpath! yes this is needed if you start the quota.sh from a crontab
extrapt="/opt/glftpd"
#
# User dir
glusers="/ftp-data/users/"
#
# Set also your site dir (including /)
site=${rootpath}"/site/"
#
# Set where you keep your quota database file
qdb=${rootpath}"/etc/quotadb"
#
# If you wanna run the script from a crontab or shell please setup the user
sysop="root"
#
# @ OK Starting to W0rk Now @ #
#
echo "${version} Starting to check..."

if [ ${USER} = ${sysop} ]; then
	qdb=${extrapt}"/etc/quotadb"
fi

if [ -e $qdb ]; then
	if [ "$USER" != "${sysop}" ]; then
		echo "I'm Checking your Quota $USER"
		luser=`cat ${qdb} | grep $USER`
	else
		# So the script is running from crontab or shell!
		rootpath=${extrapt}
		luser=`cat ${qdb}`
	fi

	for uk in ${luser} 
	do
		userz=`echo ${uk} | cut -f 1 -d ":"`
		qt=`echo ${uk} | cut -f 2 -d ":"`
		if [ -z ${qt} ]; then
			echo "You have no quota. Lucky!"
		elif [ $qt = "NOQUOTA" ]; then
			echo "You have unlimited quota! F0R N0W!"
		else
			echo "For user ${userz} Quota is ${qt}"
			real=`du -sb ${extrapt}${site}${userz}| sed 's/[[:space:]]\+/ /g'| cut -f 1 -d " "`
			if (( $real > $qt ))
			then
				if [ -e ${rootpath}${glusers}${userz} ]; then
					echo "--> Warning ${userz} is exceding Quota..."
					if [ -e ${rootpath}${glusers}${userz}".quoted" ]; then
						# Do nothing user already don't have G flags
						sleep 1
					else
						cat "${rootpath}${glusers}${userz}" | sed -e 's/LOGINS\ 2\ 0\ \-1\ 1/LOGINS\ 2\ 0\ -1\ 0/' > ${rootpath}${glusers}${userz}".quoted"
						if [ -e ${rootpath}${glusers}${userz}".quoted" ]; then
							chmod 666 ${rootpath}${glusers}${userz}".quoted"
							cp ${rootpath}${glusers}${userz}".quoted" ${rootpath}${glusers}${userz}
						else
							echo "-X- Warning I can't chmod new user settings!"
							echo "-X- I'm Skipping this user, please do some checks!"
						fi
					fi
				else
					echo "-X- User file ${rootpath}${glusers}${userz} doesn't exist... Skipping..."
				fi
				qt=""
			else
				if [ -e ${rootpath}${glusers}${userz}".quoted" ]; then
					echo "--> User was Over Quota, let me correct"
					rm ${rootpath}${glusers}${userz}".quoted"
					cat ${rootpath}${glusers}${userz} | sed -e 's/LOGINS\ 2\ 0\ \-1\ 0/LOGINS\ 2\ 0\ -1\ 1/' > ${rootpath}${glusers}${userz}".right"
					mv ${rootpath}${glusers}${userz}".right" ${rootpath}${glusers}${userz}
					chmod 666 ${rootpath}${glusers}${userz}
					echo "--> Done, User now can upload..."
				else
					echo "--> User Quota Regular"
				fi
			fi
		fi
	done
else
	echo "-X- Sorry but I can't find your Quota Database..."
	exit 1
fi

