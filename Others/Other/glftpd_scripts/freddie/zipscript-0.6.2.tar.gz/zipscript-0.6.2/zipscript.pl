#!/bin/perl -w

# $Id: zipscript.pl,v 1.41 2001/03/29 11:12:15 freddie Exp $

# ---------------------------------------------------------------
# Freddie's Zipscript                   freddie@madcowdisease.org
# ---------------------------------------------------------------

$ver = 'v0.6.2';

# ---------------------------------------------------------------


init();


# ---------------------------------------------------------------
# Initialize (almost) everything we'll need later
# ---------------------------------------------------------------
sub init {
	# install our warning handler
	$SIG{'__WARN__'} = \&warning;

	# fix up our path
	$ENV{'PATH'} = '/bin';

	# are we really being fed stuff from glftpd?
	exitwith(2, "Usage: zipscript.pl <file> <dir> <crc>") unless $#ARGV == 2;

	# load our config file
	parse_config('/etc/zipscript.conf');

	# always good to start off with a blank line
	print "\n";

	# print out the lame banner
	output('banner', ".:|:.  Freddie's Zipscript $ver  .:|:.\n\n");

	# make sure everything is set up properly
	sanity_check();

	# setup all the variables we'll be using
	setup_vars();

	# make our files world writable
	umask 000;

	# change to the dir we're playing with
	chdir $DIR;

	# check that the file exists before doing anything else
	exitwith(2, "-=> File does not exist!") unless -e $FILE;

	# identify the dir, exit if we don't care about it
	identify_dir();

	# lock the dir if we have to
	lock_dir() if $conf{'lock'}{'lockdir'};

	# start the checking!
	start_check();

	exit(0);
}

sub identify_dir() {
	# find out what type of dir it is
	my ($dir, %types);
	$types{'iso'} = [ 'sfv', 'rar', '[rs\d]\d\d' ];
	$types{'mp3'} = [ 'sfv', 'mp3', 'm3u' ];
	$types{'zip'} = [ 'zip' ];

	type: foreach my $type (qw(iso mp3 zip)) {
		($dir) = grep { $DIR =~ m#^$_# } split(/\s+/, $conf{$type}{'dirs'});
		if ($dir) {
			if (allow_extra($type)) {
				if ($FILE =~ /\.zip$/) {
					$TYPE = $type;
					last;
				}
				else {
					exitwith(0, "-=> File accepted!");
				}
			}

			match: foreach my $match (@{ $types{$type} }) {
				if ($FILE =~ /\.$match$/i) {
					$TYPE = $type;
					last type;
				}
			}
		}
	}

	# do we handle this dir?
	exitwith(0, "-=> Not set up for this directory, accepting file.") unless $dir;

	# did we match anything at all up there?
	exitwith(2, "-=> Unknown file type, deleting.") unless $TYPE;
}

# ---------------------------------------------------------------
# This is where we (kinda) do the actual checking of the files
# ---------------------------------------------------------------
sub start_check () {
	# ISO or MP3
	if ($TYPE eq 'iso' || $TYPE eq 'mp3') {
		# SFV?
		if ($FILE =~ /\.sfv$/i) {
			iso_sfv();
		}

		# RAR/MP3
		elsif ($FILE =~ /\.(rar|[r\d]\d\d)$/i || $FILE =~ /\.mp3$/i) {
		    if ($conf{$TYPE}{'sfvfirst'}) {
		    	exitwith(2, "-=> No SFV file found, upload one first.") unless find_sfvs();
		    }

			iso_testfile();
		}

		# MP3 specific
		elsif ($TYPE eq 'mp3' && $FILE =~ /\.m3u$/i) {
			if ($conf{'mp3'}{'makem3u'}) {
				exitwith(2, "-=> Sorry, an M3U is made automatically, deleting.");
			}
			else {
				exitwith(0, "-=> File accepted!");
			}
		}

		# ZIP file
		elsif ($FILE =~ /\.zip$/i) {
			exit(zip_testfile() ? 2 : 0);
		}
	}

	# ZIP
	elsif ($TYPE eq 'zip') {
		zip_checkfile();
	}
}

# --------------------------------------------------------------------------------
#   ISO verification/completion routines
# --------------------------------------------------------------------------------
sub iso_testfile {
	if (iso_checkcrc($FILE)) {
		write_speed('PASS');
		iso_update();
		exit(0);
	}
	else {
		write_speed('FAIL');
		exit(2);
	}
}

sub iso_checkcrc ($) {
	($sfv, $sfvref) = read_sfv() unless $sfv && $sfvref;

	my $cfile = shift;

	# did we find an SFV?
	if ($sfv) {
		print "-=> CRC checking $cfile... ";

		my $sfvcrc = $sfvref->{lc($cfile)};
		if ($sfvcrc) {
			my $filecrc = $crcref->{lc($cfile)} || $CRC;

			# if it's a blank or invalid CRC, generate a new one
			if ($filecrc =~ /^0+$/ || $filecrc !~ /^[A-Z0-9]+$/i) {
				(my $escfile = $FILE) =~ s/([\[\]\(\)])/\\$1/g;

				my @output = `/bin/cksfv $escfile`;
				unless (defined $output[0]) {
					print "CRC check failure, deleting.\n\n";
					return 0;
				}
				(undef, $filecrc) = split(/\s+/, $output[$#output]);
			}

			# pad the CRC value to 8 bytes like we're supposed to
			$filecrc = sprintf "%08s", $filecrc;

			if ($sfvcrc eq $filecrc) {
				print "ok!\n\n";
				unlink "$cfile-missing" if -e "$cfile-missing";
				write_crc();
				return 1;
			}
			else {
				print "failed, deleting.\n\n";
				return 0;
			}
		}
		else {
			print "not found in SFV, deleting.\n\n";
			return 0;
		}
	}
	else {
		print "-=> No SFV file found, not testing.\n\n";
		write_crc();
		write_status('NOSFV', 'NOSFV');
		return 1;
	}
}

sub iso_sfv () {
	my $sfvs = find_sfvs();

	exitwith(2, "-=> Sorry, there's already a SFV here... deleting.") if $sfvs->[1];

	($sfv, $sfvref) = read_sfv($sfvs->[0]);
	(undef, $crcref) = read_sfv('.crc') if -s '.crc';

	# just in case
	$CRC = '00000000';

	foreach my $file (sort keys %{ $sfvref }) {
		if (-f $file && ! -x _) {
			unlink $file unless iso_checkcrc($file);
		}
	}

	# Create the -missing files if we have to
	if ($conf{'general'}{'missing'}) {
		output('missing', '-=> Creating -missing files... ');
		foreach my $missing (sort keys %{ $sfvref }) {
			touch("$missing-missing") unless -e $missing && ! -x _;
		}
		output('missing', "done\n\n");
	}

	my @files = sort rar_sort keys(%{ $sfvref });
	my $total = $#files + 1;

	$sfv =~ /^(.*?)\./;
	my $base = $1 || '';
	gl_log(qq#SFV: "$DIR" "$USER" "$GROUP" "$base" "$total"\n#);

	write_speed('SFV');

	iso_update();

	exit(0);
}

sub iso_update {
	($sfv, $sfvref) = read_sfv() unless $sfv && $sfvref;
	return unless $sfv;

	my @total = keys(%{ $sfvref });
	my @complete = grep { -e $_ && (! -x _ || $_ eq $FILE) } @total;

	update_release();
}
# --------------------------------------------------------------------------------


# --------------------------------------------------------------------------------
#   ZIP verification/completion routines
# --------------------------------------------------------------------------------
sub zip_testfile {
	print "-=> Checking $FILE\'s integrity... ";
	my $ret = system("/bin/unzip -tqq $FILE") / 256;
	print $ret ? "failed!\n\n" : "OK!\n\n";
	return $ret;
}

sub zip_checkfile {
	if (zip_testfile()) {
		write_speed('FAIL');
		exit(2);
	}

	write_speed('PASS');

	my $total;
	if (! -e 'FILE_ID.DIZ') {
		print "-=> Extracting FILE_ID.DIZ... ";
		my $ret = system("/bin/unzip -Cpoqq $FILE file_id.diz > FILE_ID.DIZ") / 256;
		if ($ret || -z 'FILE_ID.DIZ') {
			unlink 'FILE_ID.DIZ';
			print "failed, deleting.\n\n";
			$total = '0';
		}
		else {
			print "OK!\n\n";
			$total = num_disks();
		}
	}
	else {
		$total = num_disks();
	}

	if ($total) {
		update_release($total);
	}
	else {
		print "-=> DIZ is bad or doesn't exist.\n\n";
	}

	exit(0);
}


# --------------------------------------------------------------------------------
#   Utility functions to do various things
# --------------------------------------------------------------------------------


# ---------------------------------------------------------------
# This is called when we exit for any reason, though not if we
# get some signals.. but then again, why are you sending signals
# to your zipscript?
# ---------------------------------------------------------------
END {
	rmdir('lock') if $conf{'lock'}{'lockdir'};
}

# ---------------------------------------------------------------
# Lock the current dir so that only one instance of the zipscript
# can be writing to the dir at a time
# ---------------------------------------------------------------
sub lock_dir() {
	my $secs = 0;
	until (mkdir('lock', 0777)) {
		select(undef, undef, undef, 0.05); # sleep for 0.05s
		$secs += 0.05;
		if ($secs >= $conf{'lock'}{'lockdelay'}) {
			rmdir('lock');
			next;
		}
	}

	output('locking', "-=> Lock grabbed in $secs seconds\n\n");
}

# ---------------------------------------------------------------
# Make sure the files we need are present and accounted for
# ---------------------------------------------------------------
sub sanity_check {
	# log file
	unless (-e $conf{'logging'}{'logfile'} && -w _) {
		error(2, "$conf{'logging'}{'logfile'} doesn't exist or isn't writable!");
	}

	foreach $bin (qw(cksfv unzip)) {
		unless (-e "/bin/$bin" && -x _) {
			error(2, "/bin/$bin doesn't exist or isn't executable!");
		}
	}
}


###########################
# Screen output functions #
###########################
sub exitwith ($$) {
	my ($level, $msg) = @_;

	print "$msg\n\n";
	exit($level);
}

sub error ($$) {
	my ($level, $msg) = @_;

	my $line = (caller(0))[2];
	(my $by = (caller(1))[3]) =~ s/^.*:://;

	print "ERROR\($by, line $line\) - $msg\n\n";
	exit($level);
}

sub output ($$) {
	my ($TYPE, $text) = @_;
	error(2, 'Bad parameters') unless $TYPE && $text;

	print $text if $conf{'display'}{$TYPE};
}

sub warning ($) {
	output('warning', "-=> Warning: " . shift);
}

# ---------------------------------------------------------------
# Print out a fruity progress bar
# ---------------------------------------------------------------
sub progress_bar ($$) {
	my ($done, $total) = @_;
	return unless $done && $total && $done <= $total;

	# left char
	my $bar = $conf{'progress'}{'left'};

	# how far we have to fill in
	my $donepos = int($done * ($conf{'progress'}{'positions'} / $total));
	if ($donepos) {
		for (1 .. $donepos) {
			$bar .= $conf{'progress'}{'filled'};
		}

		if ($donepos < $conf{'progress'}{'positions'}) {
			for (1 .. ($conf{'progress'}{'positions'} - $donepos)) {
				$bar .= $conf{'progress'}{'blank'};
			}
		}
	}
	else {
		for (1 .. $conf{'progress'}{'positions'}) {
			$bar .= $conf{'progress'}{'blank'};
		}
	}

	# right char
	$bar .= $conf{'progress'}{'right'};

	# and return
	return $bar;
}
###########################


# log a line to the glftpd log file
sub gl_log ($) {
	# just return if we don't have to log anything
	if ($conf{'logging'}{'ignore'}) {
		my ($dir) = grep { $DIR =~ m#^$_# } split(/\s+/, $conf{'logging'}{'ignore'});
		return if $dir;
	}

	my $line = shift;
	error(2, "nothing to log") unless $line;

	(my $ltime = scalar localtime) =~ s/\s+/ /g;

	open(LOG, ">> $conf{'logging'}{'logfile'}") || error(2, "couldn't open $conf{'logging'}{'logfile'}: $!");
	print LOG "$ltime $line";
	close LOG;
}

sub setup_vars {
	# grab the stuff that glftpd feeds us
	($FILE, $DIR, $CRC) = @ARGV;

	# get values we need and set them to defaults if we have to
	$SPEED = $ENV{'SPEED'} || 1;
	$USER = $ENV{'USER'} || 'unknown';
	$GROUP = $ENV{'GROUP'} || 'unknown';

	$DIR =~ /.*\/(.*?)$/;
	$REL = $1 || 'unknown';
}

# sort so that .rar comes before .r00
sub rar_sort {
	if ($a =~ /\.rar$/i) { return -1; }
	elsif ($b =~ /\.rar$/i) { return 1; }
	else { return lc($a) cmp lc($b); }
}

# create an empty file
sub touch {
	my $file = shift;
	return unless $file && ! -s $file;

	open(TOUCH, "> $file") || error(0, "couldn't touch $file: $!");
	close TOUCH;
}

sub write_speed ($) {
	my $status = shift;

	my $size = -s $FILE;
	$size = $size ? int($size / 1024) : 0;

	my $when = scalar time;

	open(SPEED, ">> .speed") || error(0, "couldn't open .speed: $!");
	print SPEED "$FILE $size $SPEED $USER $GROUP $when $status\n";
	close SPEED;
}

sub write_crc {
	open(CRC, ">> .crc") || error(0, "couldn't open .crc: $!");
	print CRC lc($FILE)." $CRC\n";
	close CRC;
}

sub write_message {
	open(MESSAGE, '> .message') || error(0, "couldn't open .message: $!");

	# write FILE_ID.DIZ?
	if ($conf{'.message'}{'file_id'} && -s 'FILE_ID.DIZ') {
		print MESSAGE "Contents of FILE_ID.DIZ\n";
		print MESSAGE "-----------------------\n";

		open(DIZ, '< FILE_ID.DIZ') || error(0, "couldn't open .message: $!");
		while (<DIZ>) {
			print MESSAGE $_;
		}
		close(DIZ);

		print MESSAGE "\n";
	}

	# write release info?
	if ($conf{'.message'}{'release'}) {
		print MESSAGE "Release Information\n";
		print MESSAGE "-------------------\n";

		print MESSAGE "Rls Name  : $REL\n";

		my $kbytes = sprintf("%.1f", $totalsref->{'kbytes'} / 1024);
		print MESSAGE "Rls Size  : ${kbytes}MB\n";

		print MESSAGE "Avg Speed : $totalsref->{'speed'}KB/s\n";

		my $fdate = scalar localtime;
		print MESSAGE "Updated   : $fdate\n\n";
	}

	# write users info?
	print_stats(\*MESSAGE, 'user') if $conf{'.message'}{'users'};

	# write groups info?
	print_stats(\*MESSAGE, 'group') if $conf{'.message'}{'groups'};

	close(MESSAGE);
}

sub write_update ($$) {
	my ($complete, $total) = @_;

	my ($found, %update);
	foreach my $block (split(/\s+/, $conf{'general'}{'update'})) {
		my ($min, $when) = split(/:/, $block);
		$update{$min} = $when;

		$found = $min if $total >= $min;
	}

	if ($found) {
		my $lastper = $complete > 1 ? int(($complete - 1) / $total * 100) : 1;
		my $percent = int($complete / $total * 100);

		foreach my $when (split(/\./, $update{$found})) {
			if ($percent == $when || ($lastper < $when && $percent > $when)) {
				my ($leader) = sort { $usersref->{$b}{'kbytes'} <=> $usersref->{$a}{'kbytes'} } keys %{ $usersref };

				my $uwin = $usersref->{$leader};

				my $left = $total - $complete;

				my $totalkb = ($totalsref->{'kbytes'} / $totalsref->{'files'}) * $total;
				my $secs = $totalsref->{'end'} - $totalsref->{'start'};
				my $eta = nice_time(($totalkb - $totalsref->{'kbytes'}) / ($totalsref->{'kbytes'} / $secs));

				gl_log(qq#UPDATE: "$DIR" "$when" "$leader" "$uwin->{'group'}" "$uwin->{'files'}" #.
					qq#"$uwin->{'kbytes'}" "$totalsref->{'files'}" "$totalsref->{'kbytes'}" #.
					qq#"$left" "$eta"\n#);
			}
		}
	}
}

sub print_stats ($$) {
	my ($fh, $type) = @_;
	error(2, "bad parameters") unless $type && defined $fh;

	$type = uc($type);

	my $i = 0;

	if ($type eq 'USER') {
		print $fh " ---(User stats)-------------------\n";

		foreach my $name (sort { $usersref->{$b}{'kbytes'} <=> $usersref->{$a}{'kbytes'} } keys %{ $usersref }) {
			next unless $usersref->{$name}{'files'};

			my $uref = $usersref->{$name};

			my $per = sprintf "%.1f", ($uref->{'files'} / $totalsref->{'files'} * 100);

			my $temp = "$name\@$uref->{'group'}";

			printf $fh "| #%02d. %-30.30s  %dKB, %dF @ %dKB/s\n",
				++$i, $temp, $uref->{'kbytes'}, $uref->{'files'}, $uref->{'speed'};
		}

		printf $fh "\n";
	}
	elsif ($type eq 'GROUP') {
		print $fh " ---(Group stats)------------------\n";

		foreach my $name (sort { $groupsref->{$b}{'kbytes'} <=> $groupsref->{$a}{'kbytes'} } keys %{ $groupsref }) {
			next unless $groupsref->{$name}{'files'};

			my $gref = $groupsref->{$name};

			my $per = sprintf "%.1f", int($gref->{'files'} / $totalsref->{'files'} * 100);

			printf $fh "| #%02d. %-25.25s  % 2dR  %dKB, %dF @ %dKB/s\n",
				++$i, $name, $gref->{'racers'}, $gref->{'kbytes'}, $gref->{'files'},
				$gref->{'speed'};
		}

		printf $fh "\n";
	}
}

sub write_status ($$) {
	return unless $conf{'status'}{'enabled'};

	my ($complete, $total) = @_;

	my $inc = $conf{$TYPE}{'incomplete'} || $conf{'status'}{'incomplete'};
	$inc =~ s/([\[\]\(\)\|\\\/\.])/\\$1/g;
	$inc =~ s/<.*?>/\.\*\?/g;

	my $com = $conf{$TYPE}{'complete'} || $conf{'status'}{'complete'};
	$com =~ s/([\[\]\(\)\|\\\/\.])/\\$1/g;
	$com =~ s/<.*?>/\.\*\?/g;

	# remove the old status marker
	opendir(DIR, $DIR) || error(2, "couldn't open $DIR: $!");
	my @old = grep { $_ =~ /^($inc|$com)$/ } readdir(DIR);
	closedir(DIR);

	foreach my $old (@old) {
		unlink $old if -f $old;
		rmdir $old if -d _;
	}


	my ($per, $percent, $nper, $missing);

	if ($total =~ /^\d+$/) {
		$missing = $total - $complete;

		$per = $complete / $total * 100;
		$percent = sprintf "%03d%%", $per <= 100 ? $per : '100';

		($nper = $per) =~ s/\D//g;
		$nper ||= 0;
	}
	else {
		$missing = 'Unknown';
		$percent = 'NOSFV';
		$complete = 0;
		$total = 'Unknown';

		$nper = 0;
	}

	my $ksize = $totalsref->{'kbytes'} || '0.00';
	my $msize = $totalsref->{'kbytes'} ? sprintf "%.1f", $totalsref->{'kbytes'} / 1024 : '0.00';

	# make the new status marker
	my $status = $nper == 100 ? 'complete' : 'incomplete';
	my $marker = $conf{$TYPE}{$status} || $conf{'status'}{$status};

	# basic tag replacing
	$marker =~ s/<per>/$percent/;
	$marker =~ s/<complete>/$complete/;
	$marker =~ s/<missing>/$missing/;
	$marker =~ s/<total>/$total/;
	$marker =~ s/<ksize>/$ksize/;
	$marker =~ s/<msize>/$msize/;

	# MP3 specific tags
	if ($TYPE eq 'mp3') {
		$marker =~ s/<genre>/$id3ref->{'genre'}/;
		$marker =~ s/<bitrate>/$headref->{'bitrate'}/;
		$marker =~ s/<year>/$id3ref->{'year'}/;
		$marker =~ s/<mode>/$headref->{'mode'}/;
	}

	if ($conf{'status'}{'type'} eq 'file') {
		touch($marker);
	}
	if ($conf{'status'}{'type'} eq 'dir') {
		mkdir($marker, 0777);
	}
}

sub update_release {
	# read the racer stats in
	($totalsref, $usersref, $groupsref) = race_stats();

	my ($complete, $total);

	$complete = $totalsref->{'files'} || 0;

	if ($TYPE eq 'zip') {
		$total = shift;
	}
	else {
		$total = scalar keys(%{ $sfvref });
	}

	error(2, "no complete or total passed") unless defined $complete && defined $total;

	print "-=> $complete of $total files completed\n\n";

	if ($conf{'status'}{'enabled'}) {
		# incomplete marker in parent dir
		my $inc = "../\[INCOMPLETE\]--$REL";
		if (($complete / $total * 100) < 100) {
			touch($inc)
		}
		else {
			unlink($inc);
		}
	}

	# no sense doing anything more if we don't have any files yet
	unless ($complete) {
		write_status($complete, $total);
		return;
	}

	# log the first file
	if ($complete == 1 && ($total > 1 || $conf{'logging'}{'alwaysfirst'})) {
		if ($TYPE eq 'zip') {
			gl_log(qq#FIRSTZIP: "$DIR" "$USER" "$GROUP" "$FILE" "$SPEED" "$total"\n#);
		}
		else {
			gl_log(qq#FIRSTFILE: "$DIR" "$USER" "$GROUP" "$FILE" "$SPEED"\n#);
		}
	}

	# announce new racer
	if ($conf{'logging'}{'newracer'} && $usersref->{$USER}{'files'} == 1) {
		my @names = sort { uc($a) cmp uc($b) } grep { $_ ne $USER } keys %{ $usersref };
		if ($names[0]) {
			my $left = $total - $complete;
			my $names = join(' ', @names);
			gl_log(qq#NEWRACER: "$DIR" "$USER" "$GROUP" "$FILE" "$SPEED" "$left" "$names"\n#);
		}
	}

	if ($complete == $total) {
		print "-=> Release complete!\n\n";

		my @uracers = sort { $usersref->{$b}{'kbytes'} <=> $usersref->{$a}{'kbytes'} } keys %{ $usersref };
		my @gracers = sort { $groupsref->{$b}{'kbytes'} <=> $groupsref->{$a}{'kbytes'} } keys %{ $groupsref };

		my $tusers = scalar @uracers;
		my $tgroups = scalar @gracers;

		my $ttime = nice_time($totalsref->{'end'} - $totalsref->{'start'});

		my $tolog = qq#COMPLETE: "$DIR" "$totalsref->{'files'}" "$totalsref->{'kbytes'}" #.
			qq#"$tusers" "$tgroups" "$totalsref->{'speed'}" "$ttime" #.
			qq#"$totalsref->{'fastest'}{'user'}" "$totalsref->{'fastest'}{'speed'}" #.
			qq#"$totalsref->{'slowest'}{'user'}" "$totalsref->{'slowest'}{'speed'}"#;

		if ($TYPE eq 'mp3') {
			eval { require '/bin/zipscript-mp3.pl' };
			error(1, "couldn't load zipscript-mp3.pl: $@") if $@;

			mp3_complete($complete, $total);

			$tolog = "MP3" . $tolog . qq# "$headref->{'bitrate'}" "$headref->{'mode'}" #.
				qq#"$id3ref->{'year'}" "$id3ref->{'genre'}"#;
		}
		else {
			write_status($complete, $total);
		}

		gl_log("$tolog\n");


		# log RACEUSER if we have to
		if ($conf{'logging'}{'raceuser'}) {
			my $num = min(scalar @uracers, $conf{'logging'}{'raceuser'});

			for (my $i = 1; $i <= $num; $i++) {
				my $uref = $usersref->{$uracers[$i-1]};

				my $per = sprintf "%.1f", $uref->{'files'} / $totalsref->{'files'} * 100;

				gl_log(qq#RACEUSER: "$DIR" "$i" "$uracers[$i-1]" "$uref->{'group'}" #.
					qq#"$uref->{'files'}" "$uref->{'kbytes'}" "$uref->{'speed'}" "$per"\n#);
			}
		}

		# log RACEGROUP if we have to
		if ($conf{'logging'}{'racegroup'}) {
			my $num = min(scalar @gracers, $conf{'logging'}{'racegroup'});

			for (my $i = 1; $i <= $num; $i++) {
				my $gref = $groupsref->{$gracers[$i - 1]};

				my $per = sprintf "%.1f", $gref->{'files'} / $totalsref->{'files'} * 100;

				gl_log(qq#RACEGROUP: "$DIR" "$i" "$gracers[$i-1]" "$gref->{'racers'}" #.
					qq#"$gref->{'files'}" "$gref->{'kbytes'}" "$gref->{'speed'}" "$per"\n#);
			}
		}
	}
	else {
		write_status($complete, $total);

		# do UPDATE checking/logging if we have to
		write_update($complete, $total) if $conf{'general'}{'update'};
	}

	# display user/group stats
	print_stats(\*STDOUT, 'USER') if $conf{'display'}{'raceuser'};
	print_stats(\*STDOUT, 'GROUP') if $conf{'display'}{'racegroup'};

	# write the .message file if we have to
	write_message() if $conf{'.message'}{'write'};
}

sub race_stats {
	my (%files, %totals, %users, %groups);

	touch('.speed');

	# read all the data in from .speed
	open(SPEED, '< .speed') || error(0, "couldn't open .speed: $!");
	while (<SPEED>) {
		chomp;
		my ($file, $kbytes, $speed, $user, $group, $ctime, $status) = split;

		my $fsize = -s $file;
		$fsize = $fsize ? int($fsize / 1024) : -1;

		$totals{'start'} ||= $ctime;
		$totals{'end'} = $ctime;

		$files{$file} = {
			kbytes	=> $kbytes,
			speed	=> $speed,
			time	=> $kbytes / $speed,
			user	=> $user,
			group	=> $group,
			when	=> $ctime,
		} if $status eq 'PASS' && $kbytes == $fsize;
	}
	close SPEED;

	foreach my $file (keys %files) {
		my ($user, $group) = ($files{$file}{'user'}, $files{$file}{'group'});

		$totals{'kbytes'} += $files{$file}{'kbytes'};
		$totals{'time'} += $files{$file}{'time'};
		$totals{'files'}++;

		if (! $totals{'slowest'} || $totals{'slowest'}{'speed'} > $files{$file}{'speed'}) {
			$totals{'slowest'}{'user'} = $user;
			$totals{'slowest'}{'speed'} = $files{$file}{'speed'};
		}
		if (! $totals{'fastest'} || $totals{'fastest'}{'speed'} < $files{$file}{'speed'}) {
			$totals{'fastest'}{'user'} = $user;
			$totals{'fastest'}{'speed'} = $files{$file}{'speed'};
		}

		$users{$user}{'kbytes'} += $files{$file}{'kbytes'};
		$users{$user}{'time'} += $files{$file}{'time'};
		$users{$user}{'files'}++;

		$groups{$group}{'kbytes'} += $files{$file}{'kbytes'};
		$groups{$group}{'time'} += $files{$file}{'time'};
		$groups{$group}{'files'}++;

		$groups{$group}{'racers'}++ unless $users{$user}{'group'};
		$users{$user}{'group'} ||= $files{$file}{'group'};
	}

	my $def = defined $totals{'kbytes'};

	# work out total average speed
	$totals{'speed'} = $def ? int($totals{'kbytes'} / $totals{'time'}) : 0;

	# work out average speed for users
	foreach my $user (keys %users) {
		unless ($users{$user}{'files'} && $users{$user}{'kbytes'}) {
			delete $users{$user};
			next;
		}

		$users{$user}{'time'} ||= 1;
		$users{$user}{'speed'} = $def ? int($users{$user}{'kbytes'} / $users{$user}{'time'}) : 0;
	}

	# work out average speed for groups
	foreach my $group (keys %groups) {
		unless ($groups{$group}{'files'} && $groups{$group}{'kbytes'}) {
			delete $groups{$group};
			next;
		}

		$groups{$group}{'time'} ||= 1;
		$groups{$group}{'speed'} = $def ? int($groups{$group}{'kbytes'} / $groups{$group}{'time'}) : 0;
	}

	return (\%totals, \%users, \%groups);
}

# find all .sfv files in the current dir that are larger than 0 bytes
sub find_sfvs {
	opendir(RELEASE, $DIR) || error(2, "couldn't open $DIR: $!");
	my @sfvs = grep { $_ =~ /\.sfv$/i && -s $_ } readdir(RELEASE);
	closedir(RELEASE);

	return \@sfvs;
}

# read all info from an sfv and return a hash ref of the data
sub read_sfv {
	my $sfv = shift || find_sfvs()->[0];
	return undef unless $sfv;

	my %sfv;
	open(SFV, "< $sfv") || error(2, "Couldn't open $sfv: $!");
	while (<SFV>) {
		s/[\r\n]//g;
		next if /^$/ || /^\;/ || tr/ // > 1;

		my ($file, $crc) = split;
		next if $file =~ /\.(?:sfv|m3u|nfo|jpg|zip)$/i;

		$crc =~ tr/A-Za-z0-9//cd;

		$sfv{lc($file)} = sprintf "%08s", uc($crc);
	}
	close(SFV);

	exitwith(2, "-=> Error: SFV contains no valid lines, rejecting.") unless keys(%sfv);

	return ($sfv, \%sfv);
}

sub num_disks () {
	open(DIZ, "$DIR/FILE_ID.DIZ") || return 'NO_DIZ';

	my $disks;
	while (<DIZ>) {
		# remove any CR/LF
		s/[\r\n]//g;

		# [??/03] (??/o3) <??/x3> - your generic "everything" case
		# " xx/15 " - PRD, REFORM
		# "xx/25" on the end of the line - RiSE, ZENiTH
		if (m#[\[\(<:]\s?[\dox]{1,2}/([\dox]{1,2})[\]\)>]#i ||
			m# [\dox]{1,2}/([\dox]{1,2}) #i ||
			m#[^/]xx/(\d\d)$#i
		) {
			$disks = $1;
		}

		if ($disks) {
			close DIZ;
			$disks =~ s/[ox]/0/gi;
			return sprintf "%d", $disks;
		}
	}

	close DIZ;

	return 1;
}

sub allow_extra ($) {
	my $type = shift;

	if ($DIR =~ m#/Samples?/?$#i && $FILE =~ /\.(avi|mpg)$/i) {
		return $conf{$type}{'allowsamples'} ? uc($1) : 0;
	}
	elsif ($DIR =~ m#/Covers?/?$#i && $FILE =~ /\.jpg$/i) {
		return $conf{$type}{'allowcovers'} ? 'JPG' : 0;
	}
	elsif ($conf{$type}{'allowextra'}) {
		my ($ext) = grep { $FILE =~ /\.$_$/i } split(/\s+/, $conf{$type}{'allowextra'});
		return $ext ? uc($ext) : 0;
	}
	else {
		return 0;
	}
}

sub parse_config ($) {
	my $file = shift;
	error(1, "$file doesn't exist!") unless -e $file;

	open(CONF, "< $file") || error(1, "couldn't open $file: $!");

	my ($cname);
	while (<CONF>) {
		# clean up the input
		s/\r//g;
		s/^\s*(.*?)\s*$/$1/;

		# don't bother parsing empty lines or comments
		next unless $_;
		next if /^\#/;

		# start of a block?
		if (/^(\S+) \{$/) {
			error(1, "failed parsing $file: block '$cname' is not closed") if $cname;
			$cname = $1;
		}

		# end of a block?
		elsif (/^\}$/) {
			error(1, "unmatched closing bracket at $file line $.") unless $cname;
			undef $cname;
		}

		# anything else
		else {
			my ($opt, $set) = split(/=/, $_, 2);
			error(1, "invalid option in block '$cname': $_ at $file line $.") unless $opt;
			$conf{$cname}{$opt} = $set || 0;
		}
	}

	close(CONF);
}

sub nice_time($) {
	my $secs = shift;

	if ($secs > (60 * 60)) {
		return sprintf "%d:%02d:%02d", int($secs / 60 / 60), int(($secs % (60 * 60)) / 60),
			($secs % (60 * 60)) % 60;
	}
	else {
		return sprintf "%d:%02d", int($secs / 60), $secs % 60;
	}
}

sub min($$) {
	return ($_[0] > $_[1] ? $_[1] : $_[0]);
}
