# $Id: zipscript-mp3.pl,v 1.8 2001/03/20 18:33:33 freddie Exp $

# MP3 frame header info
@mpeg = (2, 1);
@layer = ('bad', 3, 2, 1);
%bitrate = (
	'1:1'	=> [ 'bad', 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 'bad' ],
	'1:2'	=> [ 'bad', 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 'bad' ],
	'1:3'	=> [ 'bad', 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 'bad' ],
	'2:1'	=> [ 'bad', 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 'bad' ],
	'2:2'	=> [ 'bad', 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 'bad' ],
	'2:3'	=> [ 'bad', 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 'bad' ],
);
@mode = ('Stereo', 'Joint stereo', 'Dual channel', 'Mono');

# ID3 genres
@genres = ('Blues', 'Classic Rock', 'Country', 'Dance', 'Disco', 'Funk', 'Grunge', 'Hip-Hop',
'Jazz', 'Metal', 'New Age', 'Oldies', 'Other', 'Pop', 'R&B', 'Rap', 'Reggae', 'Rock', 'Techno',
'Industrial', 'Alternative', 'Ska', 'Death Metal', 'Pranks', 'Soundtrack', 'Euro-Techno',
'Ambient', 'Trip-Hop', 'Vocal', 'Jazz+Funk', 'Fusion', 'Trance', 'Classical', 'Instrumental',
'Acid', 'House', 'Game', 'Sound Clip', 'Gospel', 'Noise', 'Alt. Rock', 'Bass', 'Soul', 'Punk',
'Space', 'Meditative', 'Instrumental Pop', 'Instrumental Rock', 'Ethnic', 'Gothic', 'Darkwave',
'Techno-Industrial', 'Electronic', 'Pop-Folk', 'Eurodance', 'Dream', 'Southern Rock', 'Comedy',
'Cult', 'Gangsta Rap', 'Top 40', 'Christian Rap', 'Pop/Funk', 'Jungle', 'Native American',
'Cabaret', 'New Wave', 'Psychedelic', 'Rave', 'Showtunes', 'Trailer', 'Lo-Fi', 'Tribal',
'Acid Punk', 'Acid Jazz', 'Polka', 'Retro', 'Musical', 'Rock & Roll', 'Hard Rock', 'Folk',
'Folk/Rock', 'National Folk', 'Swing', 'Fast-Fusion', 'Bebob', 'Latin', 'Revival', 'Celtic',
'Bluegrass', 'Avantgarde', 'Gothic Rock', 'Progressive Rock', 'Psychedelic Rock',
'Symphonic Rock', 'Slow Rock', 'Big Band', 'Chorus', 'Easy Listening', 'Acoustic', 'Humour',
'Speech', 'Chanson', 'Opera', 'Chamber Music', 'Sonata', 'Symphony', 'Booty Bass', 'Primus',
'Porn Groove', 'Satire', 'Slow Jam', 'Club', 'Tango', 'Samba', 'Folklore', 'Ballad',
'Power Ballad', 'Rhythmic Soul', 'Freestyle', 'Duet', 'Punk Rock', 'Drum Solo', 'A Cappella',
'Euro-House', 'Dance Hall', 'Goa', 'Drum & Bass', 'Club-House', 'Hardcore', 'Terror', 'Indie',
'BritPop', 'Negerpunk', 'Polsk Punk', 'Beat', 'Christian Gangsta Rap', 'Heavy Metal',
'Black Metal', 'Crossover', 'Contemporary Christian', 'Christian Rock', 'Merengue', 'Salsa',
'Thrash Metal', 'Anime', 'JPop', 'Synthpop');


# log MP3INFO and make an M3U if we have to
sub mp3_complete ($$) {
	my ($complete, $total) = @_;

	opendir(DIR, $DIR) || error(2, "couldn't open $DIR: $!");
	my ($mp3) = sort grep /\.mp3$/i, readdir(DIR);
	closedir(DIR);
	error(2, "couldn't find an MP3") unless $mp3;

	($headref, $id3ref) = mp3_info($mp3);

	write_status($complete, $total);

	if ($conf{'mp3'}{'makem3u'}) {
		($m3u = $sfv) =~ s/\.sfv/\.m3u/;
		make_m3u($m3u);
	}
}

# make a new M3U file
sub make_m3u ($) {
	my $m3u = shift;

	print "<?> Making M3U... ";

	open(M3U, "> $m3u") || error(0, "couldn't open $m3u: $!");
	opendir(DIR, $DIR) || error(0, "couldn't open $DIR: $!");

	foreach my $mp3 (sort grep /\.mp3$/i, readdir(DIR)) {
		print M3U "$mp3\r\n";
	}

	closedir(DIR);
	close(M3U);

	print "done.\n\n";
}

# convert a binary string to an int
sub bin2dec ($) {
    return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
}

# unmangle the total size of the ID3v2 header
sub id3v2_size ($) {
	my $size = shift;
	my $newsize = 0;

	# I have no idea what this does, but it works
	for my $i (0..3) {
		my $mask = 0xff << ($i * 8);

		my $val = ($size & $mask ) >> ($i * 8);

		$newsize |= $val << ($i * 7);
	}

	return $newsize;
}

# retrieve info about an mp3
sub mp3_info ($) {
	my $file = shift;
	error(2, "no file to check") unless $file;

	my ($header, $id3);

	open (MP3, "< $file") || error(2, "couldn't open $file: $!");

	# read MP3 header
	read(MP3, $header, 4);

	# cope with an ID3v2 tag being at the start
	if (substr($header, 0, 3) eq 'ID3') {
		read(MP3, $header, 6, 4);

		my (undef, $major, $minor, $flags, $size) = unpack("a3CCB8N", $header);

		$size = id3v2_size($size) + (substr($flags, 3, 1) ? 10 : 0);
		read(MP3, $header, $size);

		read(MP3, $header, 4);
	}

	# read ID3 tag
	seek(MP3, -128, 2);
	read(MP3, $id3, 128);

	close(MP3);

	# parse header info
	my $bits = unpack("B*", $header);

	# unpack the parts
	$header{'mpeg'} = $mpeg[substr($bits, 12, 1)];
	$header{'layer'} = $layer[bin2dec(substr($bits, 13, 2))];
	$header{'bitrate'} = $bitrate{"$header{'mpeg'}:$header{'layer'}"}->[bin2dec(substr($bits, 16, 4))];
	$header{'mode'} = $mode[bin2dec(substr($bits, 24, 2))];

	# does it have an ID3 tag?
	unless (substr($id3, 0, 3) eq 'TAG') {
		print "<!> $file doesn't contain an ID3v1 tag\n";
		return \%header, undef;
	}

	# parse ID3 tag
	my @names = qw(tag songname artist album year comment genre);
	my @fields = unpack("a3a30a30a30a4a30C", $id3);

	my %id3;
	# unpack the parts
	for ($i = 1; $i <= $#fields; $i++) {
		$fields[$i] =~ s/^(.*?)\s*?\000.*$/$1/;

		$id3{$names[$i]} = $fields[$i];
	}

	$id3{'genre'} = $genres[$id3{'genre'}] || 'Unknown';
	$id3{'year'} ||= 'Unknown';

	# return references to our hashes of data
	return \%header, \%id3;
}


1;
