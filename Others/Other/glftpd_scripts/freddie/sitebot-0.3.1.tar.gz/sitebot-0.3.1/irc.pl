sub connect_to_irc {
	print "<?> Attempting to connect to IRC...\n";
	
	while (!$conn) {
		next_server();
		
		if ($conf{'bnc'}) {
			print "  <*> Bouncing to $conf{'bnc'}{'host'}:$conf{'bnc'}{'port'}... ";
			
			$conn = new IO::Socket::INET(
				PeerAddr	=> $conf{'bnc'}{'host'},
				PeerPort	=> $conf{'bnc'}{'port'},
				Proto		=> 'tcp',
				Timeout		=> 30,
			);
		}
		else {
			print "  <*> Connecting to $info{'server'}:$info{'port'}... ";
			
			$conn = new IO::Socket::INET(
				PeerAddr	=> $info{'server'},
				PeerPort	=> $info{'port'},
				Proto		=> 'tcp',
				Timeout		=> 30,
			);
		}
		
		print $conn ? "success!\n" : "failed.\n";
		
		$i++;
	}
	
	debug(3, "sending USER/NICK");
	$info{'cnick'} = 0;
	$info{'nick'} = $conf{'nicks'}->[$info{'cnick'}];
	$info{'stoned'} = 0;
	$info{'connected'} = 1;
	
	to_server("USER $conf{'irc'}{'ident'} $conf{'irc'}{'ident'} $conf{'irc'}{'ident'} :$conf{'irc'}{'realname'}");
	to_server("NICK $info{'nick'}");
}

sub reconnect_to_irc {
	print "<!> Disconnected.\n";
	$info{'connected'} = 0;
	$read_set->remove($conn);
	$conn->close();
	undef $conn;
	connect_to_irc();
	$read_set->add($conn);
}

sub next_server {
	if ($info{'server'} && $conf{'servers'}->[$info{'snum'}]) {
		$info{'snum'}++;
	}
	else {
		$info{'snum'} = 0;
	}
	
	($info{'server'}, $info{'port'}) = split(/:/, $conf{'servers'}->[$info{'snum'}]);
	$info{'port'} ||= 6667;
}

sub handle_connect {
	$info{'connected'} = 2;
	
	print "<?> Joining channels\n";
	foreach my $chan (grep /^\#/, keys %conf) {
		join_chan($chan);
	}
	
	add_timer(1, 60, 'stoned', \&stoned_check);
}

sub handle_privmsg ($$$) {
	my ($from, $to, $text) = @_;
	
	$from =~ /^(\S+)!/;
	$from = $1;
	
	# stoned check
	if ($from eq $to) {
		$info{'stoned'}--;
	}
	
	# channel message
	elsif ($to =~ /^\#/) {
		if ($text =~ /^$conf{'site'}{'trigger'}(\S+)/) {
			$command = "public_$1";
			if (defined &$command) {
				my @params = split(/\s+/, $text);
				shift(@params);
				&$command($to, @params);
			}
		}
	}
	
	# private ctcp, we don't respond to dirty channel ctcps
	elsif ($text =~ /^\001(.*)\001$/) {
		my ($ctcp, $params) = split(/\s+/, $1, 2);
		$ctcp = uc($ctcp);
		
		$params ||= '';
		debug(2, "CTCP $ctcp from $from");
		
		if ($ctcp eq 'PING' && $params =~ /^\d+$/) {
			to_server("NOTICE $from :\001$ctcp $params\001");
		}
		elsif ($ctcp eq 'VERSION') {
			my $ver = $conf{'irc'}{'versionreply'};
			$ver =~ s/<version>/$info{'ver'}/;
			to_server("NOTICE $from :\001$ctcp $ver");
		}
	}
}

sub handle_notice ($$$) {
	my ($from, $to, $text) = @_;
	
	if ($from =~ /^ezbounce!/ && $info{'connected'} == 1) {
		if ($text =~ /^Please use \/quote PASS/) {
			to_server("PASS $conf{'bnc'}{'pass'}");
			$info{'bnc'} = 1;
		}
		elsif ($text =~ /^Use \/quote CONN/ && $info{'bnc'} == 1) {
			to_server("IDENT $conf{'irc'}{'ident'}");
			to_server("VHOST $conf{'bnc'}{'vhost'}");
			$info{'bnc'} = 2;
		}
		elsif ($text =~ /^Ok\, binding your connections/ && $info{'bnc'} == 2) {
			print "  <*> Connecting to $info{'server'}:$info{'port'}... ";
			to_server("CONN $info{'server'} $info{'port'}");
			$info{'bnc'} = 3;
		}
		elsif ($text =~ /^Now connected to/ && $info{'bnc'} == 3) {
			print "success!\n";
			undef $info{'bnc'};
		}
		elsif ($info{'bnc'} == 3) {
			return if $text =~ /^Ok, attempting to/;
			print "failed.\n";
			next_server();
			print "  <*> Connecting to $info{'server'}:$info{'port'}... ";
			to_server("CONN $info{'server'} $info{'port'}");
			$info{'bnc'} = 3;
		}
	}
}

sub say ($$) {
	my ($chan, $output) = @_;
	return error(0, "no text passed") unless defined $output;
	my $type = $_[2] if $_[2];
	
	if ($chan) {
		if ($conf{$chan}{'output'} && $type) {
			my @types = split(/\s+/, $conf{$chan}{'output'});
			return unless grep { $_ eq $type } @types;
		}
		
		print "($chan) -> $output\n";
		to_server("PRIVMSG $chan :$output");
	}
	else {
		print "(All) -> $output\n";
		foreach my $chan (grep /^\#/, keys %conf) {
			if ($conf{$chan}{'output'} && $type) {
				my @types = split(/\s+/, $conf{$chan}{'output'});
				next unless grep { $_ eq $type } @types;
			}
			
			to_server("PRIVMSG $chan :$output");
		}
	}
}

# send text to server
sub to_server ($) {
	my $text = shift;
	return error(0, "no text passed") unless defined $text;
	
	if ($conn) {
		debug(10, ">>> $text");
		print $conn "$text\n";
	}
	else {
		reconnect_to_irc();
	}
}

sub join_chan {
	my ($chan, $invited) = @_;
	return error(0, "no channel passed") unless $chan;
	$invited ||= 0;
	
	debug(1, "joining $chan");
	if ($conf{$chan}{'invite'} && ! $invited) {
		to_server("$conf{$chan}{'invite'}");
	}
	elsif ($conf{$chan}{'key'}) {
		to_server("JOIN $chan $conf{$chan}{'key'}");
	}
	else {
		to_server("JOIN $chan");
	}
}


1;
