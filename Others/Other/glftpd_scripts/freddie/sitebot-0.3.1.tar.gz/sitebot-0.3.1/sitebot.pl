#!/usr/bin/perl -w

# ---------------------------------------------------
# Freddie's Sitebot                freddie@moocow.com
# ---------------------------------------------------
# Note that there are no docs yet and my web page sucks
# total ass... aah well. If you need help, I'm on EFnet
# as |Freddie| most of the time, sometimes in #glftpd
# ---------------------------------------------------


use Getopt::Std;
use IO::Socket;
use IO::Select;

use strict qw(vars);
use vars qw($conn $pid $read_set %conf %form %info);

# load the other files we need
require 'irc.pl';
require 'util.pl';


# my version, please don't change this :)
$info{'ver'} = 'v0.3.1';


start();


# ------------------------------------
# code below here, try not to break it
# ------------------------------------
sub start {
	# turn off buffered output
	$| = 1;
	
	# show the gimpy banner
	print "\nFreddie's Sitebot $info{'ver'}\n";
	print "------------------" . '-' x length($info{'ver'}) . "\n";
	
	# parse our arguments
	my %opts;
	getopts("bc:D:", \%opts);
	
	unless (defined $opts{'c'} && -e $opts{'c'}) {
		print "Usage: sitebot.pl [OPTIONS]\n\n";
		print "  -b          fork to background\n";
		print "  -c file     config file to use\n";
		print "  -D level    set the debug level\n\n";
		exit(1);
	}
	$info{'debug'} = defined $opts{'D'} ? $opts{'D'} : 1;
	
	# load our config files
	load_config($opts{'c'});
	
	# load any addons we have
	load_addons();
	
	# write our PID to a file if we need to
	if ($conf{'general'}{'pidfile'}) {
		open(PID, "> $conf{'general'}{'pidfile'}") || die $!;
		printf PID "%d\n", getppid();
		close PID;
	}
	
	# do we have to go into the background?
	if ($opts{'b'}) {
		print "Forking to background, have a nice day.\n";
		if (fork()) {
			exit(0);
		}
	}
	
	# fork time, one for the inet socket(s), one for the log
	FORK: {
		if ($pid = fork) {
			# parent
			irc_loop();
		}
		elsif (defined $pid) {
			# child
			log_loop();
		}
		elsif ($! =~ /No more process/) {
			# recoverable error
			sleep 5;
			redo FORK;
		}
		else {
			error(1, "couldn't fork: $!");
		}
	}
}

sub load_config {
	my $file = shift;
	parse_config($file);
	
	if ($conf{'dirs'}{'config'}) {
		my $dir = $conf{'dirs'}{'config'};
		opendir(CONF, $dir) || error(1, "couldn't open $dir/: $!");
		my @configs = grep /\.config$/i, readdir(CONF);
		closedir(CONF);
		
		foreach my $config (@configs) {
			parse_config("$dir/$config");
		}
	}
}

sub load_addons {
	if ($conf{'dirs'}{'addons'}) {
		my $dir = $conf{'dirs'}{'addons'};
		opendir(ADDON, $dir) || error(1, "couldn't open $dir/: $!");
		my @addons = grep { ! -d $_ } readdir(ADDON);
		closedir(ADDON);
		
		foreach my $addon (@addons) {
			debug(2, "loading addon $dir/$addon");
			require "$dir/$addon";
		}
	}
}

sub log_loop {
	sleep(1);
	
	my $ipc = new IO::Socket::UNIX(
		Type	=> SOCK_STREAM,
		Peer	=> '/tmp/sitebot_sock',
		Timeout	=> 5,
	) || error(1, "couldn't open UNIX socket: $!");
	
	my $file = "$conf{'dirs'}{'glftpd'}/ftp-data/logs/glftpd.log";
	open(LOG, "< $file") || error(1, "couldn't open $file: $!");
	seek(LOG, 0, 2) || error(1, "seek failed: $!");
	
	while (1) {
		while (<LOG>) {
			print $ipc $_;
		}
		sleep(1);
	}
}

sub irc_loop ($) {
	unlink '/tmp/sitebot_sock';
	
	my $ipc = new IO::Socket::UNIX(
		Type	=> SOCK_STREAM,
		Local	=> '/tmp/sitebot_sock',
		Listen	=> 10,
	) || error(1, "couldn't open UNIX socket: $!");
	
	my $client = $ipc->accept();
	
	$info{'server'} = '';
	$info{'port'} = 0;
	$info{'connected'} = 0;
	
	connect_to_irc();
	
	$read_set = new IO::Select();
	$read_set->add($client);
	$read_set->add($conn);
	
	my ($bnc, $data, $frag) = (0, '', '');
	while (1) {
		my @ready = $read_set->can_read(1);
		
		foreach my $fh (@ready) {
			if ($fh == $conn) {
				my $ret = sysread($conn, $data, 10240);
				if ($ret == 0) {
					reconnect_to_irc();
				}
				
				$data = $frag . $data if $frag;
				my @lines = split(/\n/, $data);
				$frag = (substr($data, -1) ne "\n" ? pop @lines : '');
				
				foreach my $line (@lines) {
					$line =~ s/[\r\n]//g;
					next unless $line;
					
					debug(10, "<<< $line");
					
					if ($line =~ /^PING :(.*)/) {
						# reply as soon as possible
						to_server("PONG :$1");
					}
					elsif ($line =~ /^:\S+ (\d\d\d)/) {
						my $numeric = $1;
						if ($numeric == '433') {
							if ($info{'connected'} == 2) {
								add_timer(0, 30, 'getnick', sub { to_server("NICK $conf{'nicks'}->[0]") });
							}
							else {
								$info{'cnick'}++;
								if ($info{'cnick'} > @{ $conf{'nicks'} }) {
									print "<!> Out of nicks, improvising...\n";
									$info{'cnick'} = 0;
									$info{'nick'} = $conf{'nicks'}->[$info{'cnick'}];
									if (length($info{'nick'}) >= 9) {
										substr($info{'nick'}, 8, 1) = '-';
									}
									else {
										$info{'nick'} .= '-';
									}
								}
								else {
									$info{'nick'} = $conf{'nicks'}->[$info{'cnick'}];
								}
								
								to_server("NICK $info{'nick'}");
								add_timer(0, 30, 'getnick', sub { to_server("NICK $conf{'nicks'}->[0]") }) unless $info{'timers'}{'getnick'};
							}
						}
						# end of MOTD / no MOTD
						elsif ($numeric == '376' || $numeric == '422') {
							handle_connect();
						}
						elsif ($numeric == '437') {
							$line =~ /^:\S+ 437 \S+ (\#\S+)/;
							
							add_timer(0, 30, "join_$1", sub { join_chan($1) });
						}
					}
					elsif ($line =~ /^:(\S+)!\S+ NICK :(\S+)$/) {
						my ($oldnick, $newnick) = ($1, $2);
						if ($oldnick eq $info{'nick'}) {
							$info{'nick'} = $newnick;
							debug(2, "changed my nick to $newnick");
						}
					}
					elsif ($line =~ /^:(\S+) PRIVMSG (\S+) :(.*)/) {
						handle_privmsg($1, $2, $3);
					}
					elsif ($line =~ /^:(\S+) NOTICE (\S+) :(.*)/) {
						handle_notice($1, $2, $3);
					}
					elsif ($line =~ /^:\S+ INVITE (\S+) :(\#\S+)/) {
						my ($who, $chan) = ($1, lc($2));
						if ($conf{$chan}) {
							debug(1, "$who invited me to $chan, joining");
							join_chan($chan, 1);
						}
						else {
							debug(1, "$who invited me to $chan, not joining");
						}
					}
					elsif ($line =~ /^:\S+ KICK (\#\S+) (\S+)/) {
						my ($chan, $who) = (lc($1), $2);
						next unless $who eq $info{'nick'};
						
						debug(1, "$who kicked me from $chan, trying to rejoin");
						join_chan($chan, 1);
					}
				}
			}
			elsif ($fh == $client) {
				my $data;
				my $ret = sysread($client, $data, 10240);
				error(1, "IPC disconnected") if $ret == 0;
				
				foreach my $line (split(/\n/, $data)) {
					$line =~ s/[\r\n]//g;
					
					my (undef, undef, undef, $time, undef, $type, $rest) = split(/\s+/, $line, 7);
					if ($form{$type}) {
						my ($output, $hashref) = interpolate($type, $rest, $time);
						
						# don't say anything about INCOMPLETE/COMPLETED dirs
						if ($type =~ /^...DIR:$/ && $hashref->{'rel'}) {
							next if $hashref->{'rel'} =~ /COMPLETE/;
						}
						
						# don't echo some dirs
						if ($hashref->{'dir'} && $conf{'dirs'}{'blocked'}) {
							next if grep { $hashref->{'dir'} =~ m#^$_# } split(/\s+/, $conf{'dirs'}{'blocked'});
						}
						
						say('', $output, $type) if $output;
						
						if ($type eq 'COMPLETE:' && $hashref->{'files'} > 1) {
							my (%files, %users);
							open(SPEED, "< $conf{'dirs'}{'glftpd'}/$hashref->{'dir'}/.speed") || error(0, "couldn't open .speed file: $!");
							while (<SPEED>) {
								s/[\r\n]//g;
								my @stuff = split;
								
								$files{$stuff[0]} = $_;
							}
							close SPEED;
							
							foreach my $file (keys %files) {
								my @stuff = split(/\s+/, $files{$file});
								$users{$stuff[3]}{'files'}++;
								$users{$stuff[3]}{'size'} += $stuff[1];
								$users{$stuff[3]}{'time'} += $stuff[1] / $stuff[2];
								$users{$stuff[3]}{'group'} = $stuff[4];
							}
							my @order = sort { $users{$b}{'size'} <=> $users{$a}{'size'} } keys %users;
							
							my $racers = $#order + 1;
							next if $racers == 1;
							
							my $pos = 0;
							my $output = interpolate('RACE:', $racers, $time);
							foreach my $racer (@order) {
								$pos++;
								$users{$racer}{'speed'} = int($users{$racer}{'size'} / $users{$racer}{'time'});
								$output .= (interpolate('RACER:', "$pos $racer $users{$racer}{'group'} $users{$racer}{'files'} $users{$racer}{'size'} $users{$racer}{'speed'}", $time))[0];
							}
							
							say('', $output);
						}
						elsif ($type eq 'NUKE:' || $type eq 'UNNUKE:') {
							$info{'nuke'}{$hashref->{'rel'}}{'start'} ||= time;
							$info{'nuke'}{$hashref->{'rel'}}{'type'} ||= $type;
							$info{'nuke'}{$hashref->{'rel'}}{'time'} ||= $hashref->{'time'};
							$info{'nuke'}{$hashref->{'rel'}}{'multi'} ||= $hashref->{'multi'};
							$info{'nuke'}{$hashref->{'rel'}}{'size'} += $hashref->{'size'};
							$info{'nuke'}{$hashref->{'rel'}}{'nuker'} ||= $hashref->{'nuker'};
							foreach my $nukee (split(/s+/, $hashref->{'nukees'})) {
								push @{ $info{'nuke'}{$hashref->{'rel'}}{'nukees'} }, "$nukee \($hashref->{'size'}MB\)";
							}
							$info{'nuke'}{$hashref->{'rel'}}{'reason'} ||= $hashref->{'_reason'};
						}
						elsif ($type eq 'INVITE:') {
							debug(1, "$hashref->{'user'}\@$hashref->{'group'} invited $hashref->{'group'} to $info{'primchan'}");
							to_server("INVITE $hashref->{'nick'} $info{'primchan'}");
						}
					}
				}
			}
		}
		
		# do we have any timers waiting to go off?
		if (keys %{ $info{'timers'} }) {
			foreach my $timer (keys %{ $info{'timers'} }) {
				my $timerref = $info{'timers'}{$timer};
				next unless (scalar time - $timerref->{'nextgo'}) >= 0;
				
				debug(3, "timer '$timer' triggered");
				
				if ($timerref->{'forever'}) {
					$timerref->{'nextgo'} = scalar time + $timerref->{'secs'};
					&{ $timerref->{'coderef'} };
				}
				else {
					&{ $timerref->{'coderef'} };
					delete $info{'timers'}{$timer};
				}
			}
		}
		
		# do we have a nuke waiting to go off?
		if (keys %{ $info{'nuke'} }) {
			foreach my $nuke (keys %{ $info{'nuke'} }) {
				my $nukeref = $info{'nuke'}{$nuke};
				next unless (time - $nukeref->{'start'}) >= 1;
				
				my $out = "$nuke $nukeref->{'nuker'} $nukeref->{'multi'} $nukeref->{'size'} \"";
				$out .= join("\, ", @{ $nukeref->{'nukees'} });
				$out .= "\" \"$nukeref->{'reason'}\"";
				print "$out\n";
				my ($output) = interpolate("REAL$nukeref->{'type'}", $out, $nukeref->{'time'});
				say('', $output);
				
				delete $info{'nuke'}{$nuke};
			}
		}
		
		# is this server stoned?
		if ($info{'stoned'} >= 2) {
			print "<!> This server is stoned, reconnecting\n";
			reconnect_to_irc();
		}
	}
}

sub stoned_check {
	$info{'stoned'}++;
	debug(5, "stoned check");
	to_server("PRIVMSG $info{'nick'} :Stoned Check");
}


# need to return true
1;
