sub error {
	my ($splat, $msg) = @_;
	
	($file, $line) = (caller(0))[1,2];
	my $by = (caller(1))[3];
	
	$file =~ s/^.*\///;
	$by =~ s/^.*:://;
	
	my $type = $splat ? 'FATAL:' : 'ERROR:';
	print "$type\($by, $file:$line\) - $msg\n";
	exit(1) if $splat;
	
	return;
}

sub debug {
	my ($level, $msg) = @_;
	return if $level > $info{'debug'};
	
	my $by = (caller(1))[3];
	$by =~ s/^.*:://;
	
	print "DEBUG($level, $by): $msg\n";
}

# -------------------------------------------------
# add_timer(forever, secs, name, subref)
# -------------------------------------------------
# Params:
#   forever		= keep going forever (0/1)
#   secs		= how many seconds until we trigger
#   name		= name to refer to the timer as
#   subref		= reference to some code to execute
# -------------------------------------------------
sub add_timer ($$$$) {
	my ($forever, $secs, $name, $subref) = @_;
	return error(0, "bad parameters") unless defined $forever && $secs && $name && $subref;
	return error(0, "timer '$name' already exists") if $info{'timers'}{$name};
	
	$info{'timers'}{$name} = {
		forever	=> $forever,
		secs	=> $secs,
		nextgo	=> time + $secs,
		coderef	=> $subref,
	};
}

sub del_timer ($) {
	my $name = shift;
	return unless $info{'timers'}{$name};
	delete $info{'timers'}{$name};
}

sub parse_config {
	my $file = shift;
	error(1, "$file doesn't exist!") unless -e $file;
	
	open(CONF, "< $file") || error(1, "couldn't open $file: $!");
	
	debug(2, "parsing config file $file");
	
	my ($cname, $ctype);
	while (<CONF>) {
		# clean up the input
		s/[\r\n]//g;
		s/^\s+//;
		s/\s+$//;
		next unless $_;
		next if /^\#/;
		
		# start of a block?
		if (/^(\S+) (\S+) \{$/) {
			error(1, "failed parsing $file: '$ctype $cname` is not closed") if $ctype || $cname;
			($ctype, $cname) = ($1, $2);
			if ($ctype ne 'list' && $ctype ne 'options' && $ctype ne 'format') {
				error(1, "invalid option type '$ctype' at $file line $.");
			}
			
			$info{'primchan'} = $cname if $cname =~ /^\#/;
		}
		
		# end of a block?
		elsif (/^\}$/) {
			error(1, "unmatched closing bracket at $file line $.") unless $ctype && $cname;
			undef $ctype;
			undef $cname;
		}
		
		# anything else
		else {
			if ($ctype eq 'list') {
				push @{ $conf{$cname} }, $_;
			}
			elsif ($ctype eq 'options') {
				my ($opt, $set) = split(/=/, $_, 2);
				error(1, "invalid option in '$ctype $cname': $_ at $file line $.") unless $opt && $set;
				$conf{$cname}{$opt} = $set;
			}
			elsif ($ctype eq 'format') {
				my ($opt, $set) = split(/=/, $_, 2);
				error(1, "invalid option in '$ctype $cname': $_ at $file line $.") unless $opt && $set;
				$form{$cname}{$opt} = $set;
			}
		}
	}
	
	close(CONF);
}

sub interpolate {
	my ($type, $rest) = (shift, shift);
	my %bits = (
		time	=> shift,
		siteshort	=> $conf{'site'}{'short'},
		sitelong	=> $conf{'site'}{'long'},
	);
	
	my $input;
	if ($form{$type}{'in'}) {
		$input = $form{$type}{'in'};
		
		my @parts = qw(blah);
		while ($input =~ /<(.*?)>/g) {
			my $part = $1;
			
			push @parts, $part;
			
			my $match;
			if ($part =~ /^_/) {
				$match = '(.*?)';
			}
			else {
				$match = '(\S*?)';
			}
			
			$input =~ s/<$part>/$match/;
		}
		
		$rest =~ /$input/;
		for (my $i = 1; $i <= $#parts; $i++) {
			$bits{$parts[$i]} = $$i;
		}
		
		if ($bits{'dir'}) {
			$bits{'dir'} =~ m#.*/(.*?)/(.*?)$#;
			$bits{'base'} = $1;
			$bits{'rel'} = $2;
		}
		
		$bits{'group'} = 'unknown' if defined $bits{'group'} && ! $bits{'group'};
	}
	
	my $output;
	if ($form{$type}{'out'}) {
		$output = $form{$type}{'out'};
		
		while ($output =~ /<(.*?)>/g) {
			my $old = $1;
			next if $old eq 'b' || $old eq 'u';
			
			my $new = $bits{$old};
			next unless defined $new;
			
			$output =~ s/<$old>/$new/;
		}
		
		# replace bold/underline codes with the actual chars
		$output =~ s/<b>/\002/g;
		$output =~ s/<u>/\037/g;
	}
	else {
		$output = '';
	}
	
	return wantarray ? ($output, \%bits) : $output;
}


1;
