#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_SIZE 255
#define SEARCH_STR "genre"

/* Space dlimited list of words that can't be genre themselves */
/* This is done in order to prevent errors from .nfo scan when genre field is left empty */
#define CANT_BE_GENRE "genre format audio encode resolution year music video"

/* Prototypes */
int GenreIsFine(char* str);
void NormalizeStr(char* str);

/* Arguments: <path_to_the_pre_dir> <info_file> */
int main(int argc, char ** argv) {

 FILE * f;
 char fullpath[MAX_LINE_SIZE];
 char line[MAX_LINE_SIZE];
 char chkline[MAX_LINE_SIZE];
 char gnrline[MAX_LINE_SIZE];
 int found_genre = 0;
 char * foundpos;
 int i, n, k, j;

 /* Checking the external arguments */
 if (argc < 3 ) {
   printf("Error! Not enough parameters ...\n");
   printf("Syntax: %s <path_to_the_pre_dir> <info_file>\n", argv[0]);
   return(1);
 }
 else {
   /* Opening the file */
   strcpy(fullpath, argv[1]);
   strcat(fullpath,"/");
   strcat(fullpath, argv[2]);
   f = fopen(fullpath, "r");
   if (f == NULL) {
     strcpy(fullpath, argv[1]);
         strcat(fullpath, "/CD1/");
         strcat(fullpath, argv[2]);
     f = fopen(fullpath, "r");
         if (f == NULL) {
                 strcpy(fullpath, argv[1]);
                 strcat(fullpath, "/Cd1/");
                 strcat(fullpath, argv[2]);
                 f = fopen(fullpath, "r");
             if (f == NULL) {
                         strcpy(fullpath, argv[1]);
                         strcat(fullpath, "/cd1/");
                         strcat(fullpath, argv[2]);
                         f = fopen(fullpath, "r");
                         if (f == NULL)
                                 return 0;
                 }
         }

   }

   /* Scan loop */
   while (!(feof(f)) && (!found_genre)) {
 	if (fgets(line, MAX_LINE_SIZE, f) != NULL) {
		strcpy(chkline, line);
		n = strlen(chkline);
		for (i=0; i<n; i++)
			if (isalpha(chkline[i]))
				chkline[i] = tolower(chkline[i]);
		if ((foundpos=strstr(chkline, SEARCH_STR)) != NULL)
			found_genre = 1;
	}
   }

   /* The result */
   if (!found_genre)
   	printf("Unknown");
   else {
      	/* Retrieving the data */
	strcpy(gnrline, "");
	found_genre = 0;
	j = 0;
	k = strlen(SEARCH_STR);
	for(i=(n-strlen(foundpos)+k); i<n && !found_genre; i++) {
		if ((isalpha(line[i])) || (((line[i] == ' ') || (line[i] == '-') || (line[i] == '&')) && (i != n-1) && (isalpha(line[i+1])))) {
			gnrline[j] = line[i];
			j++;
		}
		if ((j != 0) && (!isalpha(line[i])) && (i != n-1) && (!isalpha(line[i+1]))) {
			found_genre = 1;
		}
	}
	gnrline[j] = '\0';

	/* Printing the result */
	if ((gnrline[0] == ' ') || (gnrline[0] == '-')) {
		if (GenreIsFine(gnrline+1)) {
			NormalizeStr(gnrline+1);
   			printf("%s", gnrline+1);
		}
		else
			printf("Unknown");
	}
	else {
		if (GenreIsFine(gnrline)) {
			NormalizeStr(gnrline);
   			printf("%s", gnrline);
		}
		else
			printf("Unknown");
	}
   }

   /* Closing the file */
   fclose(f);

   /* Completed sucessfully, ERRORLEVEL 0 is out */
   return 0;
 }
}

int GenreIsFine(char* str) {
	int i, n;
	char chkstr[MAX_LINE_SIZE];

	strcpy(chkstr, str);
	n = strlen(chkstr);
	for (i=0; i<n; i++)
		if (isalpha(chkstr[i]))
			chkstr[i] = tolower(chkstr[i]);
	if (strstr(CANT_BE_GENRE, chkstr) == NULL)
		return 1;
	else
		return 0;
}

void NormalizeStr(char* str) {
	int i, n;
	char first[MAX_LINE_SIZE];
	char second[MAX_LINE_SIZE];

	n = strlen(str);
	for (i=1; i<n; i++)
		if ((isupper(str[i])) && (islower(str[i-1]))) {
			strncpy(first, str, i);
			first[i] = '\0';
			strncpy(second, str+i, n-i);
			second[n-i] = '\0';
			strcpy(str, first);
			strcat(str, "-");
			strcat(str, second);
			str[n+1] = '\0';
		}
	str[0] = toupper(str[0]);
	for (i=1; i<n; i++)
		if ((str[i-1] == ' ') || (str[i-1] == '-') || (str[i-1] == '&'))
			str[i] = toupper(str[i]);
		else
			str[i] = tolower(str[i]);
	if (strcmp(str, "Top") == 0) {
		strcpy(str, "Top 40");
		str[6] = '\0';
	}
	if (strcmp(str, "Rnb") == 0) {
		strcpy(str, "R&B");
		str[3] = '\0';
	}
	if ((strcmp(str, "Hip Hop") == 0) || (strcmp(str, "Hiphop") == 0)) {
		strcpy(str, "Hip-Hop");
		str[7] = '\0';
	}
	if (strcmp(str, "Na") == 0) {
		strcpy(str, "Unknown");
		str[7] = '\0';
	}
	if (strcmp(str, "Alt") == 0) {
		strcpy(str, "Alt. Rock");
		str[9] = '\0';
	}

}

