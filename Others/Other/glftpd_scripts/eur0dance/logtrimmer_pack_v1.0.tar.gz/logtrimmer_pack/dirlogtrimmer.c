#include <sys/param.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <syslog.h>
#include <sys/file.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdio.h>
#include <time.h>

#define DIRLOGFILEPATH "/ftp-data/logs/dirlog"
#define NEWDIRLOGFILEPATH "/ftp-data/logs/dirlog.new"

struct dirlog {
        ushort status;     // 0 = NEWDIR, 1 = NUKE, 2 = UNNUKE, 3 = DELETED
        time_t uptime;
        ushort uploader;    /* Libc6 systems use ushort in place of uid_t/gid_t */
        ushort group;
        ushort files;
        long bytes;
        char dirname[255];
        struct dirlog *nxt;
        struct dirlog *prv;
};
	
int main (int argc, char *argv[]) {
   FILE *fp1, *fp2 ;
   struct dirlog buffer;
   long position;
   int numrecords = 0, counter = 0;
   int numrectoleave;
   char command[1024];

   if (argc != 2) {
     printf("Error! Not enough parameters: %s <num_of_last_records_to_leave>\n", argv[0]);
     return 1;
   }

   if((fp1 = fopen(DIRLOGFILEPATH, "r")) == NULL) {
     printf("Unable to open dirlog (reading)");
     return 1;
   }

   if((fp2 = fopen(NEWDIRLOGFILEPATH, "w")) == NULL) {
     printf("Unable to open dirlog (writing)");
     return 1;
   }

   numrectoleave=atoi(argv[1]);
  
   while(!feof(fp1)) {
     if (fread(&buffer, sizeof(struct dirlog), 1, fp1) < 1)
       break;
     numrecords++;
   }   

   fseek(fp1, SEEK_SET, 0);

   while(!feof(fp1)) {
     if (fread(&buffer, sizeof(struct dirlog), 1, fp1) < 1)
       break;
     counter++;
     if (counter >= numrecords-numrectoleave+1)
       if (fwrite(&buffer, sizeof(struct dirlog), 1, fp2) < 1) {
         printf("Couldn't write to dirlog! Disk full?\n");
         break;
       }   
   }
   fclose(fp1);
   fflush(fp2);
   fclose(fp2);
   chmod(NEWDIRLOGFILEPATH, 438); /* chmod a+rw */
   sprintf(command, "mv -f %s %s", NEWDIRLOGFILEPATH, DIRLOGFILEPATH); 
   system(command);
   return 0;
}

