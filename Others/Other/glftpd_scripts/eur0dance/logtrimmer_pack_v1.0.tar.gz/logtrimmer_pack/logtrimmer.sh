#!/bin/sh
# Version 1.0 by eur0dance
#
# This script should be used in order not to let your glftpd related logs to fill your partition.
# Glftpd & zipscript logs are being trimmered.
#
# Installation:
# ~~~~~~~~~~~~~
# (1)
# ls, expr, awk, rm, touch, chmod, echo, du, basename binaries should be inside your glftpd bin directory.
# (2)
# Edit the CONFIG section, don't touch the CODE section, unless you really know what you're doing.
# (3)
# In order to make the script work you should crontab it like this for example:
# 0 2 * * *  /glftpd/bin/logtrimmer.sh >/dev/null 2>&1

### CONFIG ###

# The directory which holds glftpd logs (absolute path)
logfilespath="/glftpd/ftp-data/logs"

# The directory which holds your zipscript logs (by default I took zipscript-c logs path)
zipscriptlogpath="/glftpd/ftp-data/zipscript/site"

# This is the quota value, in Kbytes - all logs apart from "dirlog" and "dupelog" which
# size is more than this will be trimmered.
kbquota=1024

# This is the quota value, in Mbytes - if zipscript logs take more than this they will be cleaned. 
zipscriptlogquota=25


### CODE ###

KB="KB"
MB="MB"
for logfile in $logfilespath/*; do
	fbytessize=`ls -l $logfile | awk '{print $5}'`
	fkbsize=`expr $fbytessize / 1024`
	fname=`basename $logfile`
	if [ $fkbsize -gt $kbquota ]; then
		if [ "$fname" != "dupelog" -a "$fname" != "dirlog" ]; then
			echo "Removing $logfile cause its size now is $fkbsize$KB and the quota is $kbquota$KB ..."
			rm -f $logfile
			touch $logfile
			chmod a+rw $logfile				
		fi
	fi
done
zipscriptlogsize=`du -sm $zipscriptlogpath | cut -f1`
if [ $zipscriptlogsize -gt $zipscriptlogquota ]; then
        echo "Removing $zipscriptlogpath cause its size now is $zipscriptlogsize$MB and the quota is $zipscriptlogquota$MB ..."
        rm -rf $zipscriptlogpath
fi
