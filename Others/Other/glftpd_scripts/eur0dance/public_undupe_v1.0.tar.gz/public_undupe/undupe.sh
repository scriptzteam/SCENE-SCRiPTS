#!/bin/sh
# Version 1.0 - by eur0dance
#
# This script performs public undupe of a certain file - $1
# This would be done by performing !<sitename>undupe command on the site channel. 
# Everybody can perform it, so be careful and punish the abuse. 
#
# Notes:
# ~~~~~~
# The script can't be used as standalone, it should be binded and called from your sitebot tcl.
# Read more about this inside README file.
#
# Installation:
# ~~~~~~~~~~~~~
#       My assumption is that your glftpd bin path is /glftpd/bin, if not just edit the "binpath" variable
#       inside the CONFIG section and treat the following with your glftpd bin path instead of the /glftpd/bin.
#       Also, same thing is about /glftpd/ftp-data.
#
#       1.
#       Put this file inside /glftpd/bin. Make sure you have there these binaries: grep, dupelist, cut, undupe
#       2. 
#       /glftpd/ftp-data/logs/dupefile must be in 666 permissions mode: chmod 666 dupefile
#       3.       
#       /glftpd/bin/undupe must exist, should have effective uid permission: chmod +s undupe
#       4.  
#       /glftpd/bin/undupe should have the same ownership group as /glftpd/ftp-data/logs dir and as
#       /glftpd/ftp-data/logs/dupefile file - or for example make them all in "users" group
#       5.
#       If the group you picked for the above is "users" then do this: chown -R root:users /glftpd/ftp-data/logs
#       6.
#       /glftpd/ftp-data/logs dir should have +w for group permissions: chmod g+w /glftpd/ftp-data/logs
#       7. 
#       Edit the CONFIG section below, don't touch the CODE section unless you really know what you're doing.
 
### CONFIG ###

sitename=dS

syntaxmsg="\002undupe <filename>\002 (Don't abuse, as it will result in deluser)"

username=glftpd

binpath=/glftpd/bin


### CODE ####

if [ $# = 1 ] ; then
  num_found=`$binpath/dupelist | cut -f1 | grep -c $1`
  if [ $num_found -eq 0 ]; then
    echo -e "Error! \002$1\002 doesn't exist in the dupefile."
  else
    $binpath/undupe -u $username -f $1 >/dev/null 2>&1
    echo -e "Done. \002$1\002 has been successfully unduped!"
  fi
else
   echo -e "\002Error!\002 Wrong syntax. Usage: \002!$sitename\002$syntaxmsg"
fi
