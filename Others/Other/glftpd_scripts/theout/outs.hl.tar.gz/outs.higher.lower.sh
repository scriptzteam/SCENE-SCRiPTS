#!/bin/bash 
# PUBLIC Casino glftpd scripts..
#
# 4:higher/lower (current script..choose higher or lower) <-- public 
# 8:tombola      (just tombola)  <-- public
#
# Middle in a movement from house..no internet..so lets code something funny.
# Kinda easy thing , just 5 times , 2 are given , three times you can choose
# if its higher or lower.... all good means 2x the default bet.
# losing means removal of credits.
#
#
# Add to glftpd.conf following lines :
#
# site_cmd highlow	     EXEC    /bin/outs.higher.lower.sh
# custom-slots !8 *
#
# copy this script (outs.higher.lower.sh) to your /glftpd/bin/ dir and make sure its chmodded
# check for following binarys into your /glftpd/bin/ dir (awk,echo,cat.etc.etc)
# when you run the script and see a lot of errors , then you know you miss something :P
#
# glftpd users dir
userdir=/ftp-data/users
#glftpd logdir (make sure its writable for all scripts (chmod 777)
gllog=/ftp-data/logs/glftpd.log
higherlog=/ftp-data/logs/higher.lower.log
# allow users on leech to play? 0=no 1=yes
allowleech=0
# allow users to get under 0 credits on when losing? 0=no 1=yes
allowzero=0
##
## default jackpot = 0 (nothing ,zip,zero..)
jackpot=0
#
# * times the bet yets payed on win
times=2
#
# Gamble between numbers 0 and :
gamble=10
#
# (c) 2002 by TheOut!
# 
# And remember.. make backups of your files.. before running the script
# you never know what happens and im not the one who forces you to use 
# this scripts :)
#
# enjoy!
#
[ $PWD = /glftpd/bin ] && {
userdir=/glftpd/ftp-data/users
gllog=/glftpd/ftp-data/logs/glftpd.log
higherlog=/glftpd/ftp-data/logs/higher.lower.log
USER=TheOut
GROUP=SiteOps
TAGLINE=TESTING
}
# Lets write Top message
	echo ",------------------------------------------------------------------."
	echo "| TheOuts Higher Lower V1.0  Glftpd ready.!                        |"
	echo "|------------------------------------------------------------------|"
if [ "$1" != "start" ] && [ "$1" != higher ] && [ "$1" != lower ] && [ "$1" != abort ];then
	echo "| Usage 'site highlow start <bet in mb>'                           |"
	echo "|        (i.e.  site highlow start 500) for a 500mb bet            |"
	echo "|       'site highlow higher'                                      |"
	echo "|       'site highlow lower'                                       |"
	echo "|                                                                  |"
	echo "| You get total of 5 numbers , first 2 numbers are given and its   |"
	echo "| up to you to tell if the next number is higher or lower then     |"
	echo "| the last given number. equal numbers are disabled so it always   |"
	echo "| be higher or lower. Numbers are between 1 and 10.                |"
	echo "| all 3 times good answer means 3x your given bet :P               |"
	echo "| Credits will be added or removed at end of the fifth choose.     |"
	echo "| abort option is 'site highlow abort' and will result in 50% of   |"
	echo "| bet lost.                                                        |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0
fi
if [ $1 = start ];then
if [ -f /tmp/$USER ];then
	echo "|                                                                  |"
	echo "| Sorry a game is already running.                                 |"
	echo "|       'site highlow higher'                                      |"
	echo "|       'site highlow lower'                                       |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0
fi
#play the first 2 numbers...
# Check if credits is high enough to loose and NOT get under zero..
creds=`cat $userdir/$USER|grep "^CREDITS"|awk '{print $2}'`
ratio=`cat $userdir/$USER|grep "^RATIO"|awk '{print $2}'`
if [ $ratio = 0 ] && [ $allowleech = 0 ];then
	echo "|                                                                  |"
	echo "| Sorry not allowed to play on leech accounts.                     |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0
fi
case $2 in
	[0-9][0-9][0-9][0-9])
	check=1;;
	[0-9][0-9][0-9])
	check=1;;
	[0-9][0-9])
	check=1;;
	[0-9])
	check=1;;
	*)
	echo "|                                                                  |"
	echo "| Sorry only numeric numbers are allowed to give as bet amount     |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0 ;;
esac
if [ "$2" -gt "2500" ];then
        echo "|                                                                  |"
        echo "| Sorry not allowed to play higher then 2500 mb                    |"
        echo "|                                                                  |"
        echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
        echo "'------------------------------------------------------------------'"
        exit 0 
fi
bet=`expr $2 \* 1024`
if [ "`expr $creds - $bet`" -lt "0" ] && [ $allowzero = 0 ];then
        echo "|                                                                  |"
        echo "| Sorry not enough credits to play this game.                      |"
        echo "|                                                                  |"
        echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
        echo "'------------------------------------------------------------------'"
        exit 0
fi
# now finaly all passed and ready to give user 22 numbers to play with
numberone=$[RANDOM % $gamble]
numbertwo=$[RANDOM % $gamble]
	echo "|                                                                  |"
printf "%23s %2s %3s %2s %34s\n" "| First 2 numbers are :" "$numberone" "and" "$numbertwo" "|"
#	echo "| First 2 numbers are : $numberone and $numbertwo                                    |"
	echo "| now up to you to deside if next number will be higher or lower.  |"
	echo "|       'site highlow higher'                                      |"
	echo "|       'site highlow lower'                                       |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	echo "$2:2:$numbertwo" >> /tmp/$USER
	exit 0
fi
#
# Done with start part... now go to the "higher" and "lower" part....
if [ "$1" = higher ] || [ "$1" = lower ];then
[ -f /tmp/$USER ] || {
	echo "| Sorry no game running yet..                                      |"
	echo "| Usage 'site highlow start <bet in mb>'                           |"
	echo "|        (i.e.  site highlow start 500) for a 500mb bet            |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0
}
fi
bet=`cat /tmp/$USER | awk -F : '{print $1}'`
betkb=`expr $bet \* 1024`
time=`cat /tmp/$USER | awk -F : '{print $2}'`
lastnr=`cat /tmp/$USER | awk -F : '{print $3}'`
numberone=0
while [ "$numberone" -lt "1" ] || [ $numberone = $lastnr ] || [ "$numberone" -gt "$gamble" ];do
  numberone=$[RANDOM % $gamble]  
done

if [ "$1" = higher ];then
  check=gt
elif [ "$1" = lower ];then
  check=lt
fi
printf "%12s %2s %10s %41s\n" "| New number" "$numberone" "that means" "|"
#	echo "| New number $numberone that means :                                        |"
	echo "|                                                                  |"
if [ "$numberone" -"$check" "$lastnr" ];then
  if [ $time = 4 ];then
	echo "| 0wnage! you got it right..nice nice... now you Won the game!     |"
	echo "| $times x your bet... have a nice leeeeeech time :)                    |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	betkb=`expr $betkb \* $times`
	ukb=`grep "^CREDITS" $userdir/$USER|awk '{print $2}'`
	cat $userdir/$USER|grep -v "^CREDITS" >> $userdir/$USER.temp
	user1kb=`expr $ukb + $betkb`
	echo "CREDITS $user1kb" >> $userdir/$USER.temp
	mv $userdir/$USER.temp $userdir/$USER
	rm -f /tmp/$USER
	echo `date "+%a %b %d %T %Y"` HLWINNER: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $higherlog
	echo `date "+%a %b %d %T %Y"` HLWINNER: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $gllog
	else
	echo "| 0wnage! you got it right..nice nice... now do it again...        |"
	echo "| Usage: 'site highlow higher' or 'site highlow lower'             |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	echo "$bet:$[time + 1]:$numberone" > /tmp/$USER
	exit 0
  fi
else
	echo "| Damn..more luck next time ? yeah..prolly.                        |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	ukb=`grep "^CREDITS" $userdir/$USER|awk '{print $2}'`
	cat $userdir/$USER|grep -v "^CREDITS" >> $userdir/$USER.temp
	user1kb=`expr $ukb - $betkb`
	echo "CREDITS $user1kb" >> $userdir/$USER.temp
	mv $userdir/$USER.temp $userdir/$USER
	rm -f /tmp/$USER
	echo `date "+%a %b %d %T %Y"` HLLOSER: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $higherlog
	echo `date "+%a %b %d %T %Y"` HLLOSER: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $gllog
	exit 0
fi
if [ $1 = abort ];then
[ -f /tmp/$USER ] || {
	echo "| Sorry no game running yet..                                      |"
	echo "| Usage 'site highlow start <bet in mb>'                           |"
	echo "|        (i.e.  site highlow start 500) for a 500mb bet            |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"
	exit 0
}
bet=`cat /tmp/$USER | awk -F : '{print $1}`
betkb=`expr $bet \* 1024`
betkb=`expr $betkb / 2`
	ukb=`grep "^CREDITS" $userdir/$USER|awk '{print $2}'`
	cat $userdir/$USER|grep -v "^CREDITS" >> $userdir/$USER.temp
	user1kb=`expr $ukb - $betkb`
	echo "CREDITS $user1kb" >> $userdir/$USER.temp
	mv $userdir/$USER.temp $userdir/$USER
	rm -f /tmp/$USER
	echo `date "+%a %b %d %T %Y"` HLABORT: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $higherlog
	echo `date "+%a %b %d %T %Y"` HLABORT: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$bet\" >> $gllog
	echo "| Succesfully game aborted.                                        |"
	echo "|                                                                  |"
	echo "| TheOuts Higher Lower Casino game V1.0 (c) 2002                   |"
	echo "'------------------------------------------------------------------'"

	exit 0
fi
