/*
 * nihilredir
 * simple ftp boucer - coded by nihil 09/27/2001
 *
 * config file:
 *
 * target IP   target port
 * bouncer will cycle through IPs one after one
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define NBLISTEN 10

#define TBUFFER 1024
#define TBUF_INET 4096


typedef struct {
  struct in_addr ip_dest;
  u_short port_dest;
} t_ip_redirect;
int nb_ip_redirect = 0;
t_ip_redirect *ip_redirect_list;

FILE *logfile;

extern int errno;


int read_ip_file(char *ipfilename)
{
  FILE *fic;
  char ip_dest[TBUFFER],
    port_dest[TBUFFER];


  if ((fic = fopen(ipfilename, "r")) == NULL) {
    perror(ipfilename);
    return(1);
  }
  while (!feof(fic)) {
    if (fscanf(fic, "%s\t%s",
	       ip_dest,
	       port_dest) == 2) {
      ip_redirect_list = (t_ip_redirect *)realloc(ip_redirect_list,
						  sizeof(t_ip_redirect) *
						  (nb_ip_redirect + 1));
      if (!inet_aton(ip_dest, &ip_redirect_list[nb_ip_redirect].ip_dest)) {
	fprintf(stderr, "not an IP in IP file (ip_dest): %s\n", ip_dest);
      }
      ip_redirect_list[nb_ip_redirect].port_dest = (u_short)atoi(port_dest);
      nb_ip_redirect++;
    }
  }    

  return(0);
}


int createservsock(int noport)
{
  struct sockaddr_in server;
  int servsock;


  if ((servsock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    return(-1);

  memset(&server, 0, sizeof(server));
  server.sin_family = AF_INET;
  server.sin_port = htons(noport);
  server.sin_addr.s_addr = INADDR_ANY;

  if (bind(servsock, (struct sockaddr *)&server, sizeof(server)) == -1)
    return(-1);

  if (listen(servsock, NBLISTEN) == -1)
    return(-1);

  return(servsock);
}


void redirect_traffic(int sock1, int sock2)
{
  char buf[TBUF_INET];
  int maxfd;
  fd_set iofds, r_iofds;
  int readbytes;
  int ret;


  maxfd = sock1 > sock2 ? sock1 : sock2;
  maxfd++;

  FD_ZERO(&iofds);
  FD_SET(sock1, &iofds);
  FD_SET(sock2, &iofds);

  for (;;) {
    memcpy(&r_iofds, &iofds, sizeof(iofds));

    ret = select(maxfd, &r_iofds, (fd_set *)NULL, (fd_set *)NULL, NULL);
    if (ret <= 0)
      break;

    /*
     * data has arrived from the client
     */
    if (FD_ISSET(sock1, &r_iofds)) {
      if ((readbytes = read(sock1, buf, TBUF_INET)) <= 0)
	break;
      write(sock2, buf, readbytes);
    }

    /*
     * coming from the server to the client
     */
    if (FD_ISSET(sock2, &r_iofds)) {
      if ((readbytes = read(sock2, buf, TBUF_INET)) <= 0)
	break;
      write(sock1, buf, readbytes);
    }
  }
}


int main(int argc, char *argv[])
{
  int i;
  int noport;
  int sockserv;

  int sockf;
  struct sockaddr_in servers;
  struct hostent *host;
  char buffer[TBUFFER + 1];
  char *remotename;
  char remotehost[MAXHOSTNAMELEN + 1];

  FILE *pidfile;


  printf("nihil ftp bouncer\n\n");

  if (argc != 3) {
    fprintf(stderr, "%s <config_file> <port>\n", argv[0]);
    return(1);
  }
  if (read_ip_file(argv[1]) == 1) {
    fprintf(stderr, "incorrect syntax in config file\n");
    return(1);
  }
  noport = atoi(argv[2]);

#ifdef DEBUG
  printf("%d lines read\n", nb_ip_redirect);

  printf("\nDumping IP table\n");
  for (i = 0; i < nb_ip_redirect; i++) {
    printf("%s:%d\n", inet_ntoa(ip_redirect_list[i].ip_dest),
	   ip_redirect_list[i].port_dest);
  }
#endif

  if ((sockserv = createservsock(noport)) == -1) {
    perror("createservsock");
    return(1);
  }

#ifdef DEBUG
  printf("server socket created on port %d\n", noport);
#endif

  snprintf(buffer, TBUFFER, "%s.log", argv[0]);
  if ((logfile = fopen(buffer, "a")) == NULL)
  {
    perror("can't create log file");
    return(1);
  }
  fprintf(logfile, "bouncer launched and listening on port %d\n", noport);
  fflush(logfile);

  snprintf(buffer, TBUFFER, "%s.pid", argv[0]);
  if ((pidfile = fopen(buffer, "w")) == NULL)
  {
    fprintf(logfile, "can't create pid file: %s\n", buffer, strerror(errno));
    return(1);
  }

  if (daemon(NULL, 0) == -1)
  {
    perror(argv[0]);
    return(1);
  }

  fprintf(pidfile, "%d\n", getpid());
  fclose(pidfile);

  i = 0;

  for (;;) {
    struct sockaddr_in client;
    int clisock;
    int clientsize = sizeof(client);
    int found;


    clisock = accept(sockserv, (struct sockaddr *)&client, &clientsize);
    if (clisock == -1) {
      fprintf(logfile, "accept: %s\n", strerror(errno));
      fflush(logfile);
      continue;
    }
    fprintf(logfile, "connect from %s\n", inet_ntoa(client.sin_addr));
    fflush(logfile);

    if (fork() == 0) {
      /*
       * attach child to init
       */
      if (fork())
	exit(0);

      /*
       * connect to ftp server and send IDNT
       */
      if ((sockf = socket(AF_INET, SOCK_STREAM, 0)) == -1)
      {
	fprintf(logfile, "can't create socket: %s\n", strerror(errno));
	fflush(logfile);
      }
      
      memset(&servers, 0, sizeof(servers));
      servers.sin_family = AF_INET;
      servers.sin_port = htons(ip_redirect_list[i].port_dest);
      memcpy(&servers.sin_addr, &ip_redirect_list[i].ip_dest,
	     sizeof(struct in_addr));

      if (connect(sockf, (struct sockaddr *)&servers,
		  sizeof(struct sockaddr_in)) == -1)
      {
	fprintf(logfile, "can't connect to ftp server at %s (%s)\n",
		inet_ntoa(ip_redirect_list[i].ip_dest), strerror(errno));
	fflush(logfile);
      }

      remotename = rfc931(&client.sin_addr, &servers.sin_addr);
      host = gethostbyaddr((char *)&client.sin_addr, sizeof(struct in_addr),
			   AF_INET);
      if (host)
	strncpy(remotehost, host->h_name, MAXHOSTNAMELEN);
      else
	strncpy(remotehost, inet_ntoa(client.sin_addr), MAXHOSTNAMELEN);

      snprintf(buffer, TBUFFER, "IDNT %s@%s:%s\n", remotename,
	       inet_ntoa((struct in_addr)client.sin_addr), remotehost);

      send(sockf, buffer, strlen(buffer), 0);

      redirect_traffic(clisock, sockf);

      exit(0);
    }
    else {
      close(clisock);
      i++;
      if (i == nb_ip_redirect)
	i = 0;
      wait(NULL);
    }
  }

  return(0);
}
