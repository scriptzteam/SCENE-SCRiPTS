#!/bin/bash 
#
# Gets executed by glftpd after mkdir is done.
# add into your 'dirscript' the following line:
# /bin/outs.uploadlink.sh $1 $2
# where $1 = Releasename (with or without subsdirs)
# where $2 = path from /site->/to/sectionname/
# and enable dirscript in glftpd.conf!
# make sure ls,ln and awk are in /glftpd/bin dir!!!
#
# this script will make a /site/Lastest_Upload_DIRNAME symlink
#
# and only do main title dirs...no sub dirs or whatever...
# enable logging to get "UPLOADLINK: $2/$1" into glftpd.log
#
# on a new created dir , the old one will be deleted so there we start with in the first place..
# or second..we need to check for a valid dir first..
#
# options are : deny specific dirname (i.e. PRE or Groups...)
#               create only links where you want them to be (exempt mp3 dirs or 0day..)
#               enable/disable glftpd logging 
#               create your own "TAG" 
# 
# Idea was origional by Zio (yeah your scripting owns man!)
# and brought to my attention by my great friend Doc :)
#
# So here it is...
#
# (C) 2002 By TheOut.
# 
# USE THIS SCRIPT AT OWN RISK! 
# im not to blame when YOU screw it up in any way.
# make sure you use a little sanity when installing the script ;-)
# bla bla ---------------------------------------------------------------------------
#
################# START CONFIG
#
# Deny to create dirs for : (normaly you deny it with dirlog option in glftpd.conf)
# but to make sure.....
#
deny="groups"
#
# Sections to make link for :
#
links="/site/console/psx /site/console/ps2 /site/iso/games /site/movies/xxx /site/reuqests"
#
# Tag Name? Latest_Upload_ for example... the script will put the relname at the end!
# make sure to end the tag with a "_" !! else you get fucked up :)
#
tag="Latest_Upload_"
#
# Wanna log into glftpd.log? (dont see any use but maybe you do) (0 = no ; 1 = yes)
#
log=1
gllog=/ftp-data/logs/glftpd.log
#
#
####### END CONFIG ... DONT EDIT BELOW..
#
#
[ -z $2 ] && exit 0;if [ "`echo $2 |grep -v $deny`" =  "" ];then exit 0 ;fi
# owke , validation done.. now we get to check if the dir is the "main" release title dir or one of the
# sub dirs of any release...
action=dont
for check in $links;do
  case $2 in
        $check)
        action=make;;
        *)
        ;;
  esac
done

if [ "$action" = "make" ];then
rel=`echo $1 | awk -F '/' '{print $1}'`
currentlink=`ls /site |grep $tag`
typedir=`echo $currentlink|awk -F '$tag' '{print $2}'`
  if [ "$typedir" = "$rel" ];then
        exit 0
  else
	if [ "$tag" != "" ];then
        rm -rf /site/$tag*
	fi
        ln -s $2/$1 /site/$tag$rel
	if [ "$log" = "1" ];then
	  echo `date +%c` UPLOADLINK: $2/$1 >> $gllog
	fi
  fi
fi
exit 0
