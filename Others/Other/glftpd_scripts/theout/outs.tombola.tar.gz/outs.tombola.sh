#!/bin/sh
VER=1.2
# Tombola , every joiner pays 200mb , and once a week we play the game..
#
# make sure /tmp exists and is writable :-)
# run this script as crontab like * 20 * * sun /glftpd/bin/outs.tombola.sh playtime >/dev/null 2>&1
# so the game will be played at that time or use TCL to start the game on trigger!
# load the tcl to your sitebot for 2 triggers...
# make your sitebot tail glftpd.log for 
# 'TOMBOLAUSER: USERNAME GROUPNAME' (the one who executes the script to join)
# 'TOMBOLASTART: $nrusers' (logged in glftpd.log on "playtime")
# 'TOMBOLAWINNER: $nrusers $winneruser $winamount' (logged in glftpd.log on "playtime")
#
# 1.2 - added option for 'crontab run' so if there is a minimum number of users then play else skip.
# plz remember when running the start from the eggdrop it will fuck up the userfile ownership :P
# (so your warned)
# also added optional deny leechers/under '0' credits users
#
# cp awk/expr to your glftpd bin dir!! (and make sure they work!)
#
# add following lines to glftpd.conf :
#
# site_cmd TOMBOLA  EXEC      /bin/outs.tombola.sh
# custom-tombola *
#
# (c) 2002 by TheOut
#
# Play with minimum number of users (0 = unlimited)
minplay=5
# 
# play for : xxx mb (bet every user has to pay)
playbet=200
#
# winammount (in mb) ( add '0' for realtime amount (nr.players * playbet))
winamount=0
#
# play day (date %a)
playday=Sun
#
# play time (date +%H:%M)
playtime=20:00
#
# Your Distro ? 1 = FBSD , 0 = others 
# make sure to have 'jot' binary when running on FBSD :)
OS=0
#
# Allow leech users to play ? (0 = yes , 1 = no)
allowleech=1
#
# Allow users with lower then 0 credits (0 = yes , 1 = no)
allownull=1
#
gluserpath=/ftp-data/users
shelluserpath=/glftpd/ftp-data/users
#################################################################
daynow=`date +%a`
timenow=`date +%H:%M`
if [ "`ls /tmp/ |grep "tombola_users"`" = "" ];then echo "" > /tmp/tombola_users;fi
if [ "$1" != "bot" ] && [ "$1" != "playtime" ];then
        echo ",-------------------------------------------------------------------."
        echo "|      Tombola Glftpd v$VER                  (c) 2001 by TheOut      |"
        echo "|-------------------------------------------------------------------|"
        echo "|                                                                   |"
fi
if [ "$1" = "" ] || [ "$1" = "help" ] || [ "$1" = "info" ];then
	echo "|  Usage :    'site tombola join'                                   |"
	echo "|             'site tombola info'                                   |"
        echo "|                                                                   |"
	echo "| join:  you join the game and pay 200mb credits for playing one    |"
	echo "|        time at the end of the week.                               |"
        echo "|                                                                   |"
	echo "| info:  get info on current players and this help file.            |"
        echo "|                                                                   |"
	echo "| Current players are :                                             |"
        echo "|                                                                   |"
[ -f /tmp/tombola_users ] && {
for user in `cat /tmp/tombola_users`;do printf "%-67s %1s\n" "| $user" "|";done
}
        echo "|                                                                   |"
        echo "|   (c) 2001 by TheOut v$VER -- My Page http://glftpd.rfje.org       |"
        echo "'-------------------------------------------------------------------'"
exit 0
elif [ "$1" = "join" ];then
if [ "`cat /tmp/tombola_users | grep "$USER"`" != "" ];then
	echo "| Sorry not allowed to play more then once on the Tombola.          |"
        echo "|                                                                   |"
        echo "|   (c) 2001 by TheOut v$VER -- My Page http://glftpd.rfje.org       |"
        echo "'-------------------------------------------------------------------'"
exit 0
fi
ratio=`cat /ftp-data/users/$USER|grep RATIO|awk '{print $2}'`
if [ "$ratio" = "0" ] && [ "$allowleech" = "1" ];then
        echo "| Sorry not allowed to play on leech accounts.                      |"
        echo "|                                                                   |"
        echo "|   (c) 2001 by TheOut v$VER -- My Page http://glftpd.rfje.org       |"
        echo "'-------------------------------------------------------------------'"
exit 0
fi
usercred=`cat $gluserpath/$USER|grep "^CREDITS"|awk '{print $2}'`
if [ "$usercred" -lt "0" ] && [ "$allownull" = 1 ];then
        echo "| Sorry not allowed to play without credits.                        |"
        echo "|                                                                   |"
        echo "|   (c) 2001 by TheOut v$VER -- My Page http://glftpd.rfje.org       |"
        echo "'-------------------------------------------------------------------'"
exit 0
fi
        echo "| Super! your added to the tombola players list.. lets rock tha it. |"
printf "%-25s %-3s %-2s %-5s %-4s %25s\n" "| Playing time is set to" "$playday" "at" "$playtime" "Hour" "|"
echo "$USER" >> /tmp/tombola_users
echo `date "+%a %b %e %T %Y"` TOMBOLAUSER: $USER $GROUP >> /ftp-data/logs/glftpd.log
usercred=`cat $gluserpath/$USER|grep "^CREDITS"|awk '{print $2}'`
  betinkb=`expr $playbet \* 1024`
usercred=`expr $usercred - $betinkb`
cat $gluserpath/$USER|grep -v "^CREDITS"  >> $gluserpath/$USER.new
echo "CREDITS $usercred" >> $gluserpath/$USER.new
mv $gluserpath/$USER.new $gluserpath/$USER
        echo "|                                                                   |"
        echo "|   (c) 2001 by TheOut v$VER -- My Page http://glftpd.rfje.org       |"
        echo "'-------------------------------------------------------------------'"
exit 0
fi

if [ "$1" = "bot" ];then
nrusers=0;for nr in `cat /glftpd/tmp/tombola_users`;do nrusers=`expr $nrusers + 1`;done
if [ "$winamount" = "0" ];then  winamount=`expr $playbet \* $nrusers`;fi
for userlist in `cat /glftpd/tmp/tombola_users`;do users="$users $userlist o";done
echo "$playday $playtime $nrusers \"$users\" $winamount"
exit 0
fi
if [ "$1" = "playtime" ];then
nrusers=0;for nr in `cat /glftpd/tmp/tombola_users`;do nrusers=`expr $nrusers + 1`;done
if [ "$minplay" != "0" ];then
 if [ "$nrusers" -lt "$minplay" ];then exit;fi
fi
if [ "$winamount" = "0" ];then winamount=`expr $playbet \* $nrusers`;fi
echo `date "+%a %b %e %T %Y"` TOMBOLASTART: $nrusers >> /glftpd/ftp-data/logs/glftpd.log
#get random number to pick user...
while [ "$winneruser" = "" ];do
if [ "$OS" = "1" ];then
number1=`jot -r 1 1 $nrusers`
else
number1=$[RANDOM % $nrusers]
fi
numbergam=0
for winner in `cat /glftpd/tmp/tombola_users`;do 
numbergam=`expr $numbergam + 1`
if [ "$numbergam" = "$number1" ];then
winneruser=$winner
break
fi
done
done
usercred=`cat $shelluserpath/$winneruser|grep "^CREDITS"|awk '{print $2}'`
  betinkb=`expr $winamount \* 1024`
usercred=`expr $usercred + $betinkb`
cat $shelluserpath/$winneruser|grep -v "^CREDITS"  >> $shelluserpath/$winner.new        
echo "CREDITS $usercred" >> $shelluserpath/$winneruser.new    
mv $shelluserpath/$winneruser.new $shelluserpath/$winneruser
echo `date "+%a %b %e %T %Y"` TOMBOLAWINNER: $nrusers $winneruser $winamount >> /glftpd/ftp-data/logs/glftpd.log
rm -f /glftpd/tmp/tombola_users
fi

