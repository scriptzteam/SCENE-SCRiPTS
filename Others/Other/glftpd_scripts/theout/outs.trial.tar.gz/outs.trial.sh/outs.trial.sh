#!/bin/sh -x
ver=1.0c
#
# 1.0c - Fucked it up on 1.0b.. dont know if many was spreaded..well here is
# a WORKIN version... im deeply sorry for this to happen..
# but this one is 99% ok.. think i need a beta tester for it next time :)
#
# High advanced TRiAL script...
# No need for "TRiAL" groups...
# No need to check users for there activity Just tell this 
# script to check all users for there min. upload at a certen 
# point/time. Inform the Notifiers and gadmin
# about the failed trial , and leave a private
# message for the user to know he is delusered and reason why!
#
# We have a backup dir for deleted users (/path/to/ftp-data/users/backup)
# So if anything goes wrong , you could alway put back the orginal file
# Make sure you use this script with common sence , and no we cant make
# it idiot proof!
# chmod 777 your /ftp-data/msgs dir
# chmod 777 your /ftp-data/users dir and /backup dir
# 
# Notifiers (siteops) to inform any news (Take siteops only ,
# else there free slot would not be given back to the gadmin)
NOTIFIER[0]=TheOut
NOTIFIER[1]=rf
NOTIFIER[2]=nicey
#
# Count highest number + 1
TOTALNOTIFIERS=3
#
# Glftpd root dir
GLDIR=/glftpd
# Glftpd sub dirs (dont expect to be changed)
PASSFILE=/etc/passwd
GLUSERS=/ftp-data/users
MSGDIR=/ftp-data/msgs
DELDIR=/ftp-data/byefiles
GLLOG=/ftp-data/logs/glftpd.log
#
# Trial MB's to let the user upload within trial period
MINTRIALUPLOAD=1500
#
# Trial days ( 7 days? 14 days?)
TRIALDAYS=7
#
# Exempt users from trial (if you dont have an exempt list -
# make one then... line correct nicks under eachother)
# ((if no exempt list is made , this script will FUCK you...))
# at least exempt default.user and glftpd and your own acc
EXEMPTLIST=/glftpd/bin/exempt.list
#
# Exempt groups from trial
AFFILGRP="VULCAN|VORTEX|DNL|SINISTER|BSISO|GENIUS|TUC"
#
# Well this should be it.. lets hope for something nice now..
# DONT MESSUP BELOW..unless you know what to do :-)
#
# And again TIP of the day...
# DONT Bother me with that you can do it better and that
# you can do it without blah and with blah etc etc :-)
# If you knew so much... why didnt you made it already?
# 
# (c) 2001 Nov 07 2001 by TheOut 
# Get your latest versions of my scripts and glftpd at
#
# My page -- http://glftpd.rfje.org
# glftpd pages : www.glftpd.org -- www.glftpd.com
# 
# Last note : I can not be held responsible for any use/misuse
# or abuse or any other thing that could happen if your using
# my scripts :-).... use at your own risk!
# (make a backup every day...for example) 
###############################################################
TRIALCHECK=`date --date '+'$TRIALDAYS' days ago' +%m-%d-%y`
EXEMPT=`cat $EXEMPTLIST | awk '{print $1}'`
[ -d $GLDIR$GLUSERS/backup ] || mkdir -m777 $GLDIR$GLUSERS/backup
ls $GLDIR$GLUSERS/backup/ > $GLDIR$GLUSERS/.deletedusers
EXEMPT2=`cat $GLDIR$GLUSERS/.deletedusers`
[ "$EXEMPT" ] || EXEMPT=default.user 
[ "$EXEMPT2" ] || EXEMPT2=0000
cat $GLDIR$PASSFILE |grep "$TRIALCHECK" |awk -F ':' '{print $1}' >> $GLDIR$GLUSERS/.tocheckfile
x=0
y=0
i=0
for x in `cat $GLDIR$GLUSERS/.tocheckfile |grep -v "$EXEMPT" | grep -v "$EXEMPT2"|awk '{print $1}'`
do
        GETUP=`cat $GLDIR$GLUSERS/$x | grep "ALLUP" | awk '{print $3}'`
        MONTHMB=$[GETUP / 1024]
        USER=`basename $x`
	group=`cat $GLDIR$GLUSERS/$USER | grep "^GROUP" | awk '{print $2}'`
        leech=`cat $GLDIR$GLUSERS/$USER | grep "^RATIO" | awk '{print $2}'`
        gadmin=`cat $GLDIR$GLUSERS/$USER | grep "USER Added by" | awk '{print $4}'`
	if [ "`echo $group | tr '[:lower:]' '[:upper:]' | grep -vE "$AFFILGRP" | tr -d '|'`" != "" ];then
        if [ $MONTHMB -gt "-1" ] && [ $MONTHMB -lt $MINTRIALUPLOAD ];then
		while [ "$i" -lt "$TOTALNOTIFIERS" ];do
        	echo " " >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
        	echo "!HFrom: !CTheOuts Trialscript V$ver !H(!C`date "+%a %b %e %T %Y"`!H)!0" >>  $GLDIR$MSGDIR/${NOTIFIER[$i]}
        	echo "--------------------------------------------------------------------------" >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
        	echo "$USER ($group) has only upload : $MONTHMB MB : Account from $TRIALCHECK , so DELETED" >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
		[ "$gadmin" = ${NOTIFIER[$i]} ] && y=1
		i=$[i + 1]
		done
          mv $GLDIR$GLUSERS/$USER $GLDIR$GLUSERS/backup
          echo "FLAGS 6" >> $GLDIR$GLUSERS/$USER
          echo "CREDITS 0" >> $GLDIR$GLUSERS/$USER
          cat $GLDIR$GLUSERS/backup/$USER | grep -v "FLAG" | grep -v "^CREDIT" >> $GLDIR$GLUSERS/$USER
          echo "####### TheOut's Trial script V$ver #######" >> $GLDIR$DELDIR/$USER.bye
          echo "# $USER is deleted for the following reason" >> $GLDIR$DELDIR/$USER.bye
          echo "# Required : $MINTRIALUPLOAD MB" >> $GLDIR$DELDIR/$USER.bye
          echo "# User did : $MONTHMB MB" >> $GLDIR$DELDIR/$USER.bye
          echo "# " >> $GLDIR$DELDIR/$USER.bye
          echo "# Better luck next time" >> $GLDIR$DELDIR/$USER.bye
          echo "# (auto generated message `date "+%a %b %e %T %Y"`)" >> $GLDIR$DELDIR/$USER.bye
          echo `date "+%a %b %e %T %Y"` SCRIPT: "$USER deleted on too little upload trial" >> $GLDIR$GLLOG
	  if [ "$y" = "0" ];then 
                  gslot1=`cat $GLDIR$GLUSERS/$gadmin | grep "^SLOTS" | awk '{print $2}'`
                  gslot2=`cat $GLDIR$GLUSERS/$gadmin | grep "^SLOTS" | awk '{print $3}'`
                  gslot1=`expr $gslot1 + 1`
                        if [ "$leech" = "0" ];then
                               gslot2=`expr $gslot2 + 1`
                        fi
                  cat $GLDIR$GLUSERS/$gadmin | grep -v "^SLOTS" >> $GLDIR$GLUSERS/$gadmin.new
                  mv $GLDIR$GLUSERS/$gadmin.new $GLDIR$GLUSERS/$gadmin
                  echo "SLOTS $gslot1 $gslot2" >> $GLDIR$GLUSERS/$gadmin
	          echo "!HFrom: !CTheOut's Trialscript V$ver !H(!C`date "+%a %b %e %T %Y"`!H)!0" >>  $GLDIR$MSGDIR/$gadmin
                  echo "--------------------------------------------------------------------------" >> $GLDIR$MSGDIR/$gadmin
                  echo "$USER didnt made trial (only $MONTHMB mb) , so deleted" >> $GLDIR$MSGDIR/$gadmin
	          echo "You have regain your slots" >> $GLDIR$MSGDIR/$gadmin
	fi
        else
		echo " " >> $GLDIR$MSGDIR/$USER
		echo "!HFrom: !CTheOut's Trialscript V$ver !H(!C`date "+%a %b %e %T %Y"`!H)!0" >> $GLDIR$MSGDIR/$USER
		echo "--------------------------------------------------------------------------" >> $GLDIR$MSGDIR/$USER
		echo "$USER , you have passed Trial Period , well done" >> $GLDIR$MSGDIR/$USER
			while [ "$i" -lt "$TOTALNOTIFIERS" ];do
			echo " " >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
			echo "!HFrom: !CTheOut's Trialscript V$ver !H(!C`date "+%a %b %e %T %Y"`!H)!0" >>  $GLDIR$MSGDIR/${NOTIFIER[$i]}
			echo "--------------------------------------------------------------------------" >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
			echo "$USER ($group) has passed Trial Period , he's save for now" >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
			echo " " >> $GLDIR$MSGDIR/${NOTIFIER[$i]}
			i=$[i + 1]
			done
	fi
	fi
#fi
done
rm -rf $GLDIR$GLUSERS/.deletedusers
rm -rf $GLDIR$GLUSERS/.tocheckfile

