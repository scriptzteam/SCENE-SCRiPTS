#!/bin/sh 
#
ver=1.0b
#- Glftpd root
#
gldir=/glftpd
#
#- Xferlog location (prolly dont change it)
#
xferlog=/ftp-data/logs/xferlog
#
#- /tmp dir (under root /tmp and under glftpd glftpd/tmp)
tmp=/tmp
#
#- Glftpd log file
gllog=/ftp-data/logs/glftpd.log
#
# Fill info below
#
groupsdir="groups"
nukesyntax="NUKED"
requestdir="request"
awkfile=/bin/outs.top10leech.awk
#
# DID YOU READ THE README FILE? Do it before asking my this and why that blaaaat!
# 
# (c) 2001 by TheOut V1.0b 11/29/2001
#####################################################################################
## NO NEED TO EDIT BELOW UNLESS YOU HAVE OTHER WAY OF DIR STRUCTURE!
#####################################################################################
if [ "$1" = "" ] || [ "$1" = "bot" ];then
	echo ",-------------------------------------------------------------------."
	echo "|      Top XX Leeched last period of time - (c) 2001 by TheOut      |"
	echo "|-------------------------------------------------------------------|"
	echo "|                                                                   |"
	echo "| Usage :  ' site top10 <number> '                                  |"
	echo "|                                                                   |"
	echo "| <number> = number of shown releases.                              |"
	echo "|                                                                   |"
	echo "|   (c) 2001 by TheOut V$ver -- My Page http://glftpd.rfje.org      |"
	echo "'-------------------------------------------------------------------'"
	exit 0
elif [ "$1" -gt 25 ];then
	echo ",-------------------------------------------------------------------."
	echo "|      Top XX Leeched last period of time - (c) 2001 by TheOut      |"
	echo "|-------------------------------------------------------------------|"
	echo "|                                                                   |"
	echo "| Usage :  ' site top10 <number> '                                  |"
	echo "|                                                                   |"
	echo "| <number> = number of shown releases.                              |"
	echo "|                                                                   |"
	echo "| Please dont try to messup the box.. take a lower number!          |"
	echo "|                                                                   |"
	echo "|   (c) 2001 by TheOut V$ver -- My Page http://glftpd.rfje.org      |"
	echo "'-------------------------------------------------------------------'"
	exit 0
fi
number=$1;i=0
tal=$[number * 100]
topall="";sec=`date +%s`
if [ "$number" -lt "10" ]; then
number="0$number"
tal=1000
fi
[ "$2" = "bot" ] && xferlog=$gldir$xferlog && gllog=$gldir$gllog && awkfile=$gldir$awkfile
topall=`tail -$tal $xferlog | awk '{print $9}' | grep -v $groupsdir | grep -v $nukesyntax | grep -v $requestdir`
for x in `echo $topall`;do
section=`echo $x | awk -F '/' '{print $3}'`
release=`echo $x | awk -F '/' '{print $5}'`
############ SAMPLE ######## SAMPLE ######## SAMPLE ######## SAMPLE ######## SAMPLE ########
#
# We have as example tv-series not in /site/incoming/tv-series
# but we have it in /site/tv-series
# so we have to set the release 1 back "awk -F '/' '{print $4}'`" instead of "awk -F '/' '{print $5}'`"
############################################################################################

#[ "$section" = "tv-series" ] && release=`echo $x | awk -F '/' '{print $4}'`		

############################################################################################
# We have as example gba and gbc not in /site/incoming/gba and ~/gbc
# but we have it in /site /incoming/console/gba and ~/gbc
# so we have to set the release 1 more "awk -F '/' '{print $6}'`" instead of "awk -F '/' '{print $5}'`"
############################################################################################

#[ "$release" = "gba" ] && release=`echo $x | awk -F '/' '{print $6}'`
#[ "$release" = "gbc" ] && release=`echo $x | awk -F '/' '{print $6}'`

############################################################################################
# DONT EDIT MORE THEN NEEDED!
############################################################################################
echo "$section $release" >> $tmp/temptop10file$sec
done
cat $tmp/temptop10file$sec | awk '{print $2}' | sort | uniq >> $tmp/releasefile$sec
for rel in `cat $tmp/temptop10file$sec | awk '{print $2}' | sort | uniq`;do
datas=0;mb=0
data=`cat $xferlog | grep $rel | awk '{print $8}'`
for mb in `echo $data`;do
	mb=$[mb / 1024]
	datas=$[datas + mb]
done
datas=$[datas / 1024]
echo $datas $rel >> $tmp/finaloutput$sec
done
cat $tmp/finaloutput$sec |awk '{print $1 " " $2}'| sort -nr >> $tmp/final2$sec
cat -n $tmp/final2$sec |awk '{print $1 "#"  $3 "#" $2 }' >> $tmp/final3$sec
awk -F# -f $awkfile < $tmp/final3$sec >> $tmp/tmplog$sec
echo ",-------------------------------------------------------------------."
echo "|      Top $number Leeched last period of time - (c) 2001 by TheOut      |"
echo "|-------------------------------------------------------------------|"
echo "|                                                                   |"
echo "| Nr    Title                                            mb Leeched |"
echo "|                                                                   |"
cat $tmp/tmplog$sec | head -$number
echo "|                                                                   |"
echo "|   (c) 2001 by TheOut V$ver -- My Page http://glftpd.rfje.org      |"
echo "'-------------------------------------------------------------------'"
rm -rf $tmp/tmplog$sec
rm -rf $tmp/final2$sec
rm -rf $tmp/final3$sec
rm -rf $tmp/finaloutput$sec
rm -rf $tmp/releasefile$sec
rm -rf $tmp/temptop10file$sec
echo `date "+%a %b %e %T %Y"` TOP10: $USER $GROUP \"$TAGLINE\" \"$1\" >> $gllog
exit

################## BEING INSANE IS A WAY OF LIFE!
