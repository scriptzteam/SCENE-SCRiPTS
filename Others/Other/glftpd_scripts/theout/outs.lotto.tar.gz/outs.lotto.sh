#!/bin/bash 
#
# 1.2 -
# Added a logparser (vShit.tcl by vman) to scanlog
# the lotto.log file , so we dont get a 500 meg big
# glftpd.log just because of some lame lottoballs :-)
#
# 1.1 -
#
# Added option for looping balls...one time run balls
# and every XX seconds there will be a new ball
# Added option that a siteop must 'start' a game
# so users can join the game..(at the end of a game
# it will auto close again!
#
# 1.0 -
# Yup.. a game... lotto...
# every player doing 'site lotto nr1...nr15'
# (gives fifteen numbers)
# then when there are enough players the siteop
# can start the game... and when any user match
# 5 same numbers.. he(or she) must trigger
# 'site bingo' to announce it.. system will check
# if its a valid bingo or not...
# same goes for the 10 match balls.....
#
# Options to run the script are :
# ./outs.lotto.sh join  (join the game as player)
# ./outs.lotto.sh ball  (trigger a ball number)
# ./outs.lotto.sh play  (start the first 2 numbers)
# ./outs.lotto.sh       (info)
# ./outs.lotto.sh bingo (when first user match 5/10 balls)
# ./outs.lotto.sh open  (Opens the game , so users can join)
#
# following loggings are in glftpd.log :
# LOTTOOPEN: Username (opens the game for joiners)
# LOTTOSTART: nr_of_players ball1 ball2 (when the game starts)
# LOTTOUSER: Username Groupname Tagline (when a user joins)
# LOTTOBALL: Ballnr total_nr_balls "prev.balls" (new ballnr and older numbers)
# LOTTOBINGO: Username (user who triggers the site bingo)
# LOTTOWIN5: Username groupname tagline "matching balls" (win?)
# LOTTOWIN10: Username groupname tagline "matching balls" (win?
# LOTTOFAIL: Username Groupname Tagline (false bingo.. die die die)
#
# NOTE!: this game is workin for sites having 1 section/credit.
#        and by default will not run on FBSD :P
#        somebody with a lot of time , msg me when you want
#        to rewrite all my scripts so they run on FBSD too.!
# 
# make sure /tmp (/glftpd/tmp) exists and is writable!
# make sure /ftp-data/users is writable.. else you see errors!
# make sure /ftp-data/logs/lotto.log exists and is writable!
# 
# and check the README included here!!
# and check the README included here!!
# and check the README included here!!
#
# (c) 2002 By TheOut
#
# Allow leechers to play ? (0 = yes , 1 = no)
#
allowleech=0
#
# Allow users with no credits ? (0 = yes , 1 = no)
#
allowcreds=0
#
# Default amount of credits the user pays to join (in MB)
#
bet=1500
#
# Winamount when they match 5 & 10 balls.... (in MB)
win5=5000
#
win10=10000
#
# Min. number of players required? (0 = unlimited)
#
minplay=0
#
# Allow users to play multiple times? (0 = yes , 1 = no)
#
allowtwice=1
#
# false bingo cost player credits??? (0 = no) (else in MB)
falsebingo=500
#
# On trigger of ball.. repeat till bingo 10? (0 = no , 1 = yes)
# and how much time between? (seconds)
repeat=1
repeattime=20
#
# Dirs...
gllog=/ftp-data/logs/lotto.log
users=/ftp-data/users
tmp=/tmp
glftpd=/glftpd ;# rootpath yes!
siteopnick=theout
############################################################
opentag=lotto.open
foot="|----------------------------------------|\n|TheOut's web @ http://glftpd.rfje.org...|\n'----------------------------------------'"
if [ "$PWD" = "/glftpd/bin" ];then
  # Changing path's for shell.... :-)
  users=$glftpd$users
  tmp=$glftpd$tmp
  gllog=$glftpd$gllog
  USER=$siteopnick
fi

if [ "$1" != "join" ]&&[ "$1" != "play" ]&&[ "$1" != "ball" ]&&[ "$1" != "bingo" ]&&[ "$1" != "bot" ]&&[ "$1" != "open" ];then
echo ",----------------------------------------."
echo "| TheOut's LOTTO Casino games            |"
echo "|----------------------------------------|"
echo "|Usage and howto:                        |"
echo "|                                        |"
echo "|Every user who joins the game will be   |"
printf "%-11s %-5s %-11s %12s\n" "|Charged of" "$bet" "MB credits" "|"
echo "|You can join this game by giving us     |"
echo "|15 numbers from 0 to 50                 |"
echo "| 'site lotto join nr nr nr nr etc etc'  |"
echo "|make sure that you dont giv same numbers|"
echo "|twice. Well furthermore its for you to  |"
echo "|wait till the siteop starts the game... |"
echo "|  !!!! So write your numbers down !!!!  |"
echo "|First one who does 'site bingo' on a    |"
printf "%-28s %-5s %5s\n" "|5 number matching will get" "$win5 MB" "|"
echo "|First one who does 'site bingo' on the  |"
printf "%-28s %-5s %4s\n" "|10 number matching will get" "$win10 MB" "|"
if [ "$falsebingo" != "0" ];then
echo "|However when you do a false bingo we    |"
printf "%-16s %-5s %18s\n" "|will charge you" "$falsebingo MB" "|"
fi
if [ "$minplay" != "0" ];then
printf "%-16s %-2s %-8s %2s\n" "|There must be a minimum of" "$minplay" "users to" "|"
echo "|play the game.!                         |"
fi
echo -e $foot
exit
fi
#
# Join routine
#
if [ "$1" = "join" ];then
  echo ",----------------------------------------."
  echo "| TheOut's LOTTO Casino games            |"
  echo "|----------------------------------------|"
 if [ "${16}" = "" ];then
  echo "| Error.. need 15 numbers!               |"
  echo -e $foot
  exit
 fi
 if test ! -f $tmp/$opentag ; then
  echo "| Error..game isnt open yet for joiners  |"
  echo "| Contact siteop for time they play      |"
  echo -e $foot
  exit
 fi
 if test -f $tmp/lotto.balls ; then
  echo "| Error..game already being played..next |"
  echo "| time be a little faster on joining     |"
  echo -e $foot
  exit
 fi
# Oki we got 10 numbers.. lets check if they are a) between 1 and 50 and 
# second if they dont match eachother... you know how users can fool ya!.
listballs="$2 $3 $4 $5 $6 $7 $8 $9 ${10} ${11} ${12} ${13} ${14} ${15} ${16}"
usercred=`cat $users/$USER|grep CREDITS|awk '{print $2}'`
userratio=`cat $users/$USER|grep RATIO|awk '{print $2}'`
check=""
[ -f $tmp/lotto.play ] || touch $tmp/lotto.play
 if [ "`cat $tmp/lotto.play|grep "^$USER"`" != "" ] && [ "$allowtwice" != "0" ];then
  echo "| Error.. allowed to play more then 1 x. |"
  echo -e $foot
  exit
 fi
 if [ "$usercred" -lt "0" ] && [ "$allowcreds" = "1" ];then
  echo "| Error.. not enough credits!            |"
  echo -e $foot
  exit
 fi
if [ "$userratio" = "0" ] && [ "$allowleech" = "1" ];then
  echo "| Error.. not allowed to play on leech!  |"
  echo -e $foot
  exit
 fi
for ballie in `echo $listballs`;do
 if [ "$ballie" -lt "0" ] || [ "$ballie" -gt "50" ];then 
  echo "| Error.. found a number outside 0 - 50!|"
  echo -e $foot
  exit
 fi
 if [ "`echo $check|grep ":$ballie:"`" != "" ];then
  echo "| Error.. found duplicate numbers        |"
  echo -e $foot
  exit
 fi
 check="$check:$ballie:"
done
# Save passed the checks from input... now time to add the user
# and announce he joined!!
# Removing credits from the joined user...
cat $users/$USER |grep -v "^CREDITS" > $users/$USER.new
betkb=$[bet * 1024];newcred=$[usercred - $betkb]
echo "CREDITS $newcred" >> $users/$USER.new
mv $users/$USER.new $users/$USER
echo "$USER:$GROUP:$TAGLINE:$2:$3:$4:$5:$6:$7:$8:$9:${10}:${11}:${12}:${13}:${14}:${15}:${16}" >> $tmp/lotto.play
echo `date "+%a %b %d %T %Y"` LOTTOUSER: \"$USER\" \"$GROUP\" \"$TAGLINE\" \"$check\" >> $gllog  
  echo "| Great , your added to the lotto now.   |"
  echo "| Pay close attention when the game      |"
  echo "| starts.. cause its up to you to run    |"
  echo "| the trigger... 'site bingo' when you   |"
  echo "| match the 5 or 10 balls... enjoy!      |"
  echo -e $foot
exit
fi
# END Join routine!

#
# play routine
#
if [ "$1" = "play" ];then
  echo ",----------------------------------------."
  echo "| TheOut's LOTTO Casino games            |"
  echo "|----------------------------------------|"
[ -f $tmp/lotto.balls ] && {
  echo "| Great , but there is already a game    |"
  echo "| running... maybe dead or? remove balls |"
  echo "| to restart the game!                   |"
  echo -e $foot
  exit
}
[ -f $tmp/lotto.play ] || {
  echo "| Great to play... without PLAYERS!!!    |"
  echo -e $foot
  exit
}
 nrusers=""
 for player in `cat $tmp/lotto.play|awk -F : '{print $1}'`;do nrusers=$[nrusers + 1];done
 if [ "$minplay" != "0" ] && [ "$nrusers" -lt "$minplay" ];then
  echo "| Great , you wanna start the game....   |"
  echo "| Too bad there are not enough players :(|"
  echo -e $foot
  exit
 fi
  echo "| Great , your tha man! you started it!  |"
  echo -e $foot
# Lets grab first 2 balls.. and announce we have a game!
ball1=$[RANDOM % 50]
echo "$ball1:" > $tmp/lotto.balls
ball2="$ball1"
while [ "`cat $tmp/lotto.balls|grep "^$ball2:"`" != "" ];do
ball2=$[RANDOM % 50]
done
echo "$ball2:" >> $tmp/lotto.balls
echo `date "+%a %b %d %T %Y"` LOTTOSTART: $nrusers $ball1 $ball2 >> $gllog
exit
fi
# END Start routine!

#
# Ball routine
#
if [ "$1" = "ball" ];then
  echo ",----------------------------------------."
  echo "| TheOut's LOTTO Casino games            |"
  echo "|----------------------------------------|"
[ -f $tmp/lotto.balls ] || {
  echo "| Great , but there is not yet a game    |"
  echo "| running... you better read how this    |"
  echo "| game works to 'outs.lotto.sh play' it! |"
  echo -e $foot
  exit
}
if [ "$repeat" = "1" ];then
while [ "`cat $tmp/lotto.play`" != "" ];do
 newball=`cat $tmp/lotto.balls|awk -F : '{print $1}'|head -1`
 while [ "`cat $tmp/lotto.balls|grep "^$newball:"`" != "" ];do
 newball=$[RANDOM % 50]
 done
 nr="0"
  ballen=""
  for ballie in `cat $tmp/lotto.balls|awk -F : '{print $1}'`;do
   nr=$[nr + 1]
   ballen="$ballen $ballie"
  done;nr=$[nr + 1]
 echo `date "+%a %b %d %T %Y"` LOTTOBALL: $newball $nr \"$ballen\" >> $gllog
 echo "$newball:" >> $tmp/lotto.balls
 sleep $repeattime
done
exit
else
 newball=`cat $tmp/lotto.balls|awk -F : '{print $1}'|head -1`
 while [ "`cat $tmp/lotto.balls|grep "^$newball:"`" != "" ];do
 newball=$[RANDOM % 50]
 done
 nr="0"
  for ballie in `cat $tmp/lotto.balls|awk -F : '{print $1}'`;do
   nr=$[nr + 1]
   ballen="$ballen $ballie"
  done;nr=$[nr + 1]
 echo `date "+%a %b %d %T %Y"` LOTTOBALL: $newball $nr \"$ballen\" >> $gllog
 echo "$newball:" >> $tmp/lotto.balls
 exit
fi
fi
# End Ball routine!

#
# Bingo routine
#
if [ "$1" = "bingo" ];then
  echo ",----------------------------------------."
  echo "| TheOut's LOTTO Casino games            |"
  echo "|----------------------------------------|"
[ -f $tmp/lotto.balls ] || {
  echo "| Great , but there is not yet a game    |"
  echo "| running... you better wait till the    |"
  echo "| siteop started the game mofo!          |"
  echo -e $foot
  exit
}
echo `date "+%a %b %d %T %Y"` LOTTOBINGO: $USER >> $gllog
[ -f $tmp/win5 ] || {
# going for the check 5 balls!
usersballs=`cat $tmp/lotto.play|grep "^$USER"|awk -F : '{print $4 " " $5 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " "$14 " "$15 " "$16 " "$17 " "$18}'`
userscore=0
for ball in `echo $usersballs`;do
 if [ "`cat $tmp/lotto.balls|grep "^$ball:"`" != "" ];then
  # Match...count a point! :P
  matchingball="$matchingball $ball"
  userscore=$[userscore + 1]
 fi
done
if [ "$userscore" -gt "4" ];then
touch $tmp/win5
# Winnnnnnnner!!!!!
echo "| Concrats.. we have a 5 balls winner!   |"
echo "| Go spend some credits now! or.. try to |"
echo "| get the 10 balls..too...               |"
echo -e $foot
usercred=`cat $users/$USER|grep CREDITS|awk '{print $2}'`
winkb=$[win5 * 1024];newcred=$[usercred + $winkb]
cat $users/$USER |grep -v "^CREDITS" > $users/$USER.new
echo "CREDITS $newcred" >> $users/$USER.new
mv $users/$USER.new $users/$USER
echo `date "+%a %b %d %T %Y"` LOTTOWIN5: $USER $GROUP \"$TAGLINE\" \"$matchingball\" >> $gllog
exit
else
echo "| False bingo...!!!! dont do that offen  |"
echo "| Or siteops will deny you to play lotto.|"
if [ "$falsebingo" != "0" ];then
echo "| This joke just costed you credits      |"
falsekb=$[falsebingo * 1024]
usercred=`cat $users/$USER|grep CREDITS|awk '{print $2}'`
newcred=$[usercred - $falsekb]
cat $users/$USER |grep -v "^CREDITS" > $users/$USER.new
echo "CREDITS $newcred" >> $users/$USER.new
mv $users/$USER.new $users/$USER
fi
echo -e $foot
echo `date "+%a %b %d %T %Y"` LOTTOFAIL: $USER $GROUP \"$TAGLINE\" >> $gllog
fi
}
[ -f $tmp/win5 ] &&  {
# going for the check 10 balls and complete the game
usersballs=`cat $tmp/lotto.play|grep "^$USER"|awk -F : '{print $4 " " $5 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " "$14 " "$15 " "$16 " "$17 " "$18}'`
userscore=0
for ball in `echo $usersballs`;do
 if [ "`cat $tmp/lotto.balls|grep "^$ball:"`" != "" ];then
  # Match...count a point! :P
  matchingball="$matchingball $ball"
  userscore=$[userscore + 1]
 fi
done
if [ "$userscore" = "10" ];then
# Winnnnnnnner!!!!!
echo "| Concrats.. we have a 10 balls winner!  |"
echo "| Go spend some credits now! Cause the   |"
echo "| Game has just ended by you!..          |"
echo -e $foot
usercred=`cat $users/$USER|grep CREDITS|awk '{print $2}'`
winkb=$[win10 * 1024];newcred=$[usercred + $winkb]
cat $users/$USER |grep -v "^CREDITS" > $users/$USER.new
echo "CREDITS $newcred" >> $users/$USER.new
mv $users/$USER.new $users/$USER
echo `date "+%a %b %d %T %Y"` LOTTOWIN10: $USER $GROUP \"$TAGLINE\" \"$matchingball\" >> $gllog
rm -f $tmp/lotto.play;rm -f $tmp/lotto.balls;rm -f $tmp/win5;rm -f $tmp/$opentag
exit
else
echo "| False bingo...!!!! dont do that offen  |"
echo "| Or siteops will deny you to play lotto.|"
if [ "$falsebingo" != "0" ];then
echo "| This joke just costed you credits      |"
falsekb=$[falsebingo * 1024]
usercred=`cat $users/$USER|grep CREDITS|awk '{print $2}'`
newcred=$[usercred - $falsekb]
cat $users/$USER |grep -v "^CREDITS" > $users/$USER.new
echo "CREDITS $newcred" >> $users/$USER.new
mv $users/$USER.new $users/$USER
fi
echo -e $foot
echo `date "+%a %b %d %T %Y"` LOTTOFAIL: $USER $GROUP \"$TAGLINE\" >> $gllog
fi
}
fi
# End Bingo Routine!

#
# Bot routine
#
if [ "$1" = "bot" ];then
if test -f $glftpd/$tmp/lotto.play ;then
 nrusers=""
 for player in `cat $glftpd/$tmp/lotto.play|awk -F : '{print $1}'`;do 
 nrusers=$[nrusers + 1]
 usernames="$usernames o $player"
 done
echo "$nrusers \"$usernames o\""
exit 0
else
echo "0 \"No users\""
exit 0
fi
fi
# End Bot Routine

#
# Open game routine!
#
if [ "$1" = "open" ];then
 echo ",----------------------------------------."
 echo "| TheOut's LOTTO Casino games            |"
 echo "|----------------------------------------|"
if test -f $tmp/$opentag ; then
 echo "| Game is already open.. so get those    |"
 echo "| players...to join.                     |"
 echo -e $foot
 exit
else
 echo "| Opening the game...hold...             |"
 echo "| Announcing to iRC.                     |"
 echo `date "+%a %b %d %T %Y"` LOTTOOPEN: $USER >> $gllog
 touch $tmp/$opentag
 echo -e $foot
 exit
fi
fi
