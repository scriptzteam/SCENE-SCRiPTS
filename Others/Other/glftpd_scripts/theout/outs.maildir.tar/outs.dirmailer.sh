#!/bin/bash 
#
ver=1.0
# $1 would be the /path/dirname (6th lenght of glftpd.log)
# $2 would be username (7th)
# $3 would be groupname (8th)
# if the dirname does match any keyword specified , then
# it mails ya the sitename and the dirname that got released
# cant be more easier , dont ya think?
# make sure mail works :P
# oki, small HOW-TO get it to work :
# put this file in your /glftpd/bin dir 
# Running Darkone's sfv+TCL ?
# edit the tcl and go to :
#################################################################################
# MAIN LOOP - PARSES DATA FROM GLFTPD.LOG                                       #
#################################################################################
#proc readlog {} {
# global location lastoct disable defaultsection variables msgtypes chanlist
# utimer 1 "readlog"
#
# set glftpdlogsize [file size $location(GLLOG)]
#
# if { $glftpdlogsize == $lastoct } { return 0 }
# if { $glftpdlogsize  < $lastoct } { set lastoct 0 }
# if { [catch { set of [open $location(GLLOG) r] } ] } { return 0 }
#
# seek $of $lastoct         
# while {![eof $of]} {
#  set line [gets $of]      
#  if {$line == ""} {continue}
#  set msgtype [string trim [lindex $line 5] ":"]
#  set path [lindex $line 6]
#  XX <== there put : if {[lindex $line 5] == "NEWDIR:"} {
#  XX <== there put : set mailrun [exec /glftpd/bin/outs.dirmailer.sh [lindex $line 6] [lindex $line 7] [lindex $line 8] ]
#  XX <== there put : }
###################################################################
#
# Running the vshit TCL?
#
# Search for         NEWDIR: {
#
# and add just before the sndall line :
# set mailrun [exec /glftpd/bin/outs.dirmailer.sh [lindex $args 1] [lindex $args 2] [lindex $args 3] ]
###################################################################
#
#
# now your fixed , every NEWDIR is checked and mailed to ya when it has one of the keywords in it
#
# Seperate the search words by |
# (i.e. "manowar|metallica")
searchfor="manowar|metallica"
mailadress[0]="theout@mail.adress.nl"
# maxnumber + 1
totalmailadress=1
sitename="Your Sitename"
mailbinary="mail"
#
# (c) 2002 by TheOut . 
#
# msg me on #glftpd or not :)
#
# Thnx to xore for his wonderfull help
#
# END INFORMATION.... NOW GO PLAY WITH SOMETHING ELSE..
x=0
if [ "`echo $1 | tr '[:upper:]' '[:lower:]'| grep -E $searchfor | tr -d '|'`" != "" ];then
while [ "$x" -lt "$totalmailadress" ];do
echo -e "TheOut's newdir grabber-mailscript $ver\n--------------------------------------------\nNEW release $1 on $sitename -- done by $2@$3"|$mailbinary -s "NEW RELEASE" ${mailadress[$x]}
x=`expr $x + 1`
done
fi
