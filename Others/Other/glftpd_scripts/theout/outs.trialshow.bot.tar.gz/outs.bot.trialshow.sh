#
# Basicly this is a bad RIP from my trialscript.. removed some things
# So it can look ugly.. but it works.. added some small things so the 
# irc channel can be spammed with trial infos :)
#
# (c) 2002 TheOut
#
# Find my website at http://glftpd.rfje.org
# or on efnet #glftpd
# load included tcl into the bot and rehash it :-)
#
# And plz DONT mess up unless you know what your doing.!
#
################ start config #####################
MINTRAILUPLOAD=1500
TRAILDAYS=7
# i.e. !Sitetrial <username>
trigger="Sitetrial"
#
# Add all exempt groups in UPPERCASE!
AFFILS="SITEOPS|LEECH|FRIENDS"
#
# make sure /tmp exists and is writable
#
PASSFILE=/glftpd/etc/passwd
GLUSERS=/glftpd/ftp-data/users
GLLOG=/glftpd/ftp-data/logs/glftpd.log
# lines of announcement :
#
# Vars are : :USER:  = username                       (all)
#            :GROUP: = groupname (primary)            (all)
#            :MBUP:  = there upload                   (ontrial/donetrail)
#            :MBSHORT: = missing                      (ontrial)
#            :DAY:   = number of days there have done (ontrial/donetrail)
# busy with trial...
ontrial="Username: :USER: (:GROUP:) On day: :DAY: and did :MBUP: mb (:MBSHORT: mb short)"
# within trial days and save!
donetrial=":USER: (:GROUP:) is save with :MBUP: mb in :DAY: days."
# affils... type of announce
notrial="Username: :USER: (:GROUP:) is not on trial."
#
# (c) 2002 TheOut. 
#
################## end config ######################
echo `date "+%a %b %e %T %Y"` TRIALCHECKBOT: $USER $GROUP >> $GLLOG
if [ "$1" = "" ];then
echo "Usage: !$trigger <username>"
exit
else
usercheck=$1
fi
[ -f /glftpd/ftp-data/users/$1 ] || { 
echo "Username does not match"
exit
}
n=1;m=1;o="-1";p=1;q=1
while [ "$m" -lt "9" ];do
	TRAILCHECK[$m]=`date --date '+'$[o + 1]' days ago' +%m-%d-%y`
m=$[m + 1];o=$[o + 1]
done
DATETODAY=`date +%m%d%y`
ls $GLUSERS/ > /tmp/.usersfile
while [ "$n" -lt "8" ];do
	cat $PASSFILE |grep "${TRAILCHECK[$n]}" |awk -F ':' '{print $1}' >> /tmp/.tocheckfile$n
	n=$[n + 1]
done
while [ "$p" -lt "8" ];do
for x in `cat /tmp/.tocheckfile$p |awk '{print $1}'`
do
GETGROUP=`cat $GLUSERS/$x | grep "^GROUP" | awk '{print $2}'`
if [ "$GETGROUP" = "" ];then
GETGROUP=NoGroup
fi
day1=1
GETUP=`cat $GLUSERS/$x | grep "ALLUP" | awk '{print $3}'`
MONTHMB=`expr $GETUP / 1024`
MBSHORT=`expr $MINTRAILUPLOAD - $MONTHMB`
USER1=`basename $x`
if [ "$USER1" = "$usercheck" ];then
if [ $MONTHMB -gt "-1" ] && [ $MONTHMB -lt $MINTRAILUPLOAD ];then
    if [ "`echo $GETGROUP | tr '[:lower:]' '[:upper:]' |grep -vE "$AFFILS"| tr -d '|'`" != "" ];then
	echo $ontrial|sed 's/:USER:/'$USER1'/g'|sed 's/:GROUP:/'$GETGROUP'/g'|sed 's/:DAY:/'$p'/g'| sed 's/:MBUP:/'$MONTHMB'/g'|sed 's/:MBSHORT:/'$MBSHORT'/g'
	q=0
	else
	echo $notrial|sed 's/:USER:/'$USER1'/g'|sed 's/:GROUP:/'$GETGROUP'/g'
	q=0
    fi
else
    if [ "`echo $GETGROUP | tr '[:lower:]' '[:upper:]' |grep -vE "$AFFILS"| tr -d '|'`" != "" ];then
	echo $donetrial|sed 's/:USER:/'$USER1'/g'|sed 's/:GROUP:/'$GETGROUP'/g'|sed 's/:DAY:/'$p'/g'| sed 's/:MBUP:/'$MONTHMB'/g'
	q=0
	else
	echo $notrial|sed 's/:USER:/'$USER1'/g'|sed 's/:GROUP:/'$GETGROUP'/g'
	q=0
    fi
fi
fi
done
rm -f /tmp/.tocheckfile$p
p=$[p + 1]
done
[ "$q" = "1" ] && { 
echo "$1 isnt in his trial period anymore."
}
rm -f /tmp/.usersfile
rm -f /tmp/.deletedusers
exit

