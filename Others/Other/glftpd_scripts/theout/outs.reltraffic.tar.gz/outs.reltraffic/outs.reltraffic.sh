#!/bin/bash -
#
ver=1.0c
# Version 1.0  - Started it today, irritating some affils..
#                and wanted to see if there releases where
#                traded or not...
# Version 1.0b - minor updates , not even worth mention :-)
# Version 1.0c - Added number of users/groups to the stats.
#                Found a bug that would keep counting MB's
#                when executed script few times after eachother
# Version 1.0c - Updated no message send to supervisor if user
#                is the supervisor.
#                
# Get the latest scripts at www.glftpd.org and www.glftpd.com
# Or check my Homepage for latest versions!
#
# I can not be held responsible for any damage
# done to the server by using this script.
# Keep a little sense and dont remove the name from
# me.. if you want credits.. think of something yourself!
# and make it!
# Btw sorry for the lame ass easy coding - was at work
# and was too busy to make it a clean one...
# At least its workin , and for the first time.. PUBLIC!
#
# Release traffic Checker 1.0 by TheOut (c) 10/26/2001
#
# make sure you have all required binary's in your ~/bin dir
#
# echo , cat
# and if you get permission faults make msgs dir 777
# (thnx to RapidFire for his testing!)
# (thnx to RapidFire for his webspace!)
# add following lines to your glftpd.conf
#
#        site_cmd RELSTATS      EXEC   /bin/outs.reltraffic.sh
#        custom-relstats        1

## login to your site and try RAW commando : 'site relstats release.name'
# you can test the script from root too :P .. 'site relstats release.name root'
# 
# only modify lines below...
# Installdir (prolly dont need to change that)

installdir=/glftpd/ftp-data/
#
# supervisor server nick name... (will recieve a msg)
supervisor=TheOut

#
# name of the groups dir (i.e. PRiVATE or groups or....)
groupsdir=groups

#
# Dont touch anything below...! plz!
# 
#########################################################
rm -f /tmp/tempprefile3
rm -f /tmp/groupsfile
rm -f /tmp/nongroupsfile
rm -f /tmp/tempprefile2
if [ "$2" = "root" ];then
xferlog=$installdir/logs/xferlog
msgdir=$installdir/msgs/
else
xferlog=/ftp-data/logs/xferlog
msgdir=/ftp-data/msgs/
fi
searchdata=$1
dat=1;data=1;data2=1;data3=1;i=0;j=0;k=0;l=0;m=0;n=0
out=""

################################################################################################
user=`basename $USER`
echo "TheOut's release traffic checker V$ver"
echo "-------------------------------------------------------"
if [ "$1" = "" ];then
echo "You must enter a release dir or group"
echo ""
echo "i.e. 'site relstats <RelName>'
echo "
echo "Also try with affils.!! nice option there"
else 
echo "Your request has been made please be patient as"
echo "your query could take some time. All collected info"
echo "will be 'site msg $user output' to you"
echo "Reconnect at a later and do 'site msg read' to see"
echo "Output of your query. Thanks for using my latest script"
echo ""
echo "TheOut"
echo "(  no output means no hits found :-)  )"
search=`cat $xferlog | grep "$1" | awk '{print $8 ":" $9 ":" $12 ":" $14 ":" $15}'`
[ "$search" != "" ] || exit 0
for x in `echo $search` 
do
	if [ "`echo $x | awk -F ':' '{print $3}'`" = "o" ];then
	        echo "$x" >> /tmp/tempprefile2
	else
		echo "$x" >> /tmp/tempprefile3
	fi
done
[ -f "/tmp/tempprefile2" ] || touch /tmp/tempprefile2
[ -f "/tmp/tempprefile3" ] || touch /tmp/tempprefile3
cat /tmp/tempprefile2 | grep "$groupsdir" >> /tmp/groupsfile 
cat /tmp/tempprefile2 | grep -v "$groupsdir" >> /tmp/nongroupsfile 
#####################################################################################
x=0
# grab incoming traffic 
for x in `cat /tmp/tempprefile3 | awk -F ':' '{print $1}'`
do
	x=$[x / 1024]
        dat=$[dat + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/tempprefile3 | awk -F ':' '{print $4}' | sort -n | uniq `
do
	i=$[i + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/tempprefile3 | awk -F ':' '{print $5}' | sort -n | uniq `
do
        l=$[l + 1]
done
#####################################################################################
# grab groups dir traffic
x=0
for x in `cat /tmp/groupsfile | awk -F ':' '{print $1}'`
do
	x=$[x / 1024]
	data=$[data + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/groupsfile | awk -F ':' '{print $4}' | sort -n | uniq `
do
        j=$[j + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/groupsfile | awk -F ':' '{print $5}' | sort -n | uniq `
do
        m=$[m + 1]
done
#####################################################################################
# grab traffic without groups dir
x=0
for x in `cat /tmp/nongroupsfile | awk -F ':' '{print $1}'`
do
	x=$[x / 1024]
        data2=$[data2 + $x]
done
# Number Users ######################################################################
for a in `cat /tmp/nongroupsfile | awk -F ':' '{print $4}' | sort -n | uniq`
do
        k=$[k + 1]
done
# Number Groups #####################################################################
for a in `cat /tmp/nongroupsfile | awk -F ':' '{print $5}' | sort -n | uniq`
do
        n=$[n + 1]
done

echo "From: TheOut's release traffic checker V$ver (`date "+%a %b %e %T %Y"`)" >> $msgdir$user
echo "--------------------------------------------------------------------------" >> $msgdir$user
echo "Data traffic stats for $1 release" >> $msgdir$user
echo " " >> $msgdir$user
if [ "$dat" = "1" ];then
        dat="(no traffic)"
else
	dat=$[dat / 1024]
        dat="$dat MB"
fi
echo "Uploaded                      : $dat" >> $msgdir$user
echo "Uploaded by                   : $i Users from $l Groups" >> $msgdir$user
echo "--------------------------------------------------------" >> $msgdir$user
if [ "$data2" = "1" ];then
        data2="(no traffic)"
else
	data2=$[data2 / 1024]
        data2="$data2 MB"
fi
echo "Downloaded                    : $data2" >> $msgdir$user
echo "Downloaded by                 : $k Users from $n Groups" >> $msgdir$user
echo "--------------------------------------------------------" >> $msgdir$user
if [ "$data" = "1" ];then
        data="(no traffic)"
else
	data=$[data / 1024]
	echo "Downloaded from groups dir    : $data MB" >> $msgdir$user
	echo "Downloaded from groups dir by : $j Users from $m Groups" >> $msgdir$user
	echo "--------------------------------------------------------" >> $msgdir$user
fi
echo " " >> $msgdir$user
	if [ $user != $supervisor ];then
		echo "From: TheOut's release traffic checker V$ver (`date "+%a %b %e %T %Y"`)" >> $msgdir$supervisor
		echo "--------------------------------------------------------------------------" >> $msgdir$supervisor
		echo "$user requested info on $1" >> $msgdir$supervisor
		echo "Up: $dat - Dn: $data2 - Dn of Grp: $data MB" >> $msgdir$supervisor
		echo " " >> $msgdir$supervisor
	fi
fi
####################################################################
rm -f /tmp/tempprefile3
rm -f /tmp/groupsfile
rm -f /tmp/nongroupsfile
rm -f /tmp/tempprefile2

