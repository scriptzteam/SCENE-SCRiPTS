#!/bin/perl
#
# Script Created by Apocalypse of JiNxEdStAr
# Visit us at http://JiNxEdStAr.0ne.us
#
# Apocalypse glFTPd Locate script [PERL] v1.3

# The path where your data is
# Remember, you are chrooted
# DO NOT INCLUDE A TRAILING BACKSLASH
$ROOT = "/site";

# What is your sitename?
# Used to match against [SITENAME] directories so we can ignore them
# Ex: [ApoC] - COMPLETE - [ApoC]
# It is case-sensitive!
# To disable this feature, set it to ""
$SITENAME = "";

# Do you want to use file-based logging?
# 1 for yes, 0 for no
$USELOG = "1";

# Your log directory
# (Relative to glftpd path)
# Checked only if $USELOG is enabled
# DO NOT INCLUDE A TRAILING BACKSLASH
$LOGDIR = "/ftp-data/logs";

# Your Logname
# Checked only if $USELOG is enabled
$LOGNAME = "apocscripts.log";

# DO not edit below unless you know what you're doing

# Setup our output flushing [ Auto-Flush ]
$| = 1;

# Some Global Variables
my $search;			# Search string
my $matches = 0;		# Number of matches
my $searchdir = 0;		# 1 = enabled, 0 = disabled ( default is enabled )
my $searchfile = 0;		# 1 = enabled, 0 = disabled
my $display = 10;		# Number of matches to display
my $casesensv = 0;		# 1 = sensitive, 0 = insensitive ( default is insensitive )
my $version = "1.3";		# Version, duh :)

# Prototypes
sub RecurList ($);
sub clean_hit ($);
sub error_proc ($);
sub log_proc ($$);
sub check_settings ();

# Check our settings
if ( $ARGV[0] eq "CHECK_SETTINGS" ) {
	check_settings();

	# We passed the test
	print "SETTiNGS oK!\n";

	# Exit the program
	exit 0;
} elsif ( $ARGV[0] eq "NOCHK" ) {
	# Remove the pesky NOCHK
	shift(@ARGV);
} else {
	# Print the header
	print "|------------------------| Apocalypse Locate |------------------------|\n";

	error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 13\]");
}

# We check settings then proceed with the rest of the script
check_settings();

# Print the header
print "|------------------------| Apocalypse Locate |------------------------|\n";

# Make sure we can't be h4x0r3d
if ( join( "", @ARGV[ 0 .. $#ARGV ] ) !~ /^[\w\s\.\-]+$/ ) {
	$search = quotemeta( join( " ", @ARGV[ 0 .. $#ARGV ] ) );
	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to hack us with \"$search\"");
	error_proc("Sorry, invalid search name!");
}

# Make sure we have some arguments
if ( $#ARGV == -1 ) {
	printf( "| %-68s|\n", "Usage: locate [-f] [-d] [-df] [-c] [-number] name" );
	printf( "| %-68s|\n", "-f -> Search for files" );
	printf( "| %-68s|\n", "-d -> Search for directories" );
	printf( "| %-68s|\n", "-df -> Search for dir + file" );
	printf( "| %-68s|\n", "-c -> Be Case-Sensitive" );
	printf( "| %-68s|\n", "-number -> Display this many matches" );
	printf( "| %-68s|\n", "The default is to search for dir + case-insensitive + 10 matches" );
	printf( "| %-68s|\n", "Example: locate -f -20 -c ApoC" );
	exit 0;
}

# Loop over our arguments
my $counter = 0;
while ( $counter <= $#ARGV ) {
	if ( $ARGV[$counter] eq "-c" ) {
		# Case-sensitive search
		$casesensv = 1;

		# Remove this from the array
		splice(@ARGV, $counter, 1);

		# We do not increment the counter because of the splicing
		next;
	} elsif ( $ARGV[$counter] eq "-f" ) {
		# File Search
		$searchfile = 1;

		# Check for dirsearch ( disable it )
		if ( $searchdir ) { $searchdir = 0 }

		# Remove this from the array
		splice(@ARGV, $counter, 1);

		# We do not increment the counter because of the splicing
		next;
	} elsif ( $ARGV[$counter] eq "-d" ) {
		# Directory Search
		$searchdir = 1;

		# Check for filesearch ( disable it )
		if ( $searchfile ) { $searchfile = 0 }

		# Remove this from the array
		splice(@ARGV, $counter, 1);

		# We do not increment the counter because of the splicing
		next;
	} elsif ( $ARGV[$counter] eq "-df" ) {
		# Directory + File Search
		if ( $searchdir ) { error_proc("You don't need to include -d and -df") }
		else { $searchdir = 1 }

		if ( $searchfile ) { error_proc("You don't need to include -f and -df") }
		else { $searchfile = 1 }

		# Remove this from the array
		splice(@ARGV, $counter, 1);

		# We do not increment the counter because of the splicing
		next;
	} elsif ( $ARGV[$counter] =~ /^\-(\d+)$/ ) {
		# Number of hits
		if ( $1 > 0 and $1 < 31 ) {
			$display = $1;

			# Remove this from the array
			splice(@ARGV, $counter, 1);

			# We do not increment the counter because of the splicing
			next;
		} else {
			error_proc("The number of matches must be between 1 and 30!");
		}
	} elsif ( $ARGV[$counter] =~ /^\-/ ) {
		# Unrecognizable modifier
		error_proc("Unrecognizable argument: $ARGV[$counter]");
	} else {
		# Proceed to next word
		$counter++;
	}
}

# Set the search string
$search = join(" ", @ARGV);

# Convert spaces to .* in arguments to search for all
$search =~ s/\s+/\.\*/g;

# Check our file/dir search type
if ( ! $searchdir and ! $searchfile ) {
	# Assume we search directories
	$searchdir = 1;
}

# Construct the recursive listing parser from our settings
my $parsercode = <<'EOPC';
sub RecurList ($) {
	my $dirpath = shift;
	if ( ! opendir( DIRECTORY, $dirpath ) ) {
		log_proc("2","Couldnt open $dirpath while searching \( $search \) for $ENV{USER}\@$ENV{GROUP}");
		error_proc("Unable to open directory for searching!");
	}
	my @dirlist = readdir( DIRECTORY );
	closedir( DIRECTORY );
	if ( ! @dirlist ) {
		log_proc("2","Couldnt read $dirpath info while searching \( $search \) for $ENV{USER}\@$ENV{GROUP}");
		error_proc("Unable to open directory for searching!");
	}
	shift( @dirlist ); shift( @dirlist );
	foreach my $name ( @dirlist ) {
		if ( $matches == $display ) { last }
EOPC

# Will we match against sitename?
if ( $SITENAME ne "" ) {
	$parsercode .= 'if ( $name =~ /\[$SITENAME\]/o ) { next }';
}

# Figure out if we are doing dirsearch or filesearch or both :)
if ( $searchdir and $searchfile ) {
	# BOTH Directory and File searching
	$parsercode .= 'if ( $name =~ /^\./ ) { next }';

	# Do we do case-sensitive searches?
	if ( $casesensv ) { $parsercode .= 'if ( $name =~ /$search/o ) {' }
	else { $parsercode .= 'if ( $name =~ /$search/io ) {' }

	# Append the rest
	$parsercode .= '&clean_hit( "$dirpath/$name" );}if ( -d "$dirpath/$name" ) { &RecurList( "$dirpath/$name" ) }';
} elsif ( $searchdir ) {
	# Directory searching
	$parsercode .= 'if ( -d "$dirpath/$name" ) {';

	# Do we do case-sensitive searches?
	if ( $casesensv ) { $parsercode .= 'if ( $name =~ /$search/o ) {' }
	else { $parsercode .= 'if ( $name =~ /$search/io ) {' }

	# Append the rest
	$parsercode .= '&clean_hit( "$dirpath/$name" )}&RecurList( "$dirpath/$name" );}';
} elsif ( $searchfile ) {
	# File Searching
	$parsercode .= 'if ( $name =~ /^\./ ) { next }if ( -f "$dirpath/$name" ) {';

	# Do we do case-sensitive searches?
	if ( $casesensv ) { $parsercode .= 'if ( $name =~ /$search/o ) {' }
	else { $parsercode .= 'if ( $name =~ /$search/io ) {' }

	# Append the rest
	$parsercode .= '&clean_hit( "$dirpath/$name" )}}if ( -d _ ) { &RecurList( "$dirpath/$name" ) }';
} else {
	# SHOULD NEVER GO HERE :)
	error_proc("Please specify either directories or files to search");
}

# Common end of test block
$parsercode .= '}}';

# Compile the parser
eval "$parsercode";

# Check for errors
if ( $@ ) {
	error_proc("Internal error in initializing the parser");
}

# Call the function to recurse over the list searching for match
&RecurList( $ROOT );

# Print out the match footer
if ( $matches == 0 ) {
	printf( "| %-68s|\n", "Sorry, we did not find any matches." );
}

exit 0;

# This routine cleans up the incoming string of the $ROOT variable and prints the match
sub clean_hit ($) {
	# Strip the maindir from the name
	my $match = shift;
	$match =~ /^$ROOT(.*)$/o;
	printf( "| %-68s|\n", $1 );
	$matches++;
}

# This is the procedure that prints out the error and dies
sub error_proc ($) {
	my $errorstring = shift;
	printf( "| %-68s|\n", $errorstring );
	exit 2;
}

# This is the procedure that logs all errors/warnings/information to a logfile
# Code 1 = ERROR
# Code 2 = INFORMATION
sub log_proc ($$) {
	my $errcode = shift;
	my $string = shift;

	if ( $USELOG ) {
		# Get the current time and month/day/year
		my ( $sec, $min, $hour, $day, $month, $year ) = localtime( time );
		my $ampm = "AM";

		# Format the time
		if ( $sec < 10 ) {
			$sec = "0" . $sec;
		}
		if ( $min < 10 ) {
			$min = "0" . $min;
		}
		if ( $hour < 10 ) {
			$hour = "0" . $hour;
		} elsif ( $hour == 12 ) {
			$ampm = "PM";
		} elsif ( $hour > 12 ) {
			$hour -= 12;
			$ampm = "PM";
			if ( $hour < 10 ) {
				$hour = "0" . $hour;
			}
		}
		if ( $day < 10 ) {
			$day = "0" . $day;
		}
		$month++;
		$month = sprintf("%02d",$month);
		$year += 1900;

		open( LOG, ">>$LOGDIR/$LOGNAME" ) || error_proc("Unable to open the logging file!");

		# Print out the final strings
		if ( $errcode == 1 ) {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| Locate \) ERROR \- $string\n";
			close(LOG);
			error_proc( $string );
		} else {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| Locate \) INFORMATION \- $string\n";
			close(LOG);
			return 0;
		}
	} else {
		if ( $errcode == 1 ) {
			error_proc( $string );
		} else {
			return 0;
		}
	}
}

# The Checking routine
sub check_settings () {
	# Make sure all of our variables are defined
	if ( ! defined $ROOT ) 		{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 1\]") }
	if ( ! defined $SITENAME ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 2\]") }
	if ( ! defined $USELOG ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 3\]") }
	if ( ! defined $LOGDIR ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 4\]") }
	if ( ! defined $LOGNAME ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 5\]") }

	# Sanity check of ROOT
	if ( $ROOT =~ /\/$/ or $ROOT !~ /^\// ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 6\]");
	}

	# Sanity check of USELOG
	if ( $USELOG !~ /^[\d]+$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 7\]");
	}
	if ( ! ( $USELOG eq "0" or $USELOG eq "1" ) ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 8\]");
	}

	# Sanity check of $LOGDIR variable
	if ( $USELOG and $LOGDIR =~ /\/$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 9\]");
	}

	# Logging features checking...
	if ( $USELOG and ! -w "$LOGDIR/$LOGNAME" and ! -e "$LOGDIR/$LOGNAME" ) {
		open(LOG, ">$LOGDIR/$LOGNAME") || error_proc("Unable to create the logging file! \[code 10\]");
		close LOG;

		if ( ! chmod 0666, "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 11\]");
		}

		if ( ! chown "0", "0", "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 12\]");
		}

		log_proc("2","The log $LOGDIR/$LOGNAME doesn\'t exist, creating it");
	}
}

# The END Block
sub END {
	# Test if this was a check_settings
	if ( $ARGV[0] ne "CHECK_SETTINGS" ) {
		# Print out the footer whenever we exit
		print "|------------------------|    Version $version    |------[ " . sprintf("%2d", $matches) . " match(es) ]--|\n";
	}
}