#!/bin/perl
#
# Script Created by Apocalypse of JiNxEdStAr
# Visit us at http://JiNxEdStAr.0ne.us
#
# Apocalypse glFTPd SITE UNDIRDUPE script [PERL] v1.3

# Where is the dupelog?
# (Relative to glftpd path)
# You probably don't need to change this...
# DO NOT INCLUDE A TRAILING BACKSLASH
$DUPELOGDIR = "/ftp-data/logs";

# What is the name of your dupelog?
# (Relative to glftpd path)
# You probably don't need to change this...
$DUPELOGFILE = "dupelog";

# Do you want the advanced "log" cleaning feature enabled?
# It will auto-wipe "CDx, SAMPLE, COVER(S), VOBSUB, OGGDEC, TEST" from dupelog
# 1 for yes, 0 for no
$CLEANLOG = "1";

# Do you want to use file-based logging?
# 1 for yes, 0 for no
$USELOG = "1";

# Your log directory
# (Relative to glftpd path)
# Checked only if $USELOG is enabled
# DO NOT INCLUDE A TRAILING BACKSLASH
$LOGDIR = "/ftp-data/logs";

# Your Logname
# Checked only if $USELOG is enabled
$LOGNAME = "apocscripts.log";

# DO not edit below unless you know what you're doing

# Setup our output flushing [ Auto-Flush ]
$| = 1;

# Check our settings
if ( $ARGV[0] eq "CHECK_SETTINGS" ) {
	check_settings();

	# We passed the test
	print "SETTiNGS oK!\n";

	# Exit the program
	exit 0;
}

# We check settings then proceed with the rest of the script
check_settings();

# If no arguments specified, print usage
if ( $#ARGV == -1 ) {
	error_proc("Usage\: SITE UNDIRDUPE dirname");
}

# Get the argument
# Skip over $ARGV[0] as it is 'NOCHK' to prevent h4x
my $undirdupe = join(" ", @ARGV[ 1 .. $#ARGV ] );
chomp $undirdupe;

# Make sure we can't be h4x0r3d
if ( $undirdupe !~ /^[\w\s\(\)\.\-]+$/ ) {
	$undirdupe = quotemeta($undirdupe);
	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to hack us with \"$undirdupe\"");
	error_proc("Sorry, invalid directory name!");
}

# Open up the files
open(DUPELOG, "$DUPELOGDIR/$DUPELOGFILE") || log_proc("1","Unable to open the dupelog");
open(TEMPLOG, ">>$DUPELOGDIR/$DUPELOGFILE.tmp.$$") || log_proc("1","Unable to create the temporary dupelog");

# Disable buffering on the DUPELOG
select(DUPELOG);
$| = 0;
select(STDOUT);

# This is the routine that searches through the dupelog for the request
# If LOGCLEAN is enabled, will clean up the log automatically
my $success = 0;
my $cleanup = 0;
my $string;
if ( $CLEANLOG ) {
	while( $string = <DUPELOG> ) {
		# Remove pesky newline
		chomp $string;

		# See if this matches what we want to undirdupe
		if ( $string =~ /^.......\Q$undirdupe\E$/io ) {
			$success++;
		} else {
			# Try auto-cleaning this directory
			if ( $string =~ /^.......(?:cd|dis[ck])[-_]?(?:[0-9]{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)|sample|stats|vobsub|oggdec|test$/i ) {
				$cleanup++;
			} else {
				print TEMPLOG "$string\n";
			}
		}
	}
} else {
	while( $string = <DUPELOG> ) {
		# Remove pesky newline
		chomp $string;

		# See if this matches what we want to undirdupe
		if ( $string =~ /^.......\Q$undirdupe\E$/io ) {
			$success++;
		} else {
			print TEMPLOG "$string\n";
		}
	}
}

# Close the filehandles
close(DUPELOG);
close(TEMPLOG);

# Do the final preparation
if ( $success == 0 and $cleanup == 0 ) {
	del_temp_dupelog();

	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to undirdupe \"$undirdupe\" \- failed");
	error_proc("Sorry, couldnt UnDirDupe \"$undirdupe\"");
} elsif ( $success == 0 and $cleanup > 0 ) {
	# Move the temporary file to the original, overwriting it
	if ( ! rename "$DUPELOGDIR/$DUPELOGFILE.tmp.$$", "$DUPELOGDIR/$DUPELOGFILE" ) {
		log_proc("2","Unable to overwrite the dupelog with the cleaned up one - $DUPELOGDIR/$DUPELOGFILE.tmp.$$");

		del_temp_dupelog();
	}

	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to undirdupe \"$undirdupe\" \- failed \[cleaned up $cleanup records \]");
	error_proc("Sorry, \"$undirdupe\" was not found in the dupelog");
} elsif ( $success > 0 ) {
	# Move the temporary file to the original, overwriting it
	if ( ! rename "$DUPELOGDIR/$DUPELOGFILE.tmp.$$", "$DUPELOGDIR/$DUPELOGFILE" ) {
		log_proc("2","Unable to overwrite the dupelog with the cleaned up one - $DUPELOGDIR/$DUPELOGFILE.tmp.$$");

		del_temp_dupelog();

		error_proc("Match found, but unable to replace the old dupelog!");
	}

	if ( $success == 1 ) {
		log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to undirdupe \"$undirdupe\" \- successful \[cleaned up $cleanup records \]");
		print "Directory \"$undirdupe\" is now UnDirDuped\n";
	} else {
		log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to undirdupe \"$undirdupe\" \[$success records\] \- successful \[cleaned up $cleanup records \]");
		print "Directory \"$undirdupe\" \[$success records\] is now UnDirDuped\n";
	}

	exit 0;
}

# Procedures go here

# This is the procedure that prints out the error and dies
sub error_proc {
	my $errorstring = shift;
	print "$errorstring\n";

	# Check whether this was a settings test
	if ( $ARGV[0] eq "CHECK_SETTINGS" ) {
		print "SETTiNGS NOT oK!\n";
	}

	exit 2;
}

# This is the procedure that logs all errors/warnings/information to a logfile
# Code 1 = ERROR
# Code 2 = INFORMATION
sub log_proc {
	my $errcode = shift;
	my $string = shift;

	if ( $USELOG ) {
		# Get the current time and month/day/year
		my ( $sec, $min, $hour, $day, $month, $year ) = localtime( time );
		my $ampm = "AM";

		# Format the time
		if ( $sec < 10 ) {
			$sec = "0" . $sec;
		}
		if ( $min < 10 ) {
			$min = "0" . $min;
		}
		if ( $hour < 10 ) {
			$hour = "0" . $hour;
		} elsif ( $hour == 12 ) {
			$ampm = "PM";
		} elsif ( $hour > 12 ) {
			$hour -= 12;
			$ampm = "PM";
			if ( $hour < 10 ) {
				$hour = "0" . $hour;
			}
		}
		if ( $day < 10 ) {
			$day = "0" . $day;
		}
		$month++;
		$month = sprintf("%02d",$month);
		$year += 1900;

		open( LOG, ">>$LOGDIR/$LOGNAME" ) || error_proc("Unable to open the logging file!");

		# Print out the final strings
		if ( $errcode == 1 ) {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| UnDirDupe \) ERROR \- $string\n";
			close(LOG);
			error_proc("$string");
		} else {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| UnDirDupe \) INFORMATION \- $string\n";
			close(LOG);
			return 0;
		}
	} else {
		if ( $errcode == 1 ) {
			error_proc("$string");
		} else {
			return 0;
		}
	}
}

# This is the procedure that removes the temporary dupelog
sub del_temp_dupelog {
	if ( ! unlink "$DUPELOGDIR/$DUPELOGFILE.tmp.$$" ) {
		log_proc("2","Unable to remove the temporary file $DUPELOGDIR/$DUPELOGFILE.tmp.$$");
	}
}

# The Checking routine
sub check_settings {
	# Make sure all of our variables are defined
	if ( ! defined $DUPELOGDIR ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 1\]") }
	if ( ! defined $DUPELOGFILE ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 2\]") }
	if ( ! defined $USELOG ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 3\]") }
	if ( ! defined $LOGDIR ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 4\]") }
	if ( ! defined $LOGNAME ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 5\]") }
	if ( ! defined $CLEANLOG ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 6\]") }

	# Sanity check of $DUPELOGDIR variable
	if ( $DUPELOGDIR =~ /\/$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 7\]");
	}

	# Check to see if the DUPELOGDIR exists
	if ( ! -d $DUPELOGDIR ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 7\]");
	}

	# Check to see if we can read from dupelog
	if ( ! -r "$DUPELOGDIR/$DUPELOGFILE" ) {
		log_proc("1","Unable to read the dupelog!");
	}

	# Check to see if we can write to the dupelog
	if ( ! -w "$DUPELOGDIR/$DUPELOGFILE" ) {
		log_proc("1","Unable to write to the dupelog!");
	}

	# Check to see if we can write to dupelog dir
	if ( ! -w "$DUPELOGDIR" ) {
		log_proc("1","Unable to write to the dupelog dir");
	}

	# Sanity check of USELOG
	if ( $USELOG !~ /^[\d]+$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 9\]");
	}
	if ( ! ( $USELOG eq "0" or $USELOG eq "1" ) ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 10\]");
	}

	# Sanity check of $LOGDIR variable
	if ( $USELOG and $LOGDIR =~ /\/$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 11\]");
	}

	# Logging features checking...
	if ( $USELOG and ! -w "$LOGDIR/$LOGNAME" and ! -e "$LOGDIR/$LOGNAME" ) {
		open(LOG, ">$LOGDIR/$LOGNAME") || error_proc("Unable to create the logging file! \[code 12\]");
		close LOG;

		if ( ! chmod 0666, "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 13\]");
		}

		if ( ! chown "0", "0", "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 14\]");
		}

		log_proc("2","The log $LOGDIR/$LOGNAME doesn\'t exist, creating it");
	}

	# Sanity check of CLEANLOG
	if ( $CLEANLOG !~ /^[\d]+$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 15\]");
	}
	if ( ! ( $CLEANLOG eq "0" or $CLEANLOG eq "1" ) ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 16\]");
	}
}