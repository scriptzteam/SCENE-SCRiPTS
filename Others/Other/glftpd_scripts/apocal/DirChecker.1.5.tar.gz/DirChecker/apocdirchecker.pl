#!/bin/perl
#
# Script Created by Apocalypse of JiNxEdStAr
# Visit us at http://JiNxEdStAr.0ne.us
#
# Apocalypse glFTPd Dupechecker for Directories script [PERL] v1.5

# Where is the dupelog?
# (Relative to glftpd path)
# You probably don't need to change this...
# DO NOT INCLUDE A TRAILING BACKSLASH
$DUPELOGDIR = "/ftp-data/logs";

# What is the name of your dupelog?
# (Relative to glftpd path)
# You probably don't need to change this...
$DUPELOGFILE = "dupelog";

# Do you want to use file-based logging?
# 1 for yes, 0 for no
$USELOG = "1";

# Your log directory
# (Relative to glftpd path)
# Checked only if $USELOG is enabled
# DO NOT INCLUDE A TRAILING BACKSLASH
$LOGDIR = "/ftp-data/logs";

# Your Logname
# Checked only if $USELOG is enabled
$LOGNAME = "apocscripts.log";

# DO not edit below unless you know what you're doing

# Setup our output flushing [ Auto-Flush ]
$| = 1;

# Check our settings
if ( $ARGV[0] eq "CHECK_SETTINGS" and ! exists $ARGV[1] ) {
	check_settings();

	# We passed the test
	print "SETTiNGS oK!\n";

	# Exit the program
	exit 0;
}

# We check settings then proceed with the rest of the script
check_settings();

# If no arguments specified, print error
if ( $#ARGV == -1 ) {
	log_proc("1","Did not receive any arguments!");
}

# Get the dirname
my $dirname = $ARGV[0];
chomp $dirname;

# Make sure we can't be h4x0r3d
if ( $dirname !~ /^[\w\s\(\)\.\-]+$/ ) {
	$dirname = quotemeta($dirname);
	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to hack us with \"$dirname\"");
	error_proc("Sorry, invalid directory name!");
}

# Check ARGV[1] to see if it is valid
if ( ! -d $ARGV[1] ) {
	error_proc("glFTPd passed us an invalid directory!");
}

# Check for llama CD1, cD1 in same dir
if ( opendir(DIRSTRUCT, $ARGV[1]) ) {
	foreach my $dirstruct ( readdir( DIRSTRUCT ) ) {
		if ( $dirstruct =~ /^$dirname$/io ) {
			if ( -d "$ARGV[1]/$dirstruct" ) {
				log_proc("2","CAPS DUPE: $ENV{USER}\@$ENV{GROUP} tried to create directory \"$dirname\" in \"$ARGV[1]\"");

				# Clean up the $ARGV[1] of the /site
				$ARGV[1] =~ /^\/.*?\/(.*)/;
				$ARGV[1] = '/' . $1;
				error_proc("A directory with the same name already exists in \"$ARGV[1]\"");
			}
		}
	}
} else {
	error_proc("Unable to verify directory structure!");
}

# If the directory request is a common directory, allow it
if ( $dirname =~ /^(?:cd|dis[ck])[-_]?(?:[0-9]{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)|sample|stats|vobsub|oggdec|test$/i ) {
	accept_proc();
}

# Open up the dupelog
open( DUPELOG, "$DUPELOGDIR/$DUPELOGFILE" ) || log_proc("1","Unable to open the dupelog!");

# Disable buffering on the DUPELOG
select(DUPELOG);
$| = 0;
select(STDOUT);

# This is the routine that searches through the dupelog for the requested directory
my $success = 0;
my $hit;
my $string;
while( $string = <DUPELOG> ) {
	# Remove pesky newline
	chomp $string;

	if ( $string =~ /\Q$dirname\E/io ) {
		$hit = ( split( /\s+/, $string ) )[0];
		$hit =~ /^(..)(..)(..)/;
		$hit = join( "/", $1, $2, $3 );

		$success++;
		last;
	}
}

# Close the filehandle
close(DUPELOG);

# Do the final preparation
if ( $success == 0 ) {
	accept_proc();
} else {
	log_proc("2","$ENV{USER}\@$ENV{GROUP} tried to create a directory named \"$dirname\" \[ created on $hit \] \- failure");
	error_proc("Sorry, the directory \"$dirname\" already exists \- created on $hit");
}

# Procedures go here

# This is the procedure that displays successful creation of directory
sub accept_proc {
	print "Directory \"$dirname\" passed the dupe test!\n";
	exit 0;
}

# This is the procedure that prints out the error and dies
sub error_proc {
	my $errorstring = shift;
	print "$errorstring\n";

	# Check whether this was a settings test
	if ( $ARGV[0] eq "CHECK_SETTINGS" and ! exists $ARGV[1] ) {
		print "SETTiNGS NOT oK!\n";
	}

	exit 2;
}

# This is the procedure that logs all errors/warnings/information to a logfile
# Code 1 = ERROR
# Code 2 = INFORMATION
sub log_proc {
	my $errcode = shift;
	my $string = shift;

	if ( $USELOG ) {
		# Get the current time and month/day/year
		my ( $sec, $min, $hour, $day, $month, $year ) = localtime( time );
		my $ampm = "AM";

		# Format the time
		if ( $sec < 10 ) {
			$sec = "0" . $sec;
		}
		if ( $min < 10 ) {
			$min = "0" . $min;
		}
		if ( $hour < 10 ) {
			$hour = "0" . $hour;
		} elsif ( $hour == 12 ) {
			$ampm = "PM";
		} elsif ( $hour > 12 ) {
			$hour -= 12;
			$ampm = "PM";
			if ( $hour < 10 ) {
				$hour = "0" . $hour;
			}
		}
		if ( $day < 10 ) {
			$day = "0" . $day;
		}
		$month++;
		$month = sprintf("%02d",$month);
		$year += 1900;

		open( LOG, ">>$LOGDIR/$LOGNAME" ) || error_proc("Unable to open the logging file!");

		# Print out the final strings
		if ( $errcode == 1 ) {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| DirChecker \) ERROR \- $string\n";
			close(LOG);
			error_proc("$string");
		} else {
			print LOG "\( $hour\:$min\.$sec $ampm \| $month/$day/$year \| DirChecker \) INFORMATION \- $string\n";
			close(LOG);
			return 0;
		}
	} else {
		if ( $errcode == 1 ) {
			error_proc("$string");
		} else {
			return 0;
		}
	}
}

# The Checking routine
sub check_settings {
	# Make sure all of our variables are defined
	if ( ! defined $DUPELOGDIR ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 1\]") }
	if ( ! defined $DUPELOGFILE ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 2\]") }
	if ( ! defined $USELOG ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 3\]") }
	if ( ! defined $LOGDIR ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 4\]") }
	if ( ! defined $LOGNAME ) 	{ error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 5\]") }

	# Sanity check of $DUPELOGDIR variable
	if ( $DUPELOGDIR =~ /\/$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 6\]");
	}

	# Check to see if the DUPELOGDIR exists
	if ( ! -d $DUPELOGDIR ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 7\]");
	}

	# Check to see if we can read from dupelog
	if ( ! -r "$DUPELOGDIR/$DUPELOGFILE" ) {
		log_proc("1","Unable to read the dupelog!");
	}

	# Sanity check of USELOG
	if ( $USELOG !~ /^[\d]+$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 8\]");
	}
	if ( ! ( $USELOG eq "0" or $USELOG eq "1" ) ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 9\]");
	}

	# Sanity check of $LOGDIR variable
	if ( $USELOG and $LOGDIR =~ /\/$/ ) {
		error_proc("Error in configuration - tell SiTEOPs to fix this! \[code 10\]");
	}

	# Logging features checking...
	if ( $USELOG and ! -w "$LOGDIR/$LOGNAME" and ! -e "$LOGDIR/$LOGNAME" ) {
		open(LOG, ">$LOGDIR/$LOGNAME") || error_proc("Unable to create the logging file! \[code 11\]");
		close LOG;

		if ( ! chmod 0666, "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 12\]");
		}

		if ( ! chown "0", "0", "$LOGDIR/$LOGNAME" ) {
			error_proc("Unable to create the logging file! \[code 13\]");
		}

		log_proc("2","The log $LOGDIR/$LOGNAME doesn\'t exist, creating it");
	}
}